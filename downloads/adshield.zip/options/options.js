/**
 * AdShield Pro - Options Dashboard Controller Logic
 */

import { sanitizeDomain } from '../background/dnr-manager.js';

document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const tabHeading = document.getElementById('tabHeading');
  const tabSubHeading = document.getElementById('tabSubHeading');
  const btnUpdateNow = document.getElementById('btnUpdateNow');
  const btnUpdateNowText = document.getElementById('btnUpdateNowText');
  const toastNotification = document.getElementById('toastNotification');
  const toastMessage = document.getElementById('toastMessage');

  // Stats
  const statTotalBlocked = document.getElementById('statTotalBlocked');
  const statActiveRules = document.getElementById('statActiveRules');
  const statWhitelistedCount = document.getElementById('statWhitelistedCount');
  const statSubscriptionsCount = document.getElementById('statSubscriptionsCount');
  const statDnrQuotaSub = document.getElementById('statDnrQuotaSub');
  const topBlockedBody = document.getElementById('topBlockedBody');

  // Whitelist
  const formAddWhitelist = document.getElementById('formAddWhitelist');
  const inputWhitelistDomain = document.getElementById('inputWhitelistDomain');
  const whitelistBody = document.getElementById('whitelistBody');
  const btnClearWhitelist = document.getElementById('btnClearWhitelist');

  // Blacklist
  const formAddBlacklist = document.getElementById('formAddBlacklist');
  const inputBlacklistPattern = document.getElementById('inputBlacklistPattern');
  const selectBlacklistType = document.getElementById('selectBlacklistType');
  const blacklistBody = document.getElementById('blacklistBody');

  // Subscriptions
  const subscriptionsBody = document.getElementById('subscriptionsBody');
  const formAddSubscription = document.getElementById('formAddSubscription');
  const inputSubName = document.getElementById('inputSubName');
  const inputSubUrl = document.getElementById('inputSubUrl');

  // Settings
  const chkCosmetic = document.getElementById('chkCosmetic');
  const chkScriptlets = document.getElementById('chkScriptlets');
  const chkAntiAdblock = document.getElementById('chkAntiAdblock');
  const storageViewer = document.getElementById('storageViewer');
  const btnExportConfig = document.getElementById('btnExportConfig');
  const btnResetDefaults = document.getElementById('btnResetDefaults');

  const tabTitles = {
    'tab-overview': { title: 'Overview & Statistics', sub: 'Real-time metrics and dynamic filtering status' },
    'tab-whitelist': { title: 'Whitelist Management', sub: 'Exempt trusted domains from content filtering' },
    'tab-blacklist': { title: 'Custom Blacklist Rules', sub: 'Explicit network blocking rules for domains or URL patterns' },
    'tab-subscriptions': { title: 'Filter List Subscriptions', sub: 'Managed remote EasyList and hosts rulesets' },
    'tab-settings': { title: 'Engine Settings & Diagnostics', sub: 'Filtering feature switches and persistent storage state' }
  };

  let currentState = null;

  // 1. Tab Navigation
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');

      // Update active nav button
      document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');

      // Update headings
      if (tabTitles[targetTab]) {
        tabHeading.textContent = tabTitles[targetTab].title;
        tabSubHeading.textContent = tabTitles[targetTab].sub;
      }

      // Show target tab pane
      document.querySelectorAll('.tab-pane').forEach(p => {
        if (p.id === targetTab) {
          p.classList.remove('is-hidden');
          p.classList.add('is-visible');
        } else {
          p.classList.remove('is-visible');
          p.classList.add('is-hidden');
        }
      });
    });
  });

  // 2. Toast Notification Helper
  let toastTimer = null;
  function showToast(msg, duration = 3000) {
    if (toastTimer) clearTimeout(toastTimer);
    toastMessage.textContent = msg;
    toastNotification.classList.remove('is-hidden');
    toastTimer = setTimeout(() => {
      toastNotification.classList.add('is-hidden');
    }, duration);
  }

  // 3. Load & Render State
  async function loadState() {
    try {
      if (chrome.runtime && chrome.runtime.sendMessage) {
        const res = await chrome.runtime.sendMessage({ action: 'GET_OPTIONS_STATE' });
        if (res && res.success && res.data) {
          currentState = res.data;
          renderState(currentState);
          return;
        }
      }
    } catch (_) {}

    // Fallback: direct storage read
    if (chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(null, (items) => {
        currentState = {
          settings: items.settings || {},
          userWhitelist: items.userWhitelist || [],
          userBlacklist: items.userBlacklist || [],
          filterLists: items.filterLists || [],
          blockStats: items.blockStats || { totalBlocked: 0, domainStats: {} },
          cosmeticSelectors: items.cosmeticSelectors || [],
          dnrQuota: { activeDynamicRules: (items.userBlacklist || []).length, maxSafeDynamicRules: 30000 }
        };
        renderState(currentState);
      });
    }
  }

  function renderState(state) {
    if (!state) return;

    // --- Overview Tab ---
    const totalBlocked = (state.blockStats && state.blockStats.totalBlocked) || 0;
    const activeRules = (state.dnrQuota && state.dnrQuota.activeDynamicRules) || 0;
    const whitelist = state.userWhitelist || [];
    const subscriptions = state.filterLists || [];

    statTotalBlocked.textContent = totalBlocked.toLocaleString();
    statActiveRules.textContent = (activeRules + 60).toLocaleString(); // includes 60 seed rules
    statDnrQuotaSub.textContent = `DNR quota: ${(activeRules + 60).toLocaleString()} / 30,000`;
    statWhitelistedCount.textContent = whitelist.length.toLocaleString();
    statSubscriptionsCount.textContent = subscriptions.length.toLocaleString();

    // Top blocked domains table
    topBlockedBody.innerHTML = '';
    const domainStats = (state.blockStats && state.blockStats.domainStats) || {};
    const sortedDomains = Object.entries(domainStats).sort((a, b) => b[1] - a[1]).slice(0, 8);

    if (sortedDomains.length === 0) {
      topBlockedBody.innerHTML = '<tr><td colspan="3" style="text-align:center; color:var(--text-secondary); padding:20px;">No blocked domain hits recorded yet.</td></tr>';
    } else {
      const maxHit = sortedDomains[0][1] || 1;
      for (const [dom, hits] of sortedDomains) {
        const tr = document.createElement('tr');
        const pct = Math.round((hits / maxHit) * 100);
        tr.innerHTML = `
          <td><strong>${escapeHtml(dom)}</strong></td>
          <td>${hits.toLocaleString()}</td>
          <td>
            <div style="background:var(--bg-elevated); height:6px; border-radius:3px; width:100%; max-width:140px; overflow:hidden;">
              <div style="background:var(--accent-emerald); height:100%; width:${pct}%;"></div>
            </div>
          </td>
        `;
        topBlockedBody.appendChild(tr);
      }
    }

    // --- Whitelist Tab ---
    whitelistBody.innerHTML = '';
    if (whitelist.length === 0) {
      whitelistBody.innerHTML = '<tr><td colspan="3" style="text-align:center; color:var(--text-secondary); padding:20px;">No domains currently whitelisted.</td></tr>';
    } else {
      whitelist.forEach(domain => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td><strong>${escapeHtml(domain)}</strong></td>
          <td><span class="tag-badge is-warn">Allow All Requests</span></td>
          <td class="text-right">
            <button class="danger-btn btn-remove-whitelist" data-domain="${escapeHtml(domain)}" type="button">Remove</button>
          </td>
        `;
        whitelistBody.appendChild(tr);
      });
    }

    // --- Blacklist Tab ---
    blacklistBody.innerHTML = '';
    const blacklist = state.userBlacklist || [];
    if (blacklist.length === 0) {
      blacklistBody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-secondary); padding:20px;">No custom blacklist rules defined.</td></tr>';
    } else {
      blacklist.forEach(item => {
        const tr = document.createElement('tr');
        const formattedDate = item.addedAt ? new Date(item.addedAt).toLocaleDateString() : 'N/A';
        tr.innerHTML = `
          <td><code>${escapeHtml(item.pattern)}</code></td>
          <td><span class="tag-badge is-error">${escapeHtml(item.type)}</span></td>
          <td>${item.ruleId || 'Dynamic'}</td>
          <td>${formattedDate}</td>
          <td class="text-right">
            <button class="danger-btn btn-remove-blacklist" data-id="${escapeHtml(item.id)}" type="button">Delete</button>
          </td>
        `;
        blacklistBody.appendChild(tr);
      });
    }

    // --- Subscriptions Tab ---
    subscriptionsBody.innerHTML = '';
    if (subscriptions.length === 0) {
      subscriptionsBody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-secondary); padding:20px;">No filter subscriptions configured.</td></tr>';
    } else {
      subscriptions.forEach(sub => {
        const tr = document.createElement('tr');
        const lastUpdatedText = sub.lastUpdated ? new Date(sub.lastUpdated).toLocaleString() : 'Never';
        const statusBadgeClass = sub.status === 'success' ? 'is-success' : (sub.status === 'error' ? 'is-error' : 'is-warn');
        tr.innerHTML = `
          <td><strong>${escapeHtml(sub.name)}</strong></td>
          <td><small style="color:var(--text-secondary);">${escapeHtml(sub.url)}</small></td>
          <td>${(sub.ruleCount || 0).toLocaleString()}</td>
          <td>${lastUpdatedText}</td>
          <td><span class="tag-badge ${statusBadgeClass}">${escapeHtml(sub.status || 'idle')}</span></td>
          <td class="text-right">
            <button class="subtle-btn btn-toggle-sub" data-id="${escapeHtml(sub.id)}" type="button">${sub.enabled ? 'Disable' : 'Enable'}</button>
          </td>
        `;
        subscriptionsBody.appendChild(tr);
      });
    }

    // --- Settings Tab ---
    const settings = state.settings || {};
    chkCosmetic.checked = settings.cosmeticFilteringEnabled !== false;
    chkScriptlets.checked = settings.scriptletsEnabled !== false;
    chkAntiAdblock.checked = settings.antiAdblockDisarmEnabled !== false;

    // Raw Storage Inspector
    storageViewer.textContent = JSON.stringify(state, null, 2);
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // 4. Whitelist Actions
  formAddWhitelist.addEventListener('submit', async (e) => {
    e.preventDefault();
    const rawVal = inputWhitelistDomain.value.trim();
    if (!rawVal) return;

    const domain = rawVal.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/[:/].*$/, '');
    if (!domain) return;

    try {
      await chrome.runtime.sendMessage({
        action: 'ADD_WHITELIST_DOMAIN',
        domain
      });
      inputWhitelistDomain.value = '';
      showToast(`Added ${domain} to whitelist`);
      await loadState();
    } catch (err) {
      showToast(`Error adding domain: ${err.message}`);
    }
  });

  whitelistBody.addEventListener('click', async (e) => {
    const btn = e.target.closest('.btn-remove-whitelist');
    if (!btn) return;
    const domain = btn.getAttribute('data-domain');
    if (!domain) return;

    try {
      await chrome.runtime.sendMessage({
        action: 'REMOVE_WHITELIST_DOMAIN',
        domain
      });
      showToast(`Removed ${domain} from whitelist`);
      await loadState();
    } catch (err) {
      showToast(`Error removing domain: ${err.message}`);
    }
  });

  btnClearWhitelist.addEventListener('click', async () => {
    if (!confirm('Clear all whitelisted domains?')) return;
    try {
      await chrome.storage.local.set({ userWhitelist: [] });
      await chrome.runtime.sendMessage({ action: 'TOGGLE_WHITELIST_DOMAIN', domain: '__dummy__', whitelisted: false });
      showToast('All whitelist rules cleared');
      await loadState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  // 5. Blacklist Actions
  formAddBlacklist.addEventListener('submit', async (e) => {
    e.preventDefault();
    const pattern = inputBlacklistPattern.value.trim();
    const type = selectBlacklistType.value;
    if (!pattern) return;

    try {
      await chrome.runtime.sendMessage({
        action: 'ADD_BLACKLIST_RULE',
        pattern,
        type
      });
      inputBlacklistPattern.value = '';
      showToast(`Added rule for: ${pattern}`);
      await loadState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  blacklistBody.addEventListener('click', async (e) => {
    const btn = e.target.closest('.btn-remove-blacklist');
    if (!btn) return;
    const id = btn.getAttribute('data-id');
    if (!id) return;

    try {
      await chrome.runtime.sendMessage({
        action: 'REMOVE_BLACKLIST_RULE',
        id
      });
      showToast('Removed blacklist rule');
      await loadState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  // 6. Subscriptions Actions
  formAddSubscription.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = inputSubName.value.trim();
    const url = inputSubUrl.value.trim();
    if (!name || !url) return;

    try {
      const data = await chrome.storage.local.get(['filterLists']);
      const filterLists = data.filterLists || [];
      filterLists.push({
        id: `sub_${Date.now()}`,
        name,
        url,
        enabled: true,
        lastUpdated: 0,
        ruleCount: 0,
        status: 'idle'
      });
      await chrome.storage.local.set({ filterLists });
      inputSubName.value = '';
      inputSubUrl.value = '';
      showToast(`Subscribed to ${name}`);
      await loadState();
    } catch (err) {
      showToast(`Error adding subscription: ${err.message}`);
    }
  });

  subscriptionsBody.addEventListener('click', async (e) => {
    const btn = e.target.closest('.btn-toggle-sub');
    if (!btn) return;
    const id = btn.getAttribute('data-id');

    try {
      const data = await chrome.storage.local.get(['filterLists']);
      const filterLists = (data.filterLists || []).map(sub => {
        if (sub.id === id) {
          return { ...sub, enabled: !sub.enabled };
        }
        return sub;
      });
      await chrome.storage.local.set({ filterLists });
      showToast('Subscription updated');
      await loadState();
    } catch (err) {
      showToast(`Error: ${err.message}`);
    }
  });

  // 7. Manual Filter Update Trigger
  btnUpdateNow.addEventListener('click', async () => {
    btnUpdateNow.disabled = true;
    btnUpdateNowText.textContent = 'Updating rules...';

    try {
      const res = await chrome.runtime.sendMessage({ action: 'UPDATE_FILTER_LISTS_NOW' });
      const count = (res && res.totalRulesLoaded) || 0;
      showToast(`Update finished: ${count} rules synchronized!`);
      await loadState();
    } catch (err) {
      showToast(`Update failed: ${err.message}`);
    } finally {
      btnUpdateNow.disabled = false;
      btnUpdateNowText.textContent = 'Check for Updates Now';
    }
  });

  // 8. Settings Checkboxes
  async function saveSettings() {
    const patch = {
      cosmeticFilteringEnabled: chkCosmetic.checked,
      scriptletsEnabled: chkScriptlets.checked,
      antiAdblockDisarmEnabled: chkAntiAdblock.checked
    };
    try {
      await chrome.runtime.sendMessage({
        action: 'UPDATE_SETTINGS',
        patch
      });
      showToast('Settings saved');
      await loadState();
    } catch (err) {
      showToast(`Error saving settings: ${err.message}`);
    }
  }

  chkCosmetic.addEventListener('change', saveSettings);
  chkScriptlets.addEventListener('change', saveSettings);
  chkAntiAdblock.addEventListener('change', saveSettings);

  // 9. Export & Reset
  btnExportConfig.addEventListener('click', () => {
    const jsonStr = JSON.stringify(currentState, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `adshield-pro-config-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Configuration exported');
  });

  btnResetDefaults.addEventListener('click', async () => {
    if (!confirm('Are you sure you want to reset all AdShield settings and custom rules to factory defaults?')) {
      return;
    }
    try {
      await chrome.runtime.sendMessage({ action: 'TEST_RESET_STATE' });
      showToast('Reset to factory defaults completed');
      await loadState();
    } catch (err) {
      showToast(`Error resetting state: ${err.message}`);
    }
  });

  // Initial load
  await loadState();
});
