/**
 * AdShield Pro - Background Service Worker
 * Top-level synchronous event listeners, lifecycle management, and message routing.
 */

import { initDefaultStorage, getStorageState, setStorageState, recordBlockedHit, resetStorageState } from './storage.js';
import {
  syncWhitelistRules,
  syncBlacklistRules,
  getActiveDynamicRulesCount,
  clearAllDynamicRules,
  sanitizeDomain,
  allocateBlacklistRuleId
} from './dnr-manager.js';
import { syncDynamicContentScripts } from './scripting-manager.js';
import { updateAllFilterSubscriptions } from './updater.js';

const ALARM_NAME = 'adshield-remote-updater';
const tabBlockedCounts = new Map(); // tabId -> count blocked in current page load

// 1. Top-Level Synchronous Installation & Startup Listeners
chrome.runtime.onInstalled.addListener(async (details) => {
  try {
    console.log('[AdShield SW] Extension installed / updated:', details.reason);
    const state = await initDefaultStorage();

    await syncDynamicContentScripts(state);
    await syncWhitelistRules(state.userWhitelist || []);
    await syncBlacklistRules(state.userBlacklist || []);

    // Configure periodic update alarm
    const existingAlarm = await chrome.alarms.get(ALARM_NAME);
    if (!existingAlarm) {
      chrome.alarms.create(ALARM_NAME, {
        delayInMinutes: 5,
        periodInMinutes: 1440 // 24 hours
      });
    }
  } catch (_) {}
});

if (chrome.runtime && chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(async () => {
    const state = await getStorageState(['userWhitelist', 'settings']);
    await syncDynamicContentScripts(state);
  });
}

// Keep dynamic scripting & whitelist DNR rules synchronized on direct storage edits
if (chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.userWhitelist) {
      syncWhitelistRules(changes.userWhitelist.newValue || []).catch(() => {});
    }
    if (changes.userWhitelist || changes.settings) {
      syncDynamicContentScripts().catch(() => {});
    }
  });
}

// 2. Top-Level Synchronous Alarm Listener
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_NAME) {
    console.log('[AdShield SW] Scheduled alarm fired. Running filter update...');
    try {
      await updateAllFilterSubscriptions();
    } catch (err) {
      console.warn('[AdShield SW] Filter update error:', err);
    }
  }
});

// 3. Tab Cleanup on Navigation
if (chrome.tabs && chrome.tabs.onUpdated) {
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === 'loading') {
      tabBlockedCounts.set(tabId, 0);
    }
  });
}

// 4. Debug Rule Matching (if enabled in unpacked Chrome)
if (chrome.declarativeNetRequest && chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    try {
      const tabId = info.request && info.request.tabId;
      if (tabId && tabId > 0) {
        const prev = tabBlockedCounts.get(tabId) || 0;
        tabBlockedCounts.set(tabId, prev + 1);
      }
      const domain = info.request && info.request.url ? new URL(info.request.url).hostname : '';
      if (domain) recordBlockedHit(domain, 1).catch(() => {});
    } catch (_) {}
  });
}

// 5. Top-Level Synchronous Runtime Message Router
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.action) {
    sendResponse({ success: false, error: 'Invalid message structure' });
    return false;
  }

  // Dispatch to async handlers with guaranteed true return
  handleMessage(message, sender)
    .then(result => sendResponse(result))
    .catch(err => sendResponse({ success: false, error: err.message || String(err) }));

  return true; // Keep message channel open for async response
});

/**
 * Message Handler Router
 */
async function handleMessage(message, sender) {
  const { action, domain, pattern, type, id, patch, whitelisted } = message;

  switch (action) {
    case 'GET_STATUS':
    case 'GET_POPUP_STATE': {
      const state = await getStorageState(['userWhitelist', 'blockStats']);
      const cleanDomain = sanitizeDomain(domain);
      const whitelist = state.userWhitelist || [];
      const isWhitelisted = whitelist.includes(cleanDomain);

      const tabId = (message.tabId || (sender && sender.tab && sender.tab.id));
      const tabBlockedCount = (tabId ? (tabBlockedCounts.get(tabId) || 0) : 0);
      const totalBlockedCount = (state.blockStats && state.blockStats.totalBlocked) || 0;
      const activeRulesCount = await getActiveDynamicRulesCount();

      return {
        success: true,
        data: {
          domain: cleanDomain,
          isWhitelisted,
          tabBlockedCount,
          totalBlockedCount,
          activeRulesCount: activeRulesCount + 60 // includes seed rules
        }
      };
    }

    case 'TOGGLE_WHITELIST_DOMAIN': {
      const state = await getStorageState(['userWhitelist']);
      const cleanDomain = sanitizeDomain(domain);
      if (!cleanDomain) {
        throw new Error('Missing or invalid domain');
      }

      let whitelist = state.userWhitelist || [];
      let nextWhitelisted;

      if (typeof whitelisted === 'boolean') {
        nextWhitelisted = whitelisted;
      } else {
        nextWhitelisted = !whitelist.includes(cleanDomain);
      }

      if (nextWhitelisted) {
        if (!whitelist.includes(cleanDomain)) {
          whitelist = [...whitelist, cleanDomain];
        }
      } else {
        whitelist = whitelist.filter(d => d !== cleanDomain);
      }

      await setStorageState({ userWhitelist: whitelist });
      await syncWhitelistRules(whitelist);
      await syncDynamicContentScripts();

      return {
        success: true,
        data: {
          domain: cleanDomain,
          isWhitelisted: nextWhitelisted
        }
      };
    }

    case 'ADD_WHITELIST_DOMAIN': {
      const state = await getStorageState(['userWhitelist']);
      const cleanDomain = sanitizeDomain(domain);
      if (!cleanDomain) throw new Error('Invalid domain');

      let whitelist = state.userWhitelist || [];
      if (!whitelist.includes(cleanDomain)) {
        whitelist = [...whitelist, cleanDomain];
        await setStorageState({ userWhitelist: whitelist });
        await syncWhitelistRules(whitelist);
        await syncDynamicContentScripts();
      }

      return { success: true, domain: cleanDomain };
    }

    case 'REMOVE_WHITELIST_DOMAIN': {
      const state = await getStorageState(['userWhitelist']);
      const cleanDomain = sanitizeDomain(domain);
      if (!cleanDomain) throw new Error('Invalid domain');
      let whitelist = state.userWhitelist || [];
      whitelist = whitelist.filter(d => d !== cleanDomain);
      await setStorageState({ userWhitelist: whitelist });
      await syncWhitelistRules(whitelist);
      await syncDynamicContentScripts();

      return { success: true, domain: cleanDomain };
    }

    case 'CLEAR_WHITELIST': {
      await setStorageState({ userWhitelist: [] });
      await syncWhitelistRules([]);
      await syncDynamicContentScripts();
      return { success: true };
    }

    case 'ADD_BLACKLIST_RULE': {
      const state = await getStorageState(['userBlacklist']);
      const rawPattern = (pattern || domain || '').trim();
      if (!rawPattern) throw new Error('Missing pattern');

      const ruleType = type === 'contains' ? 'contains' : 'domain';
      let normalizedPattern = rawPattern;
      if (ruleType === 'domain') {
        const cleanDomain = sanitizeDomain(rawPattern);
        if (!cleanDomain) throw new Error('Invalid domain');
        normalizedPattern = cleanDomain;
      }

      const userBlacklist = state.userBlacklist || [];
      const ruleId = allocateBlacklistRuleId(userBlacklist);
      if (ruleId === null) throw new Error('Blacklist rule limit reached');

      const newRule = {
        id: `bl_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
        pattern: normalizedPattern,
        type: ruleType,
        ruleId,
        addedAt: Date.now(),
        enabled: true
      };

      userBlacklist.push(newRule);
      await setStorageState({ userBlacklist });
      await syncBlacklistRules(userBlacklist);

      return { success: true, rule: newRule };
    }

    case 'REMOVE_BLACKLIST_RULE': {
      const state = await getStorageState(['userBlacklist']);
      let userBlacklist = state.userBlacklist || [];
      userBlacklist = userBlacklist.filter(r => r.id !== id);

      await setStorageState({ userBlacklist });
      await syncBlacklistRules(userBlacklist);

      return { success: true, id };
    }

    case 'GET_OPTIONS_STATE': {
      const state = await getStorageState(null);
      const activeRules = await getActiveDynamicRulesCount();

      return {
        success: true,
        data: {
          settings: state.settings,
          userWhitelist: state.userWhitelist || [],
          userBlacklist: state.userBlacklist || [],
          filterLists: state.filterLists || [],
          blockStats: state.blockStats || { totalBlocked: 0, domainStats: {} },
          cosmeticSelectors: state.cosmeticSelectors || [],
          domainCosmeticSelectors: state.domainCosmeticSelectors || {},
          dnrQuota: {
            activeDynamicRules: activeRules,
            maxSafeDynamicRules: 30000
          }
        }
      };
    }

    case 'UPDATE_FILTER_LISTS_NOW': {
      console.log('[AdShield SW] Manual filter update triggered by user.');
      const result = await updateAllFilterSubscriptions();
      return result;
    }

    case 'UPDATE_SETTINGS': {
      const state = await getStorageState(['settings']);
      const current = state.settings || {};
      const updated = { ...current, ...patch };
      await setStorageState({ settings: updated });
      await syncDynamicContentScripts();
      return { success: true, settings: updated };
    }

    case 'RECORD_BLOCKED_HIT': {
      const count = message.count || 1;
      const cleanDomain = sanitizeDomain(domain);
      const tabId = (message.tabId || (sender && sender.tab && sender.tab.id));
      if (tabId) {
        const prev = tabBlockedCounts.get(tabId) || 0;
        tabBlockedCounts.set(tabId, prev + count);
      }
      await recordBlockedHit(cleanDomain, count);
      return { success: true };
    }

    case 'TEST_RESET_STATE': {
      console.log('[AdShield SW] Test reset requested.');
      const state = await resetStorageState();
      await clearAllDynamicRules();
      await syncDynamicContentScripts(state);
      tabBlockedCounts.clear();
      return { success: true, message: 'Extension state reset to factory defaults' };
    }

    default:
      return { success: false, error: `Unhandled action: ${action}` };
  }
}
