/**
 * AdShield Pro - Remote Filter List Updater & Parser
 * Converts EasyList and hosts formats to DeclarativeNetRequest dynamic rules and cosmetic selectors.
 */

import { syncRemoteRules } from './dnr-manager.js';
import { getStorageState, setStorageState } from './storage.js';

const DNR_DOMAIN_RE = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]$|^localhost$/;
const UNSUPPORTED_CSS_PSEUDO_RE = /:\s*(?:-abp-[a-z-]+|has-text|contains|xpath|upward|remove|style|matches-css(?:-before|-after)?|matches-attr|matches-path|matches-media|min-text-length|watch-attr|others)\b/i;
const HOSTS_IGNORED_DOMAINS = new Set(['localhost', 'localhost.localdomain', 'local', 'broadcasthost', 'ip6-localhost', 'ip6-loopback']);
const UNSUPPORTED_DNR_OPTIONS = new Set(['badfilter', 'popup', 'document', 'elemhide', 'generichide', 'genericblock']);

function isValidIpv4(ip) {
  const parts = ip.split('.');
  return parts.length === 4 && parts.every(p => /^\d{1,3}$/.test(p) && Number(p) <= 255);
}

export function isValidDnrDomain(domain) {
  if (!domain || typeof domain !== 'string') return false;
  const d = domain.trim().toLowerCase();
  if (!d || d.length > 253) return false;
  if (/^\d+\.\d+\.\d+\.\d+$/.test(d)) return isValidIpv4(d);
  return DNR_DOMAIN_RE.test(d);
}

function isValidUrlFilterPart(cleanFilter) {
  if (!cleanFilter || typeof cleanFilter !== 'string') return false;
  if (!/^[a-zA-Z0-9][\x21-\x7E]*$/.test(cleanFilter)) return false;
  if (cleanFilter.includes('||') || cleanFilter.includes('@@')) return false;
  return true;
}

export function isValidCssSelector(selector) {
  if (!selector || typeof selector !== 'string') return false;
  const s = selector.trim();
  if (!s || s.length > 1000) return false;
  if (/[{}\r\n;]/.test(s)) return false;
  if (s.startsWith('+js(') || s.startsWith('^') || s.startsWith('$')) return false;
  if (UNSUPPORTED_CSS_PSEUDO_RE.test(s)) return false;
  if (/^[,>+~]|[,>+~]$/.test(s)) return false;

  let paren = 0;
  let bracket = 0;
  let quote = null;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quote) {
      if (ch === '\\') { i++; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === '(') paren++;
    else if (ch === ')') { if (--paren < 0) return false; }
    else if (ch === '[') bracket++;
    else if (ch === ']') { if (--bracket < 0) return false; }
    else if (ch === ',' && s.slice(i + 1).trimStart().startsWith(',')) return false;
  }
  if (quote || paren !== 0 || bracket !== 0) return false;
  return true;
}

/**
 * Parses options suffix in EasyList rules (e.g. $script,third-party,domain=~excluded.com|included.com).
 * Returns null if the rule contains unsupported semantic modifiers or fails domain validation.
 */
function parseEasyListOptions(optionsStr) {
  if (!optionsStr) return {};
  const options = optionsStr.split(',');
  const resourceTypes = new Set();
  const excludedResourceTypes = new Set();
  let domainType;
  const initiatorDomains = new Set();
  const excludedInitiatorDomains = new Set();

  const typeMap = {
    script: 'script',
    image: 'image',
    stylesheet: 'stylesheet',
    subdocument: 'sub_frame',
    xmlhttprequest: 'xmlhttprequest',
    font: 'font',
    media: 'media',
    ping: 'ping',
    websocket: 'websocket',
    other: 'other'
  };

  for (const opt of options) {
    const cleanOpt = opt.trim().toLowerCase();
    if (!cleanOpt) continue;

    if (
      UNSUPPORTED_DNR_OPTIONS.has(cleanOpt) ||
      cleanOpt.startsWith('csp=') ||
      cleanOpt.startsWith('redirect=') ||
      cleanOpt.startsWith('rewrite=') ||
      cleanOpt.startsWith('removeparam=')
    ) {
      return null;
    }

    if (typeMap[cleanOpt]) {
      resourceTypes.add(typeMap[cleanOpt]);
    } else if (cleanOpt.startsWith('~') && typeMap[cleanOpt.slice(1)]) {
      excludedResourceTypes.add(typeMap[cleanOpt.slice(1)]);
    } else if (cleanOpt === 'third-party' || cleanOpt === '3p') {
      domainType = 'thirdParty';
    } else if (cleanOpt === '~third-party' || cleanOpt === 'first-party' || cleanOpt === '1p') {
      domainType = 'firstParty';
    } else if (cleanOpt.startsWith('domain=')) {
      const domains = cleanOpt.slice('domain='.length).split('|');
      let sawPositive = false;
      let sawNegated = false;
      for (const rawDom of domains) {
        const d = rawDom.trim();
        if (!d) continue;
        if (d.startsWith('~')) {
          sawNegated = true;
          const host = d.slice(1);
          if (isValidDnrDomain(host)) excludedInitiatorDomains.add(host);
        } else {
          sawPositive = true;
          if (isValidDnrDomain(d)) initiatorDomains.add(d);
        }
      }
      if ((sawPositive && initiatorDomains.size === 0) || (sawNegated && !sawPositive && excludedInitiatorDomains.size === 0)) {
        return null;
      }
    }
  }

  if (resourceTypes.size > 0 && excludedResourceTypes.size > 0) {
    return null;
  }

  const condition = {};
  if (resourceTypes.size > 0) condition.resourceTypes = Array.from(resourceTypes);
  if (excludedResourceTypes.size > 0) condition.excludedResourceTypes = Array.from(excludedResourceTypes);
  if (domainType) condition.domainType = domainType;
  if (initiatorDomains.size > 0) condition.initiatorDomains = Array.from(initiatorDomains);
  if (excludedInitiatorDomains.size > 0) condition.excludedInitiatorDomains = Array.from(excludedInitiatorDomains);
  return condition;
}

/**
 * Compiles raw EasyList or hosts text into DNR dynamic rule objects, global cosmetic selectors,
 * and domain-scoped cosmetic selectors.
 */
export function parseFilterListText(rawText, maxRules = 24000, maxCosmetics = 3000) {
  const lines = rawText.split(/\r?\n/);
  const dnrRules = [];
  const cosmeticSelectors = [];
  const cosmeticSet = new Set();
  const domainCosmeticSelectors = {};
  let domainCosmeticCount = 0;

  for (const rawLine of lines) {
    const line = rawLine.trim();

    // 1. Filter empty lines and comments BEFORE cosmetic detection
    if (!line || line.startsWith('!') || line.startsWith('[')) {
      continue;
    }
    const isCosmeticDirective = /^(?:[a-zA-Z0-9.,~_-]*)(?:#@\?#|#@\$#|#@%#|#@#|#\?#|#\$#|#%#|##)/.test(line);
    if (line.startsWith('#') && !isCosmeticDirective) {
      continue;
    }

    // 2. Detect Cosmetic Element Hiding / Exception / Extended Rules
    const cosmeticMatch = line.match(/^([a-zA-Z0-9.,~_-]*)(#@\?#|#@\$#|#@%#|#@#|#\?#|#\$#|#%#|##)(.+)$/);
    if (cosmeticMatch) {
      const [, domainPart, sep, body] = cosmeticMatch;
      // Only process standard ## element hiding rules; ignore #@#, #?#, #%#, #$#, etc.
      if (sep !== '##') {
        continue;
      }

      const selector = body.trim();
      if (!isValidCssSelector(selector)) {
        continue;
      }

      if (!domainPart) {
        if (cosmeticSelectors.length < maxCosmetics && !cosmeticSet.has(selector)) {
          cosmeticSet.add(selector);
          cosmeticSelectors.push(selector);
        }
      } else {
        const rawDomains = domainPart.split(',').map(d => d.trim().toLowerCase()).filter(Boolean);
        // Skip rules with negated domain exclusions (~example.com##.ad) to avoid widening
        if (rawDomains.some(d => d.startsWith('~'))) {
          continue;
        }
        for (const dom of rawDomains) {
          if (!isValidDnrDomain(dom)) continue;
          if (domainCosmeticCount >= maxCosmetics) break;
          if (!domainCosmeticSelectors[dom]) domainCosmeticSelectors[dom] = [];
          if (!domainCosmeticSelectors[dom].includes(selector)) {
            domainCosmeticSelectors[dom].push(selector);
            domainCosmeticCount++;
          }
        }
      }
      continue;
    }

    if (dnrRules.length >= maxRules) {
      continue;
    }

    // 3. Detect Hosts File Format (0.0.0.0 domain or 127.0.0.1 domain)
    const hostsMatch = line.match(/^(?:0\.0\.0\.0|127\.0\.0\.1)\s+([^\s#]+)/);
    if (hostsMatch) {
      const domain = hostsMatch[1].toLowerCase();
      if (isValidDnrDomain(domain) && !HOSTS_IGNORED_DOMAINS.has(domain)) {
        dnrRules.push({
          action: { type: 'block' },
          priority: 1,
          condition: {
            urlFilter: `||${domain}^`
          }
        });
      }
      continue;
    }

    // 4. Detect EasyList Whitelist Exception Rules (@@||domain^) and Blocking Rules (||domain^)
    if (line.startsWith('@@||') || line.startsWith('||')) {
      const isAllow = line.startsWith('@@||');
      const ruleBody = line.slice(isAllow ? 4 : 2);
      const dollarIdx = ruleBody.indexOf('$');
      const filter = dollarIdx === -1 ? ruleBody : ruleBody.slice(0, dollarIdx);
      const options = dollarIdx === -1 ? '' : ruleBody.slice(dollarIdx + 1);
      const cleanFilter = filter.trim();

      if (!isValidUrlFilterPart(cleanFilter)) continue;

      const parsedOpts = parseEasyListOptions(options);
      if (!parsedOpts) continue;

      dnrRules.push({
        action: { type: isAllow ? 'allow' : 'block' },
        priority: isAllow ? 100 : 1,
        condition: {
          urlFilter: `||${cleanFilter}`,
          ...parsedOpts
        }
      });
      continue;
    }
  }

  return { dnrRules, cosmeticSelectors, domainCosmeticSelectors };
}

/**
 * Fetches and updates a single remote filter list subscription.
 */
export async function updateFilterSubscription(subscription) {
  if (!subscription || !subscription.url || !subscription.enabled) {
    return { ...subscription, status: 'idle' };
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);

    const res = await fetch(subscription.url, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!res.ok) {
      throw new Error(`HTTP ${res.status} ${res.statusText}`);
    }

    const text = await res.text();
    const { dnrRules, cosmeticSelectors, domainCosmeticSelectors } = parseFilterListText(text);

    const next = {
      ...subscription,
      lastUpdated: Date.now(),
      ruleCount: dnrRules.length,
      status: 'success',
      _parsedRules: dnrRules,
      _parsedCosmetics: cosmeticSelectors,
      _parsedDomainCosmetics: domainCosmeticSelectors
    };
    delete next.errorMsg;
    return next;
  } catch (err) {
    return {
      ...subscription,
      status: 'error',
      errorMsg: err.message
    };
  }
}

/**
 * Orchestrates updates across all active filter subscriptions.
 */
export async function updateAllFilterSubscriptions() {
  const state = await getStorageState(['filterLists', 'cosmeticSelectors', 'domainCosmeticSelectors']);
  const filterLists = state.filterLists || [];
  const existingCosmetics = state.cosmeticSelectors || [];
  const existingDomainCosmetics = state.domainCosmeticSelectors || {};

  const updatedLists = [];
  const allDnrRules = [];
  const newCosmeticsSet = new Set();
  const newDomainCosmetics = {};
  let enabledCount = 0;
  let successCount = 0;

  for (const sub of filterLists) {
    if (!sub.enabled) {
      const disabledSub = { ...sub, status: 'idle', ruleCount: 0 };
      delete disabledSub.errorMsg;
      updatedLists.push(disabledSub);
      continue;
    }

    enabledCount++;
    const updated = await updateFilterSubscription(sub);
    if (updated.status === 'success') {
      successCount++;
    }
    if (updated._parsedRules) {
      allDnrRules.push(...updated._parsedRules);
      delete updated._parsedRules;
    }
    if (updated._parsedCosmetics) {
      for (const sel of updated._parsedCosmetics) {
        newCosmeticsSet.add(sel);
      }
      delete updated._parsedCosmetics;
    }
    if (updated._parsedDomainCosmetics) {
      for (const [dom, sels] of Object.entries(updated._parsedDomainCosmetics)) {
        if (!newDomainCosmetics[dom]) newDomainCosmetics[dom] = [];
        for (const sel of sels) {
          if (!newDomainCosmetics[dom].includes(sel)) {
            newDomainCosmetics[dom].push(sel);
          }
        }
      }
      delete updated._parsedDomainCosmetics;
    }
    updatedLists.push(updated);
  }

  let nextCosmetics = existingCosmetics;
  let nextDomainCosmetics = existingDomainCosmetics;

  if (enabledCount === 0) {
    await syncRemoteRules([]);
    nextCosmetics = [];
    nextDomainCosmetics = {};
  } else if (successCount > 0) {
    await syncRemoteRules(allDnrRules);
    nextCosmetics = Array.from(newCosmeticsSet);
    nextDomainCosmetics = newDomainCosmetics;
  }
  // If enabledCount > 0 && successCount === 0: preserve existing DNR rules and cosmetic selectors

  await setStorageState({
    filterLists: updatedLists,
    cosmeticSelectors: nextCosmetics,
    domainCosmeticSelectors: nextDomainCosmetics
  });

  return {
    success: true,
    totalRulesLoaded: allDnrRules.length,
    updatedLists
  };
}
