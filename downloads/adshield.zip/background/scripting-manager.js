/**
 * AdShield Pro - Content Script Registration Cleaner
 * Cleans up any legacy dynamic content script registrations so manifest content_scripts run without duplicate ID conflicts.
 */

const LEGACY_SCRIPT_IDS = [
  'adshield-cosmetic-css',
  'adshield-scriptlets',
  'adshield-anti-adblock'
];

export async function syncDynamicContentScripts() {
  if (typeof chrome === 'undefined' || !chrome.scripting) return;
  try {
    const existing = await chrome.scripting.getRegisteredContentScripts({ ids: LEGACY_SCRIPT_IDS });
    if (existing && existing.length > 0) {
      await chrome.scripting.unregisterContentScripts({
        ids: existing.map((s) => s.id)
      });
    }
  } catch (_) {}
}
