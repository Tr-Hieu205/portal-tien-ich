/**
 * AdShield Pro - DeclarativeNetRequest Dynamic Rules Manager
 * Enforces strict ID space partitioning and atomic updates.
 */

export const ID_RANGES = {
  WHITELIST_MIN: 100,
  WHITELIST_MAX: 999,
  BLACKLIST_MIN: 1000,
  BLACKLIST_MAX: 4999,
  REMOTE_MIN: 5000,
  REMOTE_MAX: 29999
};

/**
 * Sanitizes and validates a domain, IPv4, or IPv6 host input.
 * Returns normalized host (e.g. "example.com", "127.0.0.1", "[::1]", "localhost") or "" if invalid.
 */
export function sanitizeDomain(input) {
  if (!input || typeof input !== 'string') return '';
  let raw = input.trim().toLowerCase();
  if (!raw || /\s/.test(raw)) return '';

  // Reject non-HTTP(S) schemes (allow bare host:port and bare IPv6)
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(raw)) {
    if (!/^https?:\/\//i.test(raw)) return '';
  } else if (/^(?:javascript|data|vbscript|file|chrome|chrome-extension|about|blob|mailto):/i.test(raw)) {
    return '';
  }

  // Wrap bare IPv6 literal (e.g. "::1") so URL parser handles it cleanly
  if (/^[0-9a-f:]+$/i.test(raw) && raw.includes(':')) {
    raw = `[${raw}]`;
  }

  let parsed;
  try {
    parsed = new URL(/^https?:\/\//i.test(raw) ? raw : `http://${raw}`);
  } catch (_) {
    return '';
  }

  let host = parsed.hostname.toLowerCase().replace(/\.$/, '');
  if (!host) return '';

  // IPv6 literal (validated by WHATWG URL parser)
  if (host.startsWith('[') && host.endsWith(']')) {
    return /^\[[0-9a-f:.]+\]$/i.test(host) ? host : '';
  }

  // Strip www. only when another label follows (preserves "www.com")
  if (/^www\.(?=.+\.)/.test(host)) {
    host = host.slice(4);
  }

  if (host.length > 253) return '';
  if (host === 'localhost') return 'localhost';

  // Reject integer/2-part IPv4 shorthand that URL parser expands silently (e.g. "123.456")
  const rawAuth = raw.replace(/^https?:\/\//, '').split(/[/?#]/)[0].split('@').pop().replace(/:\d+$/, '');
  if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(host)) {
    return /^(?:\d{1,3}\.){3}\d{1,3}$/.test(rawAuth) ? host : '';
  }

  const labels = host.split('.');
  if (labels.length < 2) return '';
  const labelRe = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
  if (!labels.every(l => labelRe.test(l))) return '';
  if (/^\d+$/.test(labels[labels.length - 1])) return '';

  return host;
}

/**
 * Allocates a monotonic, non-colliding blacklist rule ID in [1000, 4999].
 * Falls back to lowest unused slot when maxId reaches BLACKLIST_MAX.
 */
export function allocateBlacklistRuleId(existingItems = []) {
  const used = new Set(
    existingItems
      .map(r => r && r.ruleId)
      .filter(id => Number.isInteger(id) && id >= ID_RANGES.BLACKLIST_MIN && id <= ID_RANGES.BLACKLIST_MAX)
  );
  let maxId = ID_RANGES.BLACKLIST_MIN - 1;
  for (const id of used) {
    if (id > maxId) maxId = id;
  }
  if (maxId + 1 <= ID_RANGES.BLACKLIST_MAX) return maxId + 1;
  for (let id = ID_RANGES.BLACKLIST_MIN; id <= ID_RANGES.BLACKLIST_MAX; id++) {
    if (!used.has(id)) return id;
  }
  return null;
}

/**
 * Syncs custom whitelist domains as allowAllRequests / allow dynamic rules.
 * Range: 100 - 999. Priority: 100.
 */
export async function syncWhitelistRules(whitelistDomains = []) {
  if (!chrome.declarativeNetRequest) return;

  const dynamicRules = await chrome.declarativeNetRequest.getDynamicRules();
  const oldIds = dynamicRules
    .filter(r => r.id >= ID_RANGES.WHITELIST_MIN && r.id <= ID_RANGES.WHITELIST_MAX)
    .map(r => r.id);

  const cleanDomains = Array.from(new Set(whitelistDomains.map(sanitizeDomain).filter(Boolean)));
  const maxWhitelist = ID_RANGES.WHITELIST_MAX - ID_RANGES.WHITELIST_MIN + 1;
  const addRules = cleanDomains.slice(0, maxWhitelist).map((domain, idx) => (
    domain.startsWith('[')
      ? {
          id: ID_RANGES.WHITELIST_MIN + idx,
          priority: 100,
          action: { type: 'allow' },
          condition: {
            urlFilter: `||${domain}^`,
            resourceTypes: ['main_frame', 'sub_frame', 'script', 'image', 'stylesheet', 'xmlhttprequest', 'other']
          }
        }
      : {
          id: ID_RANGES.WHITELIST_MIN + idx,
          priority: 100,
          action: { type: 'allowAllRequests' },
          condition: {
            initiatorDomains: [domain],
            resourceTypes: ['main_frame', 'sub_frame']
          }
        }
  ));

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: oldIds,
    addRules
  });

  return addRules;
}

/**
 * Syncs user-defined blacklist patterns as blocking dynamic rules.
 * Range: 1000 - 4999. Priority: 10.
 */
export async function syncBlacklistRules(blacklistItems = []) {
  if (!chrome.declarativeNetRequest) return;

  const dynamicRules = await chrome.declarativeNetRequest.getDynamicRules();
  const oldIds = dynamicRules
    .filter(r => r.id >= ID_RANGES.BLACKLIST_MIN && r.id <= ID_RANGES.BLACKLIST_MAX)
    .map(r => r.id);

  const maxBlacklist = ID_RANGES.BLACKLIST_MAX - ID_RANGES.BLACKLIST_MIN + 1;
  const validItems = [];
  for (const item of blacklistItems) {
    if (!item || item.enabled === false || !item.pattern) continue;
    const rawPattern = String(item.pattern).trim();
    if (!rawPattern) continue;

    let urlFilter = rawPattern;
    if (item.type === 'domain') {
      const clean = sanitizeDomain(rawPattern);
      if (!clean) continue;
      urlFilter = `||${clean}^`;
    } else if (item.type === 'contains' && !rawPattern.includes('*')) {
      urlFilter = `*${rawPattern}*`;
    }

    validItems.push({ item, urlFilter });
    if (validItems.length >= maxBlacklist) break;
  }

  // Reserve valid, non-duplicate item.ruleId values first so storage IDs match DNR IDs 1:1
  const usedIds = new Set();
  const assignedIds = new Array(validItems.length).fill(null);

  for (let i = 0; i < validItems.length; i++) {
    const rid = validItems[i].item.ruleId;
    if (
      Number.isInteger(rid) &&
      rid >= ID_RANGES.BLACKLIST_MIN &&
      rid <= ID_RANGES.BLACKLIST_MAX &&
      !usedIds.has(rid)
    ) {
      usedIds.add(rid);
      assignedIds[i] = rid;
    }
  }

  let nextId = ID_RANGES.BLACKLIST_MIN;
  const addRules = validItems.map(({ urlFilter }, i) => {
    let id = assignedIds[i];
    if (id === null) {
      while (usedIds.has(nextId) && nextId <= ID_RANGES.BLACKLIST_MAX) {
        nextId++;
      }
      id = nextId;
      usedIds.add(id);
    }

    return {
      id,
      priority: 10,
      action: {
        type: 'block'
      },
      condition: {
        urlFilter,
        resourceTypes: ['sub_frame', 'script', 'xmlhttprequest', 'image', 'other']
      }
    };
  });

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: oldIds,
    addRules
  });

  return addRules;
}

/**
 * Syncs compiled remote filter list rules into the remote ID partition.
 * Range: 5000 - 29999. Priority: 1.
 */
export async function syncRemoteRules(remoteRules = []) {
  if (!chrome.declarativeNetRequest) return;

  const dynamicRules = await chrome.declarativeNetRequest.getDynamicRules();
  const oldIds = dynamicRules
    .filter(r => r.id >= ID_RANGES.REMOTE_MIN && r.id <= ID_RANGES.REMOTE_MAX)
    .map(r => r.id);

  const maxAllowed = ID_RANGES.REMOTE_MAX - ID_RANGES.REMOTE_MIN + 1;
  const boundedRules = remoteRules.slice(0, maxAllowed).map((rule, idx) => ({
    ...rule,
    id: ID_RANGES.REMOTE_MIN + idx,
    priority: rule.priority || 1
  }));

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: oldIds,
    addRules: boundedRules
  });

  return boundedRules;
}

/**
 * Returns total count of dynamic rules registered in the DNR engine.
 */
export async function getActiveDynamicRulesCount() {
  if (!chrome.declarativeNetRequest) return 0;
  const dynamicRules = await chrome.declarativeNetRequest.getDynamicRules();
  return dynamicRules.length;
}

/**
 * Clears all dynamic rules across all partitions.
 */
export async function clearAllDynamicRules() {
  if (!chrome.declarativeNetRequest) return;
  const currentRules = await chrome.declarativeNetRequest.getDynamicRules();
  const ids = currentRules.map(r => r.id);
  if (ids.length > 0) {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: ids,
      addRules: []
    });
  }
}
