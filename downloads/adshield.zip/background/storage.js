/**
 * AdShield Pro - Storage Schema and Manager
 * chrome.storage.local wrapper
 */

export const DEFAULT_STORAGE_STATE = {
  schemaVersion: 1,
  enabled: true,
  userWhitelist: [],
  userBlacklist: [],
  filterLists: [
    {
      id: "easylist",
      name: "EasyList Standard",
      url: "https://easylist.to/easylist/easylist.txt",
      enabled: true,
      lastUpdated: 0,
      ruleCount: 0,
      status: "idle"
    },
    {
      id: "easyprivacy",
      name: "EasyPrivacy Tracking Protection",
      url: "https://easylist.to/easylist/easyprivacy.txt",
      enabled: true,
      lastUpdated: 0,
      ruleCount: 0,
      status: "idle"
    }
  ],
  blockStats: {
    totalBlocked: 0,
    domainStats: {},
    lastUpdated: 0
  },
  settings: {
    cosmeticFilteringEnabled: true,
    scriptletsEnabled: true,
    antiAdblockDisarmEnabled: true,
    autoUpdateIntervalHours: 24
  },
  cosmeticSelectors: [],
  domainCosmeticSelectors: {}
};

/**
 * Initializes default storage values if not present.
 */
export async function initDefaultStorage() {
  const current = await chrome.storage.local.get(null);
  const patch = {};

  for (const [key, defaultValue] of Object.entries(DEFAULT_STORAGE_STATE)) {
    if (current[key] === undefined) {
      patch[key] = defaultValue;
    }
  }

  // Remove legacy dead 127.0.0.1:4000 filter list if still stored from older test runs
  if (Array.isArray(current.filterLists)) {
    const cleaned = current.filterLists.filter(
      (item) => item && item.url !== "http://127.0.0.1:4000/rules/in-house.txt"
    );
    if (cleaned.length !== current.filterLists.length) {
      patch.filterLists = cleaned;
    }
  }

  if (Object.keys(patch).length > 0) {
    await chrome.storage.local.set(patch);
  }
  return await chrome.storage.local.get(null);
}

/**
 * Retrieves the full storage state or specific keys.
 */
export async function getStorageState(keys = null) {
  return await chrome.storage.local.get(keys);
}

/**
 * Persists updates to chrome.storage.local.
 */
export async function setStorageState(items) {
  await chrome.storage.local.set(items);
}

/**
 * Increments blocked statistics.
 */
export async function recordBlockedHit(domain, count = 1) {
  const data = await chrome.storage.local.get(['blockStats']);
  const blockStats = data.blockStats || { totalBlocked: 0, domainStats: {}, lastUpdated: Date.now() };

  blockStats.totalBlocked = (blockStats.totalBlocked || 0) + count;
  if (domain) {
    const cleanDomain = domain.toLowerCase();
    blockStats.domainStats = blockStats.domainStats || {};
    blockStats.domainStats[cleanDomain] = (blockStats.domainStats[cleanDomain] || 0) + count;
  }
  blockStats.lastUpdated = Date.now();

  await chrome.storage.local.set({ blockStats });
  return blockStats;
}

/**
 * Factory reset for testing and user preferences.
 */
export async function resetStorageState() {
  await chrome.storage.local.clear();
  await chrome.storage.local.set(DEFAULT_STORAGE_STATE);
  return DEFAULT_STORAGE_STATE;
}
