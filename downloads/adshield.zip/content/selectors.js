/**
 * AdShield Pro - Cosmetic Selectors Catalog
 * Comprehensive selector list for generic banners, ad slots, and video overlays.
 */

export const GENERIC_AD_SELECTORS = [
  '.ad-banner',
  '#ad-banner',
  '.ad_banner',
  '[id*="ad-banner"]',
  '[class*="ad-banner"]',
  '#ad-box',
  '.ad-box',
  '.ad_box',
  '[id*="ad-box"]',
  '[class*="ad-box"]',
  '.ad-container',
  '#ad-container',
  '.ad_container',
  '.ad-wrapper',
  '.ad-slot',
  '.ad-holder',
  '.ad-space',
  '.ad-placement',
  '.ad-unit',
  '.ad-zone',
  '.advertisement',
  '.advert',
  '.adsbox',
  '.ad_placeholder',
  'div[data-ad-slot]',
  'div[data-ad-unit]'
];

export const ADSENSE_SELECTORS = [
  '.adsbygoogle',
  'ins.adsbygoogle',
  '[id^="google_ads_"]',
  '[id^="div-gpt-ad"]',
  '[id*="google_ad_"]',
  'iframe[id^="google_ads_frame"]',
  'iframe[src*="googlesyndication.com"]',
  'iframe[src*="doubleclick.net"]'
];

export const SPONSORED_SELECTORS = [
  '.sponsored-content',
  '.sponsored-post',
  '.sponsored-article',
  '.sponsor-badge',
  '.promoted-item',
  '.promoted-tweet',
  '.promotedlink',
  '[data-promoted="true"]',
  '[data-ad-client]'
];

export const VIDEO_AD_SELECTORS = [
  '.ytp-ad-overlay-container',
  '.ytp-ad-overlay-image',
  '.ytp-ad-text-overlay',
  '.ytp-ad-message-container',
  '.ytp-ad-preview-container',
  '.ytp-ad-skip-button-container',
  '.ytp-ad-player-overlay',
  'ytd-promoted-sparkles-web-renderer',
  'ytd-promoted-video-renderer',
  'ytd-display-ad-renderer',
  'ytd-banner-promo-renderer',
  'ytd-in-feed-ad-layout-renderer',
  'ytd-ad-slot-renderer'
];

export const ALL_COSMETIC_SELECTORS = [
  ...GENERIC_AD_SELECTORS,
  ...ADSENSE_SELECTORS,
  ...SPONSORED_SELECTORS,
  ...VIDEO_AD_SELECTORS
];

export const COMBINED_SELECTOR = ALL_COSMETIC_SELECTORS.join(', ');
