/**
 * AdShield Pro - High-Performance SPA Cosmetic Filter & MutationObserver
 * Runs in ISOLATED world at document_start.
 */

(function () {
  'use strict';

  // Base list of generic selectors to suppress dynamically
  const AD_SELECTORS = [
    '.ad-banner',
    '#ad-banner',
    '#ad-box',
    '.ad-box',
    '.ad-container',
    '#ad-container',
    '.ad-wrapper',
    '.ad-slot',
    '.adsbox',
    '.adsbygoogle',
    'ins.adsbygoogle',
    '.sponsored-content',
    '.sponsored-post',
    '.promoted-item',
    '.promotedlink',
    'div[data-ad-slot]',
    '.ytp-ad-overlay-container',
    '.ytp-featured-product',
    '.ytp-featured-product-container',
    '.ytp-shopping-card',
    '.ytp-paid-content-overlay',
    'ytd-merch-shelf-renderer',
    'yt-mealbar-promo-renderer',
    'ytd-promoted-sparkles-web-renderer',
    'ytd-promoted-video-renderer',
    'ytd-compact-promoted-video-renderer',
    'ytd-display-ad-renderer',
    'ytd-banner-promo-renderer',
    'ytd-statement-banner-renderer',
    'ytd-in-feed-ad-layout-renderer',
    'ytd-ad-slot-renderer',
    '#masthead-ad',
    '#player-ads'
  ];

  // Full list of 71 selectors from content/cosmetic.css for live-toggle restoration
  const FULL_COSMETIC_CSS_SELECTORS = [
    '.ad-banner',
    '#ad-banner',
    '.ad_banner',
    '[id*="ad-banner"]',
    '[class*="ad-banner"]',
    '#ad-box',
    '.ad-box',
    '.ad_box',
    '[id*="ad-box"]',
    '[class*="ad-box"]',
    '.ad-container',
    '#ad-container',
    '.ad_container',
    '.ad-wrapper',
    '.ad-slot',
    '.ad-holder',
    '.ad-space',
    '.ad-placement',
    '.ad-unit',
    '.ad-zone',
    '.advertisement',
    '.advert',
    '.adsbox',
    '.ad_placeholder',
    'div[data-ad-slot]',
    'div[data-ad-unit]',
    '.adsbygoogle',
    'ins.adsbygoogle',
    '[id^="google_ads_"]',
    '[id^="div-gpt-ad"]',
    '[id*="google_ad_"]',
    'iframe[id^="google_ads_frame"]',
    'iframe[src*="googlesyndication.com"]',
    'iframe[src*="doubleclick.net"]',
    '.sponsored-content',
    '.sponsored-post',
    '.sponsored-article',
    '.sponsor-badge:not(yt-live-chat-renderer *):not(ytd-app *)',
    '.promoted-item',
    '.promoted-tweet',
    '.promotedlink',
    '[data-promoted="true"]',
    '[data-ad-client]',
    '.ytp-ad-overlay-container',
    '.ytp-ad-overlay-image',
    '.ytp-ad-text-overlay',
    '.ytp-ad-message-container',
    '.ytp-ad-preview-container',
    '.ytp-ad-skip-button-container',
    '.ytp-ad-player-overlay',
    'ytd-promoted-sparkles-web-renderer',
    'ytd-promoted-video-renderer',
    'ytd-display-ad-renderer',
    'ytd-banner-promo-renderer',
    'ytd-in-feed-ad-layout-renderer',
    'ytd-ad-slot-renderer',
    'ytd-player-legacy-desktop-watch-ads-renderer',
    'ytd-action-companion-ad-renderer',
    '.floating-ad',
    '.sticky-ad',
    '.bottom-ad-bar',
    '.top-banner-ad',
    '.popup-ad-container',
    '.interstitial-ad',
    '.slide-in-ad'
  ];

  const CORE_SELECTOR = AD_SELECTORS.join(', ');
  const HIDING_DECL = 'display: none !important; visibility: hidden !important; height: 0 !important; pointer-events: none !important;';
  const OVERRIDE_DECL = [
    'display: revert !important;',
    'visibility: visible !important;',
    'opacity: 1 !important;',
    'pointer-events: auto !important;',
    'height: auto !important;',
    'max-height: none !important;',
    'min-height: 0 !important;',
    'width: auto !important;',
    'max-width: none !important;',
    'min-width: 0 !important;',
    'margin: revert !important;',
    'padding: revert !important;',
    'border: revert !important;',
    'outline: revert !important;',
    'box-shadow: revert !important;',
    'overflow: visible !important;',
    'position: static !important;',
    'top: auto !important;',
    'left: auto !important;',
    'z-index: auto !important;',
    'clip: auto !important;'
  ].join(' ');

  let validCustomSelectors = [];
  let customSelector = '';
  let processedElements = new WeakSet();
  const pendingNodes = new Set();
  let isBatchScheduled = false;
  let observer = null;
  let isWhitelisted = false;
  let engineStarted = false;
  let domReadyHooked = false;

  let currentWhitelist = [];
  let currentSettings = {};
  let currentGlobalCosmetics = [];
  let currentDomainCosmetics = {};

  const currentHostname = (window.location && window.location.hostname)
    ? window.location.hostname.toLowerCase().replace(/^www\.(?=.+\.)/, '')
    : '';

  function isDomainWhitelisted(hostname, whitelist) {
    if (!hostname || !Array.isArray(whitelist)) return false;
    return whitelist.some(raw => {
      const w = typeof raw === 'string' ? raw.trim().toLowerCase().replace(/^www\.(?=.+\.)/, '') : '';
      if (!w) return false;
      return hostname === w || hostname.endsWith('.' + w);
    });
  }

  function isValidBrowserSelector(sel) {
    if (!sel || typeof sel !== 'string') return false;
    const trimmed = sel.trim();
    if (!trimmed || trimmed.includes('{') || trimmed.includes('}') || trimmed.includes(';')) return false;
    try {
      if (typeof CSS !== 'undefined' && typeof CSS.supports === 'function') {
        if (!CSS.supports(`selector(${trimmed})`)) return false;
      }
      if (typeof document.createDocumentFragment === 'function') {
        const frag = document.createDocumentFragment();
        if (frag && typeof frag.querySelector === 'function') {
          frag.querySelector(trimmed);
        }
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  function getDomainScopedSelectors(hostname, domainMap) {
    if (!hostname || !domainMap || typeof domainMap !== 'object') return [];
    const out = [];
    if (/^\d+\.\d+\.\d+\.\d+$/.test(hostname) || hostname.startsWith('[') || !hostname.includes('.')) {
      if (Array.isArray(domainMap[hostname])) out.push(...domainMap[hostname]);
      return out;
    }
    const parts = hostname.split('.');
    for (let i = 0; i < parts.length - 1; i++) {
      const candidate = parts.slice(i).join('.');
      if (Array.isArray(domainMap[candidate])) out.push(...domainMap[candidate]);
    }
    return out;
  }

  function setDynamicSelectors(rawList) {
    const coreSet = new Set(AD_SELECTORS);
    const deduped = new Set();
    for (const sel of rawList) {
      const trimmed = typeof sel === 'string' ? sel.trim() : '';
      if (!trimmed || coreSet.has(trimmed) || deduped.has(trimmed)) continue;
      if (isValidBrowserSelector(trimmed)) {
        deduped.add(trimmed);
      }
    }
    validCustomSelectors = Array.from(deduped);
    customSelector = validCustomSelectors.join(', ');
  }

  /**
   * Collapses an identified ad element and tags it with data-adshield-hidden
   */
  function collapseElement(el) {
    if (!el || isWhitelisted || processedElements.has(el)) return;

    // Safety guard: Never collapse native player, video media stream, controls, or live chat!
    if (
      el.tagName === 'VIDEO' ||
      el.id === 'movie_player' ||
      (el.classList && (
        el.classList.contains('html5-video-player') ||
        el.classList.contains('ytp-chrome-bottom') ||
        el.classList.contains('ytp-chrome-controls')
      ))
    ) {
      return;
    }
    if (el.closest && el.closest('yt-live-chat-renderer, ytd-live-chat-frame, #chatframe, ytd-live-chat-item-list-renderer')) {
      return;
    }

    processedElements.add(el);

    el.style.setProperty('display', 'none', 'important');
    el.style.setProperty('visibility', 'hidden', 'important');
    el.style.setProperty('height', '0px', 'important');
    el.style.setProperty('min-height', '0px', 'important');
    el.style.setProperty('pointer-events', 'none', 'important');
    el.setAttribute('data-adshield-hidden', 'true');

    // Notify background of cosmetic block event (fire & forget with lastError suppression)
    try {
      if (chrome.runtime && chrome.runtime.id) {
        chrome.runtime.sendMessage({
          action: 'RECORD_BLOCKED_HIT',
          domain: currentHostname,
          count: 1
        }, () => {
          void chrome.runtime.lastError;
        });
      }
    } catch (_) {}
  }

  /**
   * Matches root and descendants safely; falls back to per-selector isolation if a selector throws
   */
  function queryAndCollapse(root, selectorStr, fallbackArray) {
    if (!selectorStr || isWhitelisted || !root) return;
    try {
      if (root !== document && root.matches && root.matches(selectorStr)) {
        collapseElement(root);
        return;
      }
      if (root.querySelectorAll) {
        const matches = root.querySelectorAll(selectorStr);
        for (let i = 0; i < matches.length; i++) {
          collapseElement(matches[i]);
        }
      }
    } catch (_) {
      if (!fallbackArray || fallbackArray.length === 0) return;
      const surviving = [];
      for (let k = 0; k < fallbackArray.length; k++) {
        const s = fallbackArray[k];
        try {
          if (root !== document && root.matches && root.matches(s)) {
            collapseElement(root);
          } else if (root.querySelectorAll) {
            const nodes = root.querySelectorAll(s);
            for (let m = 0; m < nodes.length; m++) {
              collapseElement(nodes[m]);
            }
          }
          surviving.push(s);
        } catch (_) {
          // Prune offending dynamic selector
        }
      }
      if (surviving.length !== fallbackArray.length) {
        validCustomSelectors = surviving;
        customSelector = surviving.join(', ');
      }
    }
  }

  /**
   * Processes batched mutation subtrees within a frame budget
   */
  function flushBatch() {
    isBatchScheduled = false;
    if (isWhitelisted) return;

    const batch = Array.from(pendingNodes);
    pendingNodes.clear();

    for (let i = 0; i < batch.length; i++) {
      const root = batch[i];
      if (!root.isConnected || processedElements.has(root)) continue;

      queryAndCollapse(root, CORE_SELECTOR, null);
      if (customSelector && !processedElements.has(root)) {
        queryAndCollapse(root, customSelector, validCustomSelectors);
      }
    }
  }

  /**
   * Mutation observer callback
   */
  function onDomMutations(mutations) {
    if (isWhitelisted) return;
    let hasNewElements = false;

    for (let i = 0; i < mutations.length; i++) {
      const record = mutations[i];

      // Defend against anti-adblock scripts attempting to remove our custom style
      if (record.removedNodes && record.removedNodes.length > 0) {
        for (let j = 0; j < record.removedNodes.length; j++) {
          const removed = record.removedNodes[j];
          if (removed && removed.id === '__adshield_cosmetic') {
            const target = document.head || document.documentElement;
            if (target) target.appendChild(removed);
          }
        }
      }

      const added = record.addedNodes;
      if (!added) continue;

      for (let j = 0; j < added.length; j++) {
        const node = added[j];
        if (node.nodeType === 1 /* Node.ELEMENT_NODE */) {
          if (!processedElements.has(node)) {
            pendingNodes.add(node);
            hasNewElements = true;
          }
        }
      }
    }

    if (hasNewElements && !isBatchScheduled) {
      isBatchScheduled = true;
      if (typeof window.requestAnimationFrame === 'function') {
        window.requestAnimationFrame(flushBatch);
      } else {
        queueMicrotask(flushBatch);
      }
    }
  }

  /**
   * Initial DOM scan of existing elements
   */
  function scanExistingDom() {
    if (isWhitelisted) return;
    queryAndCollapse(document, CORE_SELECTOR, null);
    if (customSelector) {
      queryAndCollapse(document, customSelector, validCustomSelectors);
    }
  }

  function buildCosmeticCssText() {
    let cssText = `${CORE_SELECTOR} { ${HIDING_DECL} }`;
    if (validCustomSelectors.length > 0) {
      cssText += '\n' + validCustomSelectors.map(s => `${s} { ${HIDING_DECL} }`).join('\n');
    }
    return cssText;
  }

  /**
   * Injects auxiliary style tag and initializes the MutationObserver
   */
  function startEngine() {
    if (isWhitelisted) return;
    engineStarted = true;

    const cssText = buildCosmeticCssText();
    const existingStyle = document.getElementById('__adshield_cosmetic');
    if (existingStyle) {
      existingStyle.textContent = cssText;
    } else {
      const style = document.createElement('style');
      style.id = '__adshield_cosmetic';
      style.textContent = cssText;
      const target = document.head || document.documentElement;
      if (target) {
        target.appendChild(style);
      }
    }

    const rootTarget = document.documentElement || document.body;
    if (rootTarget) {
      if (!observer) {
        observer = new MutationObserver(onDomMutations);
        observer.observe(rootTarget, {
          childList: true,
          subtree: true
        });
      }
      scanExistingDom();
      if (document.readyState === 'loading' && !domReadyHooked) {
        domReadyHooked = true;
        document.addEventListener('DOMContentLoaded', scanExistingDom, { once: true });
      }
    } else {
      setTimeout(startEngine, 0);
    }
  }

  function restoreHiddenElements() {
    if (typeof document === 'undefined' || !document.querySelectorAll) return;
    const hidden = document.querySelectorAll('[data-adshield-hidden="true"]');
    for (let i = 0; i < hidden.length; i++) {
      const el = hidden[i];
      if (el.style && typeof el.style.removeProperty === 'function') {
        el.style.removeProperty('display');
        el.style.removeProperty('visibility');
        el.style.removeProperty('height');
        el.style.removeProperty('min-height');
        el.style.removeProperty('pointer-events');
      }
      if (typeof el.removeAttribute === 'function') {
        el.removeAttribute('data-adshield-hidden');
      }
    }
    processedElements = new WeakSet();
    pendingNodes.clear();
  }

  /**
   * Applies whitelist/settings exemption: stops observer, restores JS-collapsed elements,
   * removes injected cosmetic tag, and (when transitioning on a live tab) injects full CSS override.
   */
  function applyWhitelistExemption(injectOverride = false) {
    isWhitelisted = true;
    engineStarted = false;
    if (observer) {
      observer.disconnect();
      observer = null;
    }

    const cosmeticTag = document.getElementById('__adshield_cosmetic');
    if (cosmeticTag && typeof cosmeticTag.remove === 'function') {
      cosmeticTag.remove();
    }

    restoreHiddenElements();

    if (injectOverride && !document.getElementById('__adshield_override')) {
      const overrideSelectors = Array.from(new Set([...FULL_COSMETIC_CSS_SELECTORS, ...validCustomSelectors]));
      const overrideStyle = document.createElement('style');
      overrideStyle.id = '__adshield_override';
      overrideStyle.textContent = `${overrideSelectors.join(', ')} { ${OVERRIDE_DECL} }`;
      const target = document.head || document.documentElement;
      if (target) {
        target.appendChild(overrideStyle);
      }
    }
  }

  function applyCurrentConfiguration(fromLiveChange) {
    const domainSelectors = getDomainScopedSelectors(currentHostname, currentDomainCosmetics);
    setDynamicSelectors([...currentGlobalCosmetics, ...domainSelectors]);

    const shouldExempt =
      currentSettings.cosmeticFilteringEnabled === false ||
      isDomainWhitelisted(currentHostname, currentWhitelist);

    if (shouldExempt) {
      // Only inject #__adshield_override if transitioning live on a previously active tab
      const wasActive = fromLiveChange && (engineStarted || !isWhitelisted);
      applyWhitelistExemption(wasActive);
    } else {
      isWhitelisted = false;
      const override = document.getElementById('__adshield_override');
      if (override && typeof override.remove === 'function') {
        override.remove();
      }
      startEngine();
    }
  }

  // Check storage configuration before starting DOM engine
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(
      ['userWhitelist', 'settings', 'cosmeticSelectors', 'domainCosmeticSelectors'],
      (res) => {
        const data = res || {};
        currentWhitelist = Array.isArray(data.userWhitelist) ? data.userWhitelist : [];
        currentSettings = (data.settings && typeof data.settings === 'object') ? data.settings : {};
        currentGlobalCosmetics = Array.isArray(data.cosmeticSelectors) ? data.cosmeticSelectors : [];
        currentDomainCosmetics = (data.domainCosmeticSelectors && typeof data.domainCosmeticSelectors === 'object')
          ? data.domainCosmeticSelectors
          : {};

        applyCurrentConfiguration(false);
      }
    );

    if (chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local') return;
        let relevant = false;
        if (changes.userWhitelist) {
          currentWhitelist = Array.isArray(changes.userWhitelist.newValue) ? changes.userWhitelist.newValue : [];
          relevant = true;
        }
        if (changes.settings) {
          currentSettings = (changes.settings.newValue && typeof changes.settings.newValue === 'object')
            ? changes.settings.newValue
            : {};
          relevant = true;
        }
        if (changes.cosmeticSelectors) {
          currentGlobalCosmetics = Array.isArray(changes.cosmeticSelectors.newValue)
            ? changes.cosmeticSelectors.newValue
            : [];
          relevant = true;
        }
        if (changes.domainCosmeticSelectors) {
          currentDomainCosmetics = (changes.domainCosmeticSelectors.newValue && typeof changes.domainCosmeticSelectors.newValue === 'object')
            ? changes.domainCosmeticSelectors.newValue
            : {};
          relevant = true;
        }

        if (relevant) {
          applyCurrentConfiguration(true);
        }
      });
    }
  } else {
    // Fallback if storage unavailable
    startEngine();
  }
})();
