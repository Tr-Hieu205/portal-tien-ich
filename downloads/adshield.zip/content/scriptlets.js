/**
 * AdShield Pro - Main World Scriptlet Injector
 * Executes in world: "MAIN" at document_start when scriptletsEnabled !== false and domain is not whitelisted.
 * Neutralizes global ad framework objects, telemetry stubs, and intrusive ad popups.
 */

(function () {
  'use strict';

  // 1. Google AdSense (adsbygoogle) Tamper-Proof Mock Object
  const adsbygoogleStub = {
    loaded: true,
    push: function (cmd) {
      if (typeof cmd === 'function') {
        try {
          cmd();
        } catch (_) {}
      }
      return 0;
    }
  };
  Object.freeze(adsbygoogleStub);

  try {
    Object.defineProperty(window, 'adsbygoogle', {
      get: () => adsbygoogleStub,
      set: () => {}, // Silently discard reassignments (e.g., adsbygoogle = window.adsbygoogle || [])
      configurable: true,
      enumerable: true
    });
  } catch (_) {}

  // 2. Analytics & Telemetry Stubs (ga, gtag, _gaq, fbq)
  const noopFn = function () {};
  noopFn.answer = 42;
  noopFn.push = function () { return 0; };

  if (!('ga' in window)) {
    try {
      Object.defineProperty(window, 'ga', {
        value: noopFn,
        writable: true,
        configurable: true,
        enumerable: true
      });
    } catch (_) {}
  }

  if (!('gtag' in window)) {
    try {
      Object.defineProperty(window, 'gtag', {
        value: function () {},
        writable: true,
        configurable: true,
        enumerable: true
      });
    } catch (_) {}
  }

  if (!('_gaq' in window)) {
    try {
      Object.defineProperty(window, '_gaq', {
        value: { push: function () { return 0; } },
        writable: true,
        configurable: true,
        enumerable: true
      });
    } catch (_) {}
  }

  if (!('fbq' in window)) {
    const fbqStub = function () {};
    fbqStub.push = function () { return 0; };
    fbqStub.loaded = true;
    fbqStub.version = '2.0';
    try {
      Object.defineProperty(window, 'fbq', {
        value: fbqStub,
        writable: true,
        configurable: true,
        enumerable: true
      });
    } catch (_) {}
  }

  // 3. Intercept & Neutralize Known Malicious Ad Popups
  const nativeOpen = window.open;
  try {
    window.open = function (url, target, features) {
      if (typeof url === 'string') {
        const isAdUrl = /doubleclick|popads|propellerads|adsterra|trafficjunky|exoclick|juicyads/i.test(url);
        if (isAdUrl) {
          console.warn('[AdShield] Blocked intrusive ad popup:', url);
          return null;
        }
      }
      return nativeOpen.apply(this, arguments);
    };
  } catch (_) {}

  // 4. True YouTube Premium Ad Eliminator (MAIN World — strips player/next ads before player loads them + safe auto-skip)
  if (typeof location !== 'undefined' && /(^|\.)youtube\.com$/i.test(location.hostname) && !window.__adblockYoutubeMasterActive) {
    window.__adblockYoutubeMasterActive = true;
    const AD_KEYS = ['adPlacements', 'playerAds', 'adSlots', 'adBreakHeartbeatParams'];

    const stripYoutubeAds = (val, seen = new WeakSet(), depth = 0) => {
      if (!val || typeof val !== 'object' || depth > 7) return val;
      if (seen.has(val)) return val;
      seen.add(val);

      for (let i = 0; i < AD_KEYS.length; i++) {
        const key = AD_KEYS[i];
        if (Object.prototype.hasOwnProperty.call(val, key)) {
          try { delete val[key]; } catch (_) {}
        }
      }

      if (Array.isArray(val)) {
        for (let i = 0; i < val.length; i++) {
          if (val[i] && typeof val[i] === 'object') {
            stripYoutubeAds(val[i], seen, depth + 1);
          }
        }
        return val;
      }

      const containerKeys = [
        'playerResponse',
        'response',
        'data',
        'onResponseReceivedEndpoints',
        'contents',
        'twoColumnWatchNextResults',
        'engagementPanels'
      ];
      for (let i = 0; i < containerKeys.length; i++) {
        const ck = containerKeys[i];
        if (val[ck] && typeof val[ck] === 'object') {
          stripYoutubeAds(val[ck], seen, depth + 1);
        }
      }
      return val;
    };

    // 4a. Hook JSON.parse safely (only strip ad keys from YouTube watch/player API structures)
    try {
      const origParse = JSON.parse;
      JSON.parse = function () {
        const parsed = origParse.apply(this, arguments);
        if (parsed && typeof parsed === 'object') {
          if (parsed.playerResponse || parsed.adPlacements || parsed.playerAds || parsed.adSlots) {
            stripYoutubeAds(parsed);
          }
        }
        return parsed;
      };
    } catch (_) {}

    // 4b. Hook Response.prototype.json and Response.prototype.text ONLY for player/next requests (never live_chat!)
    try {
      const origJson = Response.prototype.json;
      Response.prototype.json = async function () {
        const data = await origJson.apply(this, arguments);
        const url = (this && typeof this.url === 'string') ? this.url : '';
        if (data && typeof data === 'object' && (url.includes('/player') || url.includes('/next'))) {
          stripYoutubeAds(data);
        }
        return data;
      };

      const origText = Response.prototype.text;
      Response.prototype.text = async function () {
        const txt = await origText.apply(this, arguments);
        const url = (this && typeof this.url === 'string') ? this.url : '';
        if (
          txt &&
          typeof txt === 'string' &&
          (url.includes('/player') || url.includes('/next')) &&
          (txt.includes('"adPlacements"') || txt.includes('"playerAds"') || txt.includes('"adSlots"'))
        ) {
          try {
            const parsed = JSON.parse(txt);
            stripYoutubeAds(parsed);
            return JSON.stringify(parsed);
          } catch (_) {}
        }
        return txt;
      };
    } catch (_) {}

    // 4c. Hook window.ytInitialPlayerResponse on initial page load
    try {
      let _ytInitialPlayerResponse = window.ytInitialPlayerResponse;
      if (_ytInitialPlayerResponse) stripYoutubeAds(_ytInitialPlayerResponse);
      Object.defineProperty(window, 'ytInitialPlayerResponse', {
        configurable: true,
        enumerable: true,
        get: () => _ytInitialPlayerResponse,
        set: (val) => {
          _ytInitialPlayerResponse = stripYoutubeAds(val);
        }
      });
    } catch (_) {}

    // 4d. Safe Ad Terminator with explicit LiveStream protection & event loop throttling
    let adActive = false;
    let prevMuted = false;
    let prevRate = 1;
    let observedPlayer = null;
    let lastSkipClickTime = 0;
    let hasSeeked = false;

    const SKIP_SELECTORS = [
      '.ytp-skip-ad-button',
      '.ytp-ad-skip-button',
      '.ytp-ad-skip-button-modern',
      '.ytp-ad-skip-button-slot button',
      '.ytp-ad-skip-button-container button',
      '.ytp-ad-player-overlay-layout__skip-or-preview-container button',
      '.ytp-ad-action-interstitial button',
      '.ytp-ad-action-interstitial-slot button',
      'button[id^="skip-button"]',
      'button[class*="skip-ad"]',
      'button[class*="ad-skip"]',
      '.ytp-ad-overlay-close-button'
    ].join(', ');

    const isLiveStream = (player, video) => {
      if (!player) return false;
      if (player.classList.contains('ytp-live') || player.classList.contains('ytp-live-badges')) return true;
      if (document.querySelector('.ytp-live-badge, .ytp-live-label, ytd-watch-flexy[is-live]')) return true;
      if (video) {
        if (!Number.isFinite(video.duration) || video.duration === Infinity || video.duration <= 0) return true;
        if (video.duration > 43200) return true;
      }
      if (typeof player.getVideoData === 'function') {
        try {
          const data = player.getVideoData();
          if (data && (data.isLive || data.isLiveContent)) return true;
        } catch (_) {}
      }
      return false;
    };

    // Neutralize YouTube Anti-Adblock enforcement modal and full-screen backdrop
    const neutralizeEnforcement = () => {
      // 1. Remove enforcement dialogs & warning cards
      const enforcementElements = document.querySelectorAll(
        'ytd-enforcement-message-view-model, tp-yt-paper-dialog:has(ytd-enforcement-message-view-model)'
      );
      const hadEnforcement = enforcementElements.length > 0;
      if (hadEnforcement) {
        enforcementElements.forEach((el) => {
          try {
            el.remove();
          } catch (_) {
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('pointer-events', 'none', 'important');
          }
        });
      }

      // 2. Remove all overlay backdrop elements that intercept pointer events
      const backdrops = document.querySelectorAll('tp-yt-iron-overlay-backdrop, iron-overlay-backdrop');
      if (backdrops.length > 0) {
        backdrops.forEach((backdrop) => {
          try {
            backdrop.remove();
          } catch (_) {
            backdrop.style.setProperty('display', 'none', 'important');
            backdrop.style.setProperty('pointer-events', 'none', 'important');
          }
        });
      }

      // 3. Unlock document overflow so scrolling and clicks work freely
      if (document.body && document.body.style.overflow === 'hidden') {
        document.body.style.overflow = '';
      }
      if (document.documentElement && document.documentElement.style.overflow === 'hidden') {
        document.documentElement.style.overflow = '';
      }

      // 4. Resume video playback if paused by enforcement dialog
      if (hadEnforcement) {
        const player = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
        if (player && typeof player.playVideo === 'function') {
          try {
            if (typeof player.getPlayerState === 'function' && player.getPlayerState() === 2) {
              player.playVideo();
            }
          } catch (_) {}
        }
      }
    };

    const triggerRealClick = (el) => {
      if (!el || !el.isConnected) return;
      // Do not abort if offsetParent is null (e.g. parent styled with display:none) as long as element is connected
      const now = Date.now();
      if (now - lastSkipClickTime < 300) return;
      lastSkipClickTime = now;
      try {
        el.click();
      } catch (_) {}
    };

    const terminateAd = () => {
      neutralizeEnforcement();

      const player = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
      if (!player) return;

      const isAd =
        player.classList.contains('ad-showing') ||
        player.classList.contains('ad-interrupting');

      const video = player.querySelector('video.html5-main-video, video');
      const isLive = isLiveStream(player, video);

      if (isAd) {
        if (!adActive && video) {
          adActive = true;
          hasSeeked = false;
          prevMuted = video.muted;
          prevRate = video.playbackRate && video.playbackRate <= 2 ? video.playbackRate : 1;
        }

        try {
          if (typeof player.skipAd === 'function') player.skipAd();
          if (typeof player.finishAd === 'function') player.finishAd();
        } catch (_) {}

        player.querySelectorAll(SKIP_SELECTORS).forEach(triggerRealClick);

        if (video) {
          video.muted = true;
          // CRITICAL: On Live Streams, NEVER touch currentTime or playbackRate!
          if (!isLive) {
            // Prioritize accelerating playback smoothly
            try {
              if (video.playbackRate !== 16) {
                video.playbackRate = 16;
              }
            } catch (_) {}

            // Verify active ad presence before attempting a seek to prevent stalling the HTML5 seek pipeline
            const isVerifiedAd = Boolean(
              player.querySelector('.ytp-ad-player-overlay, .ytp-ad-text, .ytp-ad-module, .video-ads, .ytp-ad-skip-button-slot, .ytp-skip-ad-button, .ytp-ad-preview-container')
            );

            // Guard seeks: do not call currentTime in repetitive loops; only seek once per ad transition if verified active ad
            if (isVerifiedAd && !hasSeeked && Number.isFinite(video.duration) && video.duration > 0.5 && video.duration <= 65) {
              hasSeeked = true;
              try {
                video.currentTime = video.duration;
              } catch (_) {}
            }
          }
        }
      } else if (adActive) {
        adActive = false;
        hasSeeked = false;
        if (video) {
          video.muted = prevMuted;
          try { video.playbackRate = prevRate || 1; } catch (_) {}
        }
      }

      if (player !== observedPlayer && typeof MutationObserver !== 'undefined') {
        observedPlayer = player;
        const mo = new MutationObserver(terminateAd);
        mo.observe(player, {
          attributes: true,
          attributeFilter: ['class'],
          childList: true,
          subtree: false // Observe player direct children to avoid heavy layout thrashing
        });
      }
    };

    setInterval(terminateAd, 150);
    document.addEventListener('DOMContentLoaded', terminateAd, { once: true });
    window.addEventListener('yt-navigate-start', () => {
      hasSeeked = false;
      adActive = false;
      terminateAd();
    });
    window.addEventListener('yt-navigate-finish', () => {
      hasSeeked = false;
      adActive = false;
      terminateAd();
    });
  }

  console.log('[AdShield] Main world scriptlets initialized.');
})();
