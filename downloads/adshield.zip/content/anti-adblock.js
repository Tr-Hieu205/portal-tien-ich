/**
 * AdShield Pro - Anti-Adblock Detector Deception
 * Executes in world: "MAIN" at document_start when antiAdblockDisarmEnabled !== false and domain is not whitelisted.
 */

(function () {
  'use strict';

  const deceptiveFlags = {
    canRunAds: true,
    isAdBlockActive: false,
    adBlockDetected: false,
    adblock: false,
    __adblock_detected: false,
    blockedByAdBlocker: false
  };

  for (const [propName, targetValue] of Object.entries(deceptiveFlags)) {
    try {
      Object.defineProperty(window, propName, {
        get: () => targetValue,
        set: () => {}, // Discard anti-adblock attempts to overwrite state in image onerror
        configurable: true,
        enumerable: true
      });
    } catch (_) {}
  }
})();
