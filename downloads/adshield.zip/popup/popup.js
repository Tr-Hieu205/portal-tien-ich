/**
 * AdShield Pro - Popup Controller Logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  const siteDomainEl = document.getElementById('siteDomain');
  const statusPillEl = document.getElementById('statusPill');
  const whitelistToggleEl = document.getElementById('whitelistToggle');
  const reloadBannerEl = document.getElementById('reloadBanner');
  const reloadBtnEl = document.getElementById('reloadBtn');
  const pageBlockedEl = document.getElementById('pageBlockedCount');
  const totalBlockedEl = document.getElementById('totalBlockedCount');
  const activeRulesTextEl = document.getElementById('activeRulesText');
  const openOptionsBtnEl = document.getElementById('openOptionsBtn');
  const footerOptionsLinkEl = document.getElementById('footerOptionsLink');

  let currentTab = null;
  let currentDomain = '';
  let isWhitelisted = false;
  let pageBlockedCount = 0;
  let totalBlockedCount = 0;

  // Check URL parameters for direct headless testing (e.g. ?domain=localhost&test=true)
  const urlParams = new URLSearchParams(window.location.search);
  const testDomainParam = urlParams.get('domain');

  if (testDomainParam) {
    currentDomain = testDomainParam;
    currentTab = { id: 9999, url: `http://${testDomainParam}/` };
    siteDomainEl.textContent = currentDomain;
    siteDomainEl.title = currentDomain;
  } else if (chrome.tabs && chrome.tabs.query) {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      currentTab = tabs[0];
      if (currentTab && currentTab.url) {
        const url = new URL(currentTab.url);
        if (['http:', 'https:'].includes(url.protocol)) {
          currentDomain = url.hostname.toLowerCase().replace(/^www\./, '');
          siteDomainEl.textContent = currentDomain;
          siteDomainEl.title = currentDomain;
        } else {
          renderSystemPage('Internal Page');
          return;
        }
      } else {
        renderSystemPage('No Tab Detected');
        return;
      }
    } catch (_) {
      renderSystemPage('Local Page');
    }
  } else {
    currentDomain = 'localhost';
    siteDomainEl.textContent = currentDomain;
  }

  function renderSystemPage(title) {
    siteDomainEl.textContent = title;
    statusPillEl.textContent = 'System';
    statusPillEl.className = 'status-pill is-system';
    whitelistToggleEl.disabled = true;
    whitelistToggleEl.classList.remove('is-active');
  }

  function updateUI(whitelisted, pageBlocked, totalBlocked, ruleCount) {
    isWhitelisted = !!whitelisted;
    if (isWhitelisted) {
      statusPillEl.textContent = 'Whitelisted';
      statusPillEl.dataset.status = 'whitelisted';
      statusPillEl.className = 'status-pill is-whitelisted';
      whitelistToggleEl.classList.remove('is-active');
      whitelistToggleEl.setAttribute('aria-checked', 'false');
    } else {
      statusPillEl.textContent = 'Protected';
      statusPillEl.dataset.status = 'protected';
      statusPillEl.className = 'status-pill is-protected';
      whitelistToggleEl.classList.add('is-active');
      whitelistToggleEl.setAttribute('aria-checked', 'true');
    }

    pageBlockedEl.textContent = Number(pageBlocked || 0).toLocaleString();
    totalBlockedEl.textContent = Number(totalBlocked || 0).toLocaleString();
    if (ruleCount !== undefined) {
      activeRulesTextEl.textContent = `Active Rules: ${Number(ruleCount).toLocaleString()}`;
    }
  }

  async function refreshState() {
    if (!currentDomain) return;

    try {
      if (chrome.runtime && chrome.runtime.sendMessage) {
        const response = await chrome.runtime.sendMessage({
          action: 'GET_POPUP_STATE',
          domain: currentDomain,
          tabId: currentTab ? currentTab.id : undefined
        });

        if (response && response.success && response.data) {
          const { isWhitelisted: whitelisted, tabBlockedCount, totalBlockedCount, activeRulesCount } = response.data;
          updateUI(whitelisted, tabBlockedCount, totalBlockedCount, activeRulesCount);
          return;
        }
      }
    } catch (_) {}

    // Fallback: direct storage check
    if (chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['userWhitelist', 'blockStats'], (res) => {
        const list = res.userWhitelist || [];
        const whitelisted = list.includes(currentDomain);
        const total = (res.blockStats && res.blockStats.totalBlocked) || 0;
        updateUI(whitelisted, 0, total, 60);
      });
    }
  }

  // Handle whitelist toggle button click
  whitelistToggleEl.addEventListener('click', async () => {
    if (!currentDomain || whitelistToggleEl.disabled) return;
    const targetState = !isWhitelisted;

    try {
      if (chrome.runtime && chrome.runtime.sendMessage) {
        const res = await chrome.runtime.sendMessage({
          action: 'TOGGLE_WHITELIST_DOMAIN',
          domain: currentDomain,
          whitelisted: targetState
        });

        if (res && res.success && res.data) {
          isWhitelisted = res.data.isWhitelisted;
          updateUI(isWhitelisted, parseInt(pageBlockedEl.textContent, 10), parseInt(totalBlockedEl.textContent, 10));
          reloadBannerEl.classList.remove('is-hidden');
        }
      }
    } catch (err) {
      console.warn('[AdShield Popup] Toggle error:', err);
    }
  });

  // Handle reload page action
  reloadBtnEl.addEventListener('click', () => {
    if (currentTab && currentTab.id && chrome.tabs && chrome.tabs.reload) {
      chrome.tabs.reload(currentTab.id);
    }
    window.close();
  });

  // Handle options page navigation
  function openOptions() {
    if (chrome.runtime && chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL('options/options.html'));
    }
  }

  openOptionsBtnEl.addEventListener('click', openOptions);
  footerOptionsLinkEl.addEventListener('click', (e) => {
    e.preventDefault();
    openOptions();
  });

  // Real-time storage listener
  if (chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local') {
        refreshState();
      }
    });
  }

  await refreshState();
});
