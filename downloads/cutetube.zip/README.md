# CuteTube - Giao diện Cute cho YouTube (Chrome Extension)

Tiện ích mở rộng cho Chrome giúp biến đổi giao diện YouTube sang phong cách pastel dễ thương, kèm nhân vật mini nổi trực tiếp trên trang để bạn tùy chỉnh màu sắc, hiệu ứng và tốc độ video mọi lúc.

## Tính năng nổi bật

- **5 bảng màu Pastel & Liquid Glass dịu mắt tùy chọn ngay trên YouTube:**
  - 🫧 **Liquid Glass Thủy Tinh (Mới):** Hiệu ứng kính mờ trong suốt, viền gương bóng bẩy, phản chiếu ánh sáng hiện đại.
  - 💜 **Tím Đêm Dịu Mắt**
  - 🌸 **Hồng Dâu Trầm**
  - 🌿 **Xanh Mint Đêm**
  - 🍑 **Đào Mocha Dịu**
- **3 nhân vật mini đồng hành nổi trên trang:** 🐱 Mèo Mochi, 🐰 Thỏ Bông, 🐻 Gấu Kem (có thể kéo thả tự do quanh màn hình, tự ẩn khi xem Toàn màn hình).
- **Hiệu ứng giao diện Cute & Tối ưu tốc độ:**
  - **Chế độ Liquid Glass kết hợp:** Có thể bật hiệu ứng kính thủy tinh xuyên suốt kết hợp cùng bất kỳ bảng màu nào.
  - **Tối ưu tải trang siêu tốc:** Tách biệt luồng xử lý (idle scheduling), tối ưu layer compositor GPU và trì hoãn render phần tử ngoài màn hình (content-visibility), loại bỏ hoàn toàn hiện tượng nghẽn tải ban đầu.
  - Bo tròn thumbnail, khung video và thanh tìm kiếm dạng viên thuốc.
  - Thanh tua video chuyển màu gradient + nút tua hình trái tim ♥.
  - Hạt lấp lánh / cánh hoa bay nhẹ trên nền.
  - **Chế độ tập trung:** Ẩn cột video đề xuất và màn hình kết thúc.
  - **Chỉnh nhanh tốc độ phát (`0.75x` – `2x`)** ngay trong bảng nhân vật.

## Cách thêm vào Chrome (chỉ mất 30 giây)

1. Mở Google Chrome và nhập lên thanh địa chỉ: `chrome://extensions`
2. Bật công tắc **Chế độ dành cho nhà phát triển** (Developer mode) ở góc trên bên phải.
3. Bấm nút **Tải tiện ích đã giải nén** (Load unpacked).
4. Chọn thư mục: `D:\Tr_Hiuz\Tiện ích\Youtube`
5. Quay lại tab YouTube và bấm **F5 (Tải lại trang)** một lần để thấy giao diện mới và nhân vật mini ở góc dưới bên phải.
