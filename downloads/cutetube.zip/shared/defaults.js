(function (root) {
  const STORAGE_KEY = "cutetube_settings";
  const CACHE_KEY = "cutetube_cache_v1";

  const DEFAULT_SETTINGS = {
    enabled: true,
    theme: "lavender-dark",
    mascot: "cat",
    roundedCards: true,
    cutePlayer: true,
    sparkles: true,
    focusMode: false,
    showMascot: true,
    mascotPos: null
  };

  const THEMES = {
    "lavender-dark": {
      id: "lavender-dark",
      name: "Tím Đêm Dịu Mắt",
      shortName: "Tím Đêm",
      emoji: "💜",
      isDark: true,
      bg: "#130f1e",
      surface: "#1d1730",
      surfaceAlt: "#282041",
      text: "#f6eeff",
      muted: "#bfb0e3",
      accent: "#f48fb1",
      secondary: "#b39ddb",
      accentText: "#23102b",
      border: "rgba(244, 143, 177, 0.24)",
      glow: "rgba(244, 143, 177, 0.26)",
      sparkleGlyphs: ["✦", "♡", "✧", "⋆"]
    },
    "sakura-pink": {
      id: "sakura-pink",
      name: "Hồng Dâu Trầm",
      shortName: "Hồng Dâu",
      emoji: "🌸",
      isDark: true,
      bg: "#1c1118",
      surface: "#281822",
      surfaceAlt: "#36212e",
      text: "#ffeff5",
      muted: "#dfb3c6",
      accent: "#ff80ab",
      secondary: "#f48fb1",
      accentText: "#290e1b",
      border: "rgba(255, 128, 171, 0.26)",
      glow: "rgba(255, 128, 171, 0.26)",
      sparkleGlyphs: ["🌸", "♡", "✿", "✦"]
    },
    "mint-matcha": {
      id: "mint-matcha",
      name: "Xanh Mint Đêm",
      shortName: "Xanh Mint",
      emoji: "🌿",
      isDark: true,
      bg: "#0e1b17",
      surface: "#162822",
      surfaceAlt: "#1f372f",
      text: "#ebfff6",
      muted: "#9ed3bf",
      accent: "#5ce0b3",
      secondary: "#81e6d9",
      accentText: "#0b241c",
      border: "rgba(92, 224, 179, 0.24)",
      glow: "rgba(92, 224, 179, 0.24)",
      sparkleGlyphs: ["🌿", "✦", "❀", "♡"]
    },
    "peach-cream": {
      id: "peach-cream",
      name: "Đào Mocha Dịu",
      shortName: "Đào Mocha",
      emoji: "🍑",
      isDark: true,
      bg: "#1d130f",
      surface: "#291c16",
      surfaceAlt: "#37261e",
      text: "#fff1e8",
      muted: "#dfb7a4",
      accent: "#ff9e75",
      secondary: "#ffc4a3",
      accentText: "#2b130a",
      border: "rgba(255, 158, 117, 0.25)",
      glow: "rgba(255, 158, 117, 0.25)",
      sparkleGlyphs: ["🍑", "✦", "♡", "⋆"]
    }
  };

  const MASCOTS = {
    cat: {
      id: "cat",
      name: "Mèo Mochi",
      emoji: "🐱",
      quotes: [
        "Meow~ Xem video vui vẻ nha ✨",
        "Hôm nay uống đủ nước chưa nè? 💖",
        "Đổi màu giao diện cho mới mẻ đi~ 🌸",
        "Nghe tiếng meow may mắn cả ngày 🐾"
      ]
    },
    bunny: {
      id: "bunny",
      name: "Thỏ Bông",
      emoji: "🐰",
      quotes: [
        "Nhảy nhót~ Chúc bạn thư giãn thật vui 🌷",
        "Đừng quên chớp mắt nghỉ xíu nha ♡",
        "Thích màu hồng hay tím mộng mơ? ✨",
        "Củ cà rốt nhỏ tặng bạn nè 🥕"
      ]
    },
    bear: {
      id: "bear",
      name: "Gấu Kem",
      emoji: "🐻",
      quotes: [
        "Ấm áp quá đi~ Xem tiếp nào 🍯",
        "Gấu Kem luôn ngồi đây cổ vũ bạn ⭐",
        "Bật chế độ tập trung để đỡ bị phân tâm nè!",
        "Một ngày thật ngọt ngào nha ♡"
      ]
    }
  };

  function normalizeSettings(raw) {
    const merged = Object.assign({}, DEFAULT_SETTINGS, raw || {});
    if (!THEMES[merged.theme]) merged.theme = DEFAULT_SETTINGS.theme;
    if (!MASCOTS[merged.mascot]) merged.mascot = DEFAULT_SETTINGS.mascot;
    return merged;
  }

  function getMascotSvg(mascotId, accent, secondary) {
    const a = accent || "#f48fb1";
    const s = secondary || "#b39ddb";
    if (mascotId === "bunny") {
      return `
        <svg viewBox="0 0 80 80" width="100%" height="100%" aria-hidden="true">
          <defs>
            <linearGradient id="ctBodyGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stop-color="#ffffff"/>
              <stop offset="100%" stop-color="#ffeef5"/>
            </linearGradient>
          </defs>
          <ellipse cx="29" cy="22" rx="8" ry="18" transform="rotate(-10 29 22)" fill="url(#ctBodyGrad)" stroke="${a}" stroke-width="2.6"/>
          <ellipse cx="29" cy="23" rx="4" ry="11" transform="rotate(-10 29 23)" fill="${a}" opacity="0.55"/>
          <ellipse cx="51" cy="22" rx="8" ry="18" transform="rotate(10 51 22)" fill="url(#ctBodyGrad)" stroke="${a}" stroke-width="2.6"/>
          <ellipse cx="51" cy="23" rx="4" ry="11" transform="rotate(10 51 23)" fill="${a}" opacity="0.55"/>
          <ellipse cx="40" cy="50" rx="24" ry="21" fill="url(#ctBodyGrad)" stroke="${a}" stroke-width="2.8"/>
          <g class="ct-eyes">
            <circle cx="31" cy="47" r="3.4" fill="#3a2332"/>
            <circle cx="49" cy="47" r="3.4" fill="#3a2332"/>
            <circle cx="32.1" cy="45.8" r="1.1" fill="#ffffff"/>
            <circle cx="50.1" cy="45.8" r="1.1" fill="#ffffff"/>
          </g>
          <ellipse cx="24" cy="53" rx="4.5" ry="2.6" fill="${a}" opacity="0.6"/>
          <ellipse cx="56" cy="53" rx="4.5" ry="2.6" fill="${a}" opacity="0.6"/>
          <polygon points="40,51 37.5,48.5 42.5,48.5" fill="${a}"/>
          <path d="M35.5 53.5 Q38 56.5 40 53.5 Q42 56.5 44.5 53.5" fill="none" stroke="#3a2332" stroke-width="2" stroke-linecap="round"/>
          <circle cx="40" cy="67" r="4" fill="${s}" stroke="#ffffff" stroke-width="1.5"/>
        </svg>`;
    }
    if (mascotId === "bear") {
      return `
        <svg viewBox="0 0 80 80" width="100%" height="100%" aria-hidden="true">
          <defs>
            <linearGradient id="ctBearGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stop-color="#fff4e4"/>
              <stop offset="100%" stop-color="#f7d9b8"/>
            </linearGradient>
          </defs>
          <circle cx="21" cy="25" r="9.5" fill="url(#ctBearGrad)" stroke="${a}" stroke-width="2.6"/>
          <circle cx="21" cy="25" r="4.8" fill="${a}" opacity="0.45"/>
          <circle cx="59" cy="25" r="9.5" fill="url(#ctBearGrad)" stroke="${a}" stroke-width="2.6"/>
          <circle cx="59" cy="25" r="4.8" fill="${a}" opacity="0.45"/>
          <ellipse cx="40" cy="47" rx="25" ry="22" fill="url(#ctBearGrad)" stroke="${a}" stroke-width="2.8"/>
          <ellipse cx="40" cy="53" rx="10" ry="7.5" fill="#fffaf3"/>
          <g class="ct-eyes">
            <circle cx="30" cy="44" r="3.4" fill="#3c261c"/>
            <circle cx="50" cy="44" r="3.4" fill="#3c261c"/>
            <circle cx="31.1" cy="42.8" r="1.1" fill="#ffffff"/>
            <circle cx="51.1" cy="42.8" r="1.1" fill="#ffffff"/>
          </g>
          <ellipse cx="23" cy="51" rx="4.5" ry="2.6" fill="${a}" opacity="0.6"/>
          <ellipse cx="57" cy="51" rx="4.5" ry="2.6" fill="${a}" opacity="0.6"/>
          <ellipse cx="40" cy="50.5" rx="3.2" ry="2.3" fill="#4b2d21"/>
          <path d="M35.5 54.5 Q40 58 44.5 54.5" fill="none" stroke="#4b2d21" stroke-width="2" stroke-linecap="round"/>
          <path d="M40 64 L41.5 67 L44.8 67.4 L42.3 69.5 L43 72.7 L40 71 L37 72.7 L37.7 69.5 L35.2 67.4 L38.5 67 Z" fill="${s}" stroke="#ffffff" stroke-width="1"/>
        </svg>`;
    }
    return `
      <svg viewBox="0 0 80 80" width="100%" height="100%" aria-hidden="true">
        <defs>
          <linearGradient id="ctCatGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#ffffff"/>
            <stop offset="100%" stop-color="#f7ecff"/>
          </linearGradient>
        </defs>
        <path d="M17 38 L21 15 L36 27 Z" fill="url(#ctCatGrad)" stroke="${a}" stroke-width="2.6" stroke-linejoin="round"/>
        <path d="M21 33 L23.5 21 L32 28 Z" fill="${a}" opacity="0.5"/>
        <path d="M63 38 L59 15 L44 27 Z" fill="url(#ctCatGrad)" stroke="${a}" stroke-width="2.6" stroke-linejoin="round"/>
        <path d="M59 33 L56.5 21 L48 28 Z" fill="${a}" opacity="0.5"/>
        <ellipse cx="40" cy="48" rx="25" ry="21.5" fill="url(#ctCatGrad)" stroke="${a}" stroke-width="2.8"/>
        <g class="ct-eyes">
          <circle cx="30.5" cy="45.5" r="3.5" fill="#31203d"/>
          <circle cx="49.5" cy="45.5" r="3.5" fill="#31203d"/>
          <circle cx="31.7" cy="44.2" r="1.2" fill="#ffffff"/>
          <circle cx="50.7" cy="44.2" r="1.2" fill="#ffffff"/>
        </g>
        <ellipse cx="23" cy="52" rx="4.8" ry="2.7" fill="${a}" opacity="0.62"/>
        <ellipse cx="57" cy="52" rx="4.8" ry="2.7" fill="${a}" opacity="0.62"/>
        <polygon points="40,50 37.6,47.6 42.4,47.6" fill="${a}"/>
        <path d="M35 52.5 Q37.5 55.8 40 52.5 Q42.5 55.8 45 52.5" fill="none" stroke="#31203d" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="48" x2="20" y2="49.5" stroke="${s}" stroke-width="1.8" stroke-linecap="round"/>
        <line x1="12" y1="53.5" x2="20" y2="53" stroke="${s}" stroke-width="1.8" stroke-linecap="round"/>
        <line x1="68" y1="48" x2="60" y2="49.5" stroke="${s}" stroke-width="1.8" stroke-linecap="round"/>
        <line x1="68" y1="53.5" x2="60" y2="53" stroke="${s}" stroke-width="1.8" stroke-linecap="round"/>
        <circle cx="40" cy="67.5" r="4.2" fill="${a}" stroke="#ffffff" stroke-width="1.5"/>
      </svg>`;
  }

  root.CuteTubeConfig = {
    STORAGE_KEY,
    CACHE_KEY,
    DEFAULT_SETTINGS,
    THEMES,
    MASCOTS,
    normalizeSettings,
    getMascotSvg
  };
})(globalThis);
