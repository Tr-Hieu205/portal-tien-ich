(function () {
  if (window !== window.top) return;
  const cfg = globalThis.CuteTubeConfig;
  if (!cfg) return;

  let settings = cfg.normalizeSettings(null);
  let shadowRoot = null;
  let hostEl = null;
  let panelOpen = false;
  let bubbleTimer = null;
  let happyTimer = null;
  let quoteIndex = 0;

  // Read cached settings synchronously at document_start to minimize flash
  try {
    const cached = localStorage.getItem(cfg.CACHE_KEY);
    if (cached) {
      settings = cfg.normalizeSettings(JSON.parse(cached));
    }
  } catch (_) {}

  applyAttributesToRoot(settings);

  function saveCache(nextSettings) {
    try {
      localStorage.setItem(cfg.CACHE_KEY, JSON.stringify(nextSettings));
    } catch (_) {}
  }

  function applyAttributesToRoot(current) {
    const html = document.documentElement;
    if (!html) return;
    html.dataset.cutetubeEnabled = String(Boolean(current.enabled));
    html.dataset.cutetubeTheme = current.theme;
    html.dataset.cutetubeRounded = String(Boolean(current.roundedCards));
    html.dataset.cutetubeCutePlayer = String(Boolean(current.cutePlayer));
    html.dataset.cutetubeFocus = String(Boolean(current.focusMode));
  }

  function persistSettings(patch, showBubbleMsg) {
    settings = cfg.normalizeSettings(Object.assign({}, settings, patch));
    saveCache(settings);
    applyAttributesToRoot(settings);
    applyPremiumWordmark();
    renderWidget();
    if (showBubbleMsg) {
      showBubble(showBubbleMsg);
      triggerHappy();
    }
    try {
      chrome.storage.local.set({ [cfg.STORAGE_KEY]: settings });
    } catch (_) {}
  }

  function getWidgetStyles() {
    return `
      :host {
        all: initial;
        position: fixed;
        inset: 0;
        pointer-events: none;
        z-index: 2147483000;
        font-family: "Segoe UI", "Nunito", "Quicksand", system-ui, -apple-system, sans-serif;
      }

      :host([data-fullscreen="true"]) {
        display: none !important;
      }

      * {
        box-sizing: border-box;
      }

      .ct-root {
        position: fixed;
        inset: 0;
        pointer-events: none;
      }

      /* Floating ambient sparkles */
      .ct-sparkles {
        position: fixed;
        inset: 0;
        overflow: hidden;
        pointer-events: none;
        opacity: 1;
        transition: opacity 0.3s ease;
      }

      .ct-sparkles.is-hidden {
        opacity: 0;
      }

      .ct-sparkle {
        position: absolute;
        bottom: -24px;
        user-select: none;
        pointer-events: none;
        opacity: 0;
        animation-name: ctFloatUp;
        animation-timing-function: linear;
        animation-iteration-count: infinite;
        text-shadow: 0 0 8px var(--w-glow);
      }

      @keyframes ctFloatUp {
        0% {
          transform: translateY(0) translateX(0) rotate(0deg) scale(0.8);
          opacity: 0;
        }
        12% {
          opacity: 0.26;
        }
        82% {
          opacity: 0.22;
        }
        100% {
          transform: translateY(-105vh) translateX(28px) rotate(220deg) scale(1.1);
          opacity: 0;
        }
      }

      /* Mascot anchor */
      .ct-mascot-anchor {
        position: fixed;
        width: 64px;
        height: 64px;
        pointer-events: auto;
        user-select: none;
        touch-action: none;
        transition: opacity 0.25s ease, transform 0.25s ease;
      }

      .ct-mascot-anchor.is-hidden {
        opacity: 0;
        pointer-events: none;
        transform: scale(0.7);
      }

      .ct-mascot-btn {
        position: relative;
        width: 64px;
        height: 64px;
        border-radius: 50%;
        border: 2.5px solid var(--w-accent);
        background: var(--w-surface);
        box-shadow: 0 8px 24px var(--w-glow), 0 4px 12px rgba(0, 0, 0, 0.22);
        cursor: grab;
        padding: 5px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.2s ease, border-color 0.2s ease;
        animation: ctBob 3.2s ease-in-out infinite;
      }

      .ct-mascot-btn:hover {
        transform: scale(1.08) translateY(-2px);
        box-shadow: 0 12px 28px var(--w-glow), 0 6px 16px rgba(0, 0, 0, 0.25);
      }

      .ct-mascot-btn:active {
        cursor: grabbing;
      }

      .ct-mascot-btn.is-happy {
        animation: ctJump 0.55s cubic-bezier(0.34, 1.56, 0.64, 1);
      }

      .ct-mascot-btn.is-disabled {
        filter: grayscale(0.45);
        opacity: 0.85;
      }

      .ct-mascot-btn svg {
        width: 100%;
        height: 100%;
        display: block;
        pointer-events: none;
      }

      .ct-mascot-btn .ct-eyes {
        transform-box: fill-box;
        transform-origin: center;
        animation: ctBlink 4.5s ease-in-out infinite;
      }

      @keyframes ctBob {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-4px); }
      }

      @keyframes ctJump {
        0% { transform: scale(1) translateY(0); }
        35% { transform: scale(1.14, 0.92) translateY(-10px) rotate(-6deg); }
        70% { transform: scale(0.95, 1.06) translateY(-3px) rotate(5deg); }
        100% { transform: scale(1) translateY(0); }
      }

      @keyframes ctBlink {
        0%, 92%, 100% { transform: scaleY(1); }
        96% { transform: scaleY(0.12); }
      }

      .ct-hide-btn {
        position: absolute;
        top: -4px;
        right: -4px;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: 1.5px solid var(--w-border);
        background: var(--w-surface);
        color: var(--w-muted);
        font-size: 12px;
        line-height: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        opacity: 0;
        transform: scale(0.8);
        transition: opacity 0.18s ease, transform 0.18s ease, background 0.18s ease, color 0.18s ease;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
      }

      .ct-mascot-anchor:hover .ct-hide-btn {
        opacity: 1;
        transform: scale(1);
      }

      .ct-hide-btn:hover {
        background: var(--w-accent);
        color: var(--w-accent-text);
        border-color: var(--w-accent);
      }

      /* Speech Bubble */
      .ct-bubble {
        position: absolute;
        bottom: 74px;
        right: 0;
        max-width: 220px;
        width: max-content;
        padding: 8px 12px;
        border-radius: 14px;
        background: var(--w-surface);
        color: var(--w-text);
        border: 1.5px solid var(--w-accent);
        box-shadow: 0 8px 20px var(--w-glow), 0 4px 12px rgba(0, 0, 0, 0.16);
        font-size: 12px;
        font-weight: 600;
        line-height: 1.35;
        pointer-events: none;
        opacity: 0;
        transform: translateY(6px) scale(0.95);
        transition: opacity 0.2s ease, transform 0.2s ease;
      }

      .ct-bubble.is-left {
        right: auto;
        left: 0;
      }

      .ct-bubble.is-below {
        bottom: auto;
        top: 74px;
      }

      .ct-bubble.is-visible {
        opacity: 1;
        transform: translateY(0) scale(1);
      }

      /* Quick Panel */
      .ct-panel {
        position: fixed;
        width: 300px;
        max-height: calc(100vh - 24px);
        overflow-y: auto;
        border-radius: 22px;
        background: var(--w-surface);
        color: var(--w-text);
        border: 1.5px solid var(--w-border);
        box-shadow: 0 18px 44px rgba(0, 0, 0, 0.28), 0 0 28px var(--w-glow);
        padding: 14px;
        pointer-events: auto;
        opacity: 0;
        visibility: hidden;
        transform: scale(0.92) translateY(8px);
        transition: opacity 0.2s ease, transform 0.22s cubic-bezier(0.34, 1.56, 0.64, 1), visibility 0.2s;
      }

      .ct-panel.is-open {
        opacity: 1;
        visibility: visible;
        transform: scale(1) translateY(0);
      }

      .ct-panel::-webkit-scrollbar {
        width: 6px;
      }
      .ct-panel::-webkit-scrollbar-thumb {
        background: var(--w-border);
        border-radius: 999px;
      }

      .ct-panel-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding-bottom: 11px;
        margin-bottom: 11px;
        border-bottom: 1px dashed var(--w-border);
      }

      .ct-brand {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .ct-brand-icon {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background: var(--w-surface-alt);
        border: 1.5px solid var(--w-accent);
        padding: 2px;
        flex-shrink: 0;
      }

      .ct-brand-title {
        font-size: 14px;
        font-weight: 800;
        letter-spacing: 0.2px;
        color: var(--w-text);
      }

      .ct-brand-sub {
        font-size: 11px;
        color: var(--w-muted);
      }

      .ct-header-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      .ct-close-panel {
        width: 26px;
        height: 26px;
        border-radius: 50%;
        border: 1px solid var(--w-border);
        background: var(--w-surface-alt);
        color: var(--w-muted);
        cursor: pointer;
        font-size: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .ct-close-panel:hover {
        background: var(--w-accent);
        color: var(--w-accent-text);
      }

      .ct-section-label {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--w-muted);
        margin: 10px 0 6px;
      }

      /* Theme Grid */
      .ct-theme-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 7px;
      }

      .ct-theme-btn {
        display: flex;
        align-items: center;
        gap: 7px;
        padding: 8px 9px;
        border-radius: 14px;
        border: 1.5px solid var(--w-border);
        background: var(--w-surface-alt);
        color: var(--w-text);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: transform 0.15s ease, border-color 0.15s ease, box-shadow 0.15s ease;
        text-align: left;
      }

      .ct-theme-btn:hover {
        transform: translateY(-1px);
        border-color: var(--w-accent);
      }

      .ct-theme-btn.is-active {
        border-color: var(--w-accent);
        box-shadow: 0 0 0 2px var(--w-glow);
      }

      .ct-swatch {
        width: 16px;
        height: 16px;
        border-radius: 50%;
        flex-shrink: 0;
        border: 1.5px solid rgba(255, 255, 255, 0.7);
      }

      /* Mascot Row */
      .ct-mascot-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 6px;
      }

      .ct-mascot-chip {
        padding: 7px 6px;
        border-radius: 13px;
        border: 1.5px solid var(--w-border);
        background: var(--w-surface-alt);
        color: var(--w-text);
        font-size: 11.5px;
        font-weight: 600;
        cursor: pointer;
        text-align: center;
        transition: all 0.15s ease;
      }

      .ct-mascot-chip:hover {
        border-color: var(--w-accent);
      }

      .ct-mascot-chip.is-active {
        background: var(--w-accent);
        color: var(--w-accent-text);
        border-color: var(--w-accent);
        box-shadow: 0 3px 10px var(--w-glow);
      }

      /* Toggle Rows */
      .ct-toggles {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .ct-toggle-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 6px 9px;
        border-radius: 12px;
        background: var(--w-surface-alt);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
      }

      .ct-switch {
        position: relative;
        width: 36px;
        height: 20px;
        border-radius: 999px;
        background: rgba(128, 128, 128, 0.35);
        transition: background 0.2s ease;
        flex-shrink: 0;
      }

      .ct-switch::after {
        content: "";
        position: absolute;
        top: 2px;
        left: 2px;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: #ffffff;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.25);
        transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
      }

      .ct-switch.is-on {
        background: var(--w-accent);
      }

      .ct-switch.is-on::after {
        transform: translateX(16px);
      }

      /* Speed Bar */
      .ct-speed-row {
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        gap: 5px;
      }

      .ct-speed-btn {
        padding: 6px 0;
        border-radius: 11px;
        border: 1.5px solid var(--w-border);
        background: var(--w-surface-alt);
        color: var(--w-text);
        font-size: 11.5px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.15s ease;
      }

      .ct-speed-btn:hover {
        border-color: var(--w-accent);
      }

      .ct-speed-btn.is-active {
        background: var(--w-accent);
        color: var(--w-accent-text);
        border-color: var(--w-accent);
      }

      .ct-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 11px;
        padding-top: 9px;
        border-top: 1px dashed var(--w-border);
        font-size: 11px;
        color: var(--w-muted);
      }

      .ct-reset-btn {
        background: none;
        border: none;
        color: var(--w-accent);
        font-size: 11px;
        font-weight: 700;
        cursor: pointer;
        padding: 2px 4px;
      }

      .ct-reset-btn:hover {
        text-decoration: underline;
      }
    `;
  }

  function ensureWidgetMounted() {
    if (window !== window.top) return false;
    if (!document.body) return false;
    if (hostEl && document.body.contains(hostEl)) return true;

    hostEl = document.getElementById("cutetube-host");
    if (!hostEl) {
      hostEl = document.createElement("div");
      hostEl.id = "cutetube-host";
      hostEl.style.cssText = "position: fixed; inset: 0; pointer-events: none !important; z-index: 2147483000;";
      document.body.appendChild(hostEl);
    }

    if (!hostEl.shadowRoot) {
      shadowRoot = hostEl.attachShadow({ mode: "open" });
      shadowRoot.innerHTML = `
        <style>${getWidgetStyles()}</style>
        <div class="ct-root">
          <div class="ct-sparkles" aria-hidden="true"></div>
          <div class="ct-mascot-anchor">
            <div class="ct-bubble"></div>
            <button class="ct-mascot-btn" type="button" title="Mở bảng CuteTube (kéo để di chuyển)"></button>
            <button class="ct-hide-btn" type="button" title="Ẩn nhân vật (bật lại ở icon CuteTube trên Chrome)">×</button>
          </div>
          <div class="ct-panel" role="dialog" aria-label="Bảng điều chỉnh CuteTube">
            <div class="ct-panel-header">
              <div class="ct-brand">
                <div class="ct-brand-icon"></div>
                <div>
                  <div class="ct-brand-title">CuteTube ✨</div>
                  <div class="ct-brand-sub">Giao diện YouTube dễ thương</div>
                </div>
              </div>
              <div class="ct-header-actions">
                <div class="ct-switch" data-action="toggle-enabled" title="Bật/tắt giao diện Cute"></div>
                <button class="ct-close-panel" type="button" title="Đóng">✕</button>
              </div>
            </div>

            <div class="ct-section-label">Chọn bảng màu</div>
            <div class="ct-theme-grid"></div>

            <div class="ct-section-label">Nhân vật đồng hành</div>
            <div class="ct-mascot-grid"></div>

            <div class="ct-section-label">Hiệu ứng Cute</div>
            <div class="ct-toggles"></div>

            <div class="ct-section-label">Tốc độ phát video nhanh</div>
            <div class="ct-speed-row"></div>

            <div class="ct-footer">
              <span>Kéo nhân vật để đổi vị trí</span>
              <button class="ct-reset-btn" type="button">Đặt lại góc</button>
            </div>
          </div>
        </div>
      `;

      bindWidgetEvents();
      buildSparkles();
    } else {
      shadowRoot = hostEl.shadowRoot;
    }

    syncFullscreenState();
    renderWidget();
    return true;
  }

  function buildSparkles() {
    if (!shadowRoot) return;
    const container = shadowRoot.querySelector(".ct-sparkles");
    if (!container) return;
    container.innerHTML = "";
    const theme = cfg.THEMES[settings.theme] || cfg.THEMES["lavender-dark"];
    const glyphs = theme.sparkleGlyphs;
    for (let i = 0; i < 14; i++) {
      const span = document.createElement("span");
      span.className = "ct-sparkle";
      span.textContent = glyphs[i % glyphs.length];
      span.style.left = `${(i * 7.3 + (i % 3) * 2.1) % 97}%`;
      span.style.fontSize = `${11 + (i % 4) * 4}px`;
      span.style.color = i % 2 === 0 ? theme.accent : theme.secondary;
      span.style.animationDuration = `${11 + (i % 5) * 3.2}s`;
      span.style.animationDelay = `${-(i * 1.9)}s`;
      container.appendChild(span);
    }
  }

  function bindWidgetEvents() {
    const anchor = shadowRoot.querySelector(".ct-mascot-anchor");
    const mascotBtn = shadowRoot.querySelector(".ct-mascot-btn");
    const hideBtn = shadowRoot.querySelector(".ct-hide-btn");
    const closePanelBtn = shadowRoot.querySelector(".ct-close-panel");
    const masterSwitch = shadowRoot.querySelector('[data-action="toggle-enabled"]');
    const resetBtn = shadowRoot.querySelector(".ct-reset-btn");

    // Drag & click on mascot
    let dragState = null;

    mascotBtn.addEventListener("pointerdown", (e) => {
      if (e.button !== 0) return;
      const rect = anchor.getBoundingClientRect();
      dragState = {
        pointerId: e.pointerId,
        startX: e.clientX,
        startY: e.clientY,
        origLeft: rect.left,
        origTop: rect.top,
        moved: false
      };
      mascotBtn.setPointerCapture(e.pointerId);
    });

    mascotBtn.addEventListener("pointermove", (e) => {
      if (!dragState || dragState.pointerId !== e.pointerId) return;
      const dx = e.clientX - dragState.startX;
      const dy = e.clientY - dragState.startY;
      if (!dragState.moved && Math.hypot(dx, dy) > 6) {
        dragState.moved = true;
      }
      if (!dragState.moved) return;

      const clamped = clampPosition(dragState.origLeft + dx, dragState.origTop + dy);
      anchor.style.left = `${clamped.left}px`;
      anchor.style.top = `${clamped.top}px`;
      anchor.style.right = "auto";
      anchor.style.bottom = "auto";
      if (panelOpen) positionPanelNearAnchor();
    });

    mascotBtn.addEventListener("pointerup", (e) => {
      if (!dragState || dragState.pointerId !== e.pointerId) return;
      const wasMoved = dragState.moved;
      const rect = anchor.getBoundingClientRect();
      dragState = null;

      if (wasMoved) {
        const clamped = clampPosition(rect.left, rect.top);
        persistSettings({ mascotPos: clamped });
      } else {
        togglePanel();
      }
    });

    mascotBtn.addEventListener("pointercancel", () => {
      dragState = null;
    });

    hideBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      panelOpen = false;
      persistSettings({ showMascot: false });
    });

    closePanelBtn.addEventListener("click", () => {
      setPanelOpen(false);
    });

    masterSwitch.addEventListener("click", () => {
      const next = !settings.enabled;
      persistSettings(
        { enabled: next },
        next ? "Đã bật giao diện Cute ✨" : "Đã tạm tắt về YouTube gốc"
      );
    });

    resetBtn.addEventListener("click", () => {
      persistSettings({ mascotPos: null }, "Đã đưa mình về góc quen nè 💖");
    });

    // Outside click closes panel
    document.addEventListener("pointerdown", (e) => {
      if (!panelOpen || !hostEl) return;
      const path = e.composedPath ? e.composedPath() : [];
      if (!path.includes(hostEl)) {
        setPanelOpen(false);
      }
    });

    window.addEventListener("resize", () => {
      applyAnchorPosition();
      if (panelOpen) positionPanelNearAnchor();
    });
  }

  function clampPosition(left, top) {
    const pad = 12;
    const size = 64;
    const maxLeft = Math.max(pad, window.innerWidth - size - pad);
    const maxTop = Math.max(pad, window.innerHeight - size - pad);
    return {
      left: Math.min(Math.max(pad, Math.round(left)), maxLeft),
      top: Math.min(Math.max(pad, Math.round(top)), maxTop)
    };
  }

  function applyAnchorPosition() {
    if (!shadowRoot) return;
    const anchor = shadowRoot.querySelector(".ct-mascot-anchor");
    const bubble = shadowRoot.querySelector(".ct-bubble");
    if (!anchor) return;

    if (settings.mascotPos && typeof settings.mascotPos.left === "number" && typeof settings.mascotPos.top === "number") {
      const clamped = clampPosition(settings.mascotPos.left, settings.mascotPos.top);
      anchor.style.left = `${clamped.left}px`;
      anchor.style.top = `${clamped.top}px`;
      anchor.style.right = "auto";
      anchor.style.bottom = "auto";

      if (bubble) {
        bubble.classList.toggle("is-left", clamped.left < window.innerWidth / 2);
        bubble.classList.toggle("is-below", clamped.top < 140);
      }
    } else {
      anchor.style.left = "auto";
      anchor.style.top = "auto";
      anchor.style.right = "24px";
      anchor.style.bottom = "24px";
      if (bubble) {
        bubble.classList.remove("is-left", "is-below");
      }
    }
  }

  function positionPanelNearAnchor() {
    if (!shadowRoot) return;
    const anchor = shadowRoot.querySelector(".ct-mascot-anchor");
    const panel = shadowRoot.querySelector(".ct-panel");
    if (!anchor || !panel) return;

    const aRect = anchor.getBoundingClientRect();
    const panelW = 300;
    const panelH = Math.min(panel.scrollHeight || 460, window.innerHeight - 24);
    const gap = 12;

    let left = aRect.left + aRect.width / 2 < window.innerWidth / 2
      ? aRect.left
      : aRect.right - panelW;
    left = Math.min(Math.max(12, left), Math.max(12, window.innerWidth - panelW - 12));

    let top;
    if (aRect.top > panelH + gap + 12) {
      top = aRect.top - panelH - gap;
    } else if (window.innerHeight - aRect.bottom > panelH + gap + 12) {
      top = aRect.bottom + gap;
    } else {
      top = Math.max(12, Math.min(aRect.top, window.innerHeight - panelH - 12));
    }

    panel.style.left = `${Math.round(left)}px`;
    panel.style.top = `${Math.round(top)}px`;
  }

  function togglePanel() {
    setPanelOpen(!panelOpen);
    if (panelOpen) {
      const mascotInfo = cfg.MASCOTS[settings.mascot] || cfg.MASCOTS.cat;
      const quote = mascotInfo.quotes[quoteIndex % mascotInfo.quotes.length];
      quoteIndex += 1;
      showBubble(quote);
      triggerHappy();
    }
  }

  function setPanelOpen(open) {
    panelOpen = Boolean(open);
    if (!shadowRoot) return;
    const panel = shadowRoot.querySelector(".ct-panel");
    if (!panel) return;
    if (panelOpen) {
      updateSpeedButtons();
      positionPanelNearAnchor();
    }
    panel.classList.toggle("is-open", panelOpen);
  }

  function showBubble(text) {
    if (!shadowRoot || !settings.showMascot) return;
    const bubble = shadowRoot.querySelector(".ct-bubble");
    if (!bubble) return;
    bubble.textContent = text;
    bubble.classList.add("is-visible");
    clearTimeout(bubbleTimer);
    bubbleTimer = setTimeout(() => {
      bubble.classList.remove("is-visible");
    }, 3200);
  }

  function triggerHappy() {
    if (!shadowRoot) return;
    const btn = shadowRoot.querySelector(".ct-mascot-btn");
    if (!btn) return;
    btn.classList.remove("is-happy");
    void btn.offsetWidth;
    btn.classList.add("is-happy");
    clearTimeout(happyTimer);
    happyTimer = setTimeout(() => {
      btn.classList.remove("is-happy");
    }, 600);
  }

  function renderWidget() {
    if (!shadowRoot) return;
    const root = shadowRoot.querySelector(".ct-root");
    const theme = cfg.THEMES[settings.theme] || cfg.THEMES["lavender-dark"];

    root.style.setProperty("--w-bg", theme.bg);
    root.style.setProperty("--w-surface", theme.surface);
    root.style.setProperty("--w-surface-alt", theme.surfaceAlt);
    root.style.setProperty("--w-text", theme.text);
    root.style.setProperty("--w-muted", theme.muted);
    root.style.setProperty("--w-accent", theme.accent);
    root.style.setProperty("--w-secondary", theme.secondary);
    root.style.setProperty("--w-accent-text", theme.accentText);
    root.style.setProperty("--w-border", theme.border);
    root.style.setProperty("--w-glow", theme.glow);

    const sparklesEl = shadowRoot.querySelector(".ct-sparkles");
    if (sparklesEl) {
      sparklesEl.classList.toggle("is-hidden", !(settings.enabled && settings.sparkles));
      if (sparklesEl.dataset.theme !== settings.theme) {
        sparklesEl.dataset.theme = settings.theme;
        buildSparkles();
      }
    }

    const anchor = shadowRoot.querySelector(".ct-mascot-anchor");
    const mascotBtn = shadowRoot.querySelector(".ct-mascot-btn");
    const brandIcon = shadowRoot.querySelector(".ct-brand-icon");
    const svgHtml = cfg.getMascotSvg(settings.mascot, theme.accent, theme.secondary);

    if (anchor) {
      anchor.classList.toggle("is-hidden", !settings.showMascot);
      applyAnchorPosition();
    }
    if (mascotBtn) {
      mascotBtn.innerHTML = svgHtml;
      mascotBtn.classList.toggle("is-disabled", !settings.enabled);
    }
    if (brandIcon) {
      brandIcon.innerHTML = svgHtml;
    }

    const masterSwitch = shadowRoot.querySelector('[data-action="toggle-enabled"]');
    if (masterSwitch) {
      masterSwitch.classList.toggle("is-on", Boolean(settings.enabled));
    }

    renderThemeButtons();
    renderMascotButtons();
    renderFeatureToggles();
    updateSpeedButtons();
  }

  function renderThemeButtons() {
    const grid = shadowRoot.querySelector(".ct-theme-grid");
    if (!grid) return;
    grid.innerHTML = "";

    Object.values(cfg.THEMES).forEach((t) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = `ct-theme-btn${settings.theme === t.id ? " is-active" : ""}`;

      const swatch = document.createElement("span");
      swatch.className = "ct-swatch";
      swatch.style.background = `linear-gradient(135deg, ${t.accent}, ${t.secondary})`;

      const label = document.createElement("span");
      label.textContent = `${t.emoji} ${t.shortName}`;

      btn.appendChild(swatch);
      btn.appendChild(label);
      btn.addEventListener("click", () => {
        persistSettings({ theme: t.id, enabled: true }, `Đã đổi sang ${t.name} ${t.emoji}`);
      });
      grid.appendChild(btn);
    });
  }

  function renderMascotButtons() {
    const grid = shadowRoot.querySelector(".ct-mascot-grid");
    if (!grid) return;
    grid.innerHTML = "";

    Object.values(cfg.MASCOTS).forEach((m) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = `ct-mascot-chip${settings.mascot === m.id ? " is-active" : ""}`;
      btn.textContent = `${m.emoji} ${m.name}`;
      btn.addEventListener("click", () => {
        persistSettings({ mascot: m.id }, `Xin chào! Mình là ${m.name} ${m.emoji}`);
      });
      grid.appendChild(btn);
    });
  }

  function renderFeatureToggles() {
    const container = shadowRoot.querySelector(".ct-toggles");
    if (!container) return;
    container.innerHTML = "";

    const items = [
      { key: "roundedCards", label: "✨ Bo tròn & Thẻ mềm mại" },
      { key: "cutePlayer", label: "💖 Thanh tua video Cute ♥" },
      { key: "sparkles", label: "🌸 Hạt lấp lánh nền" },
      { key: "focusMode", label: "🫧 Tập trung (Ẩn đề xuất)" }
    ];

    items.forEach((item) => {
      const row = document.createElement("div");
      row.className = "ct-toggle-row";

      const label = document.createElement("span");
      label.textContent = item.label;

      const sw = document.createElement("div");
      sw.className = `ct-switch${settings[item.key] ? " is-on" : ""}`;

      row.appendChild(label);
      row.appendChild(sw);
      row.addEventListener("click", () => {
        persistSettings({ [item.key]: !settings[item.key] });
      });
      container.appendChild(row);
    });
  }

  function updateSpeedButtons() {
    if (!shadowRoot) return;
    const row = shadowRoot.querySelector(".ct-speed-row");
    if (!row) return;
    const video = document.querySelector("video");
    const currentRate = video ? video.playbackRate : 1;
    const rates = [0.75, 1, 1.25, 1.5, 2];

    row.innerHTML = "";
    rates.forEach((r) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = `ct-speed-btn${Math.abs(currentRate - r) < 0.01 ? " is-active" : ""}`;
      btn.textContent = `${r}x`;
      btn.addEventListener("click", () => {
        const vid = document.querySelector("video");
        if (vid) {
          vid.playbackRate = r;
          showBubble(`Tốc độ phát: ${r}x ⚡`);
        } else {
          showBubble("Mở video bất kỳ để chỉnh tốc độ nha!");
        }
        updateSpeedButtons();
      });
      row.appendChild(btn);
    });
  }

  function syncFullscreenState() {
    if (!hostEl) return;
    if (document.fullscreenElement) {
      hostEl.setAttribute("data-fullscreen", "true");
      setPanelOpen(false);
    } else {
      hostEl.removeAttribute("data-fullscreen");
    }
  }

  // Official YouTube Premium SVG lockup (exact Wikimedia Commons / YouTube vector paths, viewBox 0 0 846 174)
  const PREMIUM_LOGO_SVG = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 846 174" width="100%" height="100%" focusable="false" style="pointer-events: none; display: block; width: 100%; height: 100%;">
      <g transform="translate(0,0.36)">
        <path style="fill:#ff0033" d="M 242.88,27.11 A 31.07,31.07 0 0 0 220.95,5.18 C 201.6,0 124,0 124,0 124,0 46.46,0 27.11,5.18 A 31.07,31.07 0 0 0 5.18,27.11 C 0,46.46 0,86.82 0,86.82 c 0,0 0,40.36 5.18,59.71 a 31.07,31.07 0 0 0 21.93,21.93 c 19.35,5.18 96.92,5.18 96.92,5.18 0,0 77.57,0 96.92,-5.18 a 31.07,31.07 0 0 0 21.93,-21.93 c 5.18,-19.35 5.18,-59.71 5.18,-59.71 0,0 0,-40.36 -5.18,-59.71 z" />
        <path style="fill:#ffffff" d="M 99.22,124.03 163.67,86.82 99.22,49.61 Z" />
        <path style="fill:currentColor" d="m 358.29,55.1 v 6 c 0,30 -13.3,47.53 -42.39,47.53 h -4.43 v 52.5 H 287.71 V 12.36 H 318 c 27.7,0 40.29,11.71 40.29,42.74 z m -25,2.13 c 0,-21.64 -3.9,-26.78 -17.38,-26.78 h -4.43 v 60.48 h 4.08 c 12.77,0 17.74,-9.22 17.74,-29.26 z m 81.22,-6.56 -1.24,28.2 c -10.11,-2.13 -18.45,-0.53 -22.17,6 v 76.26 H 367.52 V 52.44 h 18.8 L 388.45,76 h 0.89 c 2.48,-17.2 10.46,-25.89 20.75,-25.89 a 22.84,22.84 0 0 1 4.42,0.56 z M 441.64,115 v 5.5 c 0,19.16 1.06,25.72 9.22,25.72 7.8,0 9.58,-6 9.75,-18.44 l 21.1,1.24 c 1.6,23.41 -10.64,33.87 -31.39,33.87 -25.18,0 -32.63,-16.49 -32.63,-46.46 v -19 c 0,-31.57 8.34,-47 33.34,-47 25.18,0 31.57,13.12 31.57,45.93 V 115 Z m 0,-22.35 v 7.8 h 17.91 V 92.7 c 0,-20 -1.42,-25.72 -9,-25.72 -7.58,0 -8.91,5.86 -8.91,25.72 z M 604.45,79 v 82.11 H 580 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 a 35.59,35.59 0 0 1 0.18,4.43 v 82.11 H 537.24 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 494.5 V 52.44 h 19.33 L 516,66.28 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.86,0 20.53,10.64 20.53,28.86 z m 12.24,-54.4 c 0,-11.71 4.26,-15.07 13.3,-15.07 9.22,0 13.3,3.9 13.3,15.07 0,12.06 -4.08,15.08 -13.3,15.08 -9.04,-0.01 -13.3,-3.02 -13.3,-15.08 z m 1.42,27.84 h 23.41 v 108.72 h -23.41 z m 103.39,0 v 108.72 h -19.15 l -2.13,-13.3 h -0.53 c -5.5,10.64 -13.48,15.07 -23.41,15.07 -14.54,0 -21.11,-9.22 -21.11,-29.26 V 52.44 h 24.47 v 79.81 c 0,9.58 2,13.48 6.92,13.48 A 12.09,12.09 0 0 0 697,138.81 V 52.44 Z M 845.64,79 v 82.11 H 821.17 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8.16,2.48 -10.82,7.09 A 35.59,35.59 0 0 1 802.9,79 v 82.11 H 778.43 V 80.82 c 0,-8.87 -2.31,-13.3 -7.63,-13.3 -4.26,0 -8,2.48 -10.64,6.92 v 86.72 H 735.69 V 52.44 H 755 l 2.13,13.83 h 0.35 c 5.5,-10.46 14.37,-16.14 24.83,-16.14 10.29,0 16.14,5.14 18.8,14.37 5.68,-9.4 14.19,-14.37 23.94,-14.37 14.95,0.01 20.59,10.65 20.59,28.87 z" />
      </g>
    </svg>
  `;

  function applyPremiumWordmark() {
    const logos = document.querySelectorAll("ytd-topbar-logo-renderer #logo-icon");
    logos.forEach((logoIcon) => {
      if (settings.enabled) {
        if (logoIcon.getAttribute("data-ct-premium") === "v3") return;
        if (!logoIcon.hasAttribute("data-ct-orig-html") && logoIcon.innerHTML.trim()) {
          logoIcon.setAttribute("data-ct-orig-html", logoIcon.innerHTML);
        }
        logoIcon.style.width = "97px";
        logoIcon.style.height = "20px";
        logoIcon.innerHTML = PREMIUM_LOGO_SVG;
        logoIcon.setAttribute("data-ct-premium", "v3");
      } else if (logoIcon.hasAttribute("data-ct-premium")) {
        const orig = logoIcon.getAttribute("data-ct-orig-html");
        if (orig) logoIcon.innerHTML = orig;
        logoIcon.removeAttribute("data-ct-premium");
      }
    });
  }

  // Event-driven YouTube wordmark styling (replaces continuous 1000ms polling)
  // Invoked on DOMContentLoaded, yt-navigate-finish, and settings change events

  // Load canonical settings from chrome.storage.local
  try {
    chrome.storage.local.get(cfg.STORAGE_KEY, (res) => {
      if (res && res[cfg.STORAGE_KEY]) {
        settings = cfg.normalizeSettings(res[cfg.STORAGE_KEY]);
      } else {
        chrome.storage.local.set({ [cfg.STORAGE_KEY]: settings });
      }
      saveCache(settings);
      applyAttributesToRoot(settings);
      renderWidget();
      applyPremiumWordmark();
    });

    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local" || !changes[cfg.STORAGE_KEY]) return;
      settings = cfg.normalizeSettings(changes[cfg.STORAGE_KEY].newValue);
      saveCache(settings);
      applyAttributesToRoot(settings);
      ensureWidgetMounted();
      renderWidget();
      applyPremiumWordmark();
    });

    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (!msg || typeof msg !== "object") return;
      if (msg.type === "CUTETUBE_OPEN_PANEL") {
        ensureWidgetMounted();
        if (!settings.showMascot) {
          persistSettings({ showMascot: true });
        }
        setPanelOpen(true);
        sendResponse({ ok: true });
      }
    });
  } catch (_) {}

  // Mount Shadow DOM widget when DOM is ready and keep alive across YouTube SPA navigations
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      ensureWidgetMounted();
      applyPremiumWordmark();
    }, { once: true });
  } else {
    ensureWidgetMounted();
    applyPremiumWordmark();
  }

  window.addEventListener("yt-navigate-finish", () => {
    ensureWidgetMounted();
    applyPremiumWordmark();
    updateSpeedButtons();
  });

  document.addEventListener("fullscreenchange", syncFullscreenState);
})();
