(function () {
  const cfg = globalThis.CuteTubeConfig;
  if (!cfg) return;

  let settings = cfg.normalizeSettings(null);
  let activeYoutubeTabId = null;

  const masterToggle = document.getElementById("masterToggle");
  const statusSub = document.getElementById("statusSub");
  const brandAvatar = document.getElementById("brandAvatar");
  const themeGrid = document.getElementById("themeGrid");
  const mascotGrid = document.getElementById("mascotGrid");
  const toggleList = document.getElementById("toggleList");
  const openActionBtn = document.getElementById("openActionBtn");

  function savePatch(patch) {
    settings = cfg.normalizeSettings(Object.assign({}, settings, patch));
    render();
    chrome.storage.local.set({ [cfg.STORAGE_KEY]: settings });
  }

  function applyPopupTheme() {
    const theme = cfg.THEMES[settings.theme] || cfg.THEMES["lavender-dark"];
    const rootStyle = document.documentElement.style;
    rootStyle.setProperty("--p-bg", theme.bg);
    rootStyle.setProperty("--p-surface", theme.surface);
    rootStyle.setProperty("--p-surface-alt", theme.surfaceAlt);
    rootStyle.setProperty("--p-text", theme.text);
    rootStyle.setProperty("--p-muted", theme.muted);
    rootStyle.setProperty("--p-accent", theme.accent);
    rootStyle.setProperty("--p-secondary", theme.secondary);
    rootStyle.setProperty("--p-accent-text", theme.accentText);
    rootStyle.setProperty("--p-border", theme.border);
    rootStyle.setProperty("--p-glow", theme.glow);
  }

  function render() {
    applyPopupTheme();
    const theme = cfg.THEMES[settings.theme] || cfg.THEMES["lavender-dark"];

    masterToggle.classList.toggle("is-on", Boolean(settings.enabled));
    statusSub.textContent = settings.enabled
      ? `${theme.emoji} ${theme.name}`
      : "Đang tạm tắt giao diện Cute";

    brandAvatar.innerHTML = cfg.getMascotSvg(settings.mascot, theme.accent, theme.secondary);

    themeGrid.innerHTML = "";
    Object.values(cfg.THEMES).forEach((t) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = `theme-card${settings.theme === t.id ? " is-active" : ""}`;

      const swatch = document.createElement("span");
      swatch.className = "swatch";
      swatch.style.background = `linear-gradient(135deg, ${t.accent}, ${t.secondary})`;

      const text = document.createElement("span");
      text.textContent = `${t.emoji} ${t.shortName}`;

      btn.appendChild(swatch);
      btn.appendChild(text);
      btn.addEventListener("click", () => {
        savePatch({ theme: t.id, enabled: true });
      });
      themeGrid.appendChild(btn);
    });

    mascotGrid.innerHTML = "";
    Object.values(cfg.MASCOTS).forEach((m) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = `mascot-btn${settings.mascot === m.id ? " is-active" : ""}`;
      btn.textContent = `${m.emoji} ${m.name}`;
      btn.addEventListener("click", () => {
        savePatch({ mascot: m.id, showMascot: true });
      });
      mascotGrid.appendChild(btn);
    });

    toggleList.innerHTML = "";
    const toggles = [
      { key: "liquidGlass", label: "🫧 Hiệu ứng Liquid Glass (Kính Thủy Tinh)" },
      { key: "showMascot", label: "🐾 Hiện nhân vật nổi trên trang" },
      { key: "roundedCards", label: "✨ Bo tròn & Thẻ mềm mại" },
      { key: "cutePlayer", label: "💖 Thanh tua video Cute ♥" },
      { key: "sparkles", label: "🌸 Hạt lấp lánh nền" },
      { key: "focusMode", label: "🫧 Tập trung (Ẩn đề xuất)" }
    ];

    toggles.forEach((item) => {
      const row = document.createElement("div");
      row.className = "toggle-row";

      const label = document.createElement("span");
      label.textContent = item.label;

      const sw = document.createElement("div");
      sw.className = `switch${settings[item.key] ? " is-on" : ""}`;

      row.appendChild(label);
      row.appendChild(sw);
      row.addEventListener("click", () => {
        savePatch({ [item.key]: !settings[item.key] });
      });
      toggleList.appendChild(row);
    });

    openActionBtn.textContent = activeYoutubeTabId
      ? "Mở bảng Cute ngay trên YouTube ✨"
      : "Mở YouTube để trải nghiệm 🎀";
  }

  masterToggle.addEventListener("click", () => {
    const nextEnabled = !settings.enabled;
    savePatch({ enabled: nextEnabled });
  });

  openActionBtn.addEventListener("click", () => {
    if (activeYoutubeTabId) {
      chrome.tabs.sendMessage(activeYoutubeTabId, { type: "CUTETUBE_OPEN_PANEL" }, () => {
        if (chrome.runtime.lastError) {
          statusSub.textContent = "Hãy F5 tải lại tab YouTube 1 lần rồi thử lại nhé ✨";
          return;
        }
        window.close();
      });
    } else {
      chrome.tabs.create({ url: "https://www.youtube.com" });
      window.close();
    }
  });

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    if (tab && tab.url && /^https?:\/\/(www\.)?youtube\.com\//i.test(tab.url)) {
      activeYoutubeTabId = tab.id;
    }
    render();
  });

  chrome.storage.local.get(cfg.STORAGE_KEY, (res) => {
    if (res && res[cfg.STORAGE_KEY]) {
      settings = cfg.normalizeSettings(res[cfg.STORAGE_KEY]);
    }
    render();
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes[cfg.STORAGE_KEY]) return;
    settings = cfg.normalizeSettings(changes[cfg.STORAGE_KEY].newValue);
    render();
  });
})();
