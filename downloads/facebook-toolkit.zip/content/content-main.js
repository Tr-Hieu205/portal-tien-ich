/**
 * Facebook Toolkit Pro - Main World Content Scriptlet
 * Injected into the page's MAIN execution world at document_start.
 * Intercepts WebSocket frames to drop typing presence (/t_tp) and read watermarks (/t_ms, /t_m_r)
 * without disrupting active chat or connection handshakes.
 */

(function () {
  'use strict';

  // Prevent multiple injections
  if (typeof window !== 'undefined' && window.__FB_TOOLKIT_WS_INTERCEPTOR_INSTALLED__) {
    return;
  }
  if (typeof window !== 'undefined') {
    window.__FB_TOOLKIT_WS_INTERCEPTOR_INSTALLED__ = true;
  }

  // Active stealth settings (defaults to true for maximum safety)
  let stealthSettings = {
    blockSeen: true,
    blockTyping: true
  };

  /**
   * Evaluates whether an outgoing WebSocket frame should be dropped.
   * @param {*} data - Raw WebSocket data (string, ArrayBuffer, Uint8Array, etc.)
   * @param {Object} settings - Stealth configuration
   * @returns {{ dropped: boolean, reason?: string, binary?: boolean, payload: * }}
   */
  function interceptWebSocketFrame(data, { blockSeen = false, blockTyping = false } = {}) {
    // Binary safety: ArrayBuffer, Uint8Array, Blob pass through safely (CONNECT, PING, media)
    if (typeof data !== 'string') {
      return { dropped: false, binary: true, payload: data };
    }

    // Substring evaluation prevents JSON.parse syntax errors on malformed payloads
    if (blockTyping && (data.includes('/t_tp') || data.includes('typ.php') || data.includes('"topic":"/t_tp"') || data.includes('"type":"typing"'))) {
      return { dropped: true, reason: 'BLOCK_TYPING', payload: data };
    }

    if (blockSeen && (data.includes('change_read_status') || (data.includes('/t_ms') && data.includes('watermark')) || data.includes('/t_m_r') || data.includes('"type":"read_receipt"'))) {
      return { dropped: true, reason: 'BLOCK_SEEN', payload: data };
    }

    return { dropped: false, payload: data };
  }

  function shouldDropWebSocketFrame(payloadStr, settings) {
    const res = interceptWebSocketFrame(payloadStr, settings);
    return res.dropped;
  }

  // Install WebSocket monkey-patching in browser context
  if (typeof window !== 'undefined' && window.WebSocket) {
    const OriginalWebSocket = window.WebSocket;

    function PatchedWebSocket(url, protocols) {
      const ws = protocols !== undefined
        ? new OriginalWebSocket(url, protocols)
        : new OriginalWebSocket(url);

      const originalSend = ws.send.bind(ws);

      ws.send = function (data) {
        try {
          const res = interceptWebSocketFrame(data, stealthSettings);
          if (res.dropped) {
            return; // Silently drop frame
          }
        } catch (e) {
          // Fail open to preserve active chat
        }
        return originalSend(data);
      };

      return ws;
    }

    // Preserve prototype chain and constants
    PatchedWebSocket.prototype = OriginalWebSocket.prototype;
    PatchedWebSocket.CONNECTING = OriginalWebSocket.CONNECTING;
    PatchedWebSocket.OPEN = OriginalWebSocket.OPEN;
    PatchedWebSocket.CLOSING = OriginalWebSocket.CLOSING;
    PatchedWebSocket.CLOSED = OriginalWebSocket.CLOSED;

    // Also patch prototype send for instances created through other pathways
    const originalProtoSend = OriginalWebSocket.prototype.send;
    OriginalWebSocket.prototype.send = function (data) {
      try {
        const res = interceptWebSocketFrame(data, stealthSettings);
        if (res.dropped) {
          return;
        }
      } catch (e) {
        // Fail open
      }
      return originalProtoSend.call(this, data);
    };

    window.WebSocket = PatchedWebSocket;

    // Bridge: Listen for configuration updates from ISOLATED world
    if (typeof window.addEventListener === 'function') {
      window.addEventListener('message', (event) => {
        if (event.source !== window || !event.data || event.data.source !== 'FB_TOOLKIT_ISOLATED') {
          return;
        }

        if (event.data.type === 'SET_STEALTH_SETTINGS' && event.data.settings) {
          stealthSettings = {
            blockSeen: Boolean(event.data.settings.blockSeen),
            blockTyping: Boolean(event.data.settings.blockTyping)
          };
        }
      });
    }

    // Request initial settings from ISOLATED world upon load
    try {
      if (typeof window.postMessage === 'function') {
        window.postMessage({
          source: 'FB_TOOLKIT_MAIN',
          type: 'REQUEST_STEALTH_SETTINGS'
        }, '*');
      }
    } catch (e) {
      // Ignore
    }
  }

  // Universal export for Node.js test environments
  if (typeof globalThis !== 'undefined') {
    globalThis.shouldDropWebSocketFrame = shouldDropWebSocketFrame;
    globalThis.interceptWebSocketFrame = interceptWebSocketFrame;
  }
  if (typeof exports !== 'undefined') {
    exports.shouldDropWebSocketFrame = shouldDropWebSocketFrame;
    exports.interceptWebSocketFrame = interceptWebSocketFrame;
  }
})();
