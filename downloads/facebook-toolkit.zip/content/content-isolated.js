/**
 * Facebook Toolkit Pro - Isolated World Content Script
 * Injected into the ISOLATED execution world at document_idle.
 * Extracts session tokens (fb_dtsg, c_user UID) and bridges messages between
 * page context (MAIN world) and background service worker.
 */

(function () {
  'use strict';

  /**
   * Extracts session authentication tokens from page DOM and cookies.
   * @param {Document} doc
   * @param {string} cookieStr
   * @returns {{ userId: string|null, dtsg: string|null }}
   */
  function extractSessionFromDocument(doc, cookieStr = '') {
    let userId = null;
    let dtsg = null;

    // 1. Extract User ID (c_user)
    if (cookieStr) {
      const match = cookieStr.match(/(?:^|;\s*)c_user=([0-9]+)/);
      if (match) userId = match[1];
    }

    if (!userId && doc) {
      const userEl = doc.querySelector ? doc.querySelector('input[name="c_user"], input[name="target_c_user"]') : null;
      if (userEl && userEl.value) userId = userEl.value;
    }

    // 2. Extract fb_dtsg
    if (doc) {
      const dtsgEl = doc.querySelector ? doc.querySelector('input[name="fb_dtsg"]') : null;
      if (dtsgEl && dtsgEl.value) dtsg = dtsgEl.value;

      // Scan inline scripts for DTSG tokens and user ID if not yet resolved
      if (doc.scripts) {
        const scripts = Array.from(doc.scripts);
        for (const s of scripts) {
          const text = s.textContent || '';
          if (!dtsg && (text.includes('DTSGInitialData') || text.includes('DTSGInitData') || text.includes('"token":"AQ'))) {
            const tokenMatch = text.match(/\["(?:DTSGInitialData|DTSGInitData)",\s*\[\],\s*\{"token":"([^"]+)"/) ||
                               text.match(/"token":"(AQ[^"]+)"/);
            if (tokenMatch) {
              dtsg = tokenMatch[1];
            }
          }
          if (!userId && (text.includes('CurrentUserInitialData') || text.includes('"USER_ID"') || text.includes('"actorID"'))) {
            const uidMatch = text.match(/"USER_ID":"([0-9]+)"/) || text.match(/"actorID":"([0-9]+)"/);
            if (uidMatch) userId = uidMatch[1];
          }
          if (dtsg && userId) {
            break;
          }
        }
      }
    }

    return { userId, dtsg };
  }

  // Runtime initialization in Chrome extension context
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    // Function to broadcast current stealth settings to MAIN world
    function syncSettingsToMainWorld(settings) {
      if (!settings) return;
      if (typeof window !== 'undefined') {
        window.postMessage({
          source: 'FB_TOOLKIT_ISOLATED',
          type: 'SET_STEALTH_SETTINGS',
          settings: {
            blockSeen: Boolean(settings.blockSeen),
            blockTyping: Boolean(settings.blockTyping)
          }
        }, '*');
      }
    }

    // Fetch initial settings from chrome.storage and sync
    if (chrome.storage && chrome.storage.local) {
      chrome.storage.local.get('stealthSettings', (res) => {
        const settings = res?.stealthSettings || { blockSeen: true, blockTyping: true };
        syncSettingsToMainWorld(settings);
      });

      // Multi-tab synchronization: broadcast when storage changes (T2_067)
      if (chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area === 'local' && changes.stealthSettings && changes.stealthSettings.newValue) {
            syncSettingsToMainWorld(changes.stealthSettings.newValue);
          }
        });
      }
    }

    // Listen for requests from MAIN world
    if (typeof window !== 'undefined') {
      window.addEventListener('message', (event) => {
        if (event.source !== window || !event.data || event.data.source !== 'FB_TOOLKIT_MAIN') {
          return;
        }

        if (event.data.type === 'REQUEST_STEALTH_SETTINGS') {
          if (chrome.storage && chrome.storage.local) {
            chrome.storage.local.get('stealthSettings', (res) => {
              const settings = res?.stealthSettings || { blockSeen: true, blockTyping: true };
              syncSettingsToMainWorld(settings);
            });
          }
        }
      });
    }

    // Listen for messages from background service worker or popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.type === 'GET_PAGE_SESSION') {
        const doc = typeof document !== 'undefined' ? document : null;
        const cookie = typeof document !== 'undefined' ? document.cookie : '';
        const session = extractSessionFromDocument(doc, cookie);
        sendResponse(session);
        return false;
      }

      if (request.type === 'SYNC_STEALTH_SETTINGS') {
        syncSettingsToMainWorld(request.settings);
        sendResponse({ success: true });
        return false;
      }
    });

    // Extract session on document idle and notify background if available
    if (typeof document !== 'undefined') {
      const session = extractSessionFromDocument(document, document.cookie);
      if (session.userId || session.dtsg) {
        try {
          const sendPromise = chrome.runtime.sendMessage({
            type: 'SESSION_INFO_UPDATE',
            payload: {
              userId: session.userId,
              dtsg: session.dtsg
            }
          });
          if (sendPromise && typeof sendPromise.catch === 'function') {
            sendPromise.catch(() => {});
          }
        } catch (e) {
          // SW may be dormant
        }
      }
    }
  }

  // Universal export for Node.js test environments
  if (typeof globalThis !== 'undefined') {
    globalThis.extractSessionFromDocument = extractSessionFromDocument;
  }
  if (typeof exports !== 'undefined') {
    exports.extractSessionFromDocument = extractSessionFromDocument;
  }
})();
