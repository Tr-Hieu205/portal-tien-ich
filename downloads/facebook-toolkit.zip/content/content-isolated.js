/**
 * Facebook Toolkit Pro - Isolated World Content Script
 * Injected into the ISOLATED execution world at document_idle.
 * Extracts session tokens (fb_dtsg, c_user UID), scrapes real friends from /friends page,
 * and bridges messages between page context (MAIN world) and background service worker.
 */

(function () {
  'use strict';

  // System route keywords and non-friend paths to reject
  const SYSTEM_ROUTES = new Set([
    'notifications', 'notification', 'reel', 'reels', 'watch', 'groups', 'gaming',
    'messages', 'message', 'stories', 'story', 'marketplace', 'settings', 'professional',
    'professional_dashboard', 'bookmarks', 'help', 'privacy', 'l.php', 'sharer',
    'dialog', 'login', 'logout', 'me', 'home', 'friends', 'events', 'saved',
    'pages', 'ad_center', 'ads', 'fundraisers', 'memories', 'feeds', 'news',
    'profile.php', 'photo', 'photo.php', 'video', 'videos', 'live', 'browse',
    'search', 'checkpoint', 'recover', 'allactivity'
  ]);

  /**
   * Validates if a scraped item is a legitimate friend candidate.
   * Eliminates notifications, system navigation links, reels, settings, and self.
   */
  function isValidFriend(item, currentUserId = null) {
    if (!item || !item.id || !item.name) return false;
    const id = String(item.id).trim().toLowerCase();
    const name = String(item.name).trim();

    // 1. Reject self
    if (currentUserId && id === String(currentUserId).trim().toLowerCase()) {
      return false;
    }

    // 2. Reject system routes and URL fragments
    if (SYSTEM_ROUTES.has(id)) return false;
    if (id.includes('.php') || id.includes('?') || id.includes('/') || id.includes('&') || id.includes('=')) {
      return false;
    }

    // 3. Reject notification strings and UI menu texts
    if (
      name.startsWith('Chưa đọc') ||
      name === 'Xem tất cả' ||
      name.includes('người theo dõi') ||
      name === 'Cài đặt' ||
      name.includes('sáng tạo nội dung') ||
      name.includes('thông báo') ||
      name.includes('Trang chủ') ||
      name === 'Bạn bè' ||
      name.length < 2
    ) {
      return false;
    }

    return true;
  }

  /**
   * Parses friend items from embedded JSON or HTML text.
   * @param {string} html
   * @param {string|null} currentUserId
   * @returns {Array<Object>}
   */
  function parseFriendsFromHtml(html, currentUserId = null) {
    if (!html || typeof html !== 'string') return [];
    const friends = [];
    const seenIds = new Set();

    // 1. Regex for Comet User nodes in JSON scripts
    const userRegex = /"__typename":"User","id":"([0-9]+)","name":"([^"]+)"(?:,"profile_picture":(?:\{"uri":"([^"]+)"\}|null))?/g;
    let match;
    while ((match = userRegex.exec(html)) !== null) {
      const [, id, rawName, avatar] = match;
      if (seenIds.has(id)) continue;

      let name = rawName;
      try {
        name = JSON.parse(`"${rawName}"`);
      } catch (_) {}

      const isLocked = name.toLowerCase().includes('người dùng facebook') ||
                       name.toLowerCase().includes('facebook user');

      const item = {
        id: String(id),
        name,
        avatarUrl: avatar ? avatar.replace(/\\/g, '') : null,
        profileUrl: `https://www.facebook.com/${id}`,
        isLocked,
        accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
        classification: isLocked ? 'DEAD_INACTIVE' : 'MODERATE',
        daysInactive: isLocked ? 999 : 0
      };

      if (isValidFriend(item, currentUserId)) {
        seenIds.add(id);
        friends.push(item);
      }
    }

    // 2. Regex for Comet collection item edges with mutual friends subtitle
    const collectionRegex = /"title":\{"text":"([^"]+)"\},"subtitle_text":(?:null|\{"text":"[^"]*"\}),"image":\{"uri":"([^"]+)"\},"url":"([^"]+)"/g;
    while ((match = collectionRegex.exec(html)) !== null) {
      const [, rawName, avatar, url] = match;
      let name = rawName;
      try { name = JSON.parse(`"${rawName}"`); } catch (_) {}
      const idMatch = url.match(/[?&]id=([0-9]+)/) || url.match(/\/user\/([0-9]+)/);
      let id = idMatch ? idMatch[1] : null;

      if (!id) {
        const userMatch = url.match(/facebook\.com\/([a-zA-Z0-9.]+)/) || url.match(/^\/([a-zA-Z0-9.]+)/);
        if (userMatch) id = userMatch[1];
      }

      if (id && !seenIds.has(id)) {
        const isLocked = name.toLowerCase().includes('người dùng facebook') ||
                         name.toLowerCase().includes('facebook user');
        const cleanUrl = url.replace(/\\/g, '');
        const item = {
          id: String(id),
          name,
          avatarUrl: avatar ? avatar.replace(/\\/g, '') : null,
          profileUrl: cleanUrl.startsWith('http') ? cleanUrl : `https://www.facebook.com${cleanUrl}`,
          isLocked,
          accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
          classification: isLocked ? 'DEAD_INACTIVE' : 'MODERATE',
          daysInactive: isLocked ? 999 : 0
        };

        if (isValidFriend(item, currentUserId)) {
          seenIds.add(id);
          friends.push(item);
        }
      }
    }

    return friends;
  }

  /**
   * Scrapes friends strictly from Facebook /friends page DOM containers.
   * Guarantees zero pollution from home feed navigation or notification popups.
   */
  function extractFriendsFromFriendsPageDOM(currentUserId = null) {
    if (typeof document === 'undefined') return [];
    const friends = [];
    const seenIds = new Set();

    // Query friend cards within the profile app section or main content grid
    const containers = document.querySelectorAll(
      'div[data-pagelet*="ProfileAppSection"] div[role="listitem"], ' +
      'div[role="main"] div[role="listitem"], ' +
      'div[data-pagelet*="ProfileAppSection"] div[style*="border-radius"]'
    );

    for (const card of Array.from(containers)) {
      const link = card.querySelector('a[role="link"][href*="facebook.com/"], a[role="link"][href^="/"]');
      if (!link) continue;

      const href = link.getAttribute('href') || '';
      const nameEl = card.querySelector('span[dir="auto"], span');
      const name = (nameEl ? nameEl.textContent : link.textContent || '').trim();

      const img = card.querySelector('img');
      const avatarUrl = img ? img.src : null;

      let id = null;
      const idMatch = href.match(/[?&]id=([0-9]+)/) || href.match(/\/user\/([0-9]+)/);
      if (idMatch) {
        id = idMatch[1];
      } else {
        const userMatch = href.match(/facebook\.com\/([a-zA-Z0-9.]+)/) || href.match(/^\/([a-zA-Z0-9.]+)/);
        if (userMatch) id = userMatch[1];
      }

      if (id && !seenIds.has(id)) {
        const isLocked = name.toLowerCase().includes('người dùng facebook') ||
                         name.toLowerCase().includes('facebook user');
        const item = {
          id: String(id),
          name,
          avatarUrl,
          profileUrl: href.startsWith('http') ? href : `https://www.facebook.com${href}`,
          isLocked,
          accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
          classification: isLocked ? 'DEAD_INACTIVE' : 'MODERATE',
          daysInactive: isLocked ? 999 : 0
        };

        if (isValidFriend(item, currentUserId)) {
          seenIds.add(id);
          friends.push(item);
        }
      }
    }

    return friends;
  }

  /**
   * Fetches the /me/friends HTML within tab context and extracts initial friends.
   */
  async function fetchFriendsFromMeFriendsPage(currentUserId = null) {
    try {
      const resp = await fetch('https://www.facebook.com/me/friends', { credentials: 'include' });
      if (!resp.ok) return [];
      const html = await resp.text();
      return parseFriendsFromHtml(html, currentUserId);
    } catch (_) {
      return [];
    }
  }

  /**
   * Extracts session authentication tokens from page DOM and cookies.
   * @param {Document} doc
   * @param {string} cookieStr
   * @returns {{ userId: string|null, dtsg: string|null }}
   */
  function extractSessionFromDocument(doc, cookieStr = '') {
    let userId = null;
    let dtsg = null;

    // 1. Extract User ID (c_user)
    if (cookieStr) {
      const match = cookieStr.match(/(?:^|;\s*)c_user=([0-9]+)/);
      if (match) userId = match[1];
    }

    if (!userId && doc) {
      const userEl = doc.querySelector ? doc.querySelector('input[name="c_user"], input[name="target_c_user"]') : null;
      if (userEl && userEl.value) userId = userEl.value;
    }

    // 2. Extract fb_dtsg
    if (doc) {
      const dtsgEl = doc.querySelector ? doc.querySelector('input[name="fb_dtsg"]') : null;
      if (dtsgEl && dtsgEl.value) dtsg = dtsgEl.value;

      // Scan inline scripts for DTSG tokens and user ID if not yet resolved
      if (doc.scripts) {
        const scripts = Array.from(doc.scripts);
        for (const s of scripts) {
          const text = s.textContent || '';
          if (!dtsg && (text.includes('DTSGInitialData') || text.includes('DTSGInitData') || text.includes('"token":"AQ'))) {
            const tokenMatch = text.match(/\["(?:DTSGInitialData|DTSGInitData)",\s*\[\],\s*\{"token":"([^"]+)"/) ||
                               text.match(/"token":"(AQ[^"]+)"/);
            if (tokenMatch) {
              dtsg = tokenMatch[1];
            }
          }
          if (!userId && (text.includes('CurrentUserInitialData') || text.includes('"USER_ID"') || text.includes('"actorID"'))) {
            const uidMatch = text.match(/"USER_ID":"([0-9]+)"/) || text.match(/"actorID":"([0-9]+)"/);
            if (uidMatch) userId = uidMatch[1];
          }
          if (dtsg && userId) {
            break;
          }
        }
      }
    }

    return { userId, dtsg };
  }

  // Runtime initialization in Chrome extension context
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    // Function to broadcast current stealth settings to MAIN world
    function syncSettingsToMainWorld(settings) {
      if (!settings) return;
      if (typeof window !== 'undefined') {
        window.postMessage({
          source: 'FB_TOOLKIT_ISOLATED',
          type: 'SET_STEALTH_SETTINGS',
          settings: {
            blockSeen: Boolean(settings.blockSeen),
            blockTyping: Boolean(settings.blockTyping)
          }
        }, '*');
      }
    }

    // Fetch initial settings from chrome.storage and sync
    if (chrome.storage && chrome.storage.local) {
      chrome.storage.local.get('stealthSettings', (res) => {
        const settings = res?.stealthSettings || { blockSeen: true, blockTyping: true };
        syncSettingsToMainWorld(settings);
      });

      // Multi-tab synchronization: broadcast when storage changes (T2_067)
      if (chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area === 'local' && changes.stealthSettings && changes.stealthSettings.newValue) {
            syncSettingsToMainWorld(changes.stealthSettings.newValue);
          }
        });
      }
    }

    // Listen for requests from MAIN world
    if (typeof window !== 'undefined') {
      window.addEventListener('message', (event) => {
        if (event.source !== window || !event.data || event.data.source !== 'FB_TOOLKIT_MAIN') {
          return;
        }

        if (event.data.type === 'REQUEST_STEALTH_SETTINGS') {
          if (chrome.storage && chrome.storage.local) {
            chrome.storage.local.get('stealthSettings', (res) => {
              const settings = res?.stealthSettings || { blockSeen: true, blockTyping: true };
              syncSettingsToMainWorld(settings);
            });
          }
        }
      });
    }

    // Listen for messages from background service worker or popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.type === 'GET_PAGE_SESSION') {
        const doc = typeof document !== 'undefined' ? document : null;
        const cookie = typeof document !== 'undefined' ? document.cookie : '';
        const session = extractSessionFromDocument(doc, cookie);
        sendResponse(session);
        return false;
      }

      if (request.type === 'SYNC_STEALTH_SETTINGS') {
        syncSettingsToMainWorld(request.settings);
        sendResponse({ success: true });
        return false;
      }

      if (request.type === 'EXTRACT_PAGE_FRIENDS') {
        (async () => {
          const currentUserId = request.currentUserId || null;
          let friends = [];
          const onFriendsPage = Boolean(
            typeof window !== 'undefined' &&
            (window.location.href.includes('/friends') || window.location.href.includes('sk=friends'))
          );

          // 1. If currently on friends page, scrape DOM cards
          if (onFriendsPage) {
            friends = extractFriendsFromFriendsPageDOM(currentUserId);
          }

          // 2. If friends page yielded 0 or not currently on friends page, fetch /me/friends
          if (friends.length === 0) {
            friends = await fetchFriendsFromMeFriendsPage(currentUserId);
          }

          // 3. Scan script tags in current page
          if (friends.length === 0 && typeof document !== 'undefined') {
            const scripts = document.querySelectorAll('script[type="application/json"]');
            for (const s of Array.from(scripts)) {
              const text = s.textContent || '';
              if (text.includes('__typename') && text.includes('User')) {
                const parsed = parseFriendsFromHtml(text, currentUserId);
                for (const p of parsed) {
                  friends.push(p);
                }
              }
            }
          }

          sendResponse({ success: true, friends, onFriendsPage });
        })();
        return true; // Keep channel open for async response
      }

      // Auto-scroll on friends page to collect all 760 friends
      if (request.type === 'AUTO_SCROLL_COLLECT_FRIENDS') {
        (async () => {
          const currentUserId = request.currentUserId || null;
          const allFriends = new Map();

          const collectCurrent = () => {
            const cur = extractFriendsFromFriendsPageDOM(currentUserId);
            for (const f of cur) {
              if (!allFriends.has(f.id)) allFriends.set(f.id, f);
            }
          };

          collectCurrent();
          let prevCount = allFriends.size;
          let stagnantLoops = 0;

          for (let i = 0; i < 40; i++) {
            window.scrollBy(0, 1200);
            await new Promise(r => setTimeout(r, 400));
            collectCurrent();

            if (allFriends.size === prevCount) {
              stagnantLoops++;
              if (stagnantLoops >= 4) break; // Reached bottom
            } else {
              stagnantLoops = 0;
              prevCount = allFriends.size;
            }
          }

          const result = Array.from(allFriends.values());
          if (chrome.storage && chrome.storage.local) {
            await chrome.storage.local.set({ cachedFriends: result });
          }
          sendResponse({ success: true, friends: result, totalCount: result.length });
        })();
        return true;
      }
    });

    // Extract session on document idle and notify background if available
    if (typeof document !== 'undefined') {
      const session = extractSessionFromDocument(document, document.cookie);
      if (session.userId || session.dtsg) {
        try {
          const sendPromise = chrome.runtime.sendMessage({
            type: 'SESSION_INFO_UPDATE',
            payload: {
              userId: session.userId,
              dtsg: session.dtsg
            }
          });
          if (sendPromise && typeof sendPromise.catch === 'function') {
            sendPromise.catch(() => {});
          }
        } catch (e) {
          // SW may be dormant
        }
      }
    }
  }

  // Universal export for Node.js test environments
  if (typeof globalThis !== 'undefined') {
    globalThis.extractSessionFromDocument = extractSessionFromDocument;
    globalThis.parseFriendsFromHtml = parseFriendsFromHtml;
    globalThis.extractFriendsFromFriendsPageDOM = extractFriendsFromFriendsPageDOM;
    globalThis.isValidFriend = isValidFriend;
  }
  if (typeof exports !== 'undefined') {
    exports.extractSessionFromDocument = extractSessionFromDocument;
    exports.parseFriendsFromHtml = parseFriendsFromHtml;
    exports.extractFriendsFromFriendsPageDOM = extractFriendsFromFriendsPageDOM;
    exports.isValidFriend = isValidFriend;
  }
})();
