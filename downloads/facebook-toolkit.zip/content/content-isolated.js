/**
 * Facebook Toolkit Pro - Isolated World Content Script
 * Injected into the ISOLATED execution world at document_idle.
 * Extracts session tokens (fb_dtsg, c_user UID) and bridges messages between
 * page context (MAIN world) and background service worker.
 */

(function () {
  'use strict';

  /**
   * Parses friend items from embedded JSON or HTML text.
   * @param {string} html
   * @returns {Array<Object>}
   */
  function parseFriendsFromHtml(html) {
    if (!html || typeof html !== 'string') return [];
    const friends = [];
    const seenIds = new Set();

    // 1. Regex for Comet User nodes in JSON scripts
    const userRegex = /"__typename":"User","id":"([0-9]+)","name":"([^"]+)"(?:,"profile_picture":(?:\{"uri":"([^"]+)"\}|null))?/g;
    let match;
    while ((match = userRegex.exec(html)) !== null) {
      const [, id, rawName, avatar] = match;
      if (seenIds.has(id)) continue;
      seenIds.add(id);

      let name = rawName;
      try {
        name = JSON.parse(`"${rawName}"`);
      } catch (_) {}

      const isLocked = name.toLowerCase().includes('người dùng facebook') ||
                       name.toLowerCase().includes('facebook user');

      friends.push({
        id: String(id),
        name,
        avatarUrl: avatar ? avatar.replace(/\\/g, '') : null,
        profileUrl: `https://www.facebook.com/${id}`,
        isLocked,
        accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
        classification: isLocked ? 'DEAD_INACTIVE' : 'MODERATE',
        daysInactive: isLocked ? 999 : 0
      });
    }

    // 2. Regex for Comet collection item edges
    const collectionRegex = /"title":\{"text":"([^"]+)"\},"subtitle_text":(?:null|\{"text":"[^"]*"\}),"image":\{"uri":"([^"]+)"\},"url":"([^"]+)"/g;
    while ((match = collectionRegex.exec(html)) !== null) {
      const [, rawName, avatar, url] = match;
      let name = rawName;
      try { name = JSON.parse(`"${rawName}"`); } catch (_) {}
      const idMatch = url.match(/[?&]id=([0-9]+)/) || url.match(/\/user\/([0-9]+)/);
      const id = idMatch ? idMatch[1] : null;
      if (id && !seenIds.has(id)) {
        seenIds.add(id);
        const isLocked = name.toLowerCase().includes('người dùng facebook') ||
                         name.toLowerCase().includes('facebook user');
        friends.push({
          id: String(id),
          name,
          avatarUrl: avatar ? avatar.replace(/\\/g, '') : null,
          profileUrl: url.replace(/\\/g, ''),
          isLocked,
          accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
          classification: isLocked ? 'DEAD_INACTIVE' : 'MODERATE',
          daysInactive: isLocked ? 999 : 0
        });
      }
    }

    return friends;
  }

  /**
   * Extracts friends from document DOM and embedded scripts.
   * @param {Document} doc
   * @returns {Array<Object>}
   */
  function extractFriendsFromDocument(doc) {
    if (!doc) return [];
    const friends = [];
    const seenIds = new Set();

    // 1. Scan inline script tags for Relay User nodes
    const scripts = doc.querySelectorAll ? doc.querySelectorAll('script[type="application/json"]') : (doc.scripts || []);
    for (const s of Array.from(scripts)) {
      const text = s.textContent || '';
      if (text.includes('__typename') && text.includes('User')) {
        const fromScript = parseFriendsFromHtml(text);
        for (const f of fromScript) {
          if (!seenIds.has(f.id)) {
            seenIds.add(f.id);
            friends.push(f);
          }
        }
      }
    }

    // 2. Scan DOM rendered links and collection cards
    if (doc.querySelectorAll) {
      const links = doc.querySelectorAll('a[role="link"][href*="facebook.com/"], a[role="link"][href^="/"]');
      for (const a of Array.from(links)) {
        const href = a.getAttribute('href') || '';
        if (
          href.includes('/friends') || href.includes('/watch') ||
          href.includes('/groups') || href.includes('/gaming') ||
          href.includes('/messages') || href.includes('/stories') ||
          href.includes('/marketplace') || href === '/' || href === '#'
        ) {
          continue;
        }

        const text = (a.innerText || a.textContent || '').trim();
        if (!text || text.length < 2 || text === 'Bạn bè' || text === 'Xem tất cả bạn bè' || text === 'Trang chủ' || text === 'Thông báo') {
          continue;
        }

        const container = a.closest('div[role="listitem"]') || a.closest('div[data-pagelet*="ProfileAppSection"]') || a.parentElement;
        const img = container ? container.querySelector('img') : null;
        const avatarUrl = img ? img.src : null;

        let id = null;
        const idMatch = href.match(/[?&]id=([0-9]+)/) || href.match(/\/user\/([0-9]+)/);
        if (idMatch) {
          id = idMatch[1];
        } else {
          const userMatch = href.match(/facebook\.com\/([a-zA-Z0-9.]+)/) || href.match(/^\/([a-zA-Z0-9.]+)/);
          if (userMatch && !['profile.php', 'photo', 'story', 'watch', 'groups'].includes(userMatch[1])) {
            id = userMatch[1];
          }
        }

        if (id && !seenIds.has(id)) {
          seenIds.add(id);
          const isLocked = text.toLowerCase().includes('người dùng facebook') || text.toLowerCase().includes('facebook user');
          friends.push({
            id: String(id),
            name: text,
            avatarUrl,
            profileUrl: href.startsWith('http') ? href : `https://www.facebook.com${href}`,
            isLocked,
            accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
            classification: isLocked ? 'DEAD_INACTIVE' : 'MODERATE',
            daysInactive: isLocked ? 999 : 0
          });
        }
      }
    }

    return friends;
  }

  /**
   * Extracts session authentication tokens from page DOM and cookies.
   * @param {Document} doc
   * @param {string} cookieStr
   * @returns {{ userId: string|null, dtsg: string|null }}
   */
  function extractSessionFromDocument(doc, cookieStr = '') {
    let userId = null;
    let dtsg = null;

    // 1. Extract User ID (c_user)
    if (cookieStr) {
      const match = cookieStr.match(/(?:^|;\s*)c_user=([0-9]+)/);
      if (match) userId = match[1];
    }

    if (!userId && doc) {
      const userEl = doc.querySelector ? doc.querySelector('input[name="c_user"], input[name="target_c_user"]') : null;
      if (userEl && userEl.value) userId = userEl.value;
    }

    // 2. Extract fb_dtsg
    if (doc) {
      const dtsgEl = doc.querySelector ? doc.querySelector('input[name="fb_dtsg"]') : null;
      if (dtsgEl && dtsgEl.value) dtsg = dtsgEl.value;

      // Scan inline scripts for DTSG tokens and user ID if not yet resolved
      if (doc.scripts) {
        const scripts = Array.from(doc.scripts);
        for (const s of scripts) {
          const text = s.textContent || '';
          if (!dtsg && (text.includes('DTSGInitialData') || text.includes('DTSGInitData') || text.includes('"token":"AQ'))) {
            const tokenMatch = text.match(/\["(?:DTSGInitialData|DTSGInitData)",\s*\[\],\s*\{"token":"([^"]+)"/) ||
                               text.match(/"token":"(AQ[^"]+)"/);
            if (tokenMatch) {
              dtsg = tokenMatch[1];
            }
          }
          if (!userId && (text.includes('CurrentUserInitialData') || text.includes('"USER_ID"') || text.includes('"actorID"'))) {
            const uidMatch = text.match(/"USER_ID":"([0-9]+)"/) || text.match(/"actorID":"([0-9]+)"/);
            if (uidMatch) userId = uidMatch[1];
          }
          if (dtsg && userId) {
            break;
          }
        }
      }
    }

    return { userId, dtsg };
  }

  // Runtime initialization in Chrome extension context
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    // Function to broadcast current stealth settings to MAIN world
    function syncSettingsToMainWorld(settings) {
      if (!settings) return;
      if (typeof window !== 'undefined') {
        window.postMessage({
          source: 'FB_TOOLKIT_ISOLATED',
          type: 'SET_STEALTH_SETTINGS',
          settings: {
            blockSeen: Boolean(settings.blockSeen),
            blockTyping: Boolean(settings.blockTyping)
          }
        }, '*');
      }
    }

    // Fetch initial settings from chrome.storage and sync
    if (chrome.storage && chrome.storage.local) {
      chrome.storage.local.get('stealthSettings', (res) => {
        const settings = res?.stealthSettings || { blockSeen: true, blockTyping: true };
        syncSettingsToMainWorld(settings);
      });

      // Multi-tab synchronization: broadcast when storage changes (T2_067)
      if (chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area === 'local' && changes.stealthSettings && changes.stealthSettings.newValue) {
            syncSettingsToMainWorld(changes.stealthSettings.newValue);
          }
        });
      }
    }

    // Listen for requests from MAIN world
    if (typeof window !== 'undefined') {
      window.addEventListener('message', (event) => {
        if (event.source !== window || !event.data || event.data.source !== 'FB_TOOLKIT_MAIN') {
          return;
        }

        if (event.data.type === 'REQUEST_STEALTH_SETTINGS') {
          if (chrome.storage && chrome.storage.local) {
            chrome.storage.local.get('stealthSettings', (res) => {
              const settings = res?.stealthSettings || { blockSeen: true, blockTyping: true };
              syncSettingsToMainWorld(settings);
            });
          }
        }
      });
    }

    // Listen for messages from background service worker or popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.type === 'GET_PAGE_SESSION') {
        const doc = typeof document !== 'undefined' ? document : null;
        const cookie = typeof document !== 'undefined' ? document.cookie : '';
        const session = extractSessionFromDocument(doc, cookie);
        sendResponse(session);
        return false;
      }

      if (request.type === 'SYNC_STEALTH_SETTINGS') {
        syncSettingsToMainWorld(request.settings);
        sendResponse({ success: true });
        return false;
      }

      if (request.type === 'EXTRACT_PAGE_FRIENDS') {
        const doc = typeof document !== 'undefined' ? document : null;
        const friends = extractFriendsFromDocument(doc);
        sendResponse({ success: true, friends });
        return false;
      }
    });

    // Extract session on document idle and notify background if available
    if (typeof document !== 'undefined') {
      const session = extractSessionFromDocument(document, document.cookie);
      if (session.userId || session.dtsg) {
        try {
          const sendPromise = chrome.runtime.sendMessage({
            type: 'SESSION_INFO_UPDATE',
            payload: {
              userId: session.userId,
              dtsg: session.dtsg
            }
          });
          if (sendPromise && typeof sendPromise.catch === 'function') {
            sendPromise.catch(() => {});
          }
        } catch (e) {
          // SW may be dormant
        }
      }
    }
  }

  // Universal export for Node.js test environments
  if (typeof globalThis !== 'undefined') {
    globalThis.extractSessionFromDocument = extractSessionFromDocument;
    globalThis.parseFriendsFromHtml = parseFriendsFromHtml;
    globalThis.extractFriendsFromDocument = extractFriendsFromDocument;
  }
  if (typeof exports !== 'undefined') {
    exports.extractSessionFromDocument = extractSessionFromDocument;
    exports.parseFriendsFromHtml = parseFriendsFromHtml;
    exports.extractFriendsFromDocument = extractFriendsFromDocument;
  }
})();
