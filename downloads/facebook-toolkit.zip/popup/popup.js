/**
 * Facebook Toolkit Pro - Popup Controller (MV3)
 */

let currentSimulationMode = true;

document.addEventListener('DOMContentLoaded', async () => {
  await loadState();
  initEventListeners();
});

async function loadState() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'GET_DASHBOARD_STATE' });
    if (!res || !res.success || !res.data) {
      console.warn('[Popup] Failed to load dashboard state:', res?.error);
      return;
    }

    const state = res.data;
    currentSimulationMode = Boolean(state.simulationMode);

    // Update Simulation Badge
    updateSimulationBadge(currentSimulationMode);

    // Update Account Info
    const accEl = document.getElementById('accountInfo');
    if (accEl) {
      if (state.session && state.session.userId) {
        accEl.textContent = `UID: ${state.session.userId}`;
      } else {
        accEl.textContent = 'Mô phỏng (Offline)';
      }
    }

    // Update Circuit Breaker Badge
    const cbBadge = document.getElementById('circuitBreakerBadge');
    if (cbBadge && state.circuitBreaker) {
      const cbState = state.circuitBreaker.state || 'CLOSED';
      if (cbState === 'CLOSED') {
        cbBadge.textContent = 'Bình thường';
        cbBadge.className = 'val badge-success';
      } else if (cbState === 'HALF_OPEN') {
        cbBadge.textContent = 'Thử nghiệm (Canary)';
        cbBadge.className = 'val badge-warning';
      } else {
        cbBadge.textContent = 'Tạm ngưng an toàn';
        cbBadge.className = 'val badge-danger';
      }
    }

    // Update Stealth Settings
    const stealth = state.stealthSettings || {};
    const seenEl = document.getElementById('blockSeenToggle');
    const typingEl = document.getElementById('blockTypingToggle');
    const shieldEl = document.getElementById('shieldToggle');

    if (seenEl) seenEl.checked = Boolean(stealth.blockSeen);
    if (typingEl) typingEl.checked = Boolean(stealth.blockTyping);
    if (shieldEl && state.session) shieldEl.checked = Boolean(state.session.isShielded);

    // Update Quota Counters
    const quotas = state.quotas || {};
    updateQuotaText('quotaUnfriend', quotas['UNFRIEND'], 50);
    updateQuotaText('quotaPoke', quotas['POKE'], 100);
    updateQuotaText('quotaReact', quotas['STORY_REACT'], 200);
    updateQuotaText('quotaPostDelete', quotas['POST_DELETE'], 100);
  } catch (err) {
    console.error('[Popup] Error connecting to background worker:', err);
  }
}

function updateSimulationBadge(isSimulation) {
  const btn = document.getElementById('toggleSimulationBtn');
  const text = document.getElementById('simulationStatusText');
  if (!btn || !text) return;

  if (isSimulation) {
    btn.className = 'pill-badge pill-simulation';
    text.textContent = 'Giả lập: BẬT';
    btn.title = 'Chế độ an toàn đang bật (không gửi request thực tới Facebook). Bấm để chuyển sang chế độ Live.';
  } else {
    btn.className = 'pill-badge pill-live';
    text.textContent = 'Trực tiếp: LIVE';
    btn.title = 'Chế độ thao tác thực đang bật. Bấm để chuyển về Giả lập.';
  }
}

function updateQuotaText(elementId, quotaObj, defaultMax) {
  const el = document.getElementById(elementId);
  if (!el) return;
  const used = quotaObj?.used ?? 0;
  const max = quotaObj?.limit ?? defaultMax;
  el.textContent = `${used} / ${max}`;
}

function initEventListeners() {
  // Toggle Simulation Mode
  const simBtn = document.getElementById('toggleSimulationBtn');
  if (simBtn) {
    simBtn.addEventListener('click', async () => {
      const newMode = !currentSimulationMode;
      const res = await chrome.runtime.sendMessage({
        type: 'SET_SIMULATION_MODE',
        enabled: newMode
      });
      if (res && res.success) {
        currentSimulationMode = newMode;
        updateSimulationBadge(newMode);
      }
    });
  }

  // Toggle Avatar Guard
  const shieldToggle = document.getElementById('shieldToggle');
  if (shieldToggle) {
    shieldToggle.addEventListener('change', async () => {
      const enabled = shieldToggle.checked;
      try {
        const res = await chrome.runtime.sendMessage({
          type: 'SET_AVATAR_SHIELD',
          enable: enabled
        });
        if (!res || !res.success) {
          shieldToggle.checked = !enabled;
          alert('Không thể cập nhật khiên avatar: ' + (res?.error || 'Lỗi không xác định'));
        }
      } catch (e) {
        shieldToggle.checked = !enabled;
      }
    });
  }

  // Toggle Stealth Settings (Seen & Typing)
  const blockSeenToggle = document.getElementById('blockSeenToggle');
  const blockTypingToggle = document.getElementById('blockTypingToggle');

  const onStealthChange = async () => {
    try {
      await chrome.runtime.sendMessage({
        type: 'UPDATE_STEALTH_SETTINGS',
        settings: {
          blockSeen: blockSeenToggle ? blockSeenToggle.checked : true,
          blockTyping: blockTypingToggle ? blockTypingToggle.checked : true
        }
      });
    } catch (e) {
      console.error('[Popup] Failed to sync stealth settings:', e);
    }
  };

  if (blockSeenToggle) blockSeenToggle.addEventListener('change', onStealthChange);
  if (blockTypingToggle) blockTypingToggle.addEventListener('change', onStealthChange);

  // Open Dashboard Button
  const openDashBtn = document.getElementById('openDashboardBtn');
  if (openDashBtn) {
    openDashBtn.addEventListener('click', () => {
      if (chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
      } else {
        chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/index.html') });
      }
    });
  }
}
