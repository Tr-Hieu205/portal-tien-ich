/**
 * Facebook Toolkit Pro - Popup Controller (MV3)
 */

let currentSimulationMode = true;

document.addEventListener('DOMContentLoaded', () => {
  // Bind listeners immediately so user clicks work unconditionally
  initEventListeners();
  loadState().catch((err) => {
    console.error('[Popup] Error loading state:', err);
  });
});

async function loadState() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'GET_DASHBOARD_STATE' });
    const accEl = document.getElementById('accountInfo');
    if (!res || !res.success || !res.data) {
      console.warn('[Popup] Failed to load dashboard state:', res?.error);
      if (accEl) {
        accEl.innerHTML = '<span style="color:#f59e0b;">Chưa kết nối FB</span> <span style="font-size:11px;text-decoration:underline;cursor:pointer;">[Mở FB]</span>';
        accEl.title = 'Bấm để mở Facebook và đăng nhập';
        accEl.onclick = () => {
          if (chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: 'https://www.facebook.com' });
          }
        };
      }
      return;
    }

    const state = res.data;
    currentSimulationMode = Boolean(state.simulationMode);

    // Update Simulation Badge
    updateSimulationBadge(currentSimulationMode);

    // Update Account Info
    if (accEl) {
      if (currentSimulationMode) {
        const uid = (state.session && state.session.userId) ? state.session.userId : '100080000000001';
        accEl.textContent = `Mô phỏng (${uid})`;
        accEl.title = 'Đang ở chế độ Giả lập (Offline an toàn). Bấm nút trên góc phải để đổi sang LIVE.';
        accEl.onclick = null;
        accEl.style.cursor = 'default';
      } else if (state.session && state.session.userId && state.session.connected !== false) {
        accEl.textContent = `UID: ${state.session.userId}`;
        accEl.title = `Đã kết nối tài khoản Facebook UID: ${state.session.userId}`;
        accEl.onclick = null;
        accEl.style.cursor = 'default';
      } else {
        accEl.innerHTML = '<span style="color:#f59e0b;">Chưa đăng nhập FB</span> <span style="font-size:11px;text-decoration:underline;cursor:pointer;">[Mở FB]</span>';
        accEl.title = 'Bấm để mở trang Facebook và đăng nhập';
        accEl.style.cursor = 'pointer';
        accEl.onclick = () => {
          if (chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: 'https://www.facebook.com' });
          }
        };
      }
    }

    // Update Circuit Breaker Badge
    const cbBadge = document.getElementById('circuitBreakerBadge');
    if (cbBadge && state.circuitBreaker) {
      const cbState = state.circuitBreaker.state || 'CLOSED';
      if (cbState === 'CLOSED') {
        cbBadge.textContent = 'Bình thường';
        cbBadge.className = 'val badge-success';
      } else if (cbState === 'HALF_OPEN') {
        cbBadge.textContent = 'Thử nghiệm (Canary)';
        cbBadge.className = 'val badge-warning';
      } else {
        cbBadge.textContent = 'Tạm ngưng an toàn';
        cbBadge.className = 'val badge-danger';
      }
    }

    // Update Stealth Settings
    const stealth = state.stealthSettings || {};
    const seenEl = document.getElementById('blockSeenToggle');
    const typingEl = document.getElementById('blockTypingToggle');
    const shieldEl = document.getElementById('shieldToggle');

    if (seenEl) seenEl.checked = Boolean(stealth.blockSeen);
    if (typingEl) typingEl.checked = Boolean(stealth.blockTyping);
    if (shieldEl && state.session) shieldEl.checked = Boolean(state.session.isShielded);

    // Update Quota Counters
    const quotas = state.quotas || {};
    updateQuotaText('quotaUnfriend', quotas['UNFRIEND'], 50);
    updateQuotaText('quotaPoke', quotas['POKE'], 100);
    updateQuotaText('quotaReact', quotas['STORY_REACT'], 200);
    updateQuotaText('quotaPostDelete', quotas['POST_DELETE'], 100);
  } catch (err) {
    console.error('[Popup] Error connecting to background worker:', err);
  }
}

function updateSimulationBadge(isSimulation) {
  const btn = document.getElementById('toggleSimulationBtn');
  const text = document.getElementById('simulationStatusText');
  if (!btn || !text) return;

  if (isSimulation) {
    btn.className = 'pill-badge pill-simulation';
    text.textContent = 'Giả lập: BẬT';
    btn.title = 'Chế độ an toàn đang bật (không gửi request thực tới Facebook). Bấm để chuyển sang chế độ Live.';
  } else {
    btn.className = 'pill-badge pill-live';
    text.textContent = 'Trực tiếp: LIVE';
    btn.title = 'Chế độ thao tác thực đang bật. Bấm để chuyển về Giả lập.';
  }
}

function updateQuotaText(elementId, quotaObj, defaultMax) {
  const el = document.getElementById(elementId);
  if (!el) return;
  const used = quotaObj?.used ?? 0;
  const max = quotaObj?.limit ?? defaultMax;
  el.textContent = `${used} / ${max}`;
}

function initEventListeners() {
  // Toggle Simulation Mode
  const simBtn = document.getElementById('toggleSimulationBtn');
  if (simBtn) {
    simBtn.addEventListener('click', async () => {
      const newMode = !currentSimulationMode;
      const res = await chrome.runtime.sendMessage({
        type: 'SET_SIMULATION_MODE',
        enabled: newMode
      });
      if (res && (res.success || res.simulationMode !== undefined)) {
        currentSimulationMode = newMode;
        updateSimulationBadge(newMode);
        await loadState();
      }
    });
  }

  // Toggle Avatar Guard
  const shieldToggle = document.getElementById('shieldToggle');
  if (shieldToggle) {
    shieldToggle.addEventListener('change', async () => {
      const enabled = shieldToggle.checked;
      try {
        const res = await chrome.runtime.sendMessage({
          type: 'SET_AVATAR_SHIELD',
          enable: enabled
        });
        if (!res || !res.success) {
          shieldToggle.checked = !enabled;
          alert('Không thể cập nhật khiên avatar: ' + (res?.error || 'Lỗi không xác định'));
        }
      } catch (e) {
        shieldToggle.checked = !enabled;
      }
    });
  }

  // Toggle Stealth Settings (Seen & Typing)
  const blockSeenToggle = document.getElementById('blockSeenToggle');
  const blockTypingToggle = document.getElementById('blockTypingToggle');

  const onStealthChange = async () => {
    try {
      await chrome.runtime.sendMessage({
        type: 'UPDATE_STEALTH_SETTINGS',
        settings: {
          blockSeen: blockSeenToggle ? blockSeenToggle.checked : true,
          blockTyping: blockTypingToggle ? blockTypingToggle.checked : true
        }
      });
    } catch (e) {
      console.error('[Popup] Failed to sync stealth settings:', e);
    }
  };

  if (blockSeenToggle) blockSeenToggle.addEventListener('change', onStealthChange);
  if (blockTypingToggle) blockTypingToggle.addEventListener('change', onStealthChange);

  // Open Dashboard Button
  const openDashBtn = document.getElementById('openDashboardBtn');
  if (openDashBtn) {
    openDashBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const dashboardUrl = chrome.runtime.getURL('dashboard/index.html');
      if (chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: dashboardUrl });
      } else if (chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
      } else {
        window.open(dashboardUrl, '_blank');
      }
    });
  }
}
