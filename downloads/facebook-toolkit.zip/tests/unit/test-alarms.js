/**
 * tests/unit/test-alarms.js
 * Comprehensive Unit Test Suite for Chrome Alarms Scheduler & Background Routines
 * Run: node --test tests/unit/test-alarms.js
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  AlarmsManager,
  ALARM_NAMES,
  DEFAULT_ALARM_INTERVALS_MIN,
  isBirthdayToday,
  renderBirthdayTemplate,
  InMemoryAlarmsBackend
} from '../../background/alarms-manager.js';
import { StorageManager } from '../../background/storage-manager.js';
import { FacebookApiClient } from '../../background/fb-api.js';
import { ActionRunner } from '../../shared/action-runner.js';
import { RateLimiter } from '../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../shared/circuit-breaker.js';
import { ACTION_TYPES, STORAGE_KEYS } from '../../shared/constants.js';
import { setupMockChrome, teardownMockChrome } from '../e2e/mock-chrome.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '../..');

test('Chrome Alarms Scheduler & Background Routines Unit Test Suite', async (t) => {
  let mockChrome;
  let inMemoryBackend;

  t.beforeEach(() => {
    mockChrome = setupMockChrome();
    inMemoryBackend = new InMemoryAlarmsBackend();
    AlarmsManager.setBackend(inMemoryBackend);
  });

  t.afterEach(() => {
    teardownMockChrome();
  });

  await t.test('1. Periodic Alarm Registration & Configuration', async (t2) => {
    await t2.test('registers periodic alarm with name and periodInMinutes', async () => {
      const registered = await AlarmsManager.registerPeriodicAlarm('TEST_ALARM_1', 30);
      assert.strictEqual(registered.name, 'TEST_ALARM_1');
      assert.strictEqual(registered.periodInMinutes, 30);

      const alarm = await AlarmsManager.getAlarm('TEST_ALARM_1');
      assert.ok(alarm);
      assert.strictEqual(alarm.name, 'TEST_ALARM_1');
      assert.strictEqual(alarm.periodInMinutes, 30);
      assert.ok(alarm.scheduledTime > Date.now());
    });

    await t2.test('getAllAlarms returns all registered alarms', async () => {
      await AlarmsManager.registerPeriodicAlarm('ALARM_A', 15);
      await AlarmsManager.registerPeriodicAlarm('ALARM_B', 60);

      const all = await AlarmsManager.getAllAlarms();
      const names = all.map(a => a.name);
      assert.ok(names.includes('ALARM_A'));
      assert.ok(names.includes('ALARM_B'));
    });

    await t2.test('re-registering alarm updates interval without duplicates', async () => {
      await AlarmsManager.registerPeriodicAlarm('UPDATABLE_ALARM', 10);
      await AlarmsManager.registerPeriodicAlarm('UPDATABLE_ALARM', 20);

      const alarm = await AlarmsManager.getAlarm('UPDATABLE_ALARM');
      assert.strictEqual(alarm.periodInMinutes, 20);

      const all = await AlarmsManager.getAllAlarms();
      const matches = all.filter(a => a.name === 'UPDATABLE_ALARM');
      assert.strictEqual(matches.length, 1);
    });
  });

  await t.test('2. Alarm Cancellation', async (t2) => {
    await t2.test('cancels active alarm and verifies it no longer exists', async () => {
      await AlarmsManager.registerPeriodicAlarm('TEMP_ALARM', 45);
      const before = await AlarmsManager.getAlarm('TEMP_ALARM');
      assert.ok(before);

      const cleared = await AlarmsManager.cancelAlarm('TEMP_ALARM');
      assert.strictEqual(cleared, true);

      const after = await AlarmsManager.getAlarm('TEMP_ALARM');
      assert.strictEqual(after, null);
    });

    await t2.test('cancelling non-existent alarm returns false without throwing', async () => {
      const cleared = await AlarmsManager.cancelAlarm('NON_EXISTENT');
      assert.strictEqual(cleared, false);
    });
  });

  await t.test('3. Alarm Event Routing & Handlers', async (t2) => {
    await t2.test('triggers registered handler when alarm fires', async () => {
      let fired = false;
      let firedAlarm = null;

      AlarmsManager.registerHandler('CUSTOM_JOB', async (alarm) => {
        fired = true;
        firedAlarm = alarm;
        return { done: true };
      });

      const res = await AlarmsManager.handleAlarm({ name: 'CUSTOM_JOB', scheduledTime: Date.now() });
      assert.strictEqual(res.handled, true);
      assert.strictEqual(fired, true);
      assert.strictEqual(firedAlarm.name, 'CUSTOM_JOB');
      assert.strictEqual(res.result.done, true);
    });

    await t2.test('returns handled false for unregistered alarm name', async () => {
      const res = await AlarmsManager.handleAlarm({ name: 'UNKNOWN_JOB' });
      assert.strictEqual(res.handled, false);
      assert.strictEqual(res.reason, 'UNREGISTERED_HANDLER');
    });

    await t2.test('returns handled false on invalid alarm object', async () => {
      const res = await AlarmsManager.handleAlarm(null);
      assert.strictEqual(res.handled, false);
      assert.strictEqual(res.reason, 'INVALID_ALARM');
    });
  });

  await t.test('4. Automated Routines & Domain Helpers', async (t2) => {
    await t2.test('isBirthdayToday correctly identifies birthdays and handles leap-year edge cases', () => {
      // 1. Regular exact date
      const testDate = new Date(2026, 10, 15); // Nov 15, 2026
      assert.strictEqual(isBirthdayToday('11-15', testDate), true);
      assert.strictEqual(isBirthdayToday('11-16', testDate), false);

      // 2. Leap-year edge case: Feb 29 birthday evaluated in non-leap year (2025)
      const feb28NonLeap = new Date(2025, 1, 28); // Feb 28, 2025
      assert.strictEqual(isBirthdayToday('02-29', feb28NonLeap), true, 'Feb 29 birthday celebrated on Feb 28 in non-leap year');

      // 3. Leap-year edge case: Feb 29 birthday evaluated on Feb 29 in leap year (2028)
      const feb29Leap = new Date(2028, 1, 29); // Feb 29, 2028
      assert.strictEqual(isBirthdayToday('02-29', feb29Leap), true, 'Feb 29 birthday on Feb 29 in leap year');

      const feb28Leap = new Date(2028, 1, 28); // Feb 28, 2028
      assert.strictEqual(isBirthdayToday('02-29', feb28Leap), false, 'Feb 29 birthday NOT celebrated on Feb 28 in leap year');

      // 4. ISO formatted date (YYYY-MM-DD and YYYY/MM/DD)
      assert.strictEqual(isBirthdayToday('1995-11-15', testDate), true, '1995-11-15 matches Nov 15');
      assert.strictEqual(isBirthdayToday('1995/11/15', testDate), true, '1995/11/15 matches Nov 15');
      assert.strictEqual(isBirthdayToday('1995-11-16', testDate), false, '1995-11-16 does not match Nov 15');
      assert.strictEqual(isBirthdayToday('11/15', testDate), true, '11/15 matches Nov 15');

      // 5. Leap-year edge case with ISO formatted year (2000-02-29) in non-leap year (2025)
      assert.strictEqual(isBirthdayToday('2000-02-29', feb28NonLeap), true, '2000-02-29 matches Feb 28 in non-leap year 2025');
      assert.strictEqual(isBirthdayToday('2000-02-29', feb29Leap), true, '2000-02-29 matches Feb 29 in leap year 2028');
      assert.strictEqual(isBirthdayToday('2000-02-29', feb28Leap), false, '2000-02-29 does not match Feb 28 in leap year 2028');

      // 6. Facebook Graph API standard format (MM/DD/YYYY and MM-DD-YYYY)
      assert.strictEqual(isBirthdayToday('11/15/1995', testDate), true, '11/15/1995 matches Nov 15');
      assert.strictEqual(isBirthdayToday('11-15-1995', testDate), true, '11-15-1995 matches Nov 15');
      assert.strictEqual(isBirthdayToday('11/16/1995', testDate), false, '11/16/1995 does not match Nov 15');
      assert.strictEqual(isBirthdayToday('02/29/2000', feb28NonLeap), true, '02/29/2000 matches Feb 28 in non-leap year 2025');
    });

    await t2.test('renderBirthdayTemplate correctly resolves tokens and handles mononyms', () => {
      const template = 'Happy birthday {first_name}! Wishing you all the best, {name}! Sincerely, {last_name}';

      // Full name
      const friend1 = { name: 'Sarah Connor' };
      const rendered1 = renderBirthdayTemplate(template, friend1);
      assert.strictEqual(rendered1, 'Happy birthday Sarah! Wishing you all the best, Sarah Connor! Sincerely, Connor');

      // Mononym
      const friend2 = { name: 'Madonna' };
      const rendered2 = renderBirthdayTemplate(template, friend2);
      assert.strictEqual(rendered2, 'Happy birthday Madonna! Wishing you all the best, Madonna! Sincerely, ');
    });

    await t2.test('handleBirthdayCheckerRoutine enforces whitelist, skips non-whitelisted friends, and greets via message channel', async () => {
      const storageManager = new StorageManager();
      await storageManager.init();

      const todayStr = '11-15';
      const mockBirthdays = [
        { friendId: 'f_already_greeted', name: 'Alice Smith', birthDate: todayStr, isToday: true },
        { friendId: 'f_whitelisted', name: 'Bob Jones', birthDate: todayStr, isToday: true },
        { friendId: 'f_not_whitelisted', name: 'Charlie Brown', birthDate: todayStr, isToday: true }
      ];

      const currentYear = new Date().getFullYear();
      await storageManager.set({
        [STORAGE_KEYS.BIRTHDAY_WHITELIST]: ['f_whitelisted', 'f_already_greeted'],
        [STORAGE_KEYS.BIRTHDAY_HISTORY]: {
          f_already_greeted: { year: currentYear, timestamp: Date.now() - 3600000, channel: 'message' }
        }
      });

      const fbApi = new FacebookApiClient({
        storageManager,
        mockDataset: { birthdays: mockBirthdays }
      });

      await AlarmsManager.init({ storageManager, fbApi });
      const routineRes = await AlarmsManager.handleBirthdayCheckerRoutine({ name: ALARM_NAMES.BIRTHDAY_CHECKER });

      assert.strictEqual(routineRes.greetedCount, 1, 'Should only greet Bob Jones who is in whitelist');
      assert.strictEqual(routineRes.skippedCount, 1, 'Should skip non-whitelisted friend');

      const skippedNotWhitelisted = routineRes.results.find(r => r.friendId === 'f_not_whitelisted');
      assert.ok(skippedNotWhitelisted);
      assert.strictEqual(skippedNotWhitelisted.skipped, true);

      const updatedHistory = (await storageManager.get(STORAGE_KEYS.BIRTHDAY_HISTORY))[STORAGE_KEYS.BIRTHDAY_HISTORY];
      assert.ok(updatedHistory.f_whitelisted);
      assert.strictEqual(updatedHistory.f_whitelisted.year, currentYear);
      assert.strictEqual(updatedHistory.f_whitelisted.channel, 'message', 'Channel in history must be message');
      assert.strictEqual(updatedHistory.f_not_whitelisted, undefined, 'Non-whitelisted friend must not be greeted or recorded');
    });

    await t2.test('handleReupRunnerRoutine handles empty queue and publishes queued post', async () => {
      const storageManager = new StorageManager();
      await storageManager.init();

      const fbApi = new FacebookApiClient({ storageManager });
      await AlarmsManager.init({ storageManager, fbApi });

      // Empty queue
      const emptyRes = await AlarmsManager.handleReupRunnerRoutine({ name: ALARM_NAMES.REUP_RUNNER });
      assert.strictEqual(emptyRes.processed, 0);

      // Enqueue item
      await storageManager.set({
        [STORAGE_KEYS.REUP_QUEUE]: [
          { id: 'reup_item_1', text: 'Scheduled automated video post', isReel: true }
        ]
      });

      const processRes = await AlarmsManager.handleReupRunnerRoutine({ name: ALARM_NAMES.REUP_RUNNER });
      assert.strictEqual(processRes.processed, 1);
      assert.strictEqual(processRes.published, true);
      assert.strictEqual(processRes.targetId, 'reup_item_1');

      // Verify queue was shifted
      const remainingQueue = (await storageManager.get(STORAGE_KEYS.REUP_QUEUE))[STORAGE_KEYS.REUP_QUEUE];
      assert.strictEqual(remainingQueue.length, 0);
    });

    await t2.test('handleQuotaPrunerRoutine triggers storage pruneRollingQuotas', async () => {
      const storageManager = new StorageManager();
      await storageManager.init();

      await AlarmsManager.init({ storageManager });
      const pruneRes = await AlarmsManager.handleQuotaPrunerRoutine({ name: ALARM_NAMES.QUOTA_PRUNER });
      assert.strictEqual(pruneRes.pruned, true);
    });
  });

  await t.test('5. Anti-Contamination Verification', () => {
    const alarmsSource = fs.readFileSync(path.join(projectRoot, 'background', 'alarms-manager.js'), 'utf8');
    const forbidden = ['locket', 'video'].join('_');
    assert(!alarmsSource.toLowerCase().includes(forbidden), 'alarms-manager.js must not contain forbidden keyword');
  });
});
