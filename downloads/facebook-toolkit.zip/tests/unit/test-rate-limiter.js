/**
 * Comprehensive Unit Tests for Rate Limiter & Circuit Breaker Engine
 * Run: node --test tests/unit/test-rate-limiter.js
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  ACTION_TYPES,
  FB_ERROR_CODES,
  CIRCUIT_BREAKER_STATES
} from '../../shared/constants.js';
import {
  boxMullerRandom,
  paretoRandom,
  calculateHumanizedDelay,
  TokenBucket,
  LeakyBucketSmoother,
  RollingQuotaTracker,
  RateLimiter
} from '../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../shared/circuit-breaker.js';

test('Rate Limiter & Circuit Breaker Unit Test Suite', async (t) => {

  await t.test('1. TokenBucket Mechanics', async (t2) => {
    await t2.test('initializes with capacity tokens', () => {
      const bucket = new TokenBucket({ capacity: 5, refillRate: 1 });
      assert.equal(bucket.getTokens(), 5);
    });

    await t2.test('decrements tokens upon successful consumption', () => {
      const bucket = new TokenBucket({ capacity: 5, refillRate: 1 });
      const res = bucket.tryConsume(2);
      assert.equal(res.allowed, true);
      assert.equal(res.remainingTokens, 3);
      assert.equal(res.waitMs, 0);
    });

    await t2.test('rejects consumption when tokens are exhausted and returns waitMs', () => {
      const bucket = new TokenBucket({ capacity: 2, refillRate: 1 });
      bucket.tryConsume(2);
      const res = bucket.tryConsume(1);
      assert.equal(res.allowed, false);
      assert.ok(res.waitMs > 0);
      assert.equal(res.waitMs, 1000);
    });

    await t2.test('continuously refills tokens over elapsed time', () => {
      const start = 1000000;
      const bucket = new TokenBucket({ capacity: 10, refillRate: 2, tokens: 0, lastRefillTimestamp: start });
      // Advance virtual time by 2.5 seconds (5 tokens should be added)
      const res = bucket.tryConsume(5, start + 2500);
      assert.equal(res.allowed, true);
      assert.equal(res.remainingTokens, 0);
    });

    await t2.test('never exceeds capacity ceiling during refill', () => {
      const start = 1000000;
      const bucket = new TokenBucket({ capacity: 5, refillRate: 10, tokens: 2, lastRefillTimestamp: start });
      bucket.refill(start + 100000); // 100s later
      assert.equal(bucket.getTokens(start + 100000), 5);
    });

    await t2.test('serializes to JSON and restores state identically', () => {
      const bucket = new TokenBucket({ capacity: 8, refillRate: 0.5, tokens: 4, lastRefillTimestamp: 123456 });
      const serialized = bucket.toJSON();
      const restored = TokenBucket.fromJSON(serialized);
      assert.equal(restored.capacity, 8);
      assert.equal(restored.refillRate, 0.5);
      assert.equal(restored.tokens, 4);
      assert.equal(restored.lastRefillTimestamp, 123456);
    });
  });

  await t.test('2. LeakyBucketSmoother Mechanics', async (t2) => {
    await t2.test('enforces minimum interval between consecutive actions', () => {
      const smoother = new LeakyBucketSmoother({ minIntervalMs: 2000 });
      const t0 = 10000;
      smoother.recordExecution(t0);

      // Immediately after execution, wait should be 2000
      assert.equal(smoother.getWaitTime(t0), 2000);
      // 500ms later, wait should be 1500
      assert.equal(smoother.getWaitTime(t0 + 500), 1500);
      // 2000ms later, wait should be 0
      assert.equal(smoother.getWaitTime(t0 + 2000), 0);
      // 3000ms later, wait should be 0
      assert.equal(smoother.getWaitTime(t0 + 3000), 0);
    });
  });

  await t.test('3. Humanized Jitter & Statistical Distributions', async (t2) => {
    await t2.test('Box-Muller clamps strictly within min and max bounds', () => {
      const min = 2000;
      const max = 4000;
      for (let i = 0; i < 500; i++) {
        const val = boxMullerRandom(3000, 300, min, max);
        assert.ok(val >= min, `Value ${val} was less than min ${min}`);
        assert.ok(val <= max, `Value ${val} was greater than max ${max}`);
      }
    });

    await t2.test('Box-Muller distribution mean approaches target over 1000 samples', () => {
      const mean = 5000;
      const stdDev = 500;
      let sum = 0;
      const n = 1000;
      for (let i = 0; i < n; i++) {
        sum += boxMullerRandom(mean, stdDev);
      }
      const sampleMean = sum / n;
      const errorMargin = Math.abs(sampleMean - mean) / mean;
      assert.ok(errorMargin < 0.05, `Sample mean ${sampleMean} deviated by ${errorMargin * 100}%`);
    });

    await t2.test('Pareto generates heavy-tail pause respecting min and max bounds', () => {
      for (let i = 0; i < 200; i++) {
        const pause = paretoRandom(2.5, 1000, 10000);
        assert.ok(pause >= 1000, `Pause ${pause} was under min 1000`);
        assert.ok(pause <= 10000, `Pause ${pause} exceeded cap 10000`);
      }
    });

    await t2.test('calculateHumanizedDelay combines base delay and jitter bounds', () => {
      const base = 4000;
      const ratio = 0.25; // 3000 to 5000 base range
      const delay = calculateHumanizedDelay(base, ratio, { distractionProbability: 0 });
      assert.ok(delay >= 3000, `Delay ${delay} below min bound 3000`);
      assert.ok(delay <= 5000, `Delay ${delay} above max bound 5000`);
    });
  });

  await t.test('4. Sliding 24-Hour Rolling Quota Tracker', async (t2) => {
    await t2.test('tracks actions up to maximum quota and disallows excess', () => {
      const tracker = new RollingQuotaTracker();
      const now = 100000000;
      const limit = 3;

      assert.equal(tracker.canExecute(ACTION_TYPES.UNFRIEND, limit, now), true);
      tracker.recordAction(ACTION_TYPES.UNFRIEND, now);
      tracker.recordAction(ACTION_TYPES.UNFRIEND, now + 100);
      assert.equal(tracker.getRemainingQuota(ACTION_TYPES.UNFRIEND, limit, now + 100), 1);

      tracker.recordAction(ACTION_TYPES.UNFRIEND, now + 200);
      assert.equal(tracker.canExecute(ACTION_TYPES.UNFRIEND, limit, now + 200), false);
      assert.equal(tracker.getRemainingQuota(ACTION_TYPES.UNFRIEND, limit, now + 200), 0);
    });

    await t2.test('prunes timestamps older than 24 hours (86,400,000 ms)', () => {
      const tracker = new RollingQuotaTracker();
      const t0 = 100000000;
      const dayMs = 86400000;

      tracker.recordAction(ACTION_TYPES.POKE, t0);
      tracker.recordAction(ACTION_TYPES.POKE, t0 + 1000);

      // Exactly 24h + 1ms later, oldest action should be pruned
      const tAfter24h = t0 + dayMs + 1;
      assert.equal(tracker.getUsage(ACTION_TYPES.POKE, tAfter24h), 1);

      // 24h after second action, all actions pruned
      assert.equal(tracker.getUsage(ACTION_TYPES.POKE, t0 + 1000 + dayMs + 1), 0);
    });

    await t2.test('calculates correct timeUntilNextSlot when quota is exhausted', () => {
      const tracker = new RollingQuotaTracker();
      const t0 = 100000000;
      const dayMs = 86400000;
      const limit = 2;

      tracker.recordAction(ACTION_TYPES.STORY_REACT, t0);
      tracker.recordAction(ACTION_TYPES.STORY_REACT, t0 + 5000);

      const checkTime = t0 + 10000;
      const wait = tracker.getTimeUntilNextSlot(ACTION_TYPES.STORY_REACT, limit, checkTime);
      assert.equal(wait, (t0 + dayMs) - checkTime);
    });

    await t2.test('isolates quotas across distinct action types', () => {
      const tracker = new RollingQuotaTracker();
      const now = Date.now();
      tracker.recordAction(ACTION_TYPES.UNFRIEND, now);
      tracker.recordAction(ACTION_TYPES.UNFRIEND, now);

      assert.equal(tracker.getUsage(ACTION_TYPES.UNFRIEND, now), 2);
      assert.equal(tracker.getUsage(ACTION_TYPES.POKE, now), 0);
    });
  });

  await t.test('5. Circuit Breaker State Machine & Error Interception', async (t2) => {
    await t2.test('starts in CLOSED state with 0 failures', () => {
      const cb = new CircuitBreaker();
      assert.equal(cb.getState(), CIRCUIT_BREAKER_STATES.CLOSED);
      assert.equal(cb.canExecute().allowed, true);
    });

    await t2.test('increments failureCount on transient errors without tripping before threshold', () => {
      const cb = new CircuitBreaker({ failureThreshold: 3 });
      const now = 1000000;
      cb.recordFailure(new Error('Connection reset'), now);
      assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.CLOSED);
      assert.equal(cb.failureCount, 1);

      cb.recordFailure(new Error('Gateway timeout'), now + 1000);
      assert.equal(cb.getState(now + 1000), CIRCUIT_BREAKER_STATES.CLOSED);
      assert.equal(cb.failureCount, 2);
    });

    await t2.test('trips to OPEN when transient failures reach failureThreshold', () => {
      const cb = new CircuitBreaker({ failureThreshold: 3 });
      const now = 1000000;
      cb.recordFailure(new Error('Err 1'), now);
      cb.recordFailure(new Error('Err 2'), now + 1000);
      cb.recordFailure(new Error('Err 3'), now + 2000);

      assert.equal(cb.getState(now + 2000), CIRCUIT_BREAKER_STATES.OPEN);
      const exec = cb.canExecute(now + 2000);
      assert.equal(exec.allowed, false);
      assert.ok(exec.waitMs > 0);
    });

    await t2.test('immediately trips to OPEN on Facebook Checkpoint code 368', () => {
      const cb = new CircuitBreaker();
      const now = 2000000;
      cb.recordFailure({ code: FB_ERROR_CODES.CHECKPOINT_368, message: 'Action Blocked' }, now);

      assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.OPEN);
      assert.equal(cb.consecutiveTrips, 1);
      assert.ok(cb.pausedUntil >= now + 900000 * 0.85); // 15 min base minus jitter
    });

    await t2.test('immediately trips to OPEN on HTTP 429 Too Many Requests', () => {
      const cb = new CircuitBreaker();
      const now = 3000000;
      cb.recordFailure({ status: 429, message: 'Too Many Requests' }, now);

      assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.OPEN);
      assert.ok(cb.pausedUntil >= now + 300000 * 0.85); // 5 min base minus jitter
    });

    await t2.test('immediately trips to OPEN on temporary block code 1357004', () => {
      const cb = new CircuitBreaker();
      const now = 4000000;
      cb.recordFailure({ code: FB_ERROR_CODES.TEMPORARY_BLOCK_1357004, message: 'Temporary feature limit' }, now);
      assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.OPEN);
    });

    await t2.test('correctly extracts error codes from primitive strings and string messages', () => {
      const cb = new CircuitBreaker();

      // raw numbers
      assert.equal(cb.extractErrorCode(368), 368);
      assert.equal(cb.extractErrorCode(429), 429);
      assert.equal(cb.extractErrorCode(1357004), 1357004);
      assert.equal(cb.extractErrorCode(1404078), 1404078);

      // raw string codes
      assert.equal(cb.extractErrorCode('368'), 368);
      assert.equal(cb.extractErrorCode('429'), 429);
      assert.equal(cb.extractErrorCode('1357004'), 1357004);
      assert.equal(cb.extractErrorCode('1404078'), 1404078);

      // strings with embedded codes
      assert.equal(cb.extractErrorCode('FB error 368 checkpoint'), 368);
      assert.equal(cb.extractErrorCode('Action throttled: 1404078'), 1404078);
      assert.equal(cb.extractErrorCode('Rate limit exceeded: 429'), 429);
      assert.equal(cb.extractErrorCode('Feature restricted 1357004 temp block'), 1357004);

      // Error objects and objects with .message
      assert.equal(cb.extractErrorCode(new Error('checkpoint 368')), 368);
      assert.equal(cb.extractErrorCode({ message: 'Error 429' }), 429);
      assert.equal(cb.extractErrorCode(new Error('Action throttled: 1404078')), 1404078);
      assert.equal(cb.extractErrorCode({ message: '1357004 block' }), 1357004);

      // objects with .code, .status, .error_code
      assert.equal(cb.extractErrorCode({ code: 368 }), 368);
      assert.equal(cb.extractErrorCode({ code: '368' }), 368);
      assert.equal(cb.extractErrorCode({ status: 429 }), 429);
      assert.equal(cb.extractErrorCode({ error_code: 1357004 }), 1357004);

      // non-matching strings or generic errors
      assert.equal(cb.extractErrorCode('random error'), null);
      assert.equal(cb.extractErrorCode('Generic error message without code'), null);
      assert.equal(cb.extractErrorCode(''), null);
      assert.equal(cb.extractErrorCode(null), null);
      assert.equal(cb.extractErrorCode(undefined), null);
      assert.equal(cb.extractErrorCode(new Error('some arbitrary failure')), null);
      assert.equal(cb.extractErrorCode({ message: 'unknown error' }), null);
    });

    await t2.test('recordFailure("368") immediately trips CircuitBreaker to OPEN with 900,000ms cooldown and isCallAllowed().allowed is false', () => {
      const now = 5000000;
      // Using jitterRatio: 0 to verify the deterministic 900,000ms base cooldown
      const cb = new CircuitBreaker({ jitterRatio: 0 });
      assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.CLOSED);
      assert.equal(cb.isCallAllowed(now).allowed, true);
      assert.equal(cb.canExecute(now).allowed, true);

      cb.recordFailure('368', now);

      assert.equal(cb.state, CIRCUIT_BREAKER_STATES.OPEN);
      assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.OPEN);
      assert.equal(cb.isCallAllowed(now).allowed, false);
      assert.equal(cb.canExecute(now).allowed, false);
      assert.equal(cb.consecutiveTrips, 1);
      assert.equal(cb.pausedUntil - now, 900000);
      assert.equal(cb.isCallAllowed(now).waitMs, 900000);

      // Also verify default CircuitBreaker instance without args
      const cbDefault = new CircuitBreaker();
      cbDefault.recordFailure('368', now);
      assert.equal(cbDefault.state, CIRCUIT_BREAKER_STATES.OPEN);
      assert.equal(cbDefault.isCallAllowed(now).allowed, false);
      assert.ok(cbDefault.pausedUntil >= now + 900000);
    });

    await t2.test('immediately trips to OPEN on primitive string critical error codes', () => {
      const rawCodes = ['368', '429', '1357004', '1404078'];
      const now = 4500000;
      for (const rawCode of rawCodes) {
        const cb = new CircuitBreaker();
        cb.recordFailure(rawCode, now);
        assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.OPEN, `Failed to trip on raw string code ${rawCode}`);
        assert.equal(cb.consecutiveTrips, 1);
        assert.equal(cb.isCallAllowed(now).allowed, false);
      }
    });

    await t2.test('immediately trips to OPEN on string messages with embedded critical error codes', () => {
      const stringMessages = [
        'FB error 368 checkpoint',
        'Action throttled: 1404078',
        'Request failed with status 429 too many requests',
        'Account temporary block 1357004 warning'
      ];
      const now = 4600000;
      for (const msg of stringMessages) {
        const cb = new CircuitBreaker();
        cb.recordFailure(msg, now);
        assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.OPEN, `Failed to trip on string message: ${msg}`);
        assert.equal(cb.consecutiveTrips, 1);
        assert.equal(cb.isCallAllowed(now).allowed, false);
      }
    });

    await t2.test('transitions from OPEN to HALF_OPEN when cooldown expires', () => {
      const cb = new CircuitBreaker({ baseCooldowns: { TRANSIENT: 10000 } });
      const now = 5000000;
      cb.trip('Test trip', 10000, now);
      assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.OPEN);

      const afterCooldown = cb.pausedUntil + 1;
      assert.equal(cb.getState(afterCooldown), CIRCUIT_BREAKER_STATES.HALF_OPEN);
    });

    await t2.test('HALF_OPEN allows exactly one probe execution', () => {
      const cb = new CircuitBreaker();
      cb.state = CIRCUIT_BREAKER_STATES.HALF_OPEN;
      cb.pausedUntil = 0;

      const firstCall = cb.canExecute();
      assert.equal(firstCall.allowed, true);
      assert.equal(firstCall.isProbe, true);

      // Concurrent second call before probe finishes should be blocked
      const secondCall = cb.canExecute();
      assert.equal(secondCall.allowed, false);
      assert.equal(secondCall.reason, 'Circuit breaker probe already in progress');
    });

    await t2.test('successful probe resets breaker from HALF_OPEN back to CLOSED', () => {
      const cb = new CircuitBreaker();
      cb.state = CIRCUIT_BREAKER_STATES.HALF_OPEN;
      cb.consecutiveTrips = 2;
      cb.failureCount = 3;

      cb.recordSuccess();
      assert.equal(cb.getState(), CIRCUIT_BREAKER_STATES.CLOSED);
      assert.equal(cb.consecutiveTrips, 0);
      assert.equal(cb.failureCount, 0);
    });

    await t2.test('failed probe escalates consecutiveTrips and extends exponential backoff', () => {
      const cb = new CircuitBreaker({ baseCooldowns: { TRANSIENT: 60000 }, jitterRatio: 0 });
      const now = 6000000;
      cb.state = CIRCUIT_BREAKER_STATES.HALF_OPEN;
      cb.consecutiveTrips = 1;

      cb.recordFailure(new Error('Probe failed'), now);
      assert.equal(cb.getState(now), CIRCUIT_BREAKER_STATES.OPEN);
      assert.equal(cb.consecutiveTrips, 2);
      // trips=2: base * 2^(2-1) = 60000 * 2 = 120000
      assert.equal(cb.pausedUntil, now + 120000);
    });

    await t2.test('serializes state to JSON and rehydrates correctly', () => {
      const cb = new CircuitBreaker({
        state: CIRCUIT_BREAKER_STATES.OPEN,
        pausedUntil: 888888,
        failureCount: 2,
        consecutiveTrips: 1,
        lastError: { message: 'Rate limit' }
      });
      const json = cb.toJSON();
      const restored = CircuitBreaker.fromJSON(json);
      assert.equal(restored.state, CIRCUIT_BREAKER_STATES.OPEN);
      assert.equal(restored.pausedUntil, 888888);
      assert.equal(restored.failureCount, 2);
      assert.equal(restored.consecutiveTrips, 1);
      assert.equal(restored.lastError.message, 'Rate limit');
    });
  });
});
