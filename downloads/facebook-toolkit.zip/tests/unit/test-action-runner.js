/**
 * tests/unit/test-action-runner.js
 * Comprehensive Unit Tests for ActionRunner Engine
 * Run: node --test tests/unit/test-action-runner.js
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { ACTION_TYPES, FB_ERROR_CODES, CIRCUIT_BREAKER_STATES } from '../../shared/constants.js';
import { ActionRunner } from '../../shared/action-runner.js';
import { StorageManager } from '../../background/storage-manager.js';
import { RateLimiter } from '../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../shared/circuit-breaker.js';

test('ActionRunner Engine Unit Test Suite', async (t) => {

  await t.test('1. Initialization & Configuration', async (t2) => {
    await t2.test('initializes with simulation mode enabled by default', () => {
      const runner = new ActionRunner();
      assert.equal(runner.isSimulation(), true);
    });

    await t2.test('toggles simulation mode via setSimulation', () => {
      const runner = new ActionRunner();
      runner.setSimulation(false);
      assert.equal(runner.isSimulation(), false);
      runner.setSimulation(true);
      assert.equal(runner.isSimulation(), true);
    });

    await t2.test('toggles fastMode for non-blocking test execution', () => {
      const runner = new ActionRunner();
      runner.setFastMode(true);
      assert.equal(runner.fastMode, true);
    });
  });

  await t.test('2. Dual-Mode Execution Verification', async (t2) => {
    await t2.test('simulation mode executes without calling live executor and returns simulated payload', async () => {
      let liveCalled = false;
      const liveExecutor = async () => {
        liveCalled = true;
        return { live: true };
      };

      const runner = new ActionRunner({ isSimulation: true, fastMode: true });
      const target = { id: 'friend_1001', name: 'John Doe' };
      const res = await runner.execute(ACTION_TYPES.UNFRIEND, target, liveExecutor);

      assert.equal(liveCalled, false, 'Live executor must NOT be called in simulation mode');
      assert.equal(res.success, true);
      assert.equal(res.isSimulation, true);
      assert.equal(res.targetId, 'friend_1001');
      assert.equal(res.result.simulated, true);
    });

    await t2.test('simulation mode invokes mockExecutor when provided in options', async () => {
      let mockCalled = false;
      const mockExecutor = async (target) => {
        mockCalled = true;
        return { customMock: true, targetId: target.id };
      };

      const runner = new ActionRunner({ isSimulation: true, fastMode: true });
      const target = { id: 'post_2001' };
      const res = await runner.execute(ACTION_TYPES.POST_DELETE, target, null, { mockExecutor });

      assert.equal(mockCalled, true);
      assert.equal(res.result.customMock, true);
      assert.equal(res.result.targetId, 'post_2001');
    });

    await t2.test('live mode calls executor with proper target and returns response', async () => {
      let liveTarget = null;
      const liveExecutor = async (target) => {
        liveTarget = target;
        return { liveSuccess: true, id: target.id };
      };

      const runner = new ActionRunner({ isSimulation: false, fastMode: true });
      const target = { id: 'friend_1002', name: 'Alice Smith' };
      const res = await runner.execute(ACTION_TYPES.POKE, target, liveExecutor);

      assert.deepEqual(liveTarget, target);
      assert.equal(res.success, true);
      assert.equal(res.isSimulation, false);
      assert.equal(res.result.liveSuccess, true);
    });
  });

  await t.test('3. Rate Limiter & Delay Integration', async (t2) => {
    await t2.test('calls rateLimiter.consume with correct actionType', async () => {
      let consumedType = null;
      const fakeLimiter = {
        async consume(type) {
          consumedType = type;
          return 50;
        },
        recordAction() {}
      };

      const runner = new ActionRunner({ rateLimiter: fakeLimiter, fastMode: true });
      await runner.execute(ACTION_TYPES.STORY_REACT, { id: 'story_3001' });

      assert.equal(consumedType, ACTION_TYPES.STORY_REACT);
    });

    await t2.test('bypasses sleep when fastMode is true', async () => {
      const fakeLimiter = {
        async consume() {
          return 5000; // 5 seconds delay requested
        },
        recordAction() {}
      };

      const runner = new ActionRunner({ rateLimiter: fakeLimiter, fastMode: true });
      const start = Date.now();
      await runner.execute(ACTION_TYPES.POKE, { id: 'friend_99' });
      const elapsed = Date.now() - start;

      assert.ok(elapsed < 200, `fastMode execution took ${elapsed}ms, expected <200ms`);
    });
  });

  await t.test('4. Rolling Quota Enforcement', async (t2) => {
    await t2.test('rejects execution when 24h rolling quota is exceeded', async () => {
      const fakeLimiter = {
        checkQuota() {
          return { allowed: false, limit: 10, used: 10 };
        }
      };

      const runner = new ActionRunner({ rateLimiter: fakeLimiter, fastMode: true });
      const target = { id: 'friend_overquota' };

      // With throwOnError: true
      await assert.rejects(
        async () => runner.execute(ACTION_TYPES.UNFRIEND, target, null, { throwOnError: true }),
        (err) => err.code === 'QUOTA_EXCEEDED'
      );

      // With throwOnError: false
      const res = await runner.execute(ACTION_TYPES.UNFRIEND, target, null, { throwOnError: false });
      assert.equal(res.success, false);
      assert.ok(res.error.includes('quota exceeded'));
    });

    await t2.test('does not invoke executor when quota exceeded', async () => {
      let executorInvoked = false;
      const liveExecutor = async () => {
        executorInvoked = true;
      };

      const fakeLimiter = {
        checkQuota() {
          return { allowed: false, limit: 5, used: 5 };
        }
      };

      const runner = new ActionRunner({ rateLimiter: fakeLimiter, isSimulation: false, fastMode: true });
      await runner.execute(ACTION_TYPES.UNFRIEND, { id: 'test' }, liveExecutor, { throwOnError: false });

      assert.equal(executorInvoked, false);
    });
  });

  await t.test('5. Circuit Breaker Interception & Checkpoint Detection', async (t2) => {
    await t2.test('blocks execution immediately when circuit breaker is OPEN', async () => {
      const cb = new CircuitBreaker();
      cb.trip('Critical checkpoint triggered', 60000);

      const runner = new ActionRunner({ circuitBreaker: cb, fastMode: true });

      await assert.rejects(
        async () => runner.execute(ACTION_TYPES.POKE, { id: 'user_1' }, null, { throwOnError: true }),
        (err) => err.code === 'CIRCUIT_BREAKER_OPEN'
      );

      const res = await runner.execute(ACTION_TYPES.POKE, { id: 'user_1' }, null, { throwOnError: false });
      assert.equal(res.success, false);
      assert.ok(res.error.includes('Circuit breaker is OPEN'));
    });

    await t2.test('records failure in circuit breaker on FB 368 checkpoint error', async () => {
      const cb = new CircuitBreaker();
      const runner = new ActionRunner({ circuitBreaker: cb, isSimulation: false, fastMode: true });

      const checkpointExecutor = async () => {
        const err = new Error('Action Blocked');
        err.code = FB_ERROR_CODES.CHECKPOINT_368;
        throw err;
      };

      await assert.rejects(
        async () => runner.execute(ACTION_TYPES.UNFRIEND, { id: 'target_1' }, checkpointExecutor),
        (err) => err.code === FB_ERROR_CODES.CHECKPOINT_368
      );

      assert.equal(cb.getState(), CIRCUIT_BREAKER_STATES.OPEN);
      assert.equal(cb.consecutiveTrips, 1);
    });

    await t2.test('records success in circuit breaker on successful execution', async () => {
      const cb = new CircuitBreaker();
      cb.state = CIRCUIT_BREAKER_STATES.HALF_OPEN;
      cb.consecutiveTrips = 1;

      const runner = new ActionRunner({ circuitBreaker: cb, isSimulation: false, fastMode: true });
      const successfulExecutor = async () => ({ success: true });

      const res = await runner.execute(ACTION_TYPES.POKE, { id: 'probe_target' }, successfulExecutor);
      assert.equal(res.success, true);
      assert.equal(cb.getState(), CIRCUIT_BREAKER_STATES.CLOSED);
    });
  });

  await t.test('6. Batch Execution & Lifecycle Hooks', async (t2) => {
    await t2.test('executes batch sequentially and invokes onProgress callback with metrics', async () => {
      const runner = new ActionRunner({ fastMode: true });
      const targets = [{ id: '1' }, { id: '2' }, { id: '3' }, { id: '4' }, { id: '5' }];

      const progressEvents = [];
      const onProgress = (info) => {
        progressEvents.push({ ...info });
      };

      const results = await runner.executeBatch(
        ACTION_TYPES.STORY_REACT,
        targets,
        null,
        { onProgress }
      );

      assert.equal(results.length, 5);
      assert.equal(progressEvents.length, 5);
      assert.equal(progressEvents[0].completed, 1);
      assert.equal(progressEvents[0].percent, 20);
      assert.equal(progressEvents[4].completed, 5);
      assert.equal(progressEvents[4].percent, 100);
    });

    await t2.test('halts batch execution when AbortSignal is aborted', async () => {
      const runner = new ActionRunner({ fastMode: true });
      const targets = [{ id: '1' }, { id: '2' }, { id: '3' }, { id: '4' }];

      const controller = new AbortController();
      let count = 0;
      const onProgress = () => {
        count++;
        if (count === 2) {
          controller.abort();
        }
      };

      const results = await runner.executeBatch(
        ACTION_TYPES.POKE,
        targets,
        null,
        { abortSignal: controller.signal, onProgress }
      );

      assert.equal(results.length, 2, 'Batch must stop after 2 items upon abort');
    });

    await t2.test('handles item error according to stopOnError flag', async () => {
      const runner = new ActionRunner({ isSimulation: false, fastMode: true });
      const targets = [{ id: '1' }, { id: '2' }, { id: '3' }];

      const executorFactory = (target) => async () => {
        if (target.id === '2') {
          throw new Error('Item 2 failed');
        }
        return { ok: true, id: target.id };
      };

      // stopOnError: false -> should continue to item 3
      const resContinue = await runner.executeBatch(
        ACTION_TYPES.POKE,
        targets,
        executorFactory,
        { stopOnError: false }
      );
      assert.equal(resContinue.length, 3);
      assert.equal(resContinue[0].success, true);
      assert.equal(resContinue[1].success, false);
      assert.equal(resContinue[2].success, true);

      // stopOnError: true -> should halt after item 2
      const resHalt = await runner.executeBatch(
        ACTION_TYPES.POKE,
        targets,
        executorFactory,
        { stopOnError: true }
      );
      assert.equal(resHalt.length, 2);
      assert.equal(resHalt[1].success, false);
    });
  });

  await t.test('7. Audit Logging & History', async (t2) => {
    await t2.test('logs action execution to storageManager.appendActionLog', async () => {
      const storage = new StorageManager();
      await storage.init();

      const runner = new ActionRunner({ storageManager: storage, fastMode: true });
      await runner.execute(ACTION_TYPES.UNFRIEND, { id: 'audit_target_1' });
      await runner.execute(ACTION_TYPES.POKE, { id: 'audit_target_2' });

      const logs = (await storage.get('actionLogs')).actionLogs;
      assert.equal(Array.isArray(logs), true);
      assert.equal(logs.length, 2);
      assert.equal(logs[0].targetId, 'audit_target_2'); // Prepended
      assert.equal(logs[1].targetId, 'audit_target_1');
    });
  });
});
