/**
 * tests/unit/test-dnr.js
 * Comprehensive Unit Test Suite for DeclarativeNetRequest Stealth Engine
 * Run: node --test tests/unit/test-dnr.js
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  DnrManager,
  DNR_RULE_IDS,
  SEEN_RULE_IDS,
  TYPING_RULE_IDS,
  ALL_STEALTH_RULE_IDS,
  STATIC_RULESET_ID,
  SEEN_DYNAMIC_RULES,
  TYPING_DYNAMIC_RULES
} from '../../background/dnr-manager.js';
import { setupMockChrome, teardownMockChrome } from '../e2e/mock-chrome.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '../..');
const rulesFilePath = path.join(projectRoot, 'rules', 'stealth-rules.json');

test('DeclarativeNetRequest Stealth Engine Unit Test Suite', async (t) => {
  let mockChrome;

  t.beforeEach(() => {
    mockChrome = setupMockChrome();
  });

  t.afterEach(() => {
    teardownMockChrome();
  });

  await t.test('1. Static Ruleset File Integrity (stealth-rules.json)', async (t2) => {
    await t2.test('file exists and parses as valid JSON array', () => {
      assert(fs.existsSync(rulesFilePath), 'rules/stealth-rules.json must exist');
      const content = fs.readFileSync(rulesFilePath, 'utf8');
      const rules = JSON.parse(content);
      assert(Array.isArray(rules), 'rules/stealth-rules.json must contain an array');
      assert(rules.length >= 2, 'Must define at least 2 static rules for Seen and Typing');
    });

    await t2.test('all static rules satisfy MV3 declarative_net_request schema', () => {
      const rules = JSON.parse(fs.readFileSync(rulesFilePath, 'utf8'));
      const seenIds = new Set();

      for (const rule of rules) {
        assert(typeof rule.id === 'number' && rule.id > 0, `Rule ID must be positive integer: ${rule.id}`);
        assert(!seenIds.has(rule.id), `Duplicate rule ID found: ${rule.id}`);
        seenIds.add(rule.id);

        assert(rule.action && rule.action.type === 'block', `Rule ${rule.id} action must be "block"`);
        assert(rule.condition && typeof rule.condition === 'object', `Rule ${rule.id} requires condition`);
        assert(rule.condition.urlFilter, `Rule ${rule.id} requires urlFilter`);
        assert(Array.isArray(rule.condition.resourceTypes), `Rule ${rule.id} requires resourceTypes array`);
        assert(rule.condition.resourceTypes.includes('xmlhttprequest'), `Rule ${rule.id} resourceTypes must include xmlhttprequest`);
      }
    });

    await t2.test('static rules match facebook and messenger endpoints', () => {
      const rules = JSON.parse(fs.readFileSync(rulesFilePath, 'utf8'));
      const filters = rules.map(r => r.condition.urlFilter);

      const matchesSeen = filters.some(f => f.includes('change_read_status.php'));
      const matchesTyping = filters.some(f => f.includes('typ.php'));

      assert.strictEqual(matchesSeen, true, 'Static rules must cover change_read_status.php');
      assert.strictEqual(matchesTyping, true, 'Static rules must cover typ.php');
    });
  });

  await t.test('2. Dynamic DNR Manager Rule Registration', async (t2) => {
    await t2.test('updateStealthRules({ blockSeen: true, blockTyping: true }) registers all 4 dynamic rules', async () => {
      const res = await DnrManager.updateStealthRules({ blockSeen: true, blockTyping: true });
      assert.strictEqual(res.success, true);
      assert.strictEqual(res.blockSeen, true);
      assert.strictEqual(res.blockTyping, true);

      const activeRules = await mockChrome.declarativeNetRequest.getDynamicRules();
      const activeIds = activeRules.map(r => r.id);

      for (const expectedId of ALL_STEALTH_RULE_IDS) {
        assert(activeIds.includes(expectedId), `Dynamic rule ID ${expectedId} must be active`);
      }
    });

    await t2.test('updateStealthRules({ blockSeen: true, blockTyping: false }) registers only Seen rules', async () => {
      await DnrManager.updateStealthRules({ blockSeen: true, blockTyping: false });
      const status = await DnrManager.getStealthStatus();

      assert.strictEqual(status.blockSeen, true);
      assert.strictEqual(status.blockTyping, false);
      assert(status.activeRuleIds.includes(DNR_RULE_IDS.SEEN_PRIMARY));
      assert(status.activeRuleIds.includes(DNR_RULE_IDS.SEEN_SECONDARY));
      assert(!status.activeRuleIds.includes(DNR_RULE_IDS.TYPING_PRIMARY));
      assert(!status.activeRuleIds.includes(DNR_RULE_IDS.TYPING_SECONDARY));
    });

    await t2.test('updateStealthRules({ blockSeen: false, blockTyping: true }) registers only Typing rules', async () => {
      await DnrManager.updateStealthRules({ blockSeen: false, blockTyping: true });
      const status = await DnrManager.getStealthStatus();

      assert.strictEqual(status.blockSeen, false);
      assert.strictEqual(status.blockTyping, true);
      assert(!status.activeRuleIds.includes(DNR_RULE_IDS.SEEN_PRIMARY));
      assert(!status.activeRuleIds.includes(DNR_RULE_IDS.SEEN_SECONDARY));
      assert(status.activeRuleIds.includes(DNR_RULE_IDS.TYPING_PRIMARY));
      assert(status.activeRuleIds.includes(DNR_RULE_IDS.TYPING_SECONDARY));
    });

    await t2.test('updateStealthRules({ blockSeen: false, blockTyping: false }) removes all dynamic rules and disables static ruleset', async () => {
      await DnrManager.updateStealthRules({ blockSeen: false, blockTyping: false });
      const status = await DnrManager.getStealthStatus();

      assert.strictEqual(status.blockSeen, false);
      assert.strictEqual(status.blockTyping, false);
      assert.strictEqual(status.activeRuleIds.length, 0);

      const enabledRulesets = await mockChrome.declarativeNetRequest.getEnabledRulesets();
      assert(!enabledRulesets.includes(STATIC_RULESET_ID), 'Static ruleset must be disabled when both features off');
    });
  });

  await t.test('3. Network URL Matching & Interception Verification', async (t2) => {
    await t2.test('blocks Seen request when blockSeen is enabled', async () => {
      await DnrManager.updateStealthRules({ blockSeen: true, blockTyping: false });

      const fbUrl = 'https://www.facebook.com/ajax/mercury/change_read_status.php?dpr=1';
      const isBlocked = mockChrome.declarativeNetRequest.__isUrlBlocked(fbUrl, 'xmlhttprequest');
      assert.strictEqual(isBlocked, true, 'Seen endpoint URL must be blocked');
    });

    await t2.test('blocks Typing request when blockTyping is enabled', async () => {
      await DnrManager.updateStealthRules({ blockSeen: false, blockTyping: true });

      const typingUrl = 'https://www.facebook.com/ajax/messaging/typ.php?is_typing=1';
      const isBlocked = mockChrome.declarativeNetRequest.__isUrlBlocked(typingUrl, 'xmlhttprequest');
      assert.strictEqual(isBlocked, true, 'Typing endpoint URL must be blocked');
    });

    await t2.test('allows regular Facebook API requests through without interception', async () => {
      await DnrManager.updateStealthRules({ blockSeen: true, blockTyping: true });

      const graphqlUrl = 'https://www.facebook.com/api/graphql/';
      const isBlocked = mockChrome.declarativeNetRequest.__isUrlBlocked(graphqlUrl, 'xmlhttprequest');
      assert.strictEqual(isBlocked, false, 'Standard GraphQL API must NOT be blocked');
    });
  });

  await t.test('4. Anti-Contamination Verification', () => {
    const dnrManagerSource = fs.readFileSync(path.join(projectRoot, 'background', 'dnr-manager.js'), 'utf8');
    const rulesSource = fs.readFileSync(rulesFilePath, 'utf8');
    const forbidden = ['locket', 'video'].join('_');

    assert(!dnrManagerSource.toLowerCase().includes(forbidden), 'dnr-manager.js must not contain forbidden keyword');
    assert(!rulesSource.toLowerCase().includes(forbidden), 'stealth-rules.json must not contain forbidden keyword');
  });
});
