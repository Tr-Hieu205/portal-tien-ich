/**
 * tests/unit/test-ui-syntax.js
 * Unit test suite verifying syntax, static parsing, and UI contracts of dashboard.js and popup.js.
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '../..');

test('UI Scripts Syntax & Static Parse Verification Suite', async (t) => {
  const dashboardPath = path.join(projectRoot, 'dashboard', 'dashboard.js');
  const popupPath = path.join(projectRoot, 'popup', 'popup.js');

  await t.test('dashboard/dashboard.js exists and passes node --check', () => {
    assert(fs.existsSync(dashboardPath), 'dashboard/dashboard.js must exist');
    assert.doesNotThrow(() => {
      execFileSync(process.execPath, ['--check', dashboardPath], { encoding: 'utf8' });
    }, 'dashboard/dashboard.js must pass node --check without syntax error');
  });

  await t.test('dashboard/dashboard.js parses cleanly in Node.js VM', () => {
    const code = fs.readFileSync(dashboardPath, 'utf8');
    assert.doesNotThrow(() => {
      new vm.Script(code, { filename: 'dashboard.js' });
    }, 'dashboard/dashboard.js must compile in vm.Script without syntax errors');
  });

  await t.test('popup/popup.js exists and passes node --check', () => {
    assert(fs.existsSync(popupPath), 'popup/popup.js must exist');
    assert.doesNotThrow(() => {
      execFileSync(process.execPath, ['--check', popupPath], { encoding: 'utf8' });
    }, 'popup/popup.js must pass node --check without syntax error');
  });

  await t.test('popup/popup.js parses cleanly in Node.js VM', () => {
    const code = fs.readFileSync(popupPath, 'utf8');
    assert.doesNotThrow(() => {
      new vm.Script(code, { filename: 'popup.js' });
    }, 'popup/popup.js must compile in vm.Script without syntax errors');
  });

  await t.test('dashboard/dashboard.js contains required boot sequence and functions', () => {
    const code = fs.readFileSync(dashboardPath, 'utf8');
    assert(code.includes('bootDashboard'), 'Must define bootDashboard sequence');
    assert(code.includes('updateHeaderAndSidebarUI'), 'Must define updateHeaderAndSidebarUI');
    assert(code.includes('refreshDashboardState'), 'Must define refreshDashboardState');
    assert(code.includes('scanFriendsList'), 'Must define scanFriendsList');
    assert(code.includes('renderFriendsTable'), 'Must define renderFriendsTable');
    assert(code.includes('friendsProgressContainer'), 'Must reference friendsProgressContainer');
  });

  await t.test('dashboard/dashboard.js contains exact logged-out text specifications', () => {
    const code = fs.readFileSync(dashboardPath, 'utf8');
    assert(code.includes('Chưa đăng nhập Facebook'), 'Must include "Chưa đăng nhập Facebook"');
    assert(code.includes('[Bấm vào đây để đăng nhập]'), 'Must include "[Bấm vào đây để đăng nhập]"');
  });

  await t.test('service-worker.js implements UNFRIEND message handler', () => {
    const swPath = path.join(projectRoot, 'background', 'service-worker.js');
    const code = fs.readFileSync(swPath, 'utf8');
    assert(code.includes("case 'UNFRIEND':"), 'service-worker.js must contain case UNFRIEND');
    assert(code.includes("case 'BATCH_UNFRIEND':"), 'service-worker.js must contain case BATCH_UNFRIEND');
  });

  await t.test('fb-api.js requestFreshDtsg includes timeout guard', () => {
    const fbApiPath = path.join(projectRoot, 'background', 'fb-api.js');
    const code = fs.readFileSync(fbApiPath, 'utf8');
    assert(code.includes('setTimeout'), 'requestFreshDtsg must include timeout guard');
  });
});
