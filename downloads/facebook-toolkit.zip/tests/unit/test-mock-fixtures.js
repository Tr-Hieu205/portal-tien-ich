/**
 * tests/unit/test-mock-fixtures.js
 * Comprehensive Unit Tests for Mock Fixtures and Deterministic PRNG
 * Run: node --test tests/unit/test-mock-fixtures.js
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { SeededPRNG, generateMockDataset, calculateInteractionScore } from '../../shared/mock-fixtures.js';

test('Mock Fixtures & Deterministic PRNG Unit Test Suite', async (t) => {

  await t.test('1. PRNG Determinism & Repeatability', async (t2) => {
    await t2.test('generates identical sequences given the same seed', () => {
      const prng1 = new SeededPRNG(12345);
      const prng2 = new SeededPRNG(12345);

      for (let i = 0; i < 1000; i++) {
        assert.equal(prng1.next(), prng2.next());
      }
    });

    await t2.test('generates different sequences given different seeds', () => {
      const prng1 = new SeededPRNG(12345);
      const prng2 = new SeededPRNG(54321);

      let matches = 0;
      for (let i = 0; i < 100; i++) {
        if (prng1.next() === prng2.next()) {
          matches++;
        }
      }
      assert.ok(matches < 5, 'Different seeds should produce different sequences');
    });

    await t2.test('nextInt respects [min, max] inclusive bounds', () => {
      const prng = new SeededPRNG(999);
      for (let i = 0; i < 5000; i++) {
        const val = prng.nextInt(10, 20);
        assert.ok(val >= 10, `val ${val} was less than 10`);
        assert.ok(val <= 20, `val ${val} was greater than 20`);
        assert.equal(Number.isInteger(val), true);
      }
    });

    await t2.test('choice and sample return expected items without mutation', () => {
      const prng = new SeededPRNG(777);
      const items = ['apple', 'banana', 'cherry', 'date', 'elderberry'];
      const chosen = prng.choice(items);
      assert.ok(items.includes(chosen));

      const sampled = prng.sample(items, 3);
      assert.equal(sampled.length, 3);
      const uniqueSampled = new Set(sampled);
      assert.equal(uniqueSampled.size, 3);
      assert.equal(items.length, 5, 'Original array must not be mutated');
    });
  });

  const dataset = generateMockDataset(1337);

  await t.test('2. 150 Friends Dataset Verification', async (t2) => {
    await t2.test('generates exactly 150 friends', () => {
      assert.equal(dataset.friends.length, 150);
    });

    await t2.test('every friend complies with the friend schema', () => {
      for (const friend of dataset.friends) {
        assert.ok(typeof friend.id === 'string' && friend.id.length > 5, 'friend.id must be valid');
        assert.ok(typeof friend.name === 'string' && friend.name.includes(' '), 'friend.name must be full name');
        assert.ok(friend.profileUrl.startsWith('https://www.facebook.com/'), 'profileUrl must match FB format');
        assert.ok(friend.avatarUrl.includes('graph.facebook.com'), 'avatarUrl must match graph format');
        assert.ok(typeof friend.mutualFriends === 'number');
        assert.ok(typeof friend.messageCount === 'number');
        assert.ok(typeof friend.daysSinceLastInteraction === 'number');
        assert.ok(typeof friend.reactionCount === 'number');
        assert.ok(typeof friend.commentCount === 'number');
        assert.ok(typeof friend.interactionScore === 'number');
        assert.ok(['ghost', 'inactive', 'moderate', 'active'].includes(friend.tier));
        assert.ok(typeof friend.unfriendEligible === 'boolean');
      }
    });

    await t2.test('contains diverse engagement tiers (ghost, inactive, moderate, active)', () => {
      const ghosts = dataset.friends.filter(f => f.tier === 'ghost');
      const inactives = dataset.friends.filter(f => f.tier === 'inactive');
      const moderates = dataset.friends.filter(f => f.tier === 'moderate');
      const actives = dataset.friends.filter(f => f.tier === 'active');

      assert.ok(ghosts.length >= 20, `Expected >=20 ghosts, got ${ghosts.length}`);
      assert.ok(inactives.length >= 30, `Expected >=30 inactive, got ${inactives.length}`);
      assert.ok(moderates.length >= 30, `Expected >=30 moderate, got ${moderates.length}`);
      assert.ok(actives.length >= 20, `Expected >=20 active, got ${actives.length}`);
    });

    await t2.test('interactionScore is mathematically bounded [0, 100]', () => {
      for (const friend of dataset.friends) {
        assert.ok(friend.interactionScore >= 0, `Score ${friend.interactionScore} was negative`);
        assert.ok(friend.interactionScore <= 100, `Score ${friend.interactionScore} exceeded 100`);
      }
    });

    await t2.test('unfriendEligible is true for ghost and inactive tiers', () => {
      const eligible = dataset.friends.filter(f => f.unfriendEligible);
      for (const friend of eligible) {
        assert.ok(friend.tier === 'ghost' || friend.tier === 'inactive');
      }
      const ineligible = dataset.friends.filter(f => !f.unfriendEligible);
      for (const friend of ineligible) {
        assert.ok(friend.tier === 'moderate' || friend.tier === 'active');
      }
    });
  });

  await t.test('3. Content Cleanup Datasets (Posts, Comments, Albums, Videos)', async (t2) => {
    await t2.test('generates 50 timeline posts with diverse dates and keywords', () => {
      assert.equal(dataset.posts.length, 50);

      const hasExKeyword = dataset.posts.some(p => p.content.toLowerCase().includes('ex'));
      assert.ok(hasExKeyword, 'Posts must include keyword "ex"');

      const hasBirthdayKeyword = dataset.posts.some(p => p.content.toLowerCase().includes('happy birthday'));
      assert.ok(hasBirthdayKeyword, 'Posts must include keyword "happy birthday"');

      const olderThanYear = dataset.posts.some(p => {
        const daysAgo = (1731657600000 - p.timestamp) / 86400000;
        return daysAgo > 365;
      });
      assert.ok(olderThanYear, 'Posts must contain entries older than 365 days');
    });

    await t2.test('generates 5 photo albums with high-res and standard photo URLs', () => {
      assert.equal(dataset.albums.length, 5);
      for (const album of dataset.albums) {
        assert.ok(album.title.length > 0);
        assert.ok(album.photos.length >= 10);
        for (const photo of album.photos) {
          assert.ok(photo.highResUrl.startsWith('https://scontent.xx.fbcdn.net/'));
          assert.ok(photo.width > 0);
          assert.ok(photo.height > 0);
        }
      }
    });

    await t2.test('generates 10 videos with valid HD and SD MP4 stream URLs', () => {
      assert.equal(dataset.videos.length, 10);
      for (const video of dataset.videos) {
        assert.ok(video.hdUrl.endsWith('.mp4'));
        assert.ok(video.sdUrl.endsWith('.mp4'));
        assert.ok(video.durationSec > 0);
      }
    });
  });

  await t.test('4. Conversations & Birthdays Datasets', async (t2) => {
    await t2.test('generates 20 message conversation threads linked to friends', () => {
      assert.equal(dataset.threads.length, 20);
      const friendIds = new Set(dataset.friends.map(f => f.id));
      for (const thread of dataset.threads) {
        assert.ok(friendIds.has(thread.participantId), `Thread participant ${thread.participantId} not in friends`);
        assert.ok(thread.messages.length > 0);
      }
    });

    await t2.test('generates 15 upcoming birthdays within 0 to 30 days', () => {
      assert.equal(dataset.birthdays.length, 15);
      for (const bday of dataset.birthdays) {
        assert.ok(bday.daysUntil >= 0 && bday.daysUntil <= 30);
        assert.ok(/^\d{2}-\d{2}$/.test(bday.birthDate));
      }
    });
  });

  await t.test('5. Strict Anti-Contamination Verification', async (t2) => {
    await t2.test('ensures zero occurrences of forbidden string anywhere in mock fixtures', () => {
      const json = JSON.stringify(dataset);
      const forbidden = ['locket', 'video'].join('_');
      assert.ok(!json.toLowerCase().includes(forbidden), 'Contamination detected: forbidden term found in mock fixtures!');
    });
  });
});
