/**
 * tests/unit/test-fb-api.js
 * Comprehensive Unit Test Suite for Facebook API Client & Profile Shield (Avatar Guard)
 * Run: node --test tests/unit/test-fb-api.js
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  FacebookApiClient,
  buildAvatarShieldPayload,
  FB_GRAPHQL_ENDPOINT,
  AVATAR_SHIELD_DOC_ID
} from '../../background/fb-api.js';
import { StorageManager } from '../../background/storage-manager.js';
import { ActionRunner } from '../../shared/action-runner.js';
import { RateLimiter } from '../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../shared/circuit-breaker.js';
import { ACTION_TYPES, FB_ERROR_CODES, STORAGE_KEYS } from '../../shared/constants.js';
import { setupMockChrome, teardownMockChrome } from '../e2e/mock-chrome.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '../..');

test('Facebook API Client & Avatar Guard Unit Test Suite', async (t) => {
  let mockChrome;
  let storageManager;
  let runner;

  t.beforeEach(async () => {
    mockChrome = setupMockChrome();
    storageManager = new StorageManager();
    await storageManager.init();
    runner = new ActionRunner({
      storageManager,
      rateLimiter: new RateLimiter(),
      circuitBreaker: new CircuitBreaker(),
      isSimulation: true,
      fastMode: true
    });
  });

  t.afterEach(() => {
    teardownMockChrome();
  });

  await t.test('1. Instantiation & Simulation Mode Control', async (t2) => {
    await t2.test('initializes with simulation mode true by default', () => {
      const client = new FacebookApiClient();
      assert.strictEqual(client.isSimulation, true);
    });

    await t2.test('toggles simulation mode via setSimulation', () => {
      const client = new FacebookApiClient();
      client.setSimulation(false);
      assert.strictEqual(client.isSimulation, false);
      client.setSimulation(true);
      assert.strictEqual(client.isSimulation, true);
    });

    await t2.test('accepts injected storageManager and actionRunner', () => {
      const client = new FacebookApiClient({ storageManager, actionRunner: runner });
      assert.strictEqual(client.storageManager, storageManager);
      assert.strictEqual(client.actionRunner, runner);
    });
  });

  await t.test('2. Session Extraction & Auth Handling', async (t2) => {
    await t2.test('simulation mode returns synthetic userId, dtsg, and initial isShielded false', async () => {
      const client = new FacebookApiClient({ storageManager });
      const session = await client.getSessionInfo();
      assert.ok(session.userId);
      assert.ok(session.dtsg);
      assert.strictEqual(session.isShielded, false);
    });

    await t2.test('live mode throws AUTH_REQUIRED when c_user cookie is missing', async () => {
      const client = new FacebookApiClient({ isSimulation: false });
      let caught = null;
      try {
        await client.getSessionInfo();
      } catch (err) {
        caught = err;
      }
      assert.ok(caught);
      assert.strictEqual(caught.code, 'AUTH_REQUIRED');
    });

    await t2.test('live mode returns bridge credentials when provided', async () => {
      const client = new FacebookApiClient({ isSimulation: false });
      client.setBridgeCredentials('100088887777', 'AQFreshDtsgToken');
      const session = await client.getSessionInfo();
      assert.strictEqual(session.userId, '100088887777');
      assert.strictEqual(session.dtsg, 'AQFreshDtsgToken');
    });
  });

  await t.test('3. Profile Picture Shield (Avatar Guard)', async (t2) => {
    await t2.test('simulation mode setAvatarShield(true) returns isShielded true and persists to storage', async () => {
      const client = new FacebookApiClient({ storageManager, actionRunner: runner });
      const res = await client.setAvatarShield(true);
      assert.strictEqual(res.success, true);
      assert.strictEqual(res.isShielded, true);

      const stored = await storageManager.get('isShielded');
      assert.strictEqual(stored.isShielded, true);

      const session = await client.getSessionInfo();
      assert.strictEqual(session.isShielded, true);
    });

    await t2.test('simulation mode setAvatarShield(false) returns isShielded false and persists to storage', async () => {
      const client = new FacebookApiClient({ storageManager, actionRunner: runner });
      await client.setAvatarShield(true);
      const res = await client.setAvatarShield(false);
      assert.strictEqual(res.success, true);
      assert.strictEqual(res.isShielded, false);

      const stored = await storageManager.get('isShielded');
      assert.strictEqual(stored.isShielded, false);
    });

    await t2.test('idempotent calls preserve shield state', async () => {
      const client = new FacebookApiClient({ storageManager, actionRunner: runner });
      await client.setAvatarShield(true);
      const second = await client.setAvatarShield(true);
      assert.strictEqual(second.success, true);
      assert.strictEqual(second.isShielded, true);
    });

    await t2.test('buildAvatarShieldPayload constructs valid GraphQL payload conforming to schema', () => {
      const payload = buildAvatarShieldPayload({
        actorId: '100088880001',
        dtsg: 'AQTestDtsg',
        enable: true,
        clientMutationId: 'test_mut_123'
      });

      assert.strictEqual(payload.url, FB_GRAPHQL_ENDPOINT);
      assert.strictEqual(payload.docId, AVATAR_SHIELD_DOC_ID);

      const params = new URLSearchParams(payload.body);
      assert.strictEqual(params.get('av'), '100088880001');
      assert.strictEqual(params.get('__user'), '100088880001');
      assert.strictEqual(params.get('fb_dtsg'), 'AQTestDtsg');
      assert.strictEqual(params.get('fb_api_caller_class'), 'RelayModern');
      assert.strictEqual(params.get('fb_api_req_friendly_name'), 'IsShieldedSetMutation');
      assert.strictEqual(params.get('doc_id'), AVATAR_SHIELD_DOC_ID);

      const vars = JSON.parse(params.get('variables'));
      assert.strictEqual(vars.input.actor_id, '100088880001');
      assert.strictEqual(vars.input.is_shielded, true);
      assert.strictEqual(vars.input.client_mutation_id, 'test_mut_123');
    });

    await t2.test('live mode handles stale token error 1357001 by dynamically refreshing token and retrying', async () => {
      let callCount = 0;
      let lastDtsgUsed = null;

      const mockFetch = async (url, options) => {
        callCount++;
        const params = new URLSearchParams(options.body);
        lastDtsgUsed = params.get('fb_dtsg');

        if (callCount === 1) {
          return {
            ok: true,
            json: async () => ({
              errors: [{ message: 'Stale CSRF token', code: 1357001 }]
            })
          };
        }

        return {
          ok: true,
          json: async () => ({
            data: { is_shielded_set: { is_shielded: true } }
          })
        };
      };

      const freshTokenMock = 'dynamic_fresh_dtsg_token_999';
      let refreshCalled = false;
      const client = new FacebookApiClient({
        isSimulation: false,
        storageManager,
        fetchFn: mockFetch,
        tokenRefreshFn: async () => {
          refreshCalled = true;
          return freshTokenMock;
        }
      });
      client.setBridgeCredentials('100088880001', 'stale_token_1');

      const res = await client.setAvatarShield(true);
      assert.strictEqual(refreshCalled, true, 'tokenRefreshFn should be invoked on error 1357001');
      assert.strictEqual(callCount, 2, 'Should retry once with fresh token');
      assert.strictEqual(res.success, true);
      assert.strictEqual(res.isShielded, true);
      assert.strictEqual(lastDtsgUsed, freshTokenMock);
    });

    await t2.test('requestFreshDtsg dynamically extracts DTSG from HTML when tokenRefreshFn is not provided', async () => {
      const mockFetch = async (url) => {
        if (url === 'https://www.facebook.com/') {
          return {
            ok: true,
            text: async () => '<html><head><script>["DTSGInitialData",[],{"token":"AQGScrapedDtsgToken123"}]</script></head></html>'
          };
        }
        return { ok: false };
      };

      const client = new FacebookApiClient({
        isSimulation: false,
        fetchFn: mockFetch
      });

      const fresh = await client.requestFreshDtsg();
      assert.strictEqual(fresh, 'AQGScrapedDtsgToken123');
    });

    await t2.test('live mode re-throws 1357001 if token refresh cannot obtain a different token', async () => {
      const mockFetch = async () => {
        return {
          ok: true,
          json: async () => ({
            errors: [{ message: 'Stale CSRF token', code: 1357001 }]
          })
        };
      };

      const client = new FacebookApiClient({
        isSimulation: false,
        storageManager,
        fetchFn: mockFetch,
        tokenRefreshFn: async () => null // Refresh fails to provide a new token
      });
      client.setBridgeCredentials('100088880001', 'unrefreshable_stale_token');

      let caught = null;
      try {
        await client.setAvatarShield(true);
      } catch (err) {
        caught = err;
      }

      assert.ok(caught);
      assert.strictEqual(caught.code, 1357001);
    });

    await t2.test('live mode generic error without code (HTTP 500) does not invoke requestFreshDtsg', async () => {
      let refreshInvoked = false;
      const client = new FacebookApiClient({
        isSimulation: false,
        fetchFn: async () => ({ ok: false, status: 500 }),
        tokenRefreshFn: async () => {
          refreshInvoked = true;
          return 'new_token';
        }
      });
      client.setBridgeCredentials('100088880001', 'token_1');

      let caught = null;
      try {
        await client.setAvatarShield(true);
      } catch (err) {
        caught = err;
      }

      assert.ok(caught);
      assert.strictEqual(caught.message.includes('500'), true);
      assert.strictEqual(refreshInvoked, false, 'Generic HTTP 500 error must NOT trigger token refresh');
    });

    await t2.test('live mode handles string error code "1357001" by dynamically refreshing token and retrying', async () => {
      let callCount = 0;
      let lastDtsgUsed = null;
      let refreshCalled = false;

      const mockFetch = async (url, options) => {
        callCount++;
        const params = new URLSearchParams(options.body);
        lastDtsgUsed = params.get('fb_dtsg');

        if (callCount === 1) {
          return {
            ok: true,
            json: async () => ({
              errors: [{ message: 'Stale CSRF token', code: '1357001' }]
            })
          };
        }

        return {
          ok: true,
          json: async () => ({
            data: { is_shielded_set: { is_shielded: true } }
          })
        };
      };

      const freshTokenMock = 'dynamic_fresh_dtsg_token_from_string_code';
      const client = new FacebookApiClient({
        isSimulation: false,
        storageManager,
        fetchFn: mockFetch,
        tokenRefreshFn: async () => {
          refreshCalled = true;
          return freshTokenMock;
        }
      });
      client.setBridgeCredentials('100088880001', 'stale_token_str');

      const res = await client.setAvatarShield(true);
      assert.strictEqual(refreshCalled, true, 'tokenRefreshFn should be invoked on string error code "1357001"');
      assert.strictEqual(callCount, 2, 'Should retry mutation with refreshed token');
      assert.strictEqual(res.success, true);
      assert.strictEqual(res.isShielded, true);
      assert.strictEqual(lastDtsgUsed, freshTokenMock);
    });

    await t2.test('live mode propagates Facebook checkpoint error (code 368 / 1404078)', async () => {
      const mockFetch = async () => ({
        ok: true,
        json: async () => ({
          error: { message: 'Security checkpoint required', code: FB_ERROR_CODES.CHECKPOINT_368 }
        })
      });

      const client = new FacebookApiClient({
        isSimulation: false,
        storageManager,
        fetchFn: mockFetch
      });
      client.setBridgeCredentials('100088880001', 'test_token');

      let caught = null;
      try {
        await client.setAvatarShield(true);
      } catch (err) {
        caught = err;
      }

      assert.ok(caught);
      assert.strictEqual(caught.code, FB_ERROR_CODES.CHECKPOINT_368);
    });

    await t2.test('live mode propagates HTTP 429 Too Many Requests', async () => {
      const mockFetch = async () => ({
        ok: false,
        status: 429
      });

      const client = new FacebookApiClient({
        isSimulation: false,
        storageManager,
        fetchFn: mockFetch
      });
      client.setBridgeCredentials('100088880001', 'test_token');

      let caught = null;
      try {
        await client.setAvatarShield(true);
      } catch (err) {
        caught = err;
      }

      assert.ok(caught);
      assert.strictEqual(caught.code, FB_ERROR_CODES.TOO_MANY_REQUESTS_429);
    });
  });

  await t.test('4. ActionRunner Integration & Audit Logging', async (t2) => {
    await t2.test('setAvatarShield logs action to storage when run through ActionRunner', async () => {
      const client = new FacebookApiClient({ storageManager, actionRunner: runner });
      await client.setAvatarShield(true);

      const stored = await storageManager.get(STORAGE_KEYS.ACTION_LOGS);
      const logs = stored[STORAGE_KEYS.ACTION_LOGS] || [];
      assert.ok(logs.length > 0);
      assert.strictEqual(logs[0].actionType, ACTION_TYPES.AVATAR_GUARD);
      assert.strictEqual(logs[0].success, true);
    });

    await t2.test('live mode setAvatarShield with OPEN CircuitBreaker is blocked and throws without calling fetchFn', async () => {
      const cb = new CircuitBreaker();
      cb.trip('Manual Trip for Test');
      assert.strictEqual(cb.getState(), 'OPEN');

      let fetchCalled = false;
      const testRunner = new ActionRunner({
        circuitBreaker: cb,
        isSimulation: false,
        fastMode: true
      });

      const client = new FacebookApiClient({
        actionRunner: testRunner,
        isSimulation: false,
        fetchFn: async () => {
          fetchCalled = true;
          return { ok: true, json: async () => ({}) };
        }
      });
      client.setBridgeCredentials('100088880001', 'token_1');

      let caught = null;
      try {
        await client.setAvatarShield(true);
      } catch (err) {
        caught = err;
      }

      assert.ok(caught);
      assert.strictEqual(caught.code, 'CIRCUIT_BREAKER_OPEN');
      assert.strictEqual(fetchCalled, false, 'fetchFn must NOT be called when CircuitBreaker is OPEN');
    });

    await t2.test('live mode setAvatarShield records checkpoint error 368 into CircuitBreaker and logs action', async () => {
      const cb = new CircuitBreaker();
      assert.strictEqual(cb.getState(), 'CLOSED');

      const testRunner = new ActionRunner({
        storageManager,
        circuitBreaker: cb,
        isSimulation: false,
        fastMode: true
      });

      const mockFetch = async () => ({
        ok: true,
        json: async () => ({
          error: { message: 'Action blocked by checkpoint', code: FB_ERROR_CODES.CHECKPOINT_368 }
        })
      });

      const client = new FacebookApiClient({
        actionRunner: testRunner,
        storageManager,
        isSimulation: false,
        fetchFn: mockFetch
      });
      client.setBridgeCredentials('100088880001', 'token_1');

      let caught = null;
      try {
        await client.setAvatarShield(true);
      } catch (err) {
        caught = err;
      }

      assert.ok(caught);
      assert.strictEqual(caught.code, FB_ERROR_CODES.CHECKPOINT_368);
      assert.strictEqual(cb.getState(), 'OPEN', 'CircuitBreaker should trip to OPEN on checkpoint 368');

      const stored = await storageManager.get(STORAGE_KEYS.ACTION_LOGS);
      const logs = stored[STORAGE_KEYS.ACTION_LOGS] || [];
      assert.ok(logs.length > 0, 'ActionRunner should record action log in storage');
      const lastLog = logs[logs.length - 1];
      assert.strictEqual(lastLog.actionType, ACTION_TYPES.AVATAR_GUARD);
      assert.strictEqual(lastLog.success, false);
      assert.ok(lastLog.error.includes('Action blocked by checkpoint'));
    });
  });

  await t.test('5. IFacebookApiClient Interface Contract Conformance', async (t2) => {
    const client = new FacebookApiClient({ storageManager });

    await t2.test('scanFriends returns friend array and dispatches progress callback', async () => {
      let progressCalls = 0;
      const friends = await client.scanFriends((cur, total) => {
        progressCalls++;
      });
      assert(Array.isArray(friends));
      assert(friends.length > 0);
      assert(progressCalls > 0);
    });

    await t2.test('computeInactivity correctly evaluates friends and sets unfriendEligible', () => {
      const ghostFriend = {
        id: 'f_ghost',
        name: 'Ghost User',
        daysSinceLastInteraction: 400,
        messageCount: 0,
        reactionCount: 0,
        commentCount: 0
      };
      const activeFriend = {
        id: 'f_active',
        name: 'Active User',
        daysSinceLastInteraction: 2,
        messageCount: 150,
        reactionCount: 50,
        commentCount: 30
      };

      const ghostComputed = client.computeInactivity(ghostFriend);
      const activeComputed = client.computeInactivity(activeFriend);

      assert.strictEqual(ghostComputed.classification, 'DEAD_INACTIVE');
      assert.strictEqual(ghostComputed.unfriendEligible, true);

      assert.strictEqual(activeComputed.classification, 'ACTIVE');
      assert.strictEqual(activeComputed.unfriendEligible, false);
    });

    await t2.test('unfriend, poke, reactStory execute successfully', async () => {
      const unfriendRes = await client.unfriend('100088880001');
      assert.strictEqual(unfriendRes.success, true);

      const pokeRes = await client.poke('100088880001');
      assert.strictEqual(pokeRes.success, true);

      const reactRes = await client.reactStory('story_101', 'LOVE');
      assert.strictEqual(reactRes.success, true);
    });

    await t2.test('scanTimeline filters by keyword and date range', async () => {
      const allPosts = await client.scanTimeline();
      assert(Array.isArray(allPosts));
      assert(allPosts.length > 0);

      const birthdayPosts = await client.scanTimeline({ keyword: 'birthday' });
      assert(birthdayPosts.every(p => (p.content || p.message || '').toLowerCase().includes('birthday')));
    });

    await t2.test('deletePost, hidePost, archivePost execute successfully', async () => {
      const del = await client.deletePost('post_101');
      assert.strictEqual(del.success, true);

      const hide = await client.hidePost('post_101');
      assert.strictEqual(hide.success, true);

      const arc = await client.archivePost('post_101');
      assert.strictEqual(arc.success, true);
    });

    await t2.test('fetchAlbumPhotos and fetchVideoStreams return media items', async () => {
      const photos = await client.fetchAlbumPhotos('album_301');
      assert(Array.isArray(photos));

      const video = await client.fetchVideoStreams('https://www.facebook.com/watch/?v=12345678');
      assert.ok(video.hdUrl || video.sdUrl);
    });

    await t2.test('fetchBirthdays and sendBirthdayGreeting execute successfully', async () => {
      const bdays = await client.fetchBirthdays();
      assert(Array.isArray(bdays));

      const greet = await client.sendBirthdayGreeting('100088889999', 'Happy birthday!', 'message');
      assert.strictEqual(greet.success, true);
      assert.strictEqual(greet.channel, 'message', 'Channel must be message');
    });

    await t2.test('publishPost executes successfully for status and reel', async () => {
      const post = await client.publishPost({ text: 'Hello status' });
      assert.strictEqual(post.success, true);
      assert.ok(post.postId);

      const reel = await client.publishPost({ text: 'Reel clip', isReel: true });
      assert.strictEqual(reel.success, true);
      assert.strictEqual(reel.isReel, true);
    });
  });

  await t.test('6. Anti-Contamination Verification', () => {
    const fbApiSource = fs.readFileSync(path.join(projectRoot, 'background', 'fb-api.js'), 'utf8');
    const forbidden = ['locket', 'video'].join('_');
    assert(!fbApiSource.toLowerCase().includes(forbidden), 'fb-api.js must not contain forbidden keyword');
  });
});
