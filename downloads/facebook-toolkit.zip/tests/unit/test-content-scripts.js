/**
 * tests/unit/test-content-scripts.js
 * Comprehensive Unit Test Suite for Dual-World Content Scripts
 * Run: node --test tests/unit/test-content-scripts.js
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Load content scripts into Node environment
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '../..');

await import('../../content/content-main.js');
await import('../../content/content-isolated.js');

const { interceptWebSocketFrame, shouldDropWebSocketFrame } = globalThis;
const { extractSessionFromDocument } = globalThis;

test('Dual-World Content Scripts Unit Test Suite', async (t) => {
  await t.test('1. WebSocket Frame Interception & Dropping Logic (content-main.js)', async (t2) => {
    await t2.test('drops typing indicator /t_tp when blockTyping is enabled', () => {
      const typingPayload = JSON.stringify({ topic: '/t_tp', payload: { is_typing: true } });
      const res = interceptWebSocketFrame(typingPayload, { blockTyping: true });
      assert.strictEqual(res.dropped, true);
      assert.strictEqual(res.reason, 'BLOCK_TYPING');
      assert.strictEqual(shouldDropWebSocketFrame(typingPayload, { blockTyping: true }), true);
    });

    await t2.test('allows typing indicator /t_tp when blockTyping is disabled', () => {
      const typingPayload = JSON.stringify({ topic: '/t_tp', payload: { is_typing: true } });
      const res = interceptWebSocketFrame(typingPayload, { blockTyping: false });
      assert.strictEqual(res.dropped, false);
      assert.strictEqual(shouldDropWebSocketFrame(typingPayload, { blockTyping: false }), false);
    });

    await t2.test('drops legacy typ.php frame when blockTyping is enabled', () => {
      const payload = 'action=typ.php&typing=1';
      const res = interceptWebSocketFrame(payload, { blockTyping: true });
      assert.strictEqual(res.dropped, true);
      assert.strictEqual(res.reason, 'BLOCK_TYPING');
    });

    await t2.test('drops /t_ms watermark frame when blockSeen is enabled', () => {
      const watermarkPayload = JSON.stringify({ topic: '/t_ms', watermark: 1731657600000 });
      const res = interceptWebSocketFrame(watermarkPayload, { blockSeen: true });
      assert.strictEqual(res.dropped, true);
      assert.strictEqual(res.reason, 'BLOCK_SEEN');
      assert.strictEqual(shouldDropWebSocketFrame(watermarkPayload, { blockSeen: true }), true);
    });

    await t2.test('allows /t_ms watermark frame when blockSeen is disabled', () => {
      const watermarkPayload = JSON.stringify({ topic: '/t_ms', watermark: 1731657600000 });
      const res = interceptWebSocketFrame(watermarkPayload, { blockSeen: false });
      assert.strictEqual(res.dropped, false);
      assert.strictEqual(shouldDropWebSocketFrame(watermarkPayload, { blockSeen: false }), false);
    });

    await t2.test('drops /t_m_r read receipt watermark frame when blockSeen is enabled', () => {
      const readPayload = JSON.stringify({ topic: '/t_m_r', thread_id: 't_123' });
      const res = interceptWebSocketFrame(readPayload, { blockSeen: true });
      assert.strictEqual(res.dropped, true);
      assert.strictEqual(res.reason, 'BLOCK_SEEN');
    });

    await t2.test('drops change_read_status frame when blockSeen is enabled', () => {
      const payload = 'action=change_read_status&thread=t_101';
      const res = interceptWebSocketFrame(payload, { blockSeen: true });
      assert.strictEqual(res.dropped, true);
      assert.strictEqual(res.reason, 'BLOCK_SEEN');
    });

    await t2.test('allows regular chat frames (/send_message, /inbox_sync) when both stealth features are enabled', () => {
      const sendPayload = JSON.stringify({ topic: '/send_message', body: 'Hello World!' });
      const syncPayload = JSON.stringify({ topic: '/inbox_sync', messages: [{ id: 1 }] });

      assert.strictEqual(interceptWebSocketFrame(sendPayload, { blockSeen: true, blockTyping: true }).dropped, false);
      assert.strictEqual(interceptWebSocketFrame(syncPayload, { blockSeen: true, blockTyping: true }).dropped, false);
      assert.strictEqual(shouldDropWebSocketFrame(sendPayload, { blockSeen: true, blockTyping: true }), false);
      assert.strictEqual(shouldDropWebSocketFrame(syncPayload, { blockSeen: true, blockTyping: true }), false);
    });

    await t2.test('passes binary ArrayBuffer / Uint8Array frames safely without dropping or crashing', () => {
      const uint8 = new Uint8Array([0x10, 0x24, 0x00, 0x04, 0x4d, 0x51, 0x54, 0x54]);
      const res = interceptWebSocketFrame(uint8, { blockSeen: true, blockTyping: true });
      assert.strictEqual(res.dropped, false);
      assert.strictEqual(res.binary, true);
      assert.strictEqual(res.payload, uint8);
    });

    await t2.test('handles corrupted / malformed JSON strings safely without throwing', () => {
      const corrupted = '{"invalid_json": true, incomplete_tokens...';
      const res = interceptWebSocketFrame(corrupted, { blockSeen: true, blockTyping: true });
      assert.strictEqual(res.dropped, false);
      assert.strictEqual(res.payload, corrupted);
    });

    await t2.test('keystroke saturation drops 10/10 typing frames', () => {
      for (let i = 0; i < 10; i++) {
        const frame = JSON.stringify({ topic: '/t_tp', seq: i });
        const res = interceptWebSocketFrame(frame, { blockTyping: true });
        assert.strictEqual(res.dropped, true);
      }
    });

    await t2.test('group chat typing frame is dropped', () => {
      const frame = JSON.stringify({ topic: '/t_tp', threadKey: 'group_101', senderId: '100080000000001' });
      const res = interceptWebSocketFrame(frame, { blockTyping: true });
      assert.strictEqual(res.dropped, true);
      assert.strictEqual(res.reason, 'BLOCK_TYPING');
    });
  });

  await t.test('2. Session Authentication Token Extraction (content-isolated.js)', async (t2) => {
    await t2.test('extracts c_user user ID from cookie string', () => {
      const cookieStr = 'sb=abc123xyz; c_user=100088889999; xs=42%3Asecret%3A2';
      const session = extractSessionFromDocument(null, cookieStr);
      assert.strictEqual(session.userId, '100088889999');
    });

    await t2.test('extracts c_user user ID from mock DOM form input', () => {
      const mockDoc = {
        querySelector: (sel) => {
          if (sel.includes('c_user')) {
            return { value: '100077778888' };
          }
          return null;
        }
      };
      const session = extractSessionFromDocument(mockDoc, '');
      assert.strictEqual(session.userId, '100077778888');
    });

    await t2.test('extracts fb_dtsg token from mock DOM input', () => {
      const mockDoc = {
        querySelector: (sel) => {
          if (sel.includes('fb_dtsg')) {
            return { value: 'NAcTestDtsgToken123' };
          }
          return null;
        }
      };
      const session = extractSessionFromDocument(mockDoc, '');
      assert.strictEqual(session.dtsg, 'NAcTestDtsgToken123');
    });

    await t2.test('extracts fb_dtsg and userId from inline script contents', () => {
      const mockDoc = {
        querySelector: () => null,
        scripts: [
          { textContent: 'window.__d=function(){};' },
          { textContent: '["DTSGInitialData",[],{"token":"AQGTestDtsgTokenFromScript"}]' },
          { textContent: '["CurrentUserInitialData",[],{"USER_ID":"100099990000"}]' }
        ]
      };
      const session = extractSessionFromDocument(mockDoc, '');
      assert.strictEqual(session.dtsg, 'AQGTestDtsgTokenFromScript');
      assert.strictEqual(session.userId, '100099990000');
    });

    await t2.test('returns null for missing user ID and dtsg gracefully', () => {
      const mockDoc = {
        querySelector: () => null,
        scripts: []
      };
      const session = extractSessionFromDocument(mockDoc, '');
      assert.strictEqual(session.userId, null);
      assert.strictEqual(session.dtsg, null);
    });
  });

  await t.test('3. Session Token Auto-Report & Service Worker Message Bridge', async (t2) => {
    const { handleIncomingMessage, activeSessionTokens, fbApi } = await import('../../background/service-worker.js');

    await t2.test('service worker routes SESSION_INFO_UPDATE cleanly and updates active tokens', async () => {
      const payload = {
        userId: '100088889999',
        dtsg: 'token_dtsg_session_info_update_test'
      };

      const res = await handleIncomingMessage({
        type: 'SESSION_INFO_UPDATE',
        payload
      });

      assert.strictEqual(res.acknowledged, true);
      assert.strictEqual(activeSessionTokens.userId, payload.userId);
      assert.strictEqual(activeSessionTokens.dtsg, payload.dtsg);
      assert.strictEqual(fbApi._bridgeCredentials.userId, payload.userId);
      assert.strictEqual(fbApi._bridgeCredentials.dtsg, payload.dtsg);
    });

    await t2.test('service worker also accepts CONTENT_SCRIPT_TOKEN_REPORT for backward compatibility', async () => {
      const payload = {
        userId: '100088887777',
        dtsg: 'token_dtsg_content_script_report_test'
      };

      const res = await handleIncomingMessage({
        type: 'CONTENT_SCRIPT_TOKEN_REPORT',
        payload
      });

      assert.strictEqual(res.acknowledged, true);
      assert.strictEqual(activeSessionTokens.userId, payload.userId);
      assert.strictEqual(activeSessionTokens.dtsg, payload.dtsg);
      assert.strictEqual(fbApi._bridgeCredentials.userId, payload.userId);
      assert.strictEqual(fbApi._bridgeCredentials.dtsg, payload.dtsg);
    });

    await t2.test('service worker rejects unknown message types cleanly', async () => {
      let caught = null;
      try {
        await handleIncomingMessage({
          type: 'UNKNOWN_NONEXISTENT_TYPE',
          payload: {}
        });
      } catch (err) {
        caught = err;
      }

      assert.ok(caught);
      assert(caught.message.includes('Unknown message type: UNKNOWN_NONEXISTENT_TYPE'));
    });
  });

  await t.test('4. Anti-Contamination Verification', () => {
    const mainSource = fs.readFileSync(path.join(projectRoot, 'content', 'content-main.js'), 'utf8');
    const isolatedSource = fs.readFileSync(path.join(projectRoot, 'content', 'content-isolated.js'), 'utf8');
    const forbidden = ['locket', 'video'].join('_');

    assert(!mainSource.toLowerCase().includes(forbidden), 'content-main.js must not contain forbidden keyword');
    assert(!isolatedSource.toLowerCase().includes(forbidden), 'content-isolated.js must not contain forbidden keyword');
  });
});
