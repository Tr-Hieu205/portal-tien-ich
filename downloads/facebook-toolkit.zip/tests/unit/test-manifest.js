/**
 * tests/unit/test-manifest.js
 * Comprehensive validation suite for Chrome Extension Manifest V3 configuration.
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '../..');
const manifestPath = path.join(projectRoot, 'manifest.json');

test('Manifest V3 Configuration Suite', async (t) => {
  await t.test('manifest.json file exists and is valid JSON', () => {
    assert(fs.existsSync(manifestPath), 'manifest.json must exist in project root');
    const rawContent = fs.readFileSync(manifestPath, 'utf8');
    assert.doesNotThrow(() => JSON.parse(rawContent), 'manifest.json must be valid JSON');
  });

  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

  await t.test('Manifest version and basic metadata', () => {
    assert.strictEqual(manifest.manifest_version, 3, 'manifest_version must be exactly 3');
    assert.strictEqual(manifest.name, 'Facebook Toolkit Pro', 'Extension name must match spec');
    assert(typeof manifest.version === 'string' && /^\d+\.\d+\.\d+$/.test(manifest.version), 'version must be valid semver');
    assert(typeof manifest.description === 'string' && manifest.description.length > 10, 'description must be non-empty');
  });

  await t.test('Icons declarations and binary header integrity', () => {
    assert(manifest.icons && typeof manifest.icons === 'object', 'icons object required');
    const declaredSizes = ['16', '48', '128'];

    for (const size of declaredSizes) {
      assert(manifest.icons[size], `manifest.icons must declare size ${size}`);
      const iconPath = path.join(projectRoot, manifest.icons[size]);
      assert(fs.existsSync(iconPath), `Icon file must exist: ${manifest.icons[size]}`);

      const buf = fs.readFileSync(iconPath);
      // Verify 8-byte PNG signature: 89 50 4E 47 0D 0A 1A 0A
      const pngSignature = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
      assert(buf.subarray(0, 8).equals(pngSignature), `Icon ${manifest.icons[size]} must be valid PNG`);

      // Verify IHDR width and height
      const width = buf.readUInt32BE(16);
      const height = buf.readUInt32BE(20);
      assert.strictEqual(width, parseInt(size, 10), `Icon ${manifest.icons[size]} width must be ${size}`);
      assert.strictEqual(height, parseInt(size, 10), `Icon ${manifest.icons[size]} height must be ${size}`);
    }
  });

  await t.test('Action configuration and popup binding', () => {
    assert(manifest.action && typeof manifest.action === 'object', 'action object required');
    assert.strictEqual(manifest.action.default_popup, 'popup/popup.html', 'default_popup must point to popup/popup.html');
    assert(manifest.action.default_title, 'default_title must be specified');
    assert(manifest.action.default_icon && manifest.action.default_icon['16'], 'default_icon must be specified');
  });

  await t.test('Options UI dashboard binding', () => {
    assert(manifest.options_ui && typeof manifest.options_ui === 'object', 'options_ui object required');
    assert.strictEqual(manifest.options_ui.page, 'dashboard/index.html', 'options_ui.page must point to dashboard/index.html');
    assert.strictEqual(manifest.options_ui.open_in_tab, true, 'options_ui.open_in_tab must be true');
  });

  await t.test('Background service worker configuration', () => {
    assert(manifest.background && typeof manifest.background === 'object', 'background object required');
    assert.strictEqual(manifest.background.service_worker, 'background/service-worker.js', 'service_worker must point to background/service-worker.js');
    assert.strictEqual(manifest.background.type, 'module', 'background.type must be module');
    assert.strictEqual(manifest.background.scripts, undefined, 'MV2 scripts key must NOT be present');
  });

  await t.test('Permissions segregation and required API capabilities', () => {
    assert(Array.isArray(manifest.permissions), 'permissions must be an array');
    const requiredPermissions = [
      'declarativeNetRequest',
      'declarativeNetRequestWithHostAccess',
      'storage',
      'unlimitedStorage',
      'alarms',
      'downloads',
      'scripting',
      'activeTab',
      'cookies'
    ];

    for (const perm of requiredPermissions) {
      assert(manifest.permissions.includes(perm), `Missing required permission: ${perm}`);
    }

    // Assert NO host patterns inside permissions array (MV3 rule)
    for (const perm of manifest.permissions) {
      assert(!perm.includes('://'), `Host pattern '${perm}' found in permissions; must be in host_permissions`);
    }
  });

  await t.test('Host permissions declaration', () => {
    assert(Array.isArray(manifest.host_permissions), 'host_permissions must be an array');
    assert(manifest.host_permissions.includes('*://*.facebook.com/*'), 'Missing facebook host permission');
    assert(manifest.host_permissions.includes('*://*.messenger.com/*'), 'Missing messenger host permission');
  });

  await t.test('Content scripts dual-world configuration', () => {
    assert(Array.isArray(manifest.content_scripts), 'content_scripts must be an array');
    assert(manifest.content_scripts.length >= 2, 'content_scripts must declare at least isolated and main world entries');

    const isolatedScript = manifest.content_scripts.find(cs => cs.world === 'ISOLATED' || !cs.world);
    assert(isolatedScript, 'Must declare ISOLATED world content script');
    assert(isolatedScript.js.includes('content/content-isolated.js'), 'Must include content/content-isolated.js');

    const mainScript = manifest.content_scripts.find(cs => cs.world === 'MAIN');
    assert(mainScript, 'Must declare MAIN world content script');
    assert(mainScript.js.includes('content/content-main.js'), 'Must include content/content-main.js');
    assert.strictEqual(mainScript.run_at, 'document_start', 'MAIN world script must run at document_start for early interception');
  });

  await t.test('Declarative Net Request ruleset binding', () => {
    assert(manifest.declarative_net_request && typeof manifest.declarative_net_request === 'object', 'declarative_net_request required');
    assert(Array.isArray(manifest.declarative_net_request.rule_resources), 'rule_resources must be array');

    const stealthRule = manifest.declarative_net_request.rule_resources.find(r => r.id === 'stealth_rules');
    assert(stealthRule, 'Must include stealth_rules rule resource');
    assert.strictEqual(stealthRule.path, 'rules/stealth-rules.json', 'Rule resource path must match spec');
    assert.strictEqual(stealthRule.enabled, true, 'Rule resource must be enabled');
  });

  await t.test('Web accessible resources declaration', () => {
    assert(Array.isArray(manifest.web_accessible_resources), 'web_accessible_resources must be array');
    const mainEntry = manifest.web_accessible_resources.find(entry =>
      entry.resources && entry.resources.includes('content/content-main.js')
    );
    assert(mainEntry, 'content/content-main.js must be declared in web_accessible_resources');
    assert(mainEntry.matches.includes('*://*.facebook.com/*'), 'web_accessible_resources must match facebook.com');
  });

  await t.test('Strict exclusion of forbidden reference', () => {
    const rawContent = fs.readFileSync(manifestPath, 'utf8');
    const forbidden = ['locket', 'video'].join('_');
    assert(!rawContent.toLowerCase().includes(forbidden), 'Strict constraint violation: manifest.json contains forbidden reference');
  });
});
