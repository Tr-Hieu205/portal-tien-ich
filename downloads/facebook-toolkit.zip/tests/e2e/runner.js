#!/usr/bin/env node
/**
 * Facebook Toolkit Pro - E2E Test Suite Runner
 * CLI test runner executing Tier 1 through Tier 4 verification suites.
 *
 * Usage:
 *   node tests/e2e/runner.js --tier=1
 *   node tests/e2e/runner.js --tier=2
 *   node tests/e2e/runner.js --tier=3
 *   node tests/e2e/runner.js --tier=4
 *   node tests/e2e/runner.js
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { harness } from './harness.js';
import { setupMockChrome, resetMockChrome } from './mock-chrome.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const E2E_ROOT = __dirname;

const TIER_DIRS = {
  1: { dir: 'tier1-feature-coverage', label: 'Tier 1 - Feature Coverage' },
  2: { dir: 'tier2-boundary-corner', label: 'Tier 2 - Boundary & Corner Cases' },
  3: { dir: 'tier3-cross-feature', label: 'Tier 3 - Cross-Feature Interactions' },
  4: { dir: 'tier4-application-workloads', label: 'Tier 4 - Real-World Application Workloads' }
};

// Parse CLI flags
function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    tier: null,
    filter: null,
    verbose: true
  };

  let rawTier = null;

  for (const arg of args) {
    if (arg.startsWith('--tier=')) {
      rawTier = arg.split('=')[1];
      options.tier = parseInt(rawTier, 10);
    } else if (arg.startsWith('--filter=')) {
      options.filter = arg.split('=')[1];
    } else if (arg === '--quiet') {
      options.verbose = false;
    }
  }

  if (rawTier !== null) {
    if (isNaN(options.tier) || !(options.tier in TIER_DIRS)) {
      console.error(`[Runner Fatal] Invalid tier specified: ${rawTier}. Valid tiers: 1, 2, 3, 4.`);
      process.exit(1);
    }
  }

  return options;
}

async function findSuiteFiles(tierDirName) {
  const fullDirPath = path.join(E2E_ROOT, tierDirName);
  if (!fs.existsSync(fullDirPath)) {
    return [];
  }

  const entries = fs.readdirSync(fullDirPath, { withFileTypes: true });
  return entries
    .filter(e => e.isFile() && e.name.endsWith('.js') && (e.name.startsWith('suite-') || e.name.startsWith('test-')))
    .map(e => ({
      name: e.name,
      path: path.join(fullDirPath, e.name)
    }));
}

async function runTier(tierNumber, options) {
  const tierConfig = TIER_DIRS[tierNumber];
  if (!tierConfig) {
    console.error(`[Runner] Unknown tier number: ${tierNumber}`);
    return { total: 0, passed: 0, failed: 0, skipped: 0, errors: [] };
  }

  const suiteFiles = await findSuiteFiles(tierConfig.dir);
  if (suiteFiles.length === 0) {
    console.log(`\n======================================================`);
    console.log(`  ${tierConfig.label} (Tier ${tierNumber}): [No test suites found]`);
    console.log(`======================================================\n`);
    return { total: 0, passed: 0, failed: 0, skipped: 0, errors: [] };
  }

  console.log(`\n======================================================`);
  console.log(`  Running ${tierConfig.label} (${suiteFiles.length} suites)`);
  console.log(`======================================================\n`);

  let tierTotal = 0;
  let tierPassed = 0;
  let tierFailed = 0;
  let tierSkipped = 0;
  const tierErrors = [];

  for (const suite of suiteFiles) {
    console.log(`\n• Suite: ${suite.name}`);
    harness.reset();
    resetMockChrome();

    // Dynamically import test suite file (registers tests into harness)
    await import(`file://${suite.path}`);

    const result = await harness.run({ filter: options.filter, quiet: !options.verbose });

    tierTotal += result.total;
    tierPassed += result.passed;
    tierFailed += result.failed;
    tierSkipped += result.skipped;
    tierErrors.push(...result.errors);
  }

  return {
    tier: tierNumber,
    label: tierConfig.label,
    total: tierTotal,
    passed: tierPassed,
    failed: tierFailed,
    skipped: tierSkipped,
    errors: tierErrors
  };
}

async function main() {
  const options = parseArgs();
  setupMockChrome();

  console.log(`\n🚀 Facebook Toolkit Pro - Native E2E Test Runner`);
  console.log(`Node.js Version: ${process.version}`);
  console.log(`Target: ${options.tier ? `Tier ${options.tier}` : 'All Available Tiers'}`);

  const startClock = Date.now();
  const tiersToRun = options.tier ? [options.tier] : [1, 2, 3, 4];
  const tierResults = [];

  for (const tierNum of tiersToRun) {
    const res = await runTier(tierNum, options);
    if (res.total > 0) {
      tierResults.push(res);
    }
  }

  const durationMs = Date.now() - startClock;

  // Print Summary
  console.log(`\n======================================================`);
  console.log(`                 E2E EXECUTION SUMMARY                `);
  console.log(`======================================================`);

  let grandTotal = 0;
  let grandPassed = 0;
  let grandFailed = 0;
  let grandSkipped = 0;

  for (const tr of tierResults) {
    grandTotal += tr.total;
    grandPassed += tr.passed;
    grandFailed += tr.failed;
    grandSkipped += tr.skipped;

    const statusTag = tr.failed === 0 ? 'PASS' : 'FAIL';
    console.log(`  [${statusTag}] Tier ${tr.tier}: ${tr.passed}/${tr.total} passed (${tr.failed} failed, ${tr.skipped} skipped)`);
  }

  console.log(`------------------------------------------------------`);
  console.log(`  Grand Total: ${grandPassed}/${grandTotal} passed in ${durationMs}ms`);

  if (grandFailed > 0) {
    console.log(`\n❌ Failures Summary:`);
    for (const tr of tierResults) {
      for (const err of tr.errors) {
        console.log(`  - [Tier ${tr.tier}] ${err.name}`);
        console.log(`    ${err.error?.message || err.error}`);
      }
    }
    process.exit(1);
  } else {
    console.log(`\n🎉 ALL TESTS PASSED SUCCESSFULLY!`);
    process.exit(0);
  }
}

main().catch(err => {
  console.error('[Runner Fatal Error]', err);
  process.exit(1);
});
