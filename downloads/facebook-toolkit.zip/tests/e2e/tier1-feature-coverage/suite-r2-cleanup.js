/**
 * Tier 1 Test Suite: Requirement R2 - Profile Cleanup
 * Exactly 20 tests (T1_021 to T1_040) covering F_R2_1 to F_R2_4
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { RateLimiter, RollingQuotaTracker } from '../../../shared/rate-limiter.js';
import { ACTION_TYPES, DEFAULT_DELAYS_MS } from '../../../shared/constants.js';
import { generateMockDataset } from '../../../shared/mock-fixtures.js';

describe('Tier 1: Requirement R2 - Profile Cleanup', () => {
  let client;
  let runner;
  let rateLimiter;
  let mockData;

  beforeEach(() => {
    mockData = generateMockDataset(1337);
    client = createMockFacebookApiClient({ posts: mockData.posts });
    rateLimiter = new RateLimiter();
    runner = new ActionRunner({
      rateLimiter,
      isSimulation: true,
      fastMode: true
    });
  });

  // ----------------------------------------------------
  // F_R2_1: Timeline Content Scanner & Filter (T1_021 to T1_025)
  // ----------------------------------------------------

  test('T1_021: Timeline Post Date Range Query retrieves posts within window', async () => {
    const startDate = new Date('2022-01-01T00:00:00Z');
    const endDate = new Date('2022-12-31T23:59:59Z');

    const filtered = await client.scanTimeline({
      dateRange: { start: startDate, end: endDate }
    });

    assert.ok(Array.isArray(filtered));
    for (const post of filtered) {
      assert.ok(post.creationTime >= startDate.getTime(), 'Post creationTime must be >= start');
      assert.ok(post.creationTime <= endDate.getTime(), 'Post creationTime must be <= end');
    }
  });

  test('T1_022: Keyword Search Filtering matches message text', async () => {
    const filtered = await client.scanTimeline({ keyword: 'party' });
    assert.ok(Array.isArray(filtered));
    for (const post of filtered) {
      assert.match(post.message.toLowerCase(), /party/);
    }
  });

  test('T1_023: Empty Filter Baseline Retrieval returns all available timeline posts', async () => {
    const allPosts = await client.scanTimeline();
    assert.ok(Array.isArray(allPosts));
    assert.ok(allPosts.length > 0, 'Timeline scan without filter should return posts');
  });

  test('T1_024: Post Metadata Schema Conformance verifies standard properties', async () => {
    const posts = await client.scanTimeline();
    assert.ok(posts.length > 0);
    const post = posts[0];

    assert.ok(post.id, 'Post must have an id');
    assert.ok(typeof post.creationTime === 'number', 'Post must have creationTime timestamp');
    assert.ok(typeof post.message === 'string', 'Post must have message string');
    assert.ok(post.feedback, 'Post must have feedback object');
    assert.ok(typeof post.feedback.reactionCount === 'number', 'Feedback must have reactionCount');
    assert.ok(typeof post.feedback.commentCount === 'number', 'Feedback must have commentCount');
    assert.ok(post.privacy, 'Post must have privacy setting');
  });

  test('T1_025: Simulation Mode Timeline Scanner operates offline without network requests', async () => {
    runner.setSimulation(true);
    const posts = await client.scanTimeline();
    assert.ok(Array.isArray(posts));
    assert.ok(posts.length >= 10);
  });

  // ----------------------------------------------------
  // F_R2_2: Bulk Delete Timeline Posts (T1_026 to T1_030)
  // ----------------------------------------------------

  test('T1_026: Single Post Deletion confirms deletion status', async () => {
    const targetPostId = 'post_7001';
    const res = await client.deletePost(targetPostId);
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.deletedId, targetPostId);
  });

  test('T1_027: Bulk Post Delete Batch Execution runs queue sequentially', async () => {
    const targets = ['post_7001', 'post_7002', 'post_7003'];
    const progressLog = [];

    const results = await runner.executeBatch(
      ACTION_TYPES.POST_DELETE,
      targets,
      (pid) => () => client.deletePost(pid),
      {
        fastMode: true,
        onProgress: (p) => progressLog.push(p.completed)
      }
    );

    assert.strictEqual(results.length, 3);
    assert.deepStrictEqual(progressLog, [1, 2, 3]);
    for (const res of results) {
      assert.strictEqual(res.success, true);
    }
  });

  test('T1_028: UI Timeline State Post-Deletion Update reflects deleted flag', async () => {
    const targetPostId = 'post_7001';
    await client.deletePost(targetPostId);

    const posts = await client.scanTimeline();
    const deletedPost = posts.find(p => p.id === targetPostId);
    if (deletedPost) {
      assert.strictEqual(deletedPost.isDeleted, true);
    }
  });

  test('T1_029: Simulation Mode Post Deletion returns simulated result without network calls', async () => {
    runner.setSimulation(true);
    const result = await runner.execute(
      ACTION_TYPES.POST_DELETE,
      'post_7002',
      null
    );

    assert.strictEqual(result.success, true);
    assert.strictEqual(result.isSimulation, true);
    assert.strictEqual(result.actionType, ACTION_TYPES.POST_DELETE);
  });

  test('T1_030: Post Deletion Daily Quota Accounting records deletion timestamps', () => {
    const tracker = new RollingQuotaTracker();
    tracker.recordAction(ACTION_TYPES.POST_DELETE);
    tracker.recordAction(ACTION_TYPES.POST_DELETE);

    assert.strictEqual(tracker.getUsage(ACTION_TYPES.POST_DELETE), 2);
  });

  // ----------------------------------------------------
  // F_R2_3: Bulk Hide & Archive Posts (T1_031 to T1_035)
  // ----------------------------------------------------

  test('T1_031: Single Post Hide Mutation confirms hide status', async () => {
    const res = await client.hidePost('post_7003');
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.storyId, 'post_7003');
    assert.strictEqual(res.action, 'HIDE');
  });

  test('T1_032: Single Post Archive Mutation confirms archive status', async () => {
    const res = await client.archivePost('post_7004');
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.storyId, 'post_7004');
    assert.strictEqual(res.action, 'ARCHIVE');
  });

  test('T1_033: Batch Post Hide Sequential Pacing enforces hide delay parameters', async () => {
    const targets = ['post_h1', 'post_h2', 'post_h3', 'post_h4'];
    const results = await runner.executeBatch(
      ACTION_TYPES.POST_HIDE,
      targets,
      (pid) => () => client.hidePost(pid),
      { fastMode: true }
    );

    assert.strictEqual(results.length, 4);
    for (const r of results) {
      assert.strictEqual(r.success, true);
    }

    const delaySpec = DEFAULT_DELAYS_MS[ACTION_TYPES.POST_HIDE];
    const calculated = rateLimiter.calculateDelay(ACTION_TYPES.POST_HIDE, { distractionProbability: 0 });
    assert.ok(calculated >= delaySpec.min * 0.7);
    assert.ok(calculated <= delaySpec.max * 1.4);
  });

  test('T1_034: Batch Post Archive Sequential Pacing tracks progress across items', async () => {
    const targets = ['post_a1', 'post_a2', 'post_a3', 'post_a4'];
    const progressPercent = [];

    const results = await runner.executeBatch(
      ACTION_TYPES.POST_ARCHIVE,
      targets,
      (pid) => () => client.archivePost(pid),
      {
        fastMode: true,
        onProgress: (p) => progressPercent.push(p.percent)
      }
    );

    assert.strictEqual(results.length, 4);
    assert.deepStrictEqual(progressPercent, [25, 50, 75, 100]);
  });

  test('T1_035: Simulation Mode Hide and Archive mutates state safely offline', async () => {
    runner.setSimulation(true);
    const hideRes = await runner.execute(ACTION_TYPES.POST_HIDE, 'post_7005', null);
    const archRes = await runner.execute(ACTION_TYPES.POST_ARCHIVE, 'post_7006', null);

    assert.strictEqual(hideRes.success, true);
    assert.strictEqual(hideRes.isSimulation, true);
    assert.strictEqual(archRes.success, true);
    assert.strictEqual(archRes.isSimulation, true);
  });

  // ----------------------------------------------------
  // F_R2_4: Bulk Delete Comments & Photos (T1_036 to T1_040)
  // ----------------------------------------------------

  test('T1_036: Single Comment Deletion returns success status', async () => {
    const res = await client.executeCommentDelete('comment_5001');
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.commentId, 'comment_5001');
  });

  test('T1_037: Batch Comment Deletion Pacing processes multiple comment targets', async () => {
    const commentIds = ['comment_5001', 'comment_5002', 'comment_5003'];
    const results = await runner.executeBatch(
      ACTION_TYPES.COMMENT_DELETE,
      commentIds,
      (cid) => () => client.executeCommentDelete(cid),
      { fastMode: true }
    );

    assert.strictEqual(results.length, 3);
    for (const r of results) {
      assert.strictEqual(r.success, true);
    }
  });

  test('T1_038: Single Photo Deletion returns confirmation for target photo ID', async () => {
    const res = await client.executePhotoDelete('photo_8001');
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.photoId, 'photo_8001');
  });

  test('T1_039: Batch Photo Deletion Execution runs queue cleanly', async () => {
    const photoIds = ['photo_8001', 'photo_8002', 'photo_8003'];
    const results = await runner.executeBatch(
      ACTION_TYPES.PHOTO_DELETE,
      photoIds,
      (pid) => () => client.executePhotoDelete(pid),
      { fastMode: true }
    );

    assert.strictEqual(results.length, 3);
    for (const r of results) {
      assert.strictEqual(r.success, true);
    }
  });

  test('T1_040: Simulation Mode Comment and Photo Deletion operates with zero remote network calls', async () => {
    runner.setSimulation(true);
    const commentRes = await runner.execute(ACTION_TYPES.COMMENT_DELETE, 'comment_sim_1', null);
    const photoRes = await runner.execute(ACTION_TYPES.PHOTO_DELETE, 'photo_sim_1', null);

    assert.strictEqual(commentRes.success, true);
    assert.strictEqual(commentRes.isSimulation, true);
    assert.strictEqual(photoRes.success, true);
    assert.strictEqual(photoRes.isSimulation, true);
  });
});
