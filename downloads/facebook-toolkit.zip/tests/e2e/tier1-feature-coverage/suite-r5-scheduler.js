/**
 * Tier 1 Test Suite: Requirement R5 - Automated Post & Reup Scheduling
 * Exactly 10 tests (T1_076 to T1_085) covering F_R5_1 to F_R5_2
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { ACTION_TYPES } from '../../../shared/constants.js';
import { AlarmsManager } from '../../../background/alarms-manager.js';

// Domain helper for birthday template substitution
export function renderBirthdayTemplate(templateStr, friend) {
  const fullName = friend.name || friend.friendName || '';
  const firstName = fullName.split(' ')[0] || fullName;
  const lastName = fullName.split(' ').slice(1).join(' ') || '';

  return templateStr
    .replace(/\{name\}/g, fullName)
    .replace(/\{first_name\}/g, firstName)
    .replace(/\{last_name\}/g, lastName);
}

// Domain helper for minimal XML/RSS feed item parsing
export function parseRssFeed(xmlStr) {
  const items = [];
  const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
  let match;

  while ((match = itemRegex.exec(xmlStr)) !== null) {
    const itemBlock = match[1];
    const titleMatch = /<title>(.*?)<\/title>/i.exec(itemBlock);
    const linkMatch = /<link>(.*?)<\/link>/i.exec(itemBlock);
    const descMatch = /<description>(.*?)<\/description>/i.exec(itemBlock);
    const enclosureMatch = /<enclosure[^>]*url="([^"]*)"/i.exec(itemBlock);
    const guidMatch = /<guid[^>]*>(.*?)<\/guid>/i.exec(itemBlock);

    items.push({
      title: titleMatch ? titleMatch[1].trim() : '',
      link: linkMatch ? linkMatch[1].trim() : '',
      description: descMatch ? descMatch[1].trim() : '',
      mediaUrl: enclosureMatch ? enclosureMatch[1].trim() : null,
      guid: guidMatch ? guidMatch[1].trim() : (linkMatch ? linkMatch[1].trim() : '')
    });
  }

  return items;
}

describe('Tier 1: Requirement R5 - Automated Post & Reup Scheduling', () => {
  let client;
  let runner;

  beforeEach(async () => {
    client = createMockFacebookApiClient();
    runner = new ActionRunner({
      isSimulation: true,
      fastMode: true
    });
    await chrome.alarms.clearAll();
  });

  // ----------------------------------------------------
  // F_R5_1: Scheduled Birthday Auto-Greeter (T1_076 to T1_080)
  // ----------------------------------------------------

  test('T1_076: Upcoming Birthdays Query returns friend birthday profiles', async () => {
    const birthdays = await client.fetchBirthdays();
    assert.ok(Array.isArray(birthdays));
    assert.ok(birthdays.length > 0);

    const bday = birthdays[0];
    assert.ok(bday.friendId, 'Birthday item must have friendId');
    assert.ok(bday.name || bday.friendName, 'Birthday item must have friend name');
    assert.ok(bday.birthDate, 'Birthday item must have birthDate');
  });

  test('T1_077: Template Variable Substitution replaces name tokens correctly', () => {
    const template = 'Happy birthday {first_name}! Wishing you all the best, {name}! 🎂';
    const friend = { name: 'Sarah Connor', friendId: '100088889999' };

    const rendered = renderBirthdayTemplate(template, friend);
    assert.strictEqual(rendered, 'Happy birthday Sarah! Wishing you all the best, Sarah Connor! 🎂');
  });

  test('T1_078: Randomized Variant Selection produces diversity across recipient messages', () => {
    const templates = [
      'Chúc mừng sinh nhật {first_name}! Chúc bạn tuổi mới luôn vui vẻ và thành công! 🎉',
      'Happy Birthday {first_name}! Wishing you all the best on your special day! 🌟',
      'Chúc {name} sinh nhật thật ấm áp và ngập tràn hạnh phúc bên người thân! 🎂'
    ];

    const friends = [
      { name: 'Sarah Connor' },
      { name: 'John Connor' },
      { name: 'Kyle Reese' },
      { name: 'Miles Dyson' },
      { name: 'Marcus Wright' }
    ];

    const renderedSet = new Set();
    friends.forEach((f, idx) => {
      const template = templates[idx % templates.length];
      renderedSet.add(renderBirthdayTemplate(template, f));
    });

    assert.ok(renderedSet.size >= 3, 'Multiple distinct messages should be generated from templates');
  });

  test('T1_079: Greeting Deduplication in Storage records greeting history with message channel', async () => {
    const friendId = '100088889999';
    const currentYear = new Date().getFullYear();

    const history = {
      [friendId]: {
        year: currentYear,
        timestamp: Date.now(),
        channel: 'message'
      }
    };

    await chrome.storage.local.set({ birthdayHistory: history });
    const stored = await chrome.storage.local.get('birthdayHistory');

    assert.strictEqual(stored.birthdayHistory[friendId].year, currentYear);
    assert.strictEqual(stored.birthdayHistory[friendId].channel, 'message');
  });

  test('T1_080: Birthday Whitelist and Channel Enforcement greets only whitelisted friends via message channel and skips non-whitelisted', async () => {
    runner.setSimulation(false);
    const currentYear = new Date().getFullYear();
    const greetedFriendId = '100088889999';
    const whitelistedFriendId = '100088880001';
    const nonWhitelistedFriendId = '100088880002';

    // Seed storage with whitelist and already greeted friend
    await chrome.storage.local.set({
      birthdayWhitelist: [whitelistedFriendId, greetedFriendId],
      birthdayHistory: {
        [greetedFriendId]: {
          year: currentYear,
          timestamp: Date.now() - 3600000,
          channel: 'message'
        }
      }
    });

    const greetedCalls = [];
    const mockFbApi = {
      async fetchBirthdays() {
        return [
          { friendId: greetedFriendId, name: 'Sarah Connor', isToday: true },
          { friendId: whitelistedFriendId, name: 'John Connor', isToday: true },
          { friendId: nonWhitelistedFriendId, name: 'Kyle Reese', isToday: true }
        ];
      },
      async sendBirthdayGreeting(friendId, message, channel) {
        greetedCalls.push({ friendId, channel });
        return { success: true, friendId, channel };
      }
    };

    await AlarmsManager.init({
      storageManager: chrome.storage.local,
      fbApi: mockFbApi,
      actionRunner: runner
    });

    const res = await AlarmsManager.handleBirthdayCheckerRoutine({ name: 'FB_TOOLKIT_BIRTHDAY_CHECKER' });

    assert.strictEqual(res.greetedCount, 1, 'Only 1 friend should be greeted');
    assert.strictEqual(greetedCalls.length, 1);
    assert.strictEqual(greetedCalls[0].friendId, whitelistedFriendId, 'Whitelisted friend must be greeted');
    assert.strictEqual(greetedCalls[0].channel, 'message', 'Channel must strictly be message');
    assert.notStrictEqual(greetedCalls[0].channel, 'timeline', 'Channel must NEVER be timeline');

    const nonWhitelistedResult = res.results?.find(r => r.friendId === nonWhitelistedFriendId);
    assert.ok(nonWhitelistedResult?.skipped === true, 'Non-whitelisted friend must have skipped: true');
  });

  // ----------------------------------------------------
  // F_R5_2: Scheduled Post & Reel Reup Engine (T1_081 to T1_085)
  // ----------------------------------------------------

  test('T1_081: External RSS Feed Ingestion parses title, link and enclosure media', () => {
    const sampleXml = `<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0">
<channel>
  <title>Tech News Feed</title>
  <item>
    <title>Exciting Tech Discovery</title>
    <link>https://example.com/tech-discovery</link>
    <description>Amazing breakdown of new AI innovations.</description>
    <enclosure url="https://example.com/media/clip1.mp4" type="video/mp4" length="1024000"/>
    <guid>guid-12345</guid>
  </item>
</channel>
</rss>`;

    const items = parseRssFeed(sampleXml);
    assert.strictEqual(items.length, 1);
    assert.strictEqual(items[0].title, 'Exciting Tech Discovery');
    assert.strictEqual(items[0].mediaUrl, 'https://example.com/media/clip1.mp4');
    assert.strictEqual(items[0].guid, 'guid-12345');
  });

  test('T1_082: Chrome Alarms Scheduler Registration schedules recurring background task', async () => {
    const alarmName = 'FB_TOOLKIT_REUP_RUNNER';
    chrome.alarms.create(alarmName, { periodInMinutes: 60 });

    const alarm = await chrome.alarms.get(alarmName);
    assert.ok(alarm, 'Alarm must exist in alarms registry');
    assert.strictEqual(alarm.name, alarmName);
    assert.strictEqual(alarm.periodInMinutes, 60);
  });

  test('T1_083: Timeline Status Post Publishing publishes standard text and media post', async () => {
    const res = await client.publishPost({
      text: 'Scheduled automated update #1',
      isReel: false
    });

    assert.strictEqual(res.success, true);
    assert.ok(res.postId);
    assert.strictEqual(res.isReel, false);
  });

  test('T1_084: Reel Video Upload & Publishing handles short-form vertical video publication', async () => {
    const res = await client.publishPost({
      text: 'Highlights clip #viral #reel',
      isReel: true
    });

    assert.strictEqual(res.success, true);
    assert.ok(res.postId);
    assert.strictEqual(res.isReel, true);
  });

  test('T1_085: Processed Item ID Deduplication skips already published items', async () => {
    runner.setSimulation(false);
    const newGuid = 'guid-99999';

    // Seed storage with reupQueue containing item
    await chrome.storage.local.set({
      reupQueue: [
        { id: newGuid, title: 'Brand new tech post', isReel: false }
      ]
    });

    const published = [];
    const mockFbApi = {
      async publishPost(postData) {
        published.push(postData);
        return { success: true, postId: 'post_1001', isReel: postData.isReel };
      }
    };

    await AlarmsManager.init({
      storageManager: chrome.storage.local,
      fbApi: mockFbApi,
      actionRunner: runner
    });

    const result = await AlarmsManager.handleReupRunnerRoutine({ name: 'FB_TOOLKIT_REUP_RUNNER' });

    assert.strictEqual(result.processed, 1);
    assert.strictEqual(result.published, true);
    assert.strictEqual(result.targetId, newGuid);
    assert.strictEqual(published.length, 1);
    assert.strictEqual(published[0].text, 'Brand new tech post');

    // Verify queue in storage consumed item
    const stored = await chrome.storage.local.get('reupQueue');
    assert.strictEqual(stored.reupQueue.length, 0, 'Reup queue should have consumed the item');
  });
});
