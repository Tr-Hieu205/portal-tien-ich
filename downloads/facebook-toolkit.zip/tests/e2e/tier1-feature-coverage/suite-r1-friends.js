/**
 * Tier 1 Test Suite: Requirement R1 - Friend Filtering & Mass Interaction
 * Exactly 20 tests (T1_001 to T1_020) covering F_R1_1 to F_R1_4
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { RateLimiter, RollingQuotaTracker } from '../../../shared/rate-limiter.js';
import { ACTION_TYPES, DEFAULT_DELAYS_MS, JITTER_CONFIG } from '../../../shared/constants.js';
import { generateMockDataset, calculateInteractionScore } from '../../../shared/mock-fixtures.js';

describe('Tier 1: Requirement R1 - Friend Filtering & Mass Interaction', () => {
  let client;
  let runner;
  let rateLimiter;
  let mockData;

  beforeEach(() => {
    mockData = generateMockDataset(1337);
    client = createMockFacebookApiClient({ friends: mockData.friends });
    rateLimiter = new RateLimiter();
    runner = new ActionRunner({
      rateLimiter,
      isSimulation: true,
      fastMode: true
    });
  });

  // ----------------------------------------------------
  // F_R1_1: Friend Inactivity Scanner & Scoring (T1_001 to T1_005)
  // ----------------------------------------------------

  test('T1_001: Scan Friends List Structure returns valid friend objects', async () => {
    const friends = await client.scanFriends();
    assert.ok(Array.isArray(friends), 'Friends list must be an array');
    assert.ok(friends.length >= 30, `Expected at least 30 friends, got ${friends.length}`);

    const first = friends[0];
    assert.ok(first.id, 'Friend must have an id');
    assert.ok(first.name, 'Friend must have a name');
    assert.ok(first.profileUrl, 'Friend must have a profileUrl');
    assert.ok(first.avatar || first.avatarUrl, 'Friend must have an avatar image URL');
  });

  test('T1_002: Inactivity Score Calculation for Dormant Friend produces DEAD_INACTIVE', () => {
    const dormantFriend = {
      id: '100080000000001',
      name: 'Dormant User',
      daysSinceLastInteraction: 420,
      messageCount: 0,
      reactionCount: 0,
      commentCount: 0
    };

    const scored = client.computeInactivity(dormantFriend);
    assert.strictEqual(scored.classification, 'DEAD_INACTIVE');
    assert.ok(scored.inactivityScore >= 0.90, `Expected inactivityScore >= 0.90, got ${scored.inactivityScore}`);
    assert.ok(scored.daysInactive > 365, 'daysInactive should be greater than 365');
  });

  test('T1_003: Active Friend Recognition via Direct Messages produces ACTIVE', () => {
    const activeFriend = {
      id: '100080000000002',
      name: 'Active Messenger User',
      daysSinceLastInteraction: 5,
      messageCount: 45,
      reactionCount: 2,
      commentCount: 1
    };

    const scored = client.computeInactivity(activeFriend);
    assert.strictEqual(scored.classification, 'ACTIVE');
    assert.ok(scored.inactivityScore <= 0.15, `Expected inactivityScore <= 0.15, got ${scored.inactivityScore}`);
    assert.strictEqual(scored.daysInactive, 5);
  });

  test('T1_004: Active Friend Recognition via Timeline Interactions recognizes engagement', () => {
    const timelineEngagedFriend = {
      id: '100080000000003',
      name: 'Wall Engaged Friend',
      daysSinceLastInteraction: 2,
      messageCount: 0,
      reactionCount: 25,
      commentCount: 8
    };

    const scored = client.computeInactivity(timelineEngagedFriend);
    assert.strictEqual(scored.classification, 'ACTIVE', 'Recent post reactions must classify friend as ACTIVE');
    assert.ok(scored.inactivityScore <= 0.20, `Expected inactivityScore <= 0.20, got ${scored.inactivityScore}`);
  });

  test('T1_005: Scan Progress Callback Dispatch reports progressive counters', async () => {
    const progressEvents = [];
    const friends = await client.scanFriends((scanned, total) => {
      progressEvents.push({ scanned, total });
    });

    assert.ok(progressEvents.length > 0, 'Progress callback should be invoked');
    const lastEvent = progressEvents[progressEvents.length - 1];
    assert.strictEqual(lastEvent.scanned, lastEvent.total, 'Final progress event must show scanned === total');
    assert.strictEqual(lastEvent.total, friends.length);
  });

  // ----------------------------------------------------
  // F_R1_2: Rate-Limited Mass Unfriend (T1_006 to T1_010)
  // ----------------------------------------------------

  test('T1_006: Single Unfriend Execution executes successfully', async () => {
    const targetUid = '100080123456781';
    const result = await client.unfriend(targetUid);
    assert.strictEqual(result.success, true);
    assert.strictEqual(result.friendId, targetUid);
  });

  test('T1_007: Batch Unfriend Queue Execution runs sequentially across targets', async () => {
    const targets = ['1000801', '1000802', '1000803', '1000804', '1000805'];
    const results = await runner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      targets,
      (targetUid) => () => client.unfriend(targetUid),
      { fastMode: true }
    );

    assert.strictEqual(results.length, 5);
    for (let i = 0; i < targets.length; i++) {
      assert.strictEqual(results[i].success, true);
      assert.strictEqual(results[i].targetId, targets[i]);
    }
  });

  test('T1_008: Rolling Quota Timestamp Persistence tracks multiple unfriend actions', () => {
    const tracker = new RollingQuotaTracker();
    const now = Date.now();

    tracker.recordAction(ACTION_TYPES.UNFRIEND, now - 30000);
    tracker.recordAction(ACTION_TYPES.UNFRIEND, now - 15000);
    tracker.recordAction(ACTION_TYPES.UNFRIEND, now);

    const usage = tracker.getUsage(ACTION_TYPES.UNFRIEND, now);
    assert.strictEqual(usage, 3, 'Expected 3 unfriend timestamps within rolling window');
  });

  test('T1_009: Action Runner Simulation Mode for Unfriend prevents live remote calls', async () => {
    runner.setSimulation(true);
    let liveCalled = false;

    const res = await runner.execute(
      ACTION_TYPES.UNFRIEND,
      '100080123456782',
      async () => {
        liveCalled = true;
        return { success: true };
      }
    );

    assert.strictEqual(res.success, true);
    assert.strictEqual(res.isSimulation, true);
    assert.strictEqual(liveCalled, false, 'Live executor must NOT be called in simulation mode');
  });

  test('T1_010: Unfriend UI Progress Updates emit incremental percentage events', async () => {
    const targets = ['uid_1', 'uid_2', 'uid_3', 'uid_4'];
    const progressLog = [];

    await runner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      targets,
      (uid) => () => client.unfriend(uid),
      {
        fastMode: true,
        onProgress: (p) => progressLog.push({ ...p })
      }
    );

    assert.strictEqual(progressLog.length, 4);
    assert.strictEqual(progressLog[0].completed, 1);
    assert.strictEqual(progressLog[3].completed, 4);
    assert.strictEqual(progressLog[3].percent, 100);
  });

  // ----------------------------------------------------
  // F_R1_3: Mass Poke Friends (T1_011 to T1_015)
  // ----------------------------------------------------

  test('T1_011: Single Poke Execution returns HTTP 200 payload success', async () => {
    const targetUid = '100080123456782';
    const res = await client.poke(targetUid);
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.pokedUid, targetUid);
  });

  test('T1_012: Batch Poke Sequential Pacing calculates humanized jittered delay', () => {
    const baseConfig = DEFAULT_DELAYS_MS[ACTION_TYPES.POKE];
    const delays = [];
    for (let i = 0; i < 50; i++) {
      delays.push(rateLimiter.calculateDelay(ACTION_TYPES.POKE, { distractionProbability: 0 }));
    }

    assert.strictEqual(delays.length, 50);
    for (const d of delays) {
      assert.ok(d >= baseConfig.min * 0.8, `Delay ${d} should be above lower bound`);
      assert.ok(d <= baseConfig.max * 1.5, `Delay ${d} should be within acceptable upper bound`);
    }
  });

  test('T1_013: Poke Status Cache Deduplication prevents double poke in same session', async () => {
    const targetUid = '100080123456782';

    // First poke invocation against client
    const firstRes = await client.poke(targetUid);
    assert.strictEqual(firstRes.success, true);
    assert.strictEqual(firstRes.pokedUid, targetUid);
    assert.strictEqual(firstRes.alreadyPoked, false, 'First poke should not be marked as already poked');

    // Second poke invocation against same target in same session
    const secondRes = await client.poke(targetUid);
    assert.strictEqual(secondRes.success, true);
    assert.strictEqual(secondRes.pokedUid, targetUid);
    assert.strictEqual(secondRes.alreadyPoked, true, 'Second poke in same session must be flagged as duplicate');
  });

  test('T1_014: Simulation Mode Poke Execution runs safely without Facebook session', async () => {
    runner.setSimulation(true);
    const result = await runner.execute(
      ACTION_TYPES.POKE,
      '100080123456783',
      null
    );

    assert.strictEqual(result.success, true);
    assert.strictEqual(result.isSimulation, true);
    assert.strictEqual(result.actionType, ACTION_TYPES.POKE);
  });

  test('T1_015: Poke 24-Hour Rolling Quota Tracking increments counter upon poke dispatch', () => {
    const tracker = new RollingQuotaTracker();
    assert.strictEqual(tracker.getUsage(ACTION_TYPES.POKE), 0);

    tracker.recordAction(ACTION_TYPES.POKE);
    tracker.recordAction(ACTION_TYPES.POKE);

    assert.strictEqual(tracker.getUsage(ACTION_TYPES.POKE), 2);
  });

  // ----------------------------------------------------
  // F_R1_4: Mass Story Reactions (T1_016 to T1_020)
  // ----------------------------------------------------

  test('T1_016: Single Story Reaction LOVE confirms mutation', async () => {
    const res = await client.reactStory('story_9901', 'LOVE');
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.reaction, 'LOVE');
    assert.strictEqual(res.storyId, 'story_9901');
  });

  test('T1_017: Batch Story Reactions Pacing conforms to configured delay parameters', () => {
    const delaySpec = DEFAULT_DELAYS_MS[ACTION_TYPES.STORY_REACT];
    assert.ok(delaySpec.base > 0);
    assert.ok(delaySpec.min > 0);
    assert.ok(delaySpec.max >= delaySpec.min);

    const calculated = rateLimiter.calculateDelay(ACTION_TYPES.STORY_REACT, { distractionProbability: 0 });
    assert.ok(calculated >= delaySpec.min * 0.7);
    assert.ok(calculated <= delaySpec.max * 1.4);
  });

  test('T1_018: Multiple Reaction Types Enum Support accepts LOVE, LIKE, SUPPORT, HAHA, WOW', async () => {
    const reactionEnums = ['LOVE', 'LIKE', 'SUPPORT', 'HAHA', 'WOW'];
    for (const rType of reactionEnums) {
      const res = await client.reactStory(`story_${rType}`, rType);
      assert.strictEqual(res.success, true);
      assert.strictEqual(res.reaction, rType);
    }
  });

  test('T1_019: Story Reaction Simulation Mode returns mock confirmation', async () => {
    runner.setSimulation(true);
    const result = await runner.execute(
      ACTION_TYPES.STORY_REACT,
      { id: 'story_9902', reaction: 'LOVE' },
      null
    );

    assert.strictEqual(result.success, true);
    assert.strictEqual(result.isSimulation, true);
    assert.strictEqual(result.actionType, ACTION_TYPES.STORY_REACT);
  });

  test('T1_020: Story Reaction Quota Accounting tracks daily reaction count', () => {
    const tracker = new RollingQuotaTracker();
    for (let i = 0; i < 4; i++) {
      tracker.recordAction(ACTION_TYPES.STORY_REACT);
    }

    assert.strictEqual(tracker.getUsage(ACTION_TYPES.STORY_REACT), 4);
    const quotaCheck = rateLimiter.checkQuota(ACTION_TYPES.STORY_REACT);
    assert.strictEqual(quotaCheck.allowed, true);
    assert.ok(quotaCheck.limit >= 100);
  });
});
