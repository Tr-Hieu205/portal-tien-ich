/**
 * Tier 1 Test Suite: Requirement R4 - Security & Stealth Utilities
 * Exactly 15 tests (T1_061 to T1_075) covering F_R4_1 to F_R4_3
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { ACTION_TYPES, STORAGE_KEYS } from '../../../shared/constants.js';

// Import production MAIN-world WebSocket scriptlet
await import('../../../content/content-main.js');
const { shouldDropWebSocketFrame, interceptWebSocketFrame } = globalThis;

describe('Tier 1: Requirement R4 - Security & Stealth Utilities', () => {
  let client;
  let runner;

  beforeEach(async () => {
    client = createMockFacebookApiClient({ initialShield: false });
    runner = new ActionRunner({
      isSimulation: true,
      fastMode: true
    });
    // Reset declarativeNetRequest dynamic rules
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1001, 1002, 1003, 1004]
    });
  });

  // ----------------------------------------------------
  // F_R4_1: Profile Picture Shield (Avatar Guard) (T1_061 to T1_065)
  // ----------------------------------------------------

  test('T1_061: Enable Profile Picture Shield returns isShielded true', async () => {
    const res = await client.setAvatarShield(true);
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.isShielded, true);
  });

  test('T1_062: Disable Profile Picture Shield returns isShielded false', async () => {
    await client.setAvatarShield(true);
    const res = await client.setAvatarShield(false);
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.isShielded, false);
  });

  test('T1_063: Storage Persistence of Shield State saves toggle to storage', async () => {
    await client.setAvatarShield(true);
    await chrome.storage.local.set({ isShielded: true });

    const stored = await chrome.storage.local.get('isShielded');
    assert.strictEqual(stored.isShielded, true);
  });

  test('T1_064: Idempotent Enable Request handles duplicate enable safely', async () => {
    await client.setAvatarShield(true);
    const secondCall = await client.setAvatarShield(true);

    assert.strictEqual(secondCall.success, true);
    assert.strictEqual(secondCall.isShielded, true);
  });

  test('T1_065: Simulation Mode Avatar Guard Toggle executes offline safely', async () => {
    runner.setSimulation(true);
    const result = await runner.execute(
      ACTION_TYPES.AVATAR_GUARD,
      { enable: true },
      null
    );

    assert.strictEqual(result.success, true);
    assert.strictEqual(result.isSimulation, true);
    assert.strictEqual(result.actionType, ACTION_TYPES.AVATAR_GUARD);
  });

  // ----------------------------------------------------
  // F_R4_2: Intercept & Block "Seen" Receipts (T1_066 to T1_070)
  // ----------------------------------------------------

  test('T1_066: Enable Seen Blocking DNR Rule registers dynamic block rules', async () => {
    const seenRules = [
      {
        id: 1001,
        priority: 1,
        action: { type: 'block' },
        condition: {
          urlFilter: '*change_read_status.php*',
          resourceTypes: ['xmlhttprequest']
        }
      },
      {
        id: 1002,
        priority: 1,
        action: { type: 'block' },
        condition: {
          urlFilter: '*ajax/mercury/change_read_status*',
          resourceTypes: ['xmlhttprequest']
        }
      }
    ];

    await chrome.declarativeNetRequest.updateDynamicRules({ addRules: seenRules });
    const activeRules = await chrome.declarativeNetRequest.getDynamicRules();

    assert.ok(activeRules.some(r => r.id === 1001));
    assert.ok(activeRules.some(r => r.id === 1002));
  });

  test('T1_067: Disable Seen Blocking DNR Rule removes rules from ruleset', async () => {
    // Add first
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [{
        id: 1001,
        priority: 1,
        action: { type: 'block' },
        condition: { urlFilter: '*change_read_status*' }
      }]
    });

    // Remove
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [1001] });
    const activeRules = await chrome.declarativeNetRequest.getDynamicRules();

    assert.ok(!activeRules.some(r => r.id === 1001));
  });

  test('T1_068: Network URL Matching for Seen Endpoint matches and blocks request', async () => {
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [{
        id: 1001,
        priority: 1,
        action: { type: 'block' },
        condition: {
          urlFilter: '*change_read_status.php*',
          resourceTypes: ['xmlhttprequest']
        }
      }]
    });

    const targetUrl = 'https://www.facebook.com/ajax/mercury/change_read_status.php?dpr=1';
    const isBlocked = chrome.declarativeNetRequest.__isUrlBlocked(targetUrl, 'xmlhttprequest');
    assert.strictEqual(isBlocked, true, 'Seen endpoint URL must be blocked by rule 1001');
  });

  test('T1_069: WebSocket Scriptlet Read Watermark Drop suppresses outgoing telemetry', () => {
    const watermarkPayload = JSON.stringify({
      topic: '/t_ms',
      payload: { watermark: 1731657600000, thread_id: 't_101' }
    });

    const shouldDrop = shouldDropWebSocketFrame(watermarkPayload, { blockSeen: true, blockTyping: false });
    assert.strictEqual(shouldDrop, true, 'WebSocket watermark frame must be dropped when blockSeen is active');
  });

  test('T1_070: Chat Polling and Sync Unaffected allows normal incoming messages through', () => {
    const incomingChatPayload = JSON.stringify({
      topic: '/inbox_sync',
      message: { id: 'm_100', text: 'Hello, are you there?' }
    });

    const shouldDrop = shouldDropWebSocketFrame(incomingChatPayload, { blockSeen: true, blockTyping: true });
    assert.strictEqual(shouldDrop, false, 'Normal chat message sync must NOT be dropped');
  });

  // ----------------------------------------------------
  // F_R4_3: Intercept & Block "Typing..." Indicator (T1_071 to T1_075)
  // ----------------------------------------------------

  test('T1_071: Enable Typing Blocking DNR Rule registers dynamic typing block rules', async () => {
    const typingRules = [
      {
        id: 1003,
        priority: 1,
        action: { type: 'block' },
        condition: {
          urlFilter: '*ajax/messaging/typ.php*',
          resourceTypes: ['xmlhttprequest']
        }
      },
      {
        id: 1004,
        priority: 1,
        action: { type: 'block' },
        condition: {
          urlFilter: '*messaging/typ*',
          resourceTypes: ['xmlhttprequest']
        }
      }
    ];

    await chrome.declarativeNetRequest.updateDynamicRules({ addRules: typingRules });
    const activeRules = await chrome.declarativeNetRequest.getDynamicRules();

    assert.ok(activeRules.some(r => r.id === 1003));
    assert.ok(activeRules.some(r => r.id === 1004));
  });

  test('T1_072: Disable Typing Blocking DNR Rule removes typing rules', async () => {
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [{
        id: 1003,
        priority: 1,
        action: { type: 'block' },
        condition: { urlFilter: '*messaging/typ*' }
      }]
    });

    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [1003] });
    const activeRules = await chrome.declarativeNetRequest.getDynamicRules();

    assert.ok(!activeRules.some(r => r.id === 1003));
  });

  test('T1_073: Network URL Matching for Typing Endpoint blocks HTTP typ.php request', async () => {
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [{
        id: 1003,
        priority: 1,
        action: { type: 'block' },
        condition: {
          urlFilter: '*typ.php*',
          resourceTypes: ['xmlhttprequest']
        }
      }]
    });

    const targetUrl = 'https://www.facebook.com/ajax/messaging/typ.php?is_typing=1';
    const isBlocked = chrome.declarativeNetRequest.__isUrlBlocked(targetUrl, 'xmlhttprequest');
    assert.strictEqual(isBlocked, true, 'Typing endpoint URL must be blocked by rule 1003');
  });

  test('T1_074: WebSocket Scriptlet MQTT Typing Frame Drop drops /t_tp presence indicator', () => {
    const typingFrame = '{"topic":"/t_tp","payload":{"sender":"me","is_typing":true}}';
    const shouldDrop = shouldDropWebSocketFrame(typingFrame, { blockSeen: false, blockTyping: true });

    assert.strictEqual(shouldDrop, true, 'WebSocket typing frame (/t_tp) must be dropped when blockTyping is active');
  });

  test('T1_075: Normal Message Delivery Unaffected transmits chat message upon hitting Enter', () => {
    const messageFrame = '{"topic":"/send_message","payload":{"thread_id":"t_101","body":"Sounds great!"}}';
    const shouldDrop = shouldDropWebSocketFrame(messageFrame, { blockSeen: true, blockTyping: true });

    assert.strictEqual(shouldDrop, false, 'Outgoing message packet must NOT be dropped');
  });
});
