/**
 * Tier 1 Test Suite: Requirement R3 - Media & Data Backup
 * Exactly 20 tests (T1_041 to T1_060) covering F_R3_1 to F_R3_4
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { ACTION_TYPES } from '../../../shared/constants.js';
import { generateMockDataset, createZipBuffer } from '../../../shared/mock-fixtures.js';

// Domain helper functions for Media & Data Backup export operations
export function getHighestResPhotoUrl(photoNode) {
  if (!photoNode) return null;
  if (photoNode.highResUrl) return photoNode.highResUrl;
  if (Array.isArray(photoNode.renditions) && photoNode.renditions.length > 0) {
    const sorted = [...photoNode.renditions].sort((a, b) => (b.width * b.height) - (a.width * a.height));
    return sorted[0].uri;
  }
  return photoNode.normalResUrl || photoNode.uri || null;
}

export function sanitizeFileName(name) {
  return String(name)
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

export function sanitizeCsvCell(value) {
  if (value === null || value === undefined) return '';
  let str = String(value);

  // Anti-Spreadsheet Formula Injection: Prepend apostrophe if starting with =, +, -, @, or tab
  if (/^[=+\-@\t\r]/.test(str)) {
    str = `'${str}`;
  }

  // RFC 4180 Escaping: If contains comma, quote, or newline, escape inner quotes and wrap in quotes
  if (/[",\n\r]/.test(str)) {
    str = `"${str.replace(/"/g, '""')}"`;
  }

  return str;
}

export function exportFriendsToCsv(friends) {
  const headers = ['UID', 'Name', 'ProfileURL', 'AvatarURL', 'MutualFriends', 'InteractionScore', 'LastInteraction'];
  const rows = [headers.join(',')];

  for (const f of friends) {
    const row = [
      sanitizeCsvCell(f.id),
      sanitizeCsvCell(f.name),
      sanitizeCsvCell(f.profileUrl),
      sanitizeCsvCell(f.avatar || f.avatarUrl),
      sanitizeCsvCell(f.mutualFriends ?? 0),
      sanitizeCsvCell(f.inactivityScore ?? f.interactionScore ?? 0),
      sanitizeCsvCell(f.daysSinceLastInteraction ?? '')
    ];
    rows.push(row.join(','));
  }

  return rows.join('\r\n');
}

export function exportFriendsToJson(friends) {
  return JSON.stringify({
    export_metadata: {
      timestamp: Date.now(),
      total_count: friends.length,
      version: '1.0.0'
    },
    friends
  }, null, 2);
}

export function exportMessagesToCsv(thread) {
  const headers = ['ThreadID', 'ThreadName', 'MessageID', 'SenderID', 'SenderName', 'Timestamp', 'Content', 'AttachmentType', 'AttachmentURL'];
  const rows = [headers.join(',')];

  for (const m of (thread.messages || [])) {
    const row = [
      sanitizeCsvCell(thread.threadId),
      sanitizeCsvCell(thread.participantName || thread.threadName || ''),
      sanitizeCsvCell(m.id),
      sanitizeCsvCell(m.senderId),
      sanitizeCsvCell(m.senderName),
      sanitizeCsvCell(m.timestamp),
      sanitizeCsvCell(m.text || m.content || ''),
      sanitizeCsvCell(m.attachmentType || ''),
      sanitizeCsvCell(m.attachmentUrl || '')
    ];
    rows.push(row.join(','));
  }

  return rows.join('\r\n');
}

export function exportMessagesToJson(thread) {
  return JSON.stringify({
    thread_id: thread.threadId,
    thread_name: thread.participantName || thread.threadName || '',
    participants: thread.participants || [{ id: thread.participantId, name: thread.participantName }],
    messages: thread.messages || []
  }, null, 2);
}

describe('Tier 1: Requirement R3 - Media & Data Backup', () => {
  let client;
  let runner;
  let mockData;

  beforeEach(() => {
    mockData = generateMockDataset(1337);
    client = createMockFacebookApiClient({
      albums: mockData.albums,
      videos: mockData.videos,
      friends: mockData.friends
    });
    runner = new ActionRunner({
      isSimulation: true,
      fastMode: true
    });
  });

  // ----------------------------------------------------
  // F_R3_1: Album Photo Batch Downloader (T1_041 to T1_045)
  // ----------------------------------------------------

  test('T1_041: GraphQL Album Pagination Retrieval extracts photos from album', async () => {
    const photos = await client.fetchAlbumPhotos('album_301');
    assert.ok(Array.isArray(photos));
    assert.ok(photos.length > 0, 'Should return album photos');
    assert.ok(photos[0].id, 'Photo node must have an id');
  });

  test('T1_042: Highest-Resolution Photo URL Selection deterministically selects max pixel representation', () => {
    const photoNode = {
      id: 'photo_test_1',
      renditions: [
        { uri: 'https://fbcdn.net/p_320.jpg', width: 320, height: 240 },
        { uri: 'https://fbcdn.net/p_2048.jpg', width: 2048, height: 1536 },
        { uri: 'https://fbcdn.net/p_720.jpg', width: 720, height: 540 }
      ]
    };

    const bestUrl = getHighestResPhotoUrl(photoNode);
    assert.strictEqual(bestUrl, 'https://fbcdn.net/p_2048.jpg');
  });

  test('T1_043: Direct Download Dispatch via Chrome Downloads registers download records', async () => {
    const targetUrl = 'https://fbcdn.net/album_photo_1.jpg';
    const targetFilename = 'Facebook_Backup/Album_Trip/photo_1.jpg';

    const downloadId = await chrome.downloads.download({
      url: targetUrl,
      filename: targetFilename
    });

    assert.ok(downloadId > 0);
    const downloads = chrome.downloads.__getDownloads();
    assert.ok(downloads.some(d => d.url === targetUrl && d.filename === targetFilename));
  });

  test('T1_044: In-Memory ZIP Bundle Creation generates valid zip archive headers from album photos', async () => {
    const photos = await client.fetchAlbumPhotos('album_301');
    assert.ok(photos.length > 0, 'Album photos must be retrieved from client');

    // Map real album photos into ZIP archive file entries
    const zipEntries = photos.map((p, idx) => ({
      name: `album_photos/photo_${idx + 1}.jpg`,
      data: Buffer.from(`mock-image-bytes-${p.id}`)
    }));

    const zipBuffer = createZipBuffer(zipEntries);

    // 1. Verify ZIP local header magic number PK\x03\x04
    assert.strictEqual(zipBuffer.toString('utf8', 0, 4), 'PK\x03\x04');

    // 2. Verify ZIP end of central directory signature PK\x05\x06 (0x06054b50)
    const eocdSignature = zipBuffer.readUInt32LE(zipBuffer.length - 22);
    assert.strictEqual(eocdSignature, 0x06054b50, 'Must contain valid End of Central Directory signature');

    // 3. Verify forward slash paths
    for (const entry of zipEntries) {
      assert.ok(!entry.name.includes('\\'), 'ZIP entry paths must use forward slashes');
    }
  });

  test('T1_045: Simulation Mode Album Downloader returns simulated download success', async () => {
    runner.setSimulation(true);
    const result = await runner.execute(
      ACTION_TYPES.ALBUM_DOWNLOAD,
      { albumId: 'album_mock_1', count: 12 },
      null
    );

    assert.strictEqual(result.success, true);
    assert.strictEqual(result.isSimulation, true);
    assert.strictEqual(result.actionType, ACTION_TYPES.ALBUM_DOWNLOAD);
  });

  // ----------------------------------------------------
  // F_R3_2: High-Resolution Video Downloader (T1_046 to T1_050)
  // ----------------------------------------------------

  test('T1_046: HD Stream Extraction from Video Page resolves progressive MP4 link', async () => {
    const videoUrl = 'https://www.facebook.com/watch/?v=12345678';
    const streams = await client.fetchVideoStreams(videoUrl);

    assert.ok(streams.hdUrl, 'Must return valid hdUrl');
    assert.match(streams.hdUrl, /\.mp4/);
  });

  test('T1_047: SD Progressive Stream Fallback provides standard stream when HD unavailable', async () => {
    const sdOnlyVideo = {
      id: 'video_sd_fallback_99',
      url: 'https://www.facebook.com/watch/?v=video_sd_fallback_99',
      title: 'Legacy Standard Definition Video',
      hdUrl: null,
      sdUrl: 'https://video.xx.fbcdn.net/v/sd_stream_fallback.mp4'
    };

    const testClient = createMockFacebookApiClient({ videos: [sdOnlyVideo] });
    const streams = await testClient.fetchVideoStreams(sdOnlyVideo.url);

    assert.strictEqual(streams.hdUrl, null, 'HD URL must be null for SD-only video fixture');
    assert.strictEqual(streams.sdUrl, 'https://video.xx.fbcdn.net/v/sd_stream_fallback.mp4', 'SD URL must be resolved');

    // Verify consumer quality selection logic (HD -> SD fallback)
    const effectiveDownloadUrl = streams.hdUrl || streams.sdUrl;
    assert.strictEqual(effectiveDownloadUrl, streams.sdUrl, 'Effective download URL must fall back to SD stream');
  });

  test('T1_048: Sanitized Video Filename Download removes forbidden characters', () => {
    const rawTitle = 'My Cool Video! [2026] <NEW> : special/edition?';
    const clean = sanitizeFileName(rawTitle);

    assert.ok(!/[\\/:*?"<>|]/.test(clean), `Sanitized filename should not contain forbidden characters: ${clean}`);
    assert.match(clean, /My_Cool_Video/);
  });

  test('T1_049: Simulation Mode Video Downloader triggers simulated download pipeline', async () => {
    runner.setSimulation(true);
    const result = await runner.execute(
      ACTION_TYPES.VIDEO_DOWNLOAD,
      { videoId: 'video_3001', quality: 'HD' },
      null
    );

    assert.strictEqual(result.success, true);
    assert.strictEqual(result.isSimulation, true);
  });

  test('T1_050: Facebook Reel Video URL Extraction resolves Reel progressive stream', async () => {
    const reelUrl = 'https://www.facebook.com/reel/98765432';
    const streams = await client.fetchVideoStreams(reelUrl);

    assert.ok(streams.hdUrl || streams.sdUrl);
  });

  // ----------------------------------------------------
  // F_R3_3: Friend List Structured Export (JSON/CSV) (T1_051 to T1_055)
  // ----------------------------------------------------

  test('T1_051: JSON Schema Compliant Friend Export produces valid structure', () => {
    const sampleFriends = mockData.friends.slice(0, 10);
    const jsonStr = exportFriendsToJson(sampleFriends);
    const parsed = JSON.parse(jsonStr);

    assert.ok(parsed.export_metadata, 'JSON export must contain export_metadata');
    assert.strictEqual(parsed.export_metadata.total_count, 10);
    assert.strictEqual(parsed.friends.length, 10);
  });

  test('T1_052: RFC 4180 CSV Compliant Friend Export produces correct columns and rows', () => {
    const sampleFriends = mockData.friends.slice(0, 5);
    const csvStr = exportFriendsToCsv(sampleFriends);
    const lines = csvStr.split('\r\n');

    assert.strictEqual(lines.length, 6, '1 header line + 5 data rows');
    assert.strictEqual(lines[0], 'UID,Name,ProfileURL,AvatarURL,MutualFriends,InteractionScore,LastInteraction');
  });

  test('T1_053: CSV Special Character Quoting properly wraps commas and quotes', () => {
    const friend = {
      id: '10008001',
      name: 'Doe, John "Johnny"',
      profileUrl: 'https://facebook.com/10008001',
      avatarUrl: 'https://facebook.com/avatar.jpg'
    };

    const csv = exportFriendsToCsv([friend]);
    assert.match(csv, /"Doe, John ""Johnny"""/);
  });

  test('T1_054: Spreadsheet Formula Injection Sanitization prepends apostrophe on dangerous prefixes', () => {
    const maliciousNames = [
      '=SUM(1,1)',
      '+CMD|calc',
      '-5+2',
      '@admin'
    ];

    for (const raw of maliciousNames) {
      const sanitized = sanitizeCsvCell(raw);
      assert.ok(sanitized.startsWith("'") || sanitized.startsWith("\"'"), `Formula payload ${raw} must be neutralized with leading apostrophe`);
    }
  });

  test('T1_055: Blob Generation & Download Trigger initiates browser download with export filename', async () => {
    const csvData = exportFriendsToCsv(mockData.friends.slice(0, 5));
    const blob = new globalThis.Blob([csvData], { type: 'text/csv;charset=utf-8' });
    assert.ok(blob.size > 0);

    const blobUrl = globalThis.URL.createObjectURL(blob);
    const downloadId = await chrome.downloads.download({
      url: blobUrl,
      filename: 'Facebook_Backup/facebook_friends_export.csv'
    });

    assert.ok(downloadId > 0);
    const last = chrome.downloads.__getLastDownload();
    assert.strictEqual(last.filename, 'Facebook_Backup/facebook_friends_export.csv');
  });

  // ----------------------------------------------------
  // F_R3_4: Message History Structured Export (JSON/CSV) (T1_056 to T1_060)
  // ----------------------------------------------------

  test('T1_056: JSON Message History Export Structure includes thread metadata and messages', () => {
    const thread = mockData.threads[0];
    const jsonStr = exportMessagesToJson(thread);
    const parsed = JSON.parse(jsonStr);

    assert.strictEqual(parsed.thread_id, thread.threadId);
    assert.ok(Array.isArray(parsed.messages));
    assert.ok(parsed.messages.length > 0);
  });

  test('T1_057: RFC 4180 CSV Message History Export Structure produces valid columns', () => {
    const thread = mockData.threads[0];
    const csvStr = exportMessagesToCsv(thread);
    const lines = csvStr.split('\r\n');

    assert.strictEqual(lines[0], 'ThreadID,ThreadName,MessageID,SenderID,SenderName,Timestamp,Content,AttachmentType,AttachmentURL');
    assert.strictEqual(lines.length, (thread.messages.length + 1));
  });

  test('T1_058: Message Media Attachment Serialization preserves photo and voice note links', () => {
    const thread = {
      threadId: 'thread_attach_1',
      participantName: 'Alice',
      messages: [
        {
          id: 'msg_att_1',
          senderId: 'user_1',
          senderName: 'Alice',
          timestamp: Date.now(),
          text: 'Here is the photo',
          attachmentType: 'PHOTO',
          attachmentUrl: 'https://fbcdn.net/attach_photo_1.jpg'
        }
      ]
    };

    const csv = exportMessagesToCsv(thread);
    assert.match(csv, /PHOTO/);
    assert.match(csv, /attach_photo_1\.jpg/);
  });

  test('T1_059: Reaction Metadata Preservation preserves reaction payload in JSON message export', () => {
    const thread = {
      threadId: 'thread_react_1',
      participantName: 'Bob',
      messages: [
        {
          id: 'msg_react_1',
          senderId: 'user_2',
          senderName: 'Bob',
          timestamp: Date.now(),
          text: 'Great news!',
          reactions: [{ reaction: 'HEART', actor_id: '100080123' }]
        }
      ]
    };

    const json = exportMessagesToJson(thread);
    const parsed = JSON.parse(json);
    assert.strictEqual(parsed.messages[0].reactions[0].reaction, 'HEART');
    assert.strictEqual(parsed.messages[0].reactions[0].actor_id, '100080123');
  });

  test('T1_060: Simulation Mode Message Export completes structured message export offline', async () => {
    runner.setSimulation(true);
    const result = await runner.execute(
      ACTION_TYPES.EXPORT_MESSAGES,
      { threadId: 'thread_sim_1', format: 'CSV' },
      null
    );

    assert.strictEqual(result.success, true);
    assert.strictEqual(result.isSimulation, true);
    assert.strictEqual(result.actionType, ACTION_TYPES.EXPORT_MESSAGES);
  });
});
