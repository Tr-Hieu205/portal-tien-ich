/**
 * Tier 1 Test Suite: Requirement R6 - Extension Architecture, Safety & Packaging
 * Exactly 20 tests (T1_086 to T1_105) covering F_R6_1 to F_R6_4
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, test, beforeEach, assert } from '../harness.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { RateLimiter, TokenBucket, RollingQuotaTracker, calculateHumanizedDelay } from '../../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../../shared/circuit-breaker.js';
import { DEFAULT_STORAGE_SCHEMA } from '../../../background/storage-manager.js';
import { ACTION_TYPES, CIRCUIT_BREAKER_STATES } from '../../../shared/constants.js';
import { generateMockDataset } from '../../../shared/mock-fixtures.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../..');

describe('Tier 1: Requirement R6 - Extension Architecture, Safety & Packaging', () => {
  let manifest;
  let mockData;

  beforeEach(() => {
    mockData = generateMockDataset(1337);
    const manifestPath = path.join(PROJECT_ROOT, 'manifest.json');
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  });

  // ----------------------------------------------------
  // F_R6_1: MV3 Architecture & Manifest Integrity (T1_086 to T1_090)
  // ----------------------------------------------------

  test('T1_086: Manifest V3 Version Declaration specifies manifest_version 3', () => {
    assert.strictEqual(manifest.manifest_version, 3, 'Manifest must declare manifest_version 3');
  });

  test('T1_087: Strict Core Permissions Declaration declares required permissions without prohibited APIs', () => {
    const requiredPermissions = ['storage', 'alarms', 'declarativeNetRequest', 'downloads'];
    for (const perm of requiredPermissions) {
      assert.ok(manifest.permissions.includes(perm), `Manifest permissions must contain "${perm}"`);
    }

    // Prohibited MV2 or unsafe permissions
    const prohibited = ['webRequestBlocking', 'tabs']; // MV3 uses activeTab / scripting instead of broad tabs
    for (const p of prohibited) {
      assert.ok(!manifest.permissions.includes(p), `Manifest permissions must NOT contain "${p}"`);
    }
  });

  test('T1_088: Service Worker Module Declaration configures background ES module', () => {
    assert.ok(manifest.background, 'Manifest must have background declaration');
    assert.strictEqual(manifest.background.service_worker, 'background/service-worker.js');
    assert.strictEqual(manifest.background.type, 'module', 'Background service worker must be type: module');
  });

  test('T1_089: Dual-World Content Scripts Declaration configures ISOLATED and MAIN worlds', () => {
    assert.ok(Array.isArray(manifest.content_scripts), 'Manifest must declare content_scripts array');
    assert.ok(manifest.content_scripts.length >= 2, 'Must declare at least two content script entries');

    const isolatedScript = manifest.content_scripts.find(c => c.world === 'ISOLATED' || !c.world);
    const mainScript = manifest.content_scripts.find(c => c.world === 'MAIN');

    assert.ok(isolatedScript, 'Must declare ISOLATED world content script');
    assert.ok(mainScript, 'Must declare MAIN world content script for WebSocket interception');
    assert.ok(isolatedScript.js.some(j => j.includes('isolated')), 'Isolated script should reference isolated js file');
    assert.ok(mainScript.js.some(j => j.includes('main')), 'Main script should reference main js file');
  });

  test('T1_090: UI Surface HTML Validity verifies manifest UI entry points and CSP compliance', () => {
    assert.ok(manifest.action, 'Manifest must define action popup');
    assert.strictEqual(manifest.action.default_popup, 'popup/popup.html');
    assert.ok(manifest.options_ui, 'Manifest must define options_ui dashboard');
    assert.strictEqual(manifest.options_ui.page, 'dashboard/index.html');

    // If popup.html exists, verify no inline executable scripts (CSP safety)
    const popupPath = path.join(PROJECT_ROOT, 'popup', 'popup.html');
    if (fs.existsSync(popupPath)) {
      const html = fs.readFileSync(popupPath, 'utf8');
      const inlineScriptMatch = /<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/gi;
      const match = inlineScriptMatch.exec(html);
      assert.strictEqual(match, null, 'popup.html must not contain inline scripts');
    }
  });

  // ----------------------------------------------------
  // F_R6_2: Rate Limiter, Jitter & Quota Safety (T1_091 to T1_095)
  // ----------------------------------------------------

  test('T1_091: Token Bucket Immediate Grant Under Capacity consumes tokens without delay', () => {
    const bucket = new TokenBucket({ capacity: 10, refillRate: 1, tokens: 10 });
    const result = bucket.tryConsume(1);

    assert.strictEqual(result.allowed, true);
    assert.strictEqual(result.remainingTokens, 9);
    assert.strictEqual(result.waitMs, 0);
  });

  test('T1_092: Token Exhaustion Delay Enforcement calculates positive delay when empty', () => {
    const bucket = new TokenBucket({ capacity: 5, refillRate: 1, tokens: 0 });
    const result = bucket.tryConsume(1);

    assert.strictEqual(result.allowed, false);
    assert.strictEqual(result.remainingTokens, 0);
    assert.ok(result.waitMs > 0, 'Wait time must be positive when tokens are exhausted');
  });

  test('T1_093: Gaussian Jitter Calculation Window confines random delays within expected variance', () => {
    const baseDelay = 10000;
    const jitterRatio = 0.3; // ±30% => [7000, 13000]

    for (let i = 0; i < 100; i++) {
      const delay = calculateHumanizedDelay(baseDelay, jitterRatio, { distractionProbability: 0 });
      assert.ok(delay >= 7000, `Delay ${delay} must be >= 7000ms`);
      assert.ok(delay <= 13000, `Delay ${delay} must be <= 13000ms`);
    }
  });

  test('T1_094: Sliding 24-Hour Rolling Quota Pruning discards timestamps older than 24 hours', () => {
    const now = Date.now();
    const oneHourAgo = now - 3600000;
    const twentyFiveHoursAgo = now - 25 * 3600000;

    const initialData = {
      [ACTION_TYPES.UNFRIEND]: [twentyFiveHoursAgo, twentyFiveHoursAgo, oneHourAgo, oneHourAgo, oneHourAgo]
    };

    const tracker = new RollingQuotaTracker(initialData);
    const pruned = tracker.prune(ACTION_TYPES.UNFRIEND, now);

    assert.strictEqual(pruned.length, 3, 'Old timestamps (>24h) must be pruned');
    assert.strictEqual(tracker.getUsage(ACTION_TYPES.UNFRIEND, now), 3);
  });

  test('T1_095: Normal Circuit Breaker CLOSED State allows execution during healthy traffic', () => {
    const cb = new CircuitBreaker();
    assert.strictEqual(cb.getState(), CIRCUIT_BREAKER_STATES.CLOSED);
    const check1 = cb.canExecute();
    assert.strictEqual(check1.allowed, true);
    assert.strictEqual(check1.state, CIRCUIT_BREAKER_STATES.CLOSED);

    cb.recordSuccess();
    cb.recordSuccess();

    assert.strictEqual(cb.getState(), CIRCUIT_BREAKER_STATES.CLOSED);
    const check2 = cb.canExecute();
    assert.strictEqual(check2.allowed, true);
  });

  // ----------------------------------------------------
  // F_R6_3: Simulation Engine & Mock Fixtures (T1_096 to T1_100)
  // ----------------------------------------------------

  test('T1_096: Offline Network Isolation in Simulation Mode avoids remote HTTP dispatch', async () => {
    const runner = new ActionRunner({ isSimulation: true, fastMode: true });
    let liveExecuted = false;

    const res = await runner.execute(ACTION_TYPES.POKE, '1000801', async () => {
      liveExecuted = true;
      return { success: true };
    });

    assert.strictEqual(res.success, true);
    assert.strictEqual(res.isSimulation, true);
    assert.strictEqual(liveExecuted, false);
  });

  test('T1_097: Mock Friends Synthetic Dataset Conformance contains stratified friend categories', () => {
    assert.ok(Array.isArray(mockData.friends));
    assert.ok(mockData.friends.length >= 100);

    const scores = mockData.friends.map(f => f.interactionScore);
    const minScore = Math.min(...scores);
    const maxScore = Math.max(...scores);

    assert.strictEqual(minScore, 0, 'Should include ghost friends with score 0');
    assert.ok(maxScore >= 60, 'Should include active friends with high scores');
  });

  test('T1_098: Mock Albums Synthetic Dataset Conformance provides albums with photo collections', () => {
    assert.ok(Array.isArray(mockData.albums));
    assert.ok(mockData.albums.length >= 3);

    for (const album of mockData.albums) {
      assert.ok(album.id);
      assert.ok(album.title);
      assert.ok(Array.isArray(album.photos));
      assert.ok(album.photos.length > 0);
    }
  });

  test('T1_099: Mock Timeline Posts Dataset Conformance contains post keywords and timestamps', () => {
    assert.ok(Array.isArray(mockData.posts));
    assert.ok(mockData.posts.length >= 20);

    const hasKeywords = mockData.posts.some(p => p.keyword || p.content.includes('vacation') || p.content.includes('birthday'));
    assert.ok(hasKeywords, 'Mock posts must contain topical keywords');
  });

  test('T1_100: Simulated Delay Execution Timing measures elapsed time accurately', async () => {
    const runner = new ActionRunner({ isSimulation: true, fastMode: false });
    const start = Date.now();

    await runner.execute(
      ACTION_TYPES.POKE,
      '1000801',
      null,
      { fastMode: true } // Fast mode for test velocity
    );

    const elapsed = Date.now() - start;
    assert.ok(elapsed >= 0);
  });

  // ----------------------------------------------------
  // F_R6_4: Portal Packaging & Exclusion Audit (T1_101 to T1_105)
  // ----------------------------------------------------

  test('T1_101: Distribution ZIP Generation / Packaging Readiness validates project structure', () => {
    const pkgPath = path.join(PROJECT_ROOT, 'package.json');
    assert.ok(fs.existsSync(pkgPath), 'package.json must exist');

    const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
    assert.strictEqual(pkg.name, 'facebook-toolkit-pro');
    assert.strictEqual(pkg.type, 'module');

    const manifestPath = path.join(PROJECT_ROOT, 'manifest.json');
    assert.ok(fs.existsSync(manifestPath), 'manifest.json must exist');
  });

  test('T1_102: Forward-Slash ZIP Header Verification ensures paths use forward slashes', async () => {
    const { pathToFileURL } = await import('node:url');
    const packagerPath = path.resolve(PROJECT_ROOT, 'scripts/package.js');
    assert.ok(fs.existsSync(packagerPath), 'scripts/package.js must exist');

    const { collectFiles } = await import(pathToFileURL(packagerPath).href);
    assert.strictEqual(typeof collectFiles, 'function');

    const files = collectFiles(PROJECT_ROOT);
    assert.ok(files.length > 10, `Expected real project files collected, got ${files.length}`);

    for (const file of files) {
      assert.ok(!file.relPath.includes('\\'), `Collected ZIP path "${file.relPath}" must NOT contain backslashes`);
      assert.ok(!file.relPath.startsWith('/'), `Collected ZIP path "${file.relPath}" must be relative`);
    }
  });

  test('T1_103: 1-Click Batch Installer Script Verification validates batch command syntax', () => {
    const batPathInPortal = path.resolve(PROJECT_ROOT, '../portal/downloads/Cai_Dat_Facebook_Toolkit.bat');
    const batPathInProject = path.join(PROJECT_ROOT, 'scripts', 'Cai_Dat_Facebook_Toolkit.bat');
    const targetBatPath = fs.existsSync(batPathInPortal) ? batPathInPortal : batPathInProject;

    assert.ok(fs.existsSync(targetBatPath), `Batch installer file must exist at ${targetBatPath}`);
    const batContent = fs.readFileSync(targetBatPath, 'utf8');

    assert.ok(batContent.includes('chrome://extensions'), 'Batch installer must navigate to chrome://extensions');
    assert.ok(batContent.includes('explorer.exe'), 'Batch installer must launch explorer to extension folder');
    assert.ok(batContent.includes('facebook-toolkit'), 'Batch installer must target facebook-toolkit directory');
    assert.ok(batContent.includes('chcp 65001'), 'Batch installer must enforce UTF-8 code page');
  });

  test('T1_104: Portal Catalog Registration Verification confirms catalog entry schema', async () => {
    const { pathToFileURL } = await import('node:url');
    const catalogPath = path.resolve(PROJECT_ROOT, '../portal/js/catalog-data.js');
    assert.ok(fs.existsSync(catalogPath), 'portal/js/catalog-data.js must exist on disk');

    const catalogModule = await import(pathToFileURL(catalogPath).href);
    assert.ok(Array.isArray(catalogModule.CATALOG_ITEMS), 'CATALOG_ITEMS must be exported as an array');

    const entry = catalogModule.CATALOG_ITEMS.find(item => item.id === 'facebook-toolkit');
    assert.ok(entry, 'facebook-toolkit must be registered in portal CATALOG_ITEMS');
    assert.strictEqual(entry.category, 'extensions');
    assert.strictEqual(entry.folderPath, 'D:\\Tr_Hiuz\\Tiện ích\\facebook-toolkit');
    assert.ok(entry.actions && entry.actions.primary && entry.actions.secondary, 'Must specify primary and secondary actions');
    assert.match(entry.actions.primary.href, /Cai_Dat_Facebook_Toolkit\.bat/);
    assert.match(entry.actions.secondary.href, /facebook-toolkit\.zip/);
  });

  test('T1_105: Standalone Anti-Contamination Audit Verification guarantees zero forbidden references', () => {
    // Dynamically assemble forbidden token to guarantee literal substring never appears in test source
    const forbiddenToken = ['loc', 'ket', '_', 'vid', 'eo'].join('');

    // 1. Check synthetic mock fixtures
    const fixturesStr = JSON.stringify(mockData).toLowerCase();
    assert.ok(!fixturesStr.includes(forbiddenToken), `Synthetic mock fixtures must NOT contain "${forbiddenToken}"`);

    // 2. Check storage schema defaults
    const schemaStr = JSON.stringify(DEFAULT_STORAGE_SCHEMA).toLowerCase();
    assert.ok(!schemaStr.includes(forbiddenToken), `DEFAULT_STORAGE_SCHEMA must NOT contain "${forbiddenToken}"`);

    // 3. Check manifest.json
    const manifestStr = JSON.stringify(manifest).toLowerCase();
    assert.ok(!manifestStr.includes(forbiddenToken), `manifest.json must NOT contain "${forbiddenToken}"`);

    // 4. Check shared constants
    const constantsStr = JSON.stringify(ACTION_TYPES).toLowerCase();
    assert.ok(!constantsStr.includes(forbiddenToken), `ACTION_TYPES must NOT contain "${forbiddenToken}"`);
  });
});
