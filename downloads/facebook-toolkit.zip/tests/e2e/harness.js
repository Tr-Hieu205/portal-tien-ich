/**
 * Facebook Toolkit Pro - E2E Test Harness
 * Lightweight test runner supporting asynchronous suites, lifecycle hooks,
 * strict assertions, and structured console reporting.
 */

import assert from 'node:assert/strict';

class TestHarness {
  constructor() {
    this.tests = [];
    this.suites = [];
    this.currentSuite = null;
    this.beforeHooks = [];
    this.afterHooks = [];
    this.beforeEachHooks = [];
    this.afterEachHooks = [];
    this.reporterQuiet = false;
  }

  describe(name, fn) {
    const parentSuite = this.currentSuite;
    const suite = {
      name,
      parent: parentSuite,
      tests: [],
      beforeHooks: [],
      afterHooks: [],
      beforeEachHooks: [],
      afterEachHooks: []
    };

    this.suites.push(suite);
    this.currentSuite = suite;

    try {
      fn();
    } finally {
      this.currentSuite = parentSuite;
    }
  }

  test(name, fn, options = {}) {
    const fullName = this.currentSuite ? `${this.currentSuite.name} > ${name}` : name;
    const testItem = {
      name: fullName,
      shortName: name,
      fn,
      suite: this.currentSuite,
      timeout: options.timeout || 10000,
      skip: Boolean(options.skip)
    };

    if (this.currentSuite) {
      this.currentSuite.tests.push(testItem);
    }
    this.tests.push(testItem);
  }

  before(fn) {
    if (this.currentSuite) {
      this.currentSuite.beforeHooks.push(fn);
    } else {
      this.beforeHooks.push(fn);
    }
  }

  after(fn) {
    if (this.currentSuite) {
      this.currentSuite.afterHooks.push(fn);
    } else {
      this.afterHooks.push(fn);
    }
  }

  beforeEach(fn) {
    if (this.currentSuite) {
      this.currentSuite.beforeEachHooks.push(fn);
    } else {
      this.beforeEachHooks.push(fn);
    }
  }

  afterEach(fn) {
    if (this.currentSuite) {
      this.currentSuite.afterEachHooks.push(fn);
    } else {
      this.afterEachHooks.push(fn);
    }
  }

  reset() {
    this.tests = [];
    this.suites = [];
    this.currentSuite = null;
    this.beforeHooks = [];
    this.afterHooks = [];
    this.beforeEachHooks = [];
    this.afterEachHooks = [];
  }

  async run(options = {}) {
    const filter = options.filter || null;
    const quiet = options.quiet ?? this.reporterQuiet;

    let passed = 0;
    let failed = 0;
    let skipped = 0;
    const errors = [];
    const startTime = Date.now();

    // Global before hooks
    for (const hook of this.beforeHooks) {
      try {
        await hook();
      } catch (err) {
        failed++;
        errors.push({ name: 'global:beforeHook', error: err });
        if (!quiet) {
          console.error(`  ✗ [FAIL] global:beforeHook`);
          console.error(`    Error: ${err?.message || err}`);
        }
      }
    }

    const targetTests = filter
      ? this.tests.filter(t => t.name.includes(filter) || (t.shortName && t.shortName.includes(filter)))
      : this.tests;

    // Track active suite stack for suite-level before/after hooks
    const activeSuites = [];

    const closeSuitesDownTo = async (targetDepth) => {
      while (activeSuites.length > targetDepth) {
        const suite = activeSuites.pop();
        for (const hook of suite.afterHooks) {
          try {
            await hook();
          } catch (err) {
            failed++;
            errors.push({ name: `${suite.name}:afterHook`, error: err });
            if (!quiet) {
              console.error(`  ✗ [FAIL] ${suite.name}:afterHook`);
              console.error(`    Error: ${err?.message || err}`);
            }
          }
        }
      }
    };

    for (const t of targetTests) {
      // Build suite chain for the test: from root suite down to immediate parent
      const suiteChain = [];
      let s = t.suite;
      while (s) {
        suiteChain.unshift(s);
        s = s.parent;
      }

      // Find common prefix depth between currently activeSuites and suiteChain
      let commonDepth = 0;
      while (
        commonDepth < activeSuites.length &&
        commonDepth < suiteChain.length &&
        activeSuites[commonDepth] === suiteChain[commonDepth]
      ) {
        commonDepth++;
      }

      // Close suites that are no longer active
      await closeSuitesDownTo(commonDepth);

      // Open new suites and run their beforeHooks
      for (let i = commonDepth; i < suiteChain.length; i++) {
        const suite = suiteChain[i];
        activeSuites.push(suite);
        for (const hook of suite.beforeHooks) {
          try {
            await hook();
          } catch (err) {
            failed++;
            errors.push({ name: `${suite.name}:beforeHook`, error: err });
            if (!quiet) {
              console.error(`  ✗ [FAIL] ${suite.name}:beforeHook`);
              console.error(`    Error: ${err?.message || err}`);
            }
          }
        }
      }

      if (t.skip) {
        skipped++;
        if (!quiet) {
          console.log(`  - [SKIP] ${t.name}`);
        }
        continue;
      }

      // Collect beforeEach hooks: root + parent suites + current suite
      const activeBeforeEach = [...this.beforeEachHooks];
      const activeAfterEach = [...this.afterEachHooks];
      for (const chainSuite of suiteChain) {
        activeBeforeEach.push(...chainSuite.beforeEachHooks);
        activeAfterEach.unshift(...chainSuite.afterEachHooks);
      }

      const testStartTime = Date.now();
      let testPassed = false;
      let testError = null;
      let timer;

      try {
        for (const hook of activeBeforeEach) {
          await hook();
        }

        // Run test with timeout
        await Promise.race([
          Promise.resolve(t.fn()),
          new Promise((_, reject) => {
            timer = setTimeout(() => reject(new Error(`Test timed out after ${t.timeout}ms`)), t.timeout);
            if (typeof timer.unref === 'function') timer.unref();
          })
        ]);

        testPassed = true;
      } catch (err) {
        testPassed = false;
        testError = err;
      } finally {
        if (timer) clearTimeout(timer);
        for (const hook of activeAfterEach) {
          try {
            await hook();
          } catch (hookErr) {
            testPassed = false;
            if (!testError) testError = hookErr;
          }
        }
      }

      const durationMs = Date.now() - testStartTime;

      if (testPassed) {
        passed++;
        if (!quiet) {
          console.log(`  ✓ [PASS] ${t.name} (${durationMs}ms)`);
        }
      } else {
        failed++;
        errors.push({ name: t.name, error: testError, durationMs });
        if (!quiet) {
          console.error(`  ✗ [FAIL] ${t.name} (${durationMs}ms)`);
          console.error(`    Error: ${testError?.message || testError}`);
          if (testError?.stack) {
            const stackLines = testError.stack.split('\n').slice(1, 4).join('\n');
            console.error(`    ${stackLines}`);
          }
        }
      }
    }

    // Close any remaining active suites
    await closeSuitesDownTo(0);

    // Global after hooks
    for (const hook of this.afterHooks) {
      try {
        await hook();
      } catch (err) {
        failed++;
        errors.push({ name: 'global:afterHook', error: err });
        if (!quiet) {
          console.error(`  ✗ [FAIL] global:afterHook`);
          console.error(`    Error: ${err?.message || err}`);
        }
      }
    }

    const totalDurationMs = Date.now() - startTime;

    return {
      total: targetTests.length,
      passed,
      failed,
      skipped,
      errors,
      durationMs: totalDurationMs
    };
  }
}

// Singleton harness instance
export const harness = new TestHarness();

// Export standard BDD functions bound to default harness
export const describe = (name, fn) => harness.describe(name, fn);
export const test = (name, fn, options) => harness.test(name, fn, options);
export const it = test;
export const before = (fn) => harness.before(fn);
export const after = (fn) => harness.after(fn);
export const beforeEach = (fn) => harness.beforeEach(fn);
export const afterEach = (fn) => harness.afterEach(fn);

// Re-export strict assertion library
export { assert };
export default harness;
