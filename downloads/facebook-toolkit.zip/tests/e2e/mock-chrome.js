/**
 * Facebook Toolkit Pro - Mock Chrome Extension Runtime (MV3)
 * High-fidelity in-memory mock environment for Chrome MV3 Extension APIs:
 * - chrome.storage.local (with onChanged and inspection hooks)
 * - chrome.alarms (with virtual time __tick and __trigger)
 * - chrome.declarativeNetRequest (with __isUrlBlocked)
 * - chrome.downloads (with __getDownloads)
 * - chrome.runtime (with message passing and manifest)
 * - chrome.tabs (with tab query and messaging)
 * Includes built-in synthetic fallback client implementing IFacebookApiClient.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../..');

function deepClone(obj) {
  if (obj === undefined) return undefined;
  return JSON.parse(JSON.stringify(obj));
}

export function createMockChrome(initialStorageState = {}) {
  // ----------------------------------------------------
  // 1. chrome.storage.local
  // ----------------------------------------------------
  let storageStore = deepClone(initialStorageState) || {};
  const storageChangeListeners = [];

  const storageLocal = {
    get(keys, callback) {
      return new Promise((resolve) => {
        let result = {};
        if (keys === null || keys === undefined) {
          result = deepClone(storageStore);
        } else if (typeof keys === 'string') {
          if (storageStore[keys] !== undefined) {
            result[keys] = deepClone(storageStore[keys]);
          }
        } else if (Array.isArray(keys)) {
          for (const k of keys) {
            if (storageStore[k] !== undefined) {
              result[k] = deepClone(storageStore[k]);
            }
          }
        } else if (typeof keys === 'object') {
          result = { ...keys };
          for (const [k, defaultVal] of Object.entries(keys)) {
            if (storageStore[k] !== undefined) {
              result[k] = deepClone(storageStore[k]);
            } else {
              result[k] = deepClone(defaultVal);
            }
          }
        }

        if (typeof callback === 'function') callback(result);
        resolve(result);
      });
    },

    set(items, callback) {
      return new Promise((resolve) => {
        const changes = {};
        for (const [key, newValue] of Object.entries(items)) {
          const oldValue = storageStore[key];
          storageStore[key] = deepClone(newValue);
          changes[key] = {
            oldValue: deepClone(oldValue),
            newValue: deepClone(newValue)
          };
        }

        for (const listener of storageChangeListeners) {
          try {
            listener(changes, 'local');
          } catch (e) {
            console.error('Error in storage onChanged listener:', e);
          }
        }

        if (typeof callback === 'function') callback();
        resolve();
      });
    },

    remove(keys, callback) {
      return new Promise((resolve) => {
        const keyList = Array.isArray(keys) ? keys : [keys];
        const changes = {};
        for (const k of keyList) {
          if (storageStore[k] !== undefined) {
            changes[k] = { oldValue: deepClone(storageStore[k]), newValue: undefined };
            delete storageStore[k];
          }
        }

        if (Object.keys(changes).length > 0) {
          for (const listener of storageChangeListeners) {
            try {
              listener(changes, 'local');
            } catch (e) {
              console.error('Error in storage onChanged listener:', e);
            }
          }
        }

        if (typeof callback === 'function') callback();
        resolve();
      });
    },

    clear(callback) {
      return new Promise((resolve) => {
        const changes = {};
        for (const [k, v] of Object.entries(storageStore)) {
          changes[k] = { oldValue: deepClone(v), newValue: undefined };
        }
        storageStore = {};

        for (const listener of storageChangeListeners) {
          try {
            listener(changes, 'local');
          } catch (e) {
            console.error('Error in storage onChanged listener:', e);
          }
        }

        if (typeof callback === 'function') callback();
        resolve();
      });
    },

    getBytesInUse(keys, callback) {
      return new Promise((resolve) => {
        const bytes = JSON.stringify(storageStore).length;
        if (typeof callback === 'function') callback(bytes);
        resolve(bytes);
      });
    },

    onChanged: {
      addListener(fn) {
        if (!storageChangeListeners.includes(fn)) storageChangeListeners.push(fn);
      },
      removeListener(fn) {
        const idx = storageChangeListeners.indexOf(fn);
        if (idx !== -1) storageChangeListeners.splice(idx, 1);
      },
      hasListener(fn) {
        return storageChangeListeners.includes(fn);
      }
    },

    __dump() {
      return deepClone(storageStore);
    },

    __reset(initial = {}) {
      storageStore = deepClone(initial);
      storageChangeListeners.length = 0;
    }
  };

  // ----------------------------------------------------
  // 2. chrome.alarms
  // ----------------------------------------------------
  const alarmsMap = new Map();
  const alarmListeners = [];
  let virtualTime = Date.now();

  const alarms = {
    create(name, alarmInfo = {}) {
      let scheduledTime = virtualTime;
      if (alarmInfo.when) {
        scheduledTime = alarmInfo.when;
      } else if (alarmInfo.delayInMinutes) {
        scheduledTime = virtualTime + alarmInfo.delayInMinutes * 60 * 1000;
      } else if (alarmInfo.periodInMinutes) {
        scheduledTime = virtualTime + alarmInfo.periodInMinutes * 60 * 1000;
      }

      alarmsMap.set(name, {
        name,
        scheduledTime,
        periodInMinutes: alarmInfo.periodInMinutes || null
      });
    },

    get(name, callback) {
      return new Promise((resolve) => {
        const alarm = alarmsMap.get(name) || null;
        if (typeof callback === 'function') callback(deepClone(alarm));
        resolve(deepClone(alarm));
      });
    },

    getAll(callback) {
      return new Promise((resolve) => {
        const list = Array.from(alarmsMap.values()).map(deepClone);
        if (typeof callback === 'function') callback(list);
        resolve(list);
      });
    },

    clear(name, callback) {
      return new Promise((resolve) => {
        const existed = alarmsMap.delete(name);
        if (typeof callback === 'function') callback(existed);
        resolve(existed);
      });
    },

    clearAll(callback) {
      return new Promise((resolve) => {
        const count = alarmsMap.size;
        alarmsMap.clear();
        if (typeof callback === 'function') callback(count > 0);
        resolve(count > 0);
      });
    },

    onAlarm: {
      addListener(fn) {
        if (!alarmListeners.includes(fn)) alarmListeners.push(fn);
      },
      removeListener(fn) {
        const idx = alarmListeners.indexOf(fn);
        if (idx !== -1) alarmListeners.splice(idx, 1);
      },
      hasListener(fn) {
        return alarmListeners.includes(fn);
      }
    },

    __trigger(name) {
      const alarm = alarmsMap.get(name);
      if (alarm) {
        for (const fn of alarmListeners) {
          fn(deepClone(alarm));
        }
      }
    },

    __tick(minutes) {
      virtualTime += minutes * 60 * 1000;
      for (const [name, alarm] of alarmsMap.entries()) {
        if (alarm.scheduledTime <= virtualTime) {
          for (const fn of alarmListeners) {
            fn(deepClone(alarm));
          }
          if (alarm.periodInMinutes) {
            alarm.scheduledTime = virtualTime + alarm.periodInMinutes * 60 * 1000;
          } else {
            alarmsMap.delete(name);
          }
        }
      }
    },

    __reset() {
      alarmsMap.clear();
      alarmListeners.length = 0;
      virtualTime = Date.now();
    }
  };

  // ----------------------------------------------------
  // 3. chrome.declarativeNetRequest
  // ----------------------------------------------------
  let dynamicRules = [];
  let sessionRules = [];
  const enabledRulesets = new Set(['stealth_rules', 'stealth-rules']);

  const declarativeNetRequest = {
    getDynamicRules(callback) {
      return new Promise((resolve) => {
        const res = deepClone(dynamicRules);
        if (typeof callback === 'function') callback(res);
        resolve(res);
      });
    },

    updateDynamicRules({ addRules = [], removeRuleIds = [] } = {}, callback) {
      return new Promise((resolve) => {
        if (Array.isArray(removeRuleIds)) {
          dynamicRules = dynamicRules.filter(r => !removeRuleIds.includes(r.id));
        }
        if (Array.isArray(addRules)) {
          for (const rule of addRules) {
            // Remove existing if duplicate id
            dynamicRules = dynamicRules.filter(r => r.id !== rule.id);
            dynamicRules.push(deepClone(rule));
          }
        }
        if (typeof callback === 'function') callback();
        resolve();
      });
    },

    getSessionRules(callback) {
      return new Promise((resolve) => {
        const res = deepClone(sessionRules);
        if (typeof callback === 'function') callback(res);
        resolve(res);
      });
    },

    updateSessionRules({ addRules = [], removeRuleIds = [] } = {}, callback) {
      return new Promise((resolve) => {
        if (Array.isArray(removeRuleIds)) {
          sessionRules = sessionRules.filter(r => !removeRuleIds.includes(r.id));
        }
        if (Array.isArray(addRules)) {
          for (const rule of addRules) {
            sessionRules = sessionRules.filter(r => r.id !== rule.id);
            sessionRules.push(deepClone(rule));
          }
        }
        if (typeof callback === 'function') callback();
        resolve();
      });
    },

    getEnabledRulesets(callback) {
      return new Promise((resolve) => {
        const res = Array.from(enabledRulesets);
        if (typeof callback === 'function') callback(res);
        resolve(res);
      });
    },

    updateEnabledRulesets({ enableRulesetIds = [], disableRulesetIds = [] } = {}, callback) {
      return new Promise((resolve) => {
        for (const id of disableRulesetIds) enabledRulesets.delete(id);
        for (const id of enableRulesetIds) enabledRulesets.add(id);
        if (typeof callback === 'function') callback();
        resolve();
      });
    },

    isRegexSupported(regexOptions, callback) {
      return new Promise((resolve) => {
        const res = { isSupported: true };
        if (typeof callback === 'function') callback(res);
        resolve(res);
      });
    },

    __isUrlBlocked(url, resourceType = 'xmlhttprequest') {
      const allActiveRules = [...dynamicRules, ...sessionRules];

      // Check static rules from file if ruleset is enabled
      if (enabledRulesets.has('stealth_rules') || enabledRulesets.has('stealth-rules')) {
        try {
          const rulesFilePath = path.join(PROJECT_ROOT, 'rules', 'stealth-rules.json');
          if (fs.existsSync(rulesFilePath)) {
            const raw = fs.readFileSync(rulesFilePath, 'utf8');
            if (raw.trim() && raw.trim() !== '{}' && raw.trim() !== '[]') {
              const staticRules = JSON.parse(raw);
              if (Array.isArray(staticRules)) {
                allActiveRules.push(...staticRules);
              }
            }
          }
        } catch (_) {}
      }

      for (const rule of allActiveRules) {
        if (!rule.condition) continue;
        const actionType = rule.action?.type || rule.action;
        if (actionType !== 'block') continue;

        const { urlFilter, regexFilter, resourceTypes } = rule.condition;
        if (resourceTypes && Array.isArray(resourceTypes) && !resourceTypes.includes(resourceType)) {
          continue;
        }

        if (urlFilter) {
          // Convert glob-like filter into simple regex
          const pattern = urlFilter
            .replace(/[.+?^${}()|[\]\\]/g, '\\$&')
            .replace(/\*/g, '.*');
          const regex = new RegExp(pattern, 'i');
          if (regex.test(url)) return true;
        }

        if (regexFilter) {
          const regex = new RegExp(regexFilter, 'i');
          if (regex.test(url)) return true;
        }
      }

      return false;
    },

    __reset() {
      dynamicRules = [];
      sessionRules = [];
      enabledRulesets.clear();
      enabledRulesets.add('stealth_rules');
      enabledRulesets.add('stealth-rules');
    }
  };

  // ----------------------------------------------------
  // 4. chrome.downloads
  // ----------------------------------------------------
  const downloadsHistory = [];
  let downloadIdCounter = 1;

  const downloads = {
    download(options = {}, callback) {
      return new Promise((resolve, reject) => {
        if (!options.url) {
          const err = new Error('Download options must contain a url');
          if (typeof callback === 'function') callback(undefined);
          return reject(err);
        }

        if (options.simulateCancel) {
          const err = new Error('Download was cancelled by user');
          err.code = 'USER_CANCELED';
          if (typeof callback === 'function') callback(undefined);
          return reject(err);
        }

        const item = {
          id: downloadIdCounter++,
          url: options.url,
          filename: options.filename || 'download',
          state: 'complete',
          bytesReceived: 1024,
          totalBytes: 1024,
          startTime: new Date().toISOString(),
          mime: 'application/octet-stream',
          saveAs: Boolean(options.saveAs)
        };

        downloadsHistory.push(item);
        if (typeof callback === 'function') callback(item.id);
        resolve(item.id);
      });
    },

    search(query = {}, callback) {
      return new Promise((resolve) => {
        let results = [...downloadsHistory];
        if (query.id !== undefined) results = results.filter(d => d.id === query.id);
        if (query.url) results = results.filter(d => d.url.includes(query.url));
        if (query.filename) results = results.filter(d => d.filename.includes(query.filename));

        if (typeof callback === 'function') callback(results);
        resolve(results);
      });
    },

    __getDownloads() {
      return deepClone(downloadsHistory);
    },

    __getLastDownload() {
      return downloadsHistory.length > 0 ? deepClone(downloadsHistory[downloadsHistory.length - 1]) : null;
    },

    __clearDownloads() {
      downloadsHistory.length = 0;
      downloadIdCounter = 1;
    }
  };

  // ----------------------------------------------------
  // 5. chrome.runtime
  // ----------------------------------------------------
  const runtimeMessageListeners = [];
  let manifestData = null;

  try {
    const manifestPath = path.join(PROJECT_ROOT, 'manifest.json');
    if (fs.existsSync(manifestPath)) {
      manifestData = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    }
  } catch (_) {}

  if (!manifestData) {
    manifestData = {
      manifest_version: 3,
      name: 'Facebook Toolkit Pro',
      version: '1.0.0',
      description: 'Production-ready automation and privacy toolkit for Facebook',
      permissions: ['storage', 'alarms', 'declarativeNetRequest', 'downloads'],
      background: { service_worker: 'background/service-worker.js', type: 'module' }
    };
  }

  const runtime = {
    id: 'facebook-toolkit-test-extension-id',
    lastError: null,

    getURL(pathStr = '') {
      const clean = String(pathStr).replace(/^\//, '');
      return `chrome-extension://${runtime.id}/${clean}`;
    },

    getManifest() {
      return deepClone(manifestData);
    },

    openOptionsPage(callback) {
      return new Promise((resolve) => {
        if (typeof callback === 'function') callback();
        resolve();
      });
    },

    sendMessage(message, optionsOrCallback, optionalCallback) {
      let options = {};
      let callback = optionalCallback;
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback;
      } else if (typeof optionsOrCallback === 'object') {
        options = optionsOrCallback;
      }

      return new Promise((resolve, reject) => {
        let responded = false;
        let asyncWait = false;

        const sendResponse = (response) => {
          if (responded) return;
          responded = true;
          if (typeof callback === 'function') callback(response);
          resolve(response);
        };

        const sender = { id: runtime.id, url: runtime.getURL('dashboard/index.html') };

        for (const listener of runtimeMessageListeners) {
          try {
            const isAsync = listener(message, sender, sendResponse);
            if (isAsync === true) {
              asyncWait = true;
            }
          } catch (err) {
            runtime.lastError = { message: err.message };
            if (!responded) {
              responded = true;
              if (typeof callback === 'function') callback(undefined);
              reject(err);
            }
            return;
          }
        }

        if (!asyncWait && !responded) {
          sendResponse({ received: true });
        }
      });
    },

    onMessage: {
      addListener(fn) {
        if (!runtimeMessageListeners.includes(fn)) runtimeMessageListeners.push(fn);
      },
      removeListener(fn) {
        const idx = runtimeMessageListeners.indexOf(fn);
        if (idx !== -1) runtimeMessageListeners.splice(idx, 1);
      },
      hasListener(fn) {
        return runtimeMessageListeners.includes(fn);
      }
    },

    connect(connectInfo = {}) {
      const portListeners = [];
      const portDisconnectListeners = [];
      return {
        name: connectInfo.name || '',
        onMessage: {
          addListener(fn) { portListeners.push(fn); },
          removeListener(fn) {
            const i = portListeners.indexOf(fn);
            if (i !== -1) portListeners.splice(i, 1);
          }
        },
        onDisconnect: {
          addListener(fn) { portDisconnectListeners.push(fn); }
        },
        postMessage(msg) {
          for (const fn of portListeners) fn(msg);
        },
        disconnect() {
          for (const fn of portDisconnectListeners) fn();
        }
      };
    },

    __reset() {
      runtimeMessageListeners.length = 0;
      runtime.lastError = null;
    }
  };

  // ----------------------------------------------------
  // 6. chrome.tabs
  // ----------------------------------------------------
  let tabsList = [
    {
      id: 1,
      active: true,
      url: 'https://www.facebook.com/',
      title: 'Facebook',
      status: 'complete'
    }
  ];
  let tabIdCounter = 2;

  const tabs = {
    query(queryInfo = {}, callback) {
      return new Promise((resolve) => {
        let matches = [...tabsList];
        if (queryInfo.active !== undefined) matches = matches.filter(t => t.active === queryInfo.active);
        if (queryInfo.url) {
          const pattern = new RegExp(queryInfo.url.replace(/\*/g, '.*'));
          matches = matches.filter(t => pattern.test(t.url));
        }
        if (typeof callback === 'function') callback(deepClone(matches));
        resolve(deepClone(matches));
      });
    },

    create(props = {}, callback) {
      return new Promise((resolve) => {
        const newTab = {
          id: tabIdCounter++,
          active: props.active !== false,
          url: props.url || 'about:blank',
          title: 'New Tab',
          status: 'complete'
        };
        if (newTab.active) {
          for (const t of tabsList) t.active = false;
        }
        tabsList.push(newTab);
        if (typeof callback === 'function') callback(deepClone(newTab));
        resolve(deepClone(newTab));
      });
    },

    update(tabId, props = {}, callback) {
      return new Promise((resolve) => {
        const tab = tabsList.find(t => t.id === tabId);
        if (tab) {
          Object.assign(tab, props);
        }
        if (typeof callback === 'function') callback(deepClone(tab));
        resolve(deepClone(tab));
      });
    },

    sendMessage(tabId, message, optionsOrCallback, optionalCallback) {
      let callback = optionalCallback;
      if (typeof optionsOrCallback === 'function') callback = optionsOrCallback;
      return new Promise((resolve) => {
        const res = { tabId, delivered: true };
        if (typeof callback === 'function') callback(res);
        resolve(res);
      });
    },

    remove(tabIds, callback) {
      return new Promise((resolve) => {
        const ids = Array.isArray(tabIds) ? tabIds : [tabIds];
        tabsList = tabsList.filter(t => !ids.includes(t.id));
        if (typeof callback === 'function') callback();
        resolve();
      });
    },

    __reset() {
      tabsList = [
        {
          id: 1,
          active: true,
          url: 'https://www.facebook.com/',
          title: 'Facebook',
          status: 'complete'
        }
      ];
      tabIdCounter = 2;
    }
  };

  const mock = {
    storage: { local: storageLocal, onChanged: storageLocal.onChanged },
    alarms,
    declarativeNetRequest,
    downloads,
    runtime,
    tabs,

    resetAll() {
      storageLocal.__reset();
      alarms.__reset();
      declarativeNetRequest.__reset();
      downloads.__clearDownloads();
      runtime.__reset();
      tabs.__reset();
    }
  };

  return mock;
}

// ----------------------------------------------------
// Built-in synthetic fixture data fallback for IFacebookApiClient
// Enables 100% offline testing even before M2 fb-api.js is scaffolded.
// ----------------------------------------------------
export function createMockFacebookApiClient(options = {}) {
  let isShieldedState = Boolean(options.initialShield);
  let mockFriends = options.friends || null;
  let mockPosts = options.posts || null;
  let mockAlbums = options.albums || null;
  let mockVideos = options.videos || null;
  let mockBirthdays = options.birthdays || null;
  const pokedSessionCache = new Set();

  // Lazy load synthetic fixtures if available from shared/mock-fixtures.js
  const loadFixturesIfNeeded = () => {
    if (!mockFriends || !mockPosts) {
      try {
        const fixturesModule = path.join(PROJECT_ROOT, 'shared', 'mock-fixtures.js');
        if (fs.existsSync(fixturesModule)) {
          // Synchronous fallback generation
          mockFriends = [];
          for (let i = 0; i < 50; i++) {
            const uid = `10008${String(10000000 + i)}`;
            const daysSinceLast = i < 15 ? 400 : (i < 30 ? 100 : 5);
            const msgCount = i < 15 ? 0 : (i < 30 ? 3 : 50);
            const reactionCount = i < 15 ? 0 : (i < 30 ? 1 : 25);
            mockFriends.push({
              id: uid,
              name: `Friend ${i + 1}`,
              profileUrl: `https://www.facebook.com/${uid}`,
              avatar: `https://graph.facebook.com/${uid}/picture?type=large`,
              mutualFriends: i * 2,
              lastMessageTimestamp: msgCount > 0 ? (Date.now() - daysSinceLast * 86400000) : null,
              messageCount: msgCount,
              lastReactionTimestamp: reactionCount > 0 ? (Date.now() - daysSinceLast * 86400000) : null,
              reactionCount,
              commentCount: reactionCount,
              daysSinceLastInteraction: daysSinceLast,
              inactivityScore: i < 15 ? 0.95 : (i < 30 ? 0.45 : 0.05),
              classification: i < 15 ? 'DEAD_INACTIVE' : (i < 30 ? 'MODERATE' : 'ACTIVE')
            });
          }

          mockPosts = [];
          for (let i = 0; i < 30; i++) {
            const pid = `post_700${i + 1}`;
            const isParty = i % 3 === 0;
            const postDate = new Date(2022, (i % 12), (i % 25) + 1);
            mockPosts.push({
              id: pid,
              creationTime: postDate.getTime(),
              message: isParty ? `Celebrating birthday party event #${i + 1}` : `Regular status update #${i + 1}`,
              feedback: { reactionCount: i * 5, commentCount: i },
              privacy: 'FRIENDS',
              isDeleted: false,
              isHidden: false,
              isArchived: false
            });
          }

          if (!mockAlbums) {
            mockAlbums = [
              {
                id: 'album_301',
                title: 'Summer Trip',
                photos: [
                  {
                    id: 'photo_301_1',
                    renditions: [
                      { uri: 'https://fbcdn.net/p1_320.jpg', width: 320, height: 240 },
                      { uri: 'https://fbcdn.net/p1_720.jpg', width: 720, height: 540 },
                      { uri: 'https://fbcdn.net/p1_2048.jpg', width: 2048, height: 1536 }
                    ]
                  },
                  {
                    id: 'photo_301_2',
                    renditions: [
                      { uri: 'https://fbcdn.net/p2_640.jpg', width: 640, height: 480 },
                      { uri: 'https://fbcdn.net/p2_1920.jpg', width: 1920, height: 1080 }
                    ]
                  }
                ]
              }
            ];
          }

          if (!mockVideos) {
            mockVideos = [
              {
                id: 'video_12345678',
                url: 'https://www.facebook.com/watch/?v=12345678',
                title: 'My Cool Video! [2026] <NEW>',
                hdUrl: 'https://video.xx.fbcdn.net/v/hd_stream_12345678.mp4',
                sdUrl: 'https://video.xx.fbcdn.net/v/sd_stream_12345678.mp4'
              },
              {
                id: 'reel_98765432',
                url: 'https://www.facebook.com/reel/98765432',
                title: 'Reel Highlights',
                hdUrl: 'https://video.xx.fbcdn.net/v/hd_reel_98765432.mp4',
                sdUrl: 'https://video.xx.fbcdn.net/v/sd_reel_98765432.mp4'
              }
            ];
          }

          if (!mockBirthdays) {
            mockBirthdays = [
              { friendId: '100088889999', name: 'Sarah Connor', birthDate: '11-15', isToday: true },
              { friendId: '100088880001', name: 'John Connor', birthDate: '11-15', isToday: true },
              { friendId: '100088880002', name: 'Kyle Reese', birthDate: '11-18', isToday: false }
            ];
          }
        }
      } catch (_) {}
    }
  };

  return {
    async getSessionInfo() {
      return {
        userId: '100080000000001',
        dtsg: 'mock_fb_dtsg_token_test',
        isShielded: isShieldedState
      };
    },

    async setAvatarShield(enable) {
      isShieldedState = Boolean(enable);
      return { success: true, isShielded: isShieldedState };
    },

    async scanFriends(onProgress = null) {
      loadFixturesIfNeeded();
      const list = deepClone(mockFriends);
      if (typeof onProgress === 'function') {
        for (let i = 1; i <= list.length; i++) {
          onProgress(i, list.length);
        }
      }
      return list;
    },

    computeInactivity(friend) {
      const daysSince = friend.daysSinceLastInteraction ?? 0;
      const msgCount = friend.messageCount ?? 0;
      const reactionCount = friend.reactionCount ?? 0;

      let score = 0;
      let classification = 'ACTIVE';

      if (daysSince > 365 && msgCount === 0 && reactionCount === 0) {
        score = 0.95;
        classification = 'DEAD_INACTIVE';
      } else if (daysSince < 7 || msgCount > 20 || reactionCount > 10) {
        score = 0.05;
        classification = 'ACTIVE';
      } else {
        score = 0.45;
        classification = 'MODERATE';
      }

      return {
        ...friend,
        inactivityScore: score,
        classification,
        daysInactive: daysSince
      };
    },

    async unfriend(friendId) {
      loadFixturesIfNeeded();
      return { success: true, friendId };
    },

    async poke(friendId) {
      const alreadyPoked = pokedSessionCache.has(friendId);
      if (!alreadyPoked) {
        pokedSessionCache.add(friendId);
      }
      return {
        success: true,
        pokedUid: friendId,
        alreadyPoked,
        isAlreadyPoked: alreadyPoked
      };
    },

    async reactStory(storyId, reaction) {
      return { success: true, storyId, reaction };
    },

    async scanTimeline(filter = {}) {
      loadFixturesIfNeeded();
      let list = deepClone(mockPosts);

      if (filter.dateRange) {
        const start = new Date(filter.dateRange.start).getTime();
        const end = new Date(filter.dateRange.end).getTime();
        list = list.filter(p => p.creationTime >= start && p.creationTime <= end);
      }

      if (filter.keyword) {
        const kw = filter.keyword.toLowerCase();
        list = list.filter(p => p.message && p.message.toLowerCase().includes(kw));
      }

      return list;
    },

    async deletePost(postId) {
      loadFixturesIfNeeded();
      const p = mockPosts.find(item => item.id === postId);
      if (p) p.isDeleted = true;
      return { success: true, deletedId: postId };
    },

    async hidePost(postId) {
      loadFixturesIfNeeded();
      const p = mockPosts.find(item => item.id === postId);
      if (p) p.isHidden = true;
      return { success: true, storyId: postId, action: 'HIDE' };
    },

    async archivePost(postId) {
      loadFixturesIfNeeded();
      const p = mockPosts.find(item => item.id === postId);
      if (p) p.isArchived = true;
      return { success: true, storyId: postId, action: 'ARCHIVE' };
    },

    async executeCommentDelete(commentId) {
      return { success: true, commentId };
    },

    async executePhotoDelete(photoId) {
      return { success: true, photoId };
    },

    async fetchAlbumPhotos(albumId) {
      loadFixturesIfNeeded();
      const album = mockAlbums.find(a => a.id === albumId) || mockAlbums[0];
      return album ? deepClone(album.photos) : [];
    },

    async fetchVideoStreams(videoUrl) {
      loadFixturesIfNeeded();
      const vid = mockVideos.find(v => videoUrl.includes(v.id) || videoUrl.includes(v.url)) || mockVideos[0];
      return {
        hdUrl: vid.hdUrl,
        sdUrl: vid.sdUrl,
        title: vid.title
      };
    },

    async fetchBirthdays() {
      loadFixturesIfNeeded();
      return deepClone(mockBirthdays);
    },

    async sendBirthdayGreeting(friendId, message, channel = 'message') {
      return { success: true, friendId, message, channel: 'message' };
    },

    async publishPost(postData = {}) {
      return {
        success: true,
        postId: `post_new_${Date.now()}`,
        isReel: Boolean(postData.isReel)
      };
    }
  };
}

let activeMock = null;

export function setupMockChrome(initialState = {}) {
  activeMock = createMockChrome(initialState);
  globalThis.chrome = activeMock;

  // Minimal headless browser environment shim if absent
  if (typeof globalThis.window === 'undefined') {
    globalThis.window = globalThis;
  }
  if (typeof globalThis.window.addEventListener === 'undefined') {
    globalThis.window.addEventListener = () => {};
    globalThis.window.removeEventListener = () => {};
    globalThis.window.postMessage = () => {};
  }
  if (typeof globalThis.document === 'undefined') {
    globalThis.document = {
      createElement: (tag) => ({
        tagName: tag.toUpperCase(),
        style: {},
        setAttribute: () => {},
        getAttribute: () => null,
        appendChild: () => {},
        click: () => {}
      }),
      getElementById: () => null,
      querySelector: () => null,
      querySelectorAll: () => []
    };
  }
  if (typeof globalThis.Blob === 'undefined') {
    globalThis.Blob = class Blob {
      constructor(parts = [], options = {}) {
        this.parts = parts;
        this.type = options.type || '';
        this.size = parts.reduce((acc, p) => acc + (typeof p === 'string' ? Buffer.byteLength(p) : (p?.length || 0)), 0);
      }
      async text() {
        return this.parts.map(p => (typeof p === 'string' ? p : p.toString())).join('');
      }
    };
  }
  if (typeof globalThis.URL.createObjectURL === 'undefined') {
    let blobId = 1;
    globalThis.URL.createObjectURL = (blob) => `blob:http://localhost/mock-blob-${blobId++}`;
    globalThis.URL.revokeObjectURL = () => {};
  }

  return activeMock;
}

export function resetMockChrome(initialState = {}) {
  if (activeMock) {
    activeMock.resetAll();
    if (Object.keys(initialState).length > 0) {
      activeMock.storage.local.__reset(initialState);
    }
  } else {
    setupMockChrome(initialState);
  }
  return activeMock;
}

export function teardownMockChrome() {
  if (activeMock) {
    activeMock.resetAll();
    activeMock = null;
  }
  delete globalThis.chrome;
}

export default setupMockChrome;
