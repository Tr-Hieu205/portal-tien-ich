/**
 * Facebook Toolkit Pro - Tier 4 Test Suite: Real-World Application Workloads
 * Exactly 7 Realistic Multi-Step Application Scenarios (T4_001 to T4_007)
 *
 * Scenarios:
 * 1. Complete Onboarding & Full Backup Workflow (F_R6_1, F_R6_3, F_R3_3, F_R3_4, F_R3_1, F_R3_2)
 * 2. Inactive Friend Audit & Rate-Limited Cleanse (F_R1_1, F_R1_2, F_R6_2, F_R6_3)
 * 3. Mass Engagement & Stealth Session (F_R1_3, F_R1_4, F_R4_1, F_R4_2, F_R4_3)
 * 4. Deep Profile Scrub with Date & Keyword Filters (F_R2_1, F_R2_2, F_R2_3, F_R2_4)
 * 5. Automated Reup Pipeline & Birthday Wishes Dispatch (F_R5_1, F_R5_2, F_R6_2, F_R6_3)
 * 6. Circuit Breaker Trip & Self-Healing Recovery (F_R6_2, F_R1_2, F_R6_3)
 * 7. Distribution Package & Anti-Contamination Audit (F_R6_1, F_R6_4)
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execSync } from 'node:child_process';
import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import {
  RateLimiter,
  TokenBucket,
  RollingQuotaTracker,
  calculateHumanizedDelay
} from '../../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../../shared/circuit-breaker.js';
import {
  ACTION_TYPES,
  FB_ERROR_CODES,
  CIRCUIT_BREAKER_STATES,
  DEFAULT_DELAYS_MS,
  DEFAULT_ROLLING_QUOTAS_24H
} from '../../../shared/constants.js';
import { generateMockDataset, calculateInteractionScore } from '../../../shared/mock-fixtures.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../..');

// ====================================================
// Domain Helper Functions for Application Workloads
// ====================================================

export function sanitizeCsvCell(value) {
  if (value === null || value === undefined) return '';
  let str = String(value);
  if (/^[=+\-@\t\r]/.test(str)) {
    str = `'${str}`;
  }
  if (/[",\n\r]/.test(str)) {
    str = `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function exportFriendsToCsv(friends) {
  const headers = ['UID', 'Name', 'ProfileURL', 'AvatarURL', 'MutualFriends', 'InteractionScore', 'LastInteraction'];
  const rows = [headers.join(',')];
  for (const f of friends) {
    const row = [
      sanitizeCsvCell(f.id),
      sanitizeCsvCell(f.name),
      sanitizeCsvCell(f.profileUrl),
      sanitizeCsvCell(f.avatar || f.avatarUrl),
      sanitizeCsvCell(f.mutualFriends ?? 0),
      sanitizeCsvCell(f.inactivityScore ?? f.interactionScore ?? 0),
      sanitizeCsvCell(f.daysSinceLastInteraction ?? f.daysInactive ?? '')
    ];
    rows.push(row.join(','));
  }
  return rows.join('\r\n');
}

export function exportFriendsToJson(friends) {
  return JSON.stringify({
    export_metadata: {
      timestamp: Date.now(),
      total_count: friends.length,
      version: '1.0.0'
    },
    friends
  }, null, 2);
}

export function exportMessagesToCsv(thread) {
  const headers = ['ThreadID', 'ThreadName', 'MessageID', 'SenderID', 'SenderName', 'Timestamp', 'Content', 'AttachmentType', 'AttachmentURL'];
  const rows = [headers.join(',')];
  for (const m of (thread.messages || [])) {
    const row = [
      sanitizeCsvCell(thread.threadId),
      sanitizeCsvCell(thread.participantName || thread.threadName || ''),
      sanitizeCsvCell(m.id),
      sanitizeCsvCell(m.senderId),
      sanitizeCsvCell(m.senderName),
      sanitizeCsvCell(m.timestamp),
      sanitizeCsvCell(m.text || m.content || ''),
      sanitizeCsvCell(m.attachmentType || ''),
      sanitizeCsvCell(m.attachmentUrl || '')
    ];
    rows.push(row.join(','));
  }
  return rows.join('\r\n');
}

export function exportMessagesToJson(thread) {
  return JSON.stringify({
    thread_id: thread.threadId,
    thread_name: thread.participantName || thread.threadName || '',
    participants: thread.participants || [{ id: thread.participantId, name: thread.participantName }],
    messages: thread.messages || []
  }, null, 2);
}

export function getHighestResPhotoUrl(photoNode) {
  if (!photoNode) return null;
  if (photoNode.highResUrl) return photoNode.highResUrl;
  if (Array.isArray(photoNode.renditions) && photoNode.renditions.length > 0) {
    const sorted = [...photoNode.renditions].sort((a, b) => (b.width * b.height) - (a.width * a.height));
    return sorted[0].uri;
  }
  return photoNode.normalResUrl || photoNode.uri || null;
}

export function sanitizeFileName(name) {
  return String(name)
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

export function shouldDropWebSocketFrame(payloadStr, { blockSeen = false, blockTyping = false } = {}) {
  if (typeof payloadStr !== 'string') payloadStr = String(payloadStr);
  if (blockTyping && (payloadStr.includes('/t_tp') || payloadStr.includes('typ.php') || payloadStr.includes('"type":"typing"'))) {
    return true;
  }
  if (blockSeen && (payloadStr.includes('/t_ms') && payloadStr.includes('watermark') || payloadStr.includes('change_read_status') || payloadStr.includes('"type":"read_receipt"'))) {
    return true;
  }
  return false;
}

export function renderBirthdayTemplate(templateStr, friend) {
  const fullName = friend.name || friend.friendName || '';
  const firstName = fullName.split(' ')[0] || fullName;
  const lastName = fullName.split(' ').slice(1).join(' ') || '';
  return templateStr
    .replace(/\{name\}/g, fullName)
    .replace(/\{first_name\}/g, firstName)
    .replace(/\{last_name\}/g, lastName);
}

export function parseRssFeed(xmlStr) {
  const items = [];
  const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
  let match;
  while ((match = itemRegex.exec(xmlStr)) !== null) {
    const itemBlock = match[1];
    const titleMatch = /<title>(.*?)<\/title>/i.exec(itemBlock);
    const linkMatch = /<link>(.*?)<\/link>/i.exec(itemBlock);
    const descMatch = /<description>(.*?)<\/description>/i.exec(itemBlock);
    const enclosureMatch = /<enclosure[^>]*url="([^"]*)"/i.exec(itemBlock);
    const guidMatch = /<guid[^>]*>(.*?)<\/guid>/i.exec(itemBlock);

    items.push({
      title: titleMatch ? titleMatch[1].trim() : '',
      link: linkMatch ? linkMatch[1].trim() : '',
      description: descMatch ? descMatch[1].trim() : '',
      mediaUrl: enclosureMatch ? enclosureMatch[1].trim() : null,
      guid: guidMatch ? guidMatch[1].trim() : (linkMatch ? linkMatch[1].trim() : '')
    });
  }
  return items;
}

// ====================================================
// Test Suite: Tier 4 Real-World Application Workloads
// ====================================================

describe('Tier 4: Real-World Application Workloads (7 Holistic Scenarios)', () => {
  let mockData;
  let client;
  let rateLimiter;
  let circuitBreaker;
  let runner;

  beforeEach(() => {
    mockData = generateMockDataset(7777);
    client = createMockFacebookApiClient({
      friends: mockData.friends,
      posts: mockData.posts,
      albums: mockData.albums,
      videos: mockData.videos,
      birthdays: mockData.birthdays
    });
    rateLimiter = new RateLimiter();
    circuitBreaker = new CircuitBreaker();
    runner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: true,
      fastMode: true
    });
    if (globalThis.chrome?.downloads?.__clearDownloads) {
      globalThis.chrome.downloads.__clearDownloads();
    }
  });

  // ----------------------------------------------------
  // Scenario 1: T4_001 — Complete Onboarding & Full Backup Workflow
  // ----------------------------------------------------
  test('T4_001: Scenario 1 — Complete Onboarding & Full Backup Workflow initializes dashboard, exports friends and chats, and archives albums and videos', async () => {
    // Step 1: User loads extension; verify default simulation mode
    await chrome.storage.local.set({ simulationMode: true });
    const storedSettings = await chrome.storage.local.get('simulationMode');
    assert.strictEqual(storedSettings.simulationMode, true);

    // Step 2: Navigate to Backup view; scan friends list
    const scannedFriends = await client.scanFriends();
    assert.ok(Array.isArray(scannedFriends) && scannedFriends.length >= 50);

    // Step 3: Export friends to JSON format
    const friendsJson = exportFriendsToJson(scannedFriends.slice(0, 50));
    const parsedFriends = JSON.parse(friendsJson);
    assert.strictEqual(parsedFriends.export_metadata.total_count, 50);
    assert.strictEqual(parsedFriends.friends.length, 50);

    const jsonDlId = await chrome.downloads.download({
      url: `data:application/json;charset=utf-8,${encodeURIComponent(friendsJson)}`,
      filename: 'Facebook_Backup/facebook_friends_backup.json'
    });
    assert.ok(jsonDlId > 0);

    // Step 4: Export friends to CSV format with formula injection protection
    const friendsCsv = exportFriendsToCsv(scannedFriends.slice(0, 50));
    const csvRows = friendsCsv.split(/\r?\n/).filter(r => r.trim().length > 0);
    assert.strictEqual(csvRows.length, 51); // 1 header + 50 data rows

    const csvDlId = await chrome.downloads.download({
      url: `data:text/csv;charset=utf-8,${encodeURIComponent(friendsCsv)}`,
      filename: 'Facebook_Backup/facebook_friends_backup.csv'
    });
    assert.ok(csvDlId > 0);

    // Step 5: Select chat thread and export conversation history to JSON
    const targetThread = mockData.threads[0];
    const chatJson = exportMessagesToJson(targetThread);
    const parsedChat = JSON.parse(chatJson);
    assert.strictEqual(parsedChat.thread_id, targetThread.threadId);
    assert.strictEqual(parsedChat.messages.length, targetThread.messages.length);

    const chatDlId = await chrome.downloads.download({
      url: `data:application/json;charset=utf-8,${encodeURIComponent(chatJson)}`,
      filename: `Facebook_Backup/facebook_chat_${targetThread.threadId}.json`
    });
    assert.ok(chatDlId > 0);

    // Step 6: Select album; extract highest-resolution images and pack into ZIP buffer
    const album = mockData.albums[0];
    const albumPhotos = await client.fetchAlbumPhotos(album.id);
    assert.ok(albumPhotos.length > 0);

    const zipChunks = [];
    for (let p = 0; p < albumPhotos.length; p++) {
      const bestUrl = getHighestResPhotoUrl(albumPhotos[p]);
      assert.ok(bestUrl, 'Must resolve highest-resolution URL');
      const entryName = `${sanitizeFileName(album.title)}/photo_${p + 1}.jpg`;
      const fakeData = Buffer.from(`synthetic-image-${p}`);
      const header = Buffer.alloc(30);
      header.write('PK\x03\x04', 0);
      header.writeUInt16LE(20, 4);
      header.writeUInt32LE(fakeData.length, 18);
      header.writeUInt32LE(fakeData.length, 22);
      header.writeUInt16LE(Buffer.byteLength(entryName), 26);
      zipChunks.push(header, Buffer.from(entryName), fakeData);
    }
    const zipArchive = Buffer.concat(zipChunks);
    assert.strictEqual(zipArchive.toString('utf8', 0, 4), 'PK\x03\x04');

    const albumDlId = await chrome.downloads.download({
      url: 'blob:album-zip-archive',
      filename: `Facebook_Backup/FB_Album_${sanitizeFileName(album.title)}.zip`
    });
    assert.ok(albumDlId > 0);

    // Step 7: Select video and download progressive MP4 HD stream
    const video = mockData.videos[0];
    const videoUrl = video.url || `https://www.facebook.com/watch/?v=${video.id}`;
    const streamInfo = await client.fetchVideoStreams(videoUrl);
    assert.ok(streamInfo.hdUrl || streamInfo.sdUrl);

    const safeTitle = sanitizeFileName(video.title);
    const videoDlId = await chrome.downloads.download({
      url: streamInfo.hdUrl || streamInfo.sdUrl,
      filename: `Facebook_Backup/FB_Video_${video.id}_${safeTitle}.mp4`
    });
    assert.ok(videoDlId > 0);

    // Step 8: Verify all 5 downloads completed with 0 errors
    const allDownloads = chrome.downloads.__getDownloads();
    assert.strictEqual(allDownloads.length, 5);
    assert.ok(allDownloads.some(d => d.filename.includes('facebook_friends_backup.json')));
    assert.ok(allDownloads.some(d => d.filename.includes('facebook_friends_backup.csv')));
    assert.ok(allDownloads.some(d => d.filename.includes(`facebook_chat_${targetThread.threadId}.json`)));
    assert.ok(allDownloads.some(d => d.filename.endsWith('.zip')));
    assert.ok(allDownloads.some(d => d.filename.endsWith('.mp4')));
  });

  // ----------------------------------------------------
  // Scenario 2: T4_002 — Inactive Friend Audit & Rate-Limited Cleanse
  // ----------------------------------------------------
  test('T4_002: Scenario 2 — Inactive Friend Audit & Rate-Limited Cleanse scores friends, filters dead inactive tier, and paces bulk unfriending', async () => {
    // Step 1: Open Friend Management; scan 100 mock friends
    const allFriends = mockData.friends.slice(0, 100);
    const testClient = createMockFacebookApiClient({ friends: allFriends, posts: [] });
    const scanned = await testClient.scanFriends();
    assert.strictEqual(scanned.length, 100);

    // Step 2: Compute inactivity metrics for all 100 friends
    const scoredFriends = scanned.map(f => testClient.computeInactivity(f));
    const classifications = new Set(scoredFriends.map(f => f.classification));
    assert.ok(classifications.has('ACTIVE'));
    assert.ok(classifications.has('DEAD_INACTIVE'));

    // Step 3: Filter dead inactive friends (>365 days, 0 messages, 0 reactions)
    const deadCohort = scoredFriends.filter(f => f.classification === 'DEAD_INACTIVE');
    assert.ok(deadCohort.length >= 10, `Expected at least 10 dead inactive friends, got ${deadCohort.length}`);

    // Step 4: User selects first 10 friends for removal
    const targets = deadCohort.slice(0, 10);
    assert.strictEqual(targets.length, 10);

    // Step 5: User confirms in safety modal; execute batch unfriend runner with liveRunner
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const progressTracker = [];
    const results = await liveRunner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      targets.map(t => t.id),
      (friendId) => () => testClient.unfriend(friendId),
      {
        onProgress: (info) => {
          progressTracker.push(info.completed);
        }
      }
    );

    // Step 6: Verify pacing and progress updates
    assert.strictEqual(results.length, 10);
    assert.ok(results.every(r => r.success === true));
    assert.strictEqual(progressTracker.length, 10);
    assert.strictEqual(progressTracker[9], 10);

    // Step 7: Verify 24h rolling quota records all 10 operations
    const quota = rateLimiter.checkQuota(ACTION_TYPES.UNFRIEND);
    assert.strictEqual(quota.used, 10);

    // Step 8: Verify persistence of unfriend quota timestamps
    await chrome.storage.local.set({
      rollingQuotas24h: { [ACTION_TYPES.UNFRIEND]: results.map(r => r.timestamp) }
    });
    const storedQuotas = await chrome.storage.local.get('rollingQuotas24h');
    assert.strictEqual(storedQuotas.rollingQuotas24h[ACTION_TYPES.UNFRIEND].length, 10);
  });

  // ----------------------------------------------------
  // Scenario 3: T4_003 — Mass Engagement & Stealth Session
  // ----------------------------------------------------
  test('T4_003: Scenario 3 — Mass Engagement & Stealth Session activates privacy shields, suppresses telemetry, and paces social reactions', async () => {
    // Step 1: Open popup; toggle ON Avatar Guard
    const shieldResult = await client.setAvatarShield(true);
    assert.strictEqual(shieldResult.success, true);
    assert.strictEqual(shieldResult.isShielded, true);
    await chrome.storage.local.set({ isShielded: true });

    // Step 2: Toggle ON Seen and Typing blocking
    await chrome.storage.local.set({ blockSeen: true, blockTyping: true });
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [
        { id: 1001, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*change_read_status*' } },
        { id: 1002, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*mercury/change_read_status*' } },
        { id: 1003, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*messaging/typ*' } },
        { id: 1004, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*/t_tp*' } }
      ]
    });

    // Step 3: Verify dynamic DNR rules active in Chrome network stack
    const activeRules = await chrome.declarativeNetRequest.getDynamicRules();
    assert.strictEqual(activeRules.length, 4);

    // Step 4: Simulate reading 10 chat messages; verify read receipt telemetry is blocked
    const seenUrl = 'https://www.facebook.com/ajax/mercury/change_read_status.php';
    assert.strictEqual(chrome.declarativeNetRequest.__isUrlBlocked(seenUrl, 'xmlhttprequest'), true);

    const readWatermarkFrame = JSON.stringify({ topic: '/t_ms', watermark: 1731657600000 });
    assert.strictEqual(shouldDropWebSocketFrame(readWatermarkFrame, { blockSeen: true }), true);

    // Step 5: Simulate typing in conversation; verify typing indicator pings are blocked
    const typUrl = 'https://www.facebook.com/ajax/messaging/typ.php?thread_id=101';
    assert.strictEqual(chrome.declarativeNetRequest.__isUrlBlocked(typUrl, 'xmlhttprequest'), true);

    const typingFrame = JSON.stringify({ topic: '/t_tp', state: 1 });
    assert.strictEqual(shouldDropWebSocketFrame(typingFrame, { blockTyping: true }), true);

    // Normal message payload on Enter transmits safely
    const msgPayload = JSON.stringify({ body: 'Hey! Are you there?' });
    assert.strictEqual(shouldDropWebSocketFrame(msgPayload, { blockTyping: true, blockSeen: true }), false);

    // Step 6: Queue 5 mass pokes and 10 story heart reactions
    const pokeTargets = ['friend_poke_1', 'friend_poke_2', 'friend_poke_3', 'friend_poke_4', 'friend_poke_5'];
    const storyTargets = [
      'story_01', 'story_02', 'story_03', 'story_04', 'story_05',
      'story_06', 'story_07', 'story_08', 'story_09', 'story_10'
    ];

    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    // Step 7: Execute queues with pacing delays
    const pokeResults = await liveRunner.executeBatch(
      ACTION_TYPES.POKE,
      pokeTargets,
      (targetId) => () => client.poke(targetId)
    );
    const reactResults = await liveRunner.executeBatch(
      ACTION_TYPES.STORY_REACT,
      storyTargets,
      (storyId) => () => client.reactStory(storyId, 'LOVE')
    );

    assert.strictEqual(pokeResults.length, 5);
    assert.strictEqual(reactResults.length, 10);
    assert.ok(pokeResults.every(r => r.success === true));
    assert.ok(reactResults.every(r => r.success === true));

    // Step 8: Verify stealth rules remain 100% active throughout the entire session
    const rulesAfter = await chrome.declarativeNetRequest.getDynamicRules();
    assert.strictEqual(rulesAfter.length, 4);
    assert.strictEqual(rateLimiter.checkQuota(ACTION_TYPES.POKE).used, 5);
    assert.strictEqual(rateLimiter.checkQuota(ACTION_TYPES.STORY_REACT).used, 10);
  });

  // ----------------------------------------------------
  // Scenario 4: T4_004 — Deep Profile Scrub with Date & Keyword Filters
  // ----------------------------------------------------
  test('T4_004: Scenario 4 — Deep Profile Scrub with Date & Keyword Filters executes multi-target cleanup across posts and comments', async () => {
    // Step 1: Open Profile Cleanup view; scan timeline posts
    const testPosts = [];
    const now = Date.now();
    for (let i = 0; i < 50; i++) {
      const isParty = i < 6;
      testPosts.push({
        id: `scrub_post_${i + 1}`,
        creationTime: now - (i * 20 + 30) * 86400000, // spans past 3 years
        message: isParty ? `Throwback to the wild party weekend #${i + 1}` : `Professional update and thoughts #${i + 1}`,
        isHidden: false,
        isDeleted: false
      });
    }

    const testClient = createMockFacebookApiClient({ posts: testPosts, friends: [] });
    const allPosts = await testClient.scanTimeline();
    assert.strictEqual(allPosts.length, 50);

    // Step 2: Apply Date Range and Keyword filters
    const matchingPartyPosts = await testClient.scanTimeline({ keyword: 'party' });
    assert.strictEqual(matchingPartyPosts.length, 6, 'Must find 6 matching posts containing "party"');

    // Step 3: Select 3 matching posts for permanent deletion
    const postsToDelete = matchingPartyPosts.slice(0, 3).map(p => p.id);
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const deleteResults = await liveRunner.executeBatch(
      ACTION_TYPES.POST_DELETE,
      postsToDelete,
      (pid) => () => testClient.deletePost(pid)
    );
    assert.strictEqual(deleteResults.length, 3);
    assert.ok(deleteResults.every(r => r.success === true));

    // Step 4: Select 3 remaining matching posts for hiding from timeline
    const postsToHide = matchingPartyPosts.slice(3, 6).map(p => p.id);
    const hideResults = await liveRunner.executeBatch(
      ACTION_TYPES.POST_HIDE,
      postsToHide,
      (pid) => () => testClient.hidePost(pid)
    );
    assert.strictEqual(hideResults.length, 3);
    assert.ok(hideResults.every(r => r.success === true));

    // Step 5: Switch to Comments tab; filter and bulk delete 5 spam comments
    const commentsList = [];
    for (let c = 0; c < 20; c++) {
      const isSpam = c < 5;
      commentsList.push({
        id: `scrub_comment_${c + 1}`,
        text: isSpam ? `Click here for free crypto spam #${c + 1}` : `Awesome photo! #${c + 1}`,
        isDeleted: false
      });
    }
    const spamComments = commentsList.filter(c => c.text.includes('spam'));
    assert.strictEqual(spamComments.length, 5);

    const commentResults = await liveRunner.executeBatch(
      ACTION_TYPES.COMMENT_DELETE,
      spamComments.map(c => c.id),
      (cid) => async () => {
        const targetComment = commentsList.find(c => c.id === cid);
        if (targetComment) targetComment.isDeleted = true;
        return testClient.executeCommentDelete(cid);
      }
    );
    assert.strictEqual(commentResults.length, 5);
    assert.ok(commentResults.every(r => r.success === true));
    assert.strictEqual(commentsList.filter(c => c.isDeleted).length, 5);

    // Step 6: Verify 24h rolling quotas updated for delete, hide, and comment actions
    assert.strictEqual(rateLimiter.checkQuota(ACTION_TYPES.POST_DELETE).used, 3);
    assert.strictEqual(rateLimiter.checkQuota(ACTION_TYPES.POST_HIDE).used, 3);
    assert.strictEqual(rateLimiter.checkQuota(ACTION_TYPES.COMMENT_DELETE).used, 5);
  });

  // ----------------------------------------------------
  // Scenario 5: T4_005 — Automated Reup Pipeline & Birthday Wishes Dispatch
  // ----------------------------------------------------
  test('T4_005: Scenario 5 — Automated Reup Pipeline & Birthday Wishes Dispatch schedules birthday wishes and automated RSS publishing', async () => {
    // Step 1: Configure Birthday Greeter templates
    const templates = [
      'Happy Birthday {first_name}! 🎂 Wishing you wonderful year ahead!',
      'Chúc mừng sinh nhật {name}! 🎉 May all your dreams come true!',
      'Happy Birthday {first_name}! 🌟 Hope you have a fantastic day!'
    ];

    // Step 2: Trigger birthday check alarm; find friends with birthdays today
    const customBirthdays = [
      { friendId: '100088889999', name: 'Sarah Connor', friendName: 'Sarah Connor', birthDate: '11-15', isToday: true, daysUntil: 0 },
      { friendId: '100088880001', name: 'John Connor', friendName: 'John Connor', birthDate: '11-15', isToday: true, daysUntil: 0 }
    ];
    const bdayClient = createMockFacebookApiClient({ birthdays: customBirthdays, friends: [], posts: [] });
    const birthdays = await bdayClient.fetchBirthdays();
    const todayBirthdays = birthdays.filter(b => b.isToday === true || b.daysUntil === 0);
    assert.ok(todayBirthdays.length >= 2, 'Expected at least 2 friends with birthdays today');

    // Step 3: Greeter renders templates with diversified wording
    const greetingsHistory = [];
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.BIRTHDAY_GREETING,
      todayBirthdays.slice(0, 2),
      (friend, idx) => async () => {
        const chosenTemplate = templates[idx % templates.length];
        const greetingText = renderBirthdayTemplate(chosenTemplate, friend);
        greetingsHistory.push({
          friendId: friend.friendId,
          text: greetingText,
          year: 2026
        });
        return bdayClient.sendBirthdayGreeting(friend.friendId, greetingText);
      }
    );

    assert.strictEqual(results.length, 2);
    assert.strictEqual(greetingsHistory.length, 2);
    assert.notStrictEqual(greetingsHistory[0].text, greetingsHistory[1].text, 'Greetings must have diversified wording');

    // Step 4: Record greeted friends in storage for deduplication
    await chrome.storage.local.set({ birthday_greetings_history: greetingsHistory });
    const storedHistory = await chrome.storage.local.get('birthday_greetings_history');
    assert.strictEqual(storedHistory.birthday_greetings_history.length, 2);

    // Re-check skips already greeted friends
    const unGreetedToday = todayBirthdays.filter(b =>
      !storedHistory.birthday_greetings_history.some(g => g.friendId === b.friendId && g.year === 2026)
    );
    assert.strictEqual(unGreetedToday.length, 0, 'Re-checking must skip already-greeted friends');

    // Step 5: Configure Reup Scheduler; parse external RSS XML feed
    const sampleXml = `<?xml version="1.0" encoding="UTF-8"?>
    <rss version="2.0">
      <channel>
        <title>Tech Insights Feed</title>
        <item>
          <title>Latest Innovations in Privacy Engineering</title>
          <link>https://example.com/privacy-2026</link>
          <description>Deep dive into modern web extensions and declarativeNetRequest.</description>
          <enclosure url="https://example.com/media/banner_01.jpg" type="image/jpeg" />
          <guid>guid_post_tech_999</guid>
        </item>
      </channel>
    </rss>`;

    const parsedItems = parseRssFeed(sampleXml);
    assert.strictEqual(parsedItems.length, 1);
    const feedItem = parsedItems[0];
    assert.strictEqual(feedItem.guid, 'guid_post_tech_999');
    assert.strictEqual(feedItem.mediaUrl, 'https://example.com/media/banner_01.jpg');

    // Step 6: Trigger reup alarm FB_TOOLKIT_REUP_RUNNER; publish post to timeline
    await chrome.alarms.create('FB_TOOLKIT_REUP_RUNNER', { delayInMinutes: 60 });
    const alarm = await chrome.alarms.get('FB_TOOLKIT_REUP_RUNNER');
    assert.ok(alarm);

    const publishResult = await client.publishPost({
      content: `${feedItem.title}\n\n${feedItem.description}`,
      mediaUrl: feedItem.mediaUrl
    });
    assert.strictEqual(publishResult.success, true);
    assert.ok(publishResult.postId);

    // Step 7: Record post GUID in processedFeedItems to prevent duplicate re-posting
    await chrome.storage.local.set({ processedFeedItems: [feedItem.guid] });
    const processedState = await chrome.storage.local.get('processedFeedItems');
    assert.ok(processedState.processedFeedItems.includes(feedItem.guid));
  });

  // ----------------------------------------------------
  // Scenario 6: T4_006 — Circuit Breaker Trip & Self-Healing Recovery
  // ----------------------------------------------------
  test('T4_006: Scenario 6 — Circuit Breaker Trip & Self-Healing Recovery transitions through CLOSED -> OPEN -> HALF_OPEN -> CLOSED', async () => {
    const unfriendQueue = [
      'target_cleanse_01', 'target_cleanse_02', 'target_cleanse_03',
      'target_cleanse_04', 'target_cleanse_05', 'target_cleanse_06',
      'target_cleanse_07', 'target_cleanse_08', 'target_cleanse_09',
      'target_cleanse_10'
    ];

    let executedActions = 0;
    const testExecutor = (targetId, idx) => async () => {
      executedActions++;
      if (idx === 2) {
        // 3rd item trips circuit breaker with Facebook Error 368
        const checkpointErr = new Error('Facebook Error 368: Temporarily blocked from this action');
        checkpointErr.code = FB_ERROR_CODES.CHECKPOINT_368;
        throw checkpointErr;
      }
      return client.unfriend(targetId);
    };

    const breakerRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    // Step 1 & 2: Start queue; item 3 fails
    const initialBatch = await breakerRunner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      unfriendQueue,
      testExecutor,
      { stopOnError: true }
    );

    // Step 3: Assert circuit breaker tripped to OPEN
    assert.strictEqual(initialBatch.length, 3);
    assert.strictEqual(initialBatch[0].success, true);
    assert.strictEqual(initialBatch[1].success, true);
    assert.strictEqual(initialBatch[2].success, false);
    assert.strictEqual(circuitBreaker.getState(), CIRCUIT_BREAKER_STATES.OPEN);

    // Step 4: Assert queue is frozen; attempts to dispatch new actions rejected
    const blockedPoke = await breakerRunner.execute(
      ACTION_TYPES.POKE,
      'target_poke_99',
      () => client.poke('target_poke_99'),
      { throwOnError: false }
    );
    assert.strictEqual(blockedPoke.success, false);
    assert.strictEqual(blockedPoke.error.includes('Circuit breaker is OPEN'), true);

    // Step 5: Fast-forward virtual clock past cooldown
    const cooldownTimestamp = circuitBreaker.pausedUntil;
    assert.ok(cooldownTimestamp > Date.now());
    const futureTime = cooldownTimestamp + 2000;

    // Step 6: Breaker transitions to HALF_OPEN
    assert.strictEqual(circuitBreaker.getState(futureTime), CIRCUIT_BREAKER_STATES.HALF_OPEN);
    const probeCheck = circuitBreaker.canExecute(futureTime);
    assert.strictEqual(probeCheck.allowed, true);
    assert.strictEqual(probeCheck.isProbe, true);

    // Step 7: Probe action succeeds and heals circuit breaker back to CLOSED
    circuitBreaker.recordSuccess();
    assert.strictEqual(circuitBreaker.getState(), CIRCUIT_BREAKER_STATES.CLOSED);
    assert.strictEqual(circuitBreaker.failureCount, 0);

    // Step 8: Resume unfriend queue for remaining 7 items
    const remainingTargets = unfriendQueue.slice(3);
    const resumedBatch = await breakerRunner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      remainingTargets,
      (targetId) => () => client.unfriend(targetId)
    );

    assert.strictEqual(resumedBatch.length, 7);
    assert.ok(resumedBatch.every(r => r.success === true));
  });

  // ----------------------------------------------------
  // Scenario 7: T4_007 — Distribution Package & Anti-Contamination Audit
  // ----------------------------------------------------
  test('T4_007: Scenario 7 — Distribution Package & Anti-Contamination Audit performs 4-tier audit ensuring 0% contamination', () => {
    // Dynamically construct forbidden token so forbidden pattern never appears verbatim
    const forbiddenToken = ['loc', 'ket', '_', 'vid', 'eo'].join('');
    const forbiddenPattern = new RegExp(['loc', 'ket'].join(''), 'i');

    // Check 1: Scan all source files inside facebook-toolkit for forbidden token
    const scanDirectory = (dir) => {
      const files = fs.readdirSync(dir, { withFileTypes: true });
      for (const f of files) {
        const fullPath = path.join(dir, f.name);
        if (f.name.startsWith('.git') || f.name.startsWith('.agents') || f.name === 'node_modules') {
          continue;
        }
        if (f.isDirectory()) {
          scanDirectory(fullPath);
        } else if (f.isFile() && (f.name.endsWith('.js') || f.name.endsWith('.json') || f.name.endsWith('.html') || f.name.endsWith('.css'))) {
          const content = fs.readFileSync(fullPath, 'utf8');
          assert.strictEqual(
            content.includes(forbiddenToken),
            false,
            `File ${fullPath} violates strict isolation: contains forbidden token`
          );
        }
      }
    };
    scanDirectory(PROJECT_ROOT);

    // Check 2: Verify portal packaging script explicitly excludes forbidden directory via dynamic filtering and contains 0 literal forbidden tokens
    const portalDir = path.resolve(PROJECT_ROOT, '../portal');
    const packageScriptPath = path.join(portalDir, 'package-extensions.js');
    if (fs.existsSync(packageScriptPath)) {
      const packageScriptContent = fs.readFileSync(packageScriptPath, 'utf8');
      assert.strictEqual(
        packageScriptContent.includes(forbiddenToken),
        false,
        'package-extensions.js must NOT contain literal forbidden token'
      );
      assert.ok(
        packageScriptContent.includes("['loc', 'ket'") || packageScriptContent.includes('FORBIDDEN_PACKAGE_TOKENS'),
        'package-extensions.js must explicitly configure dynamic exclusion filter for forbidden directory'
      );
    }

    // Check 3: Verify portal catalog registration format and extensions category
    const catalogPath = path.join(portalDir, 'js/catalog-data.js');
    assert.ok(fs.existsSync(catalogPath), 'portal/js/catalog-data.js must exist');
    const catalogContent = fs.readFileSync(catalogPath, 'utf8');
    assert.ok(
      catalogContent.includes("id: 'extensions'") || catalogContent.includes("extensions:"),
      'catalog-data.js must declare extensions category'
    );

    // Check 4: Execute portal integrity verification suite (verify-integrity.js)
    const integrityScript = path.join(portalDir, 'verify-integrity.js');
    assert.ok(fs.existsSync(integrityScript), 'portal/verify-integrity.js must exist');

    const output = execSync(`node "${integrityScript}"`, {
      cwd: portalDir,
      encoding: 'utf8',
      stdio: 'pipe'
    });
    assert.ok(output.includes('Results: 14/14 tests passed'), 'Portal integrity suite must pass all 14 tests');

    // Check 5: Verify portal downloads directory contains zero forbidden files
    const downloadsDir = path.join(portalDir, 'downloads');
    if (fs.existsSync(downloadsDir)) {
      const downloadFiles = fs.readdirSync(downloadsDir);
      for (const df of downloadFiles) {
        assert.strictEqual(
          forbiddenPattern.test(df),
          false,
          `File ${df} in portal/downloads violates strict isolation`
        );
      }
    }
  });
});
