/**
 * Tier 2 Test Suite: Requirement R1 - Friend Filtering & Mass Interaction Boundary Tests
 * Exactly 20 tests (T2_001 to T2_020) covering F_R1_1 to F_R1_4
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { RateLimiter, RollingQuotaTracker } from '../../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../../shared/circuit-breaker.js';
import {
  ACTION_TYPES,
  FB_ERROR_CODES,
  CIRCUIT_BREAKER_STATES
} from '../../../shared/constants.js';
import { generateMockDataset } from '../../../shared/mock-fixtures.js';

// Domain helper for Friend UID Validation
export function isValidFacebookUid(uid) {
  if (typeof uid !== 'string') return false;
  const trimmed = uid.trim();
  if (!trimmed || trimmed === 'null' || trimmed === 'undefined') return false;
  return /^\d{4,25}$/.test(trimmed);
}

// Domain helper for Story Reaction Enum Validation
export function isValidReactionType(reaction) {
  const ALLOWED = ['LOVE', 'LIKE', 'SUPPORT', 'HAHA', 'WOW', 'SAD', 'ANGRY'];
  return typeof reaction === 'string' && ALLOWED.includes(reaction.toUpperCase());
}

describe('Tier 2: Requirement R1 - Friend Filtering & Mass Interaction (Boundary & Corner Cases)', () => {
  let client;
  let runner;
  let rateLimiter;
  let circuitBreaker;
  let mockData;

  beforeEach(() => {
    mockData = generateMockDataset(4242);
    circuitBreaker = new CircuitBreaker();
    rateLimiter = new RateLimiter();
    runner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: true,
      fastMode: true
    });
    client = createMockFacebookApiClient({ friends: mockData.friends });
  });

  // ----------------------------------------------------
  // F_R1_1: Friend Inactivity Scanner & Scoring (T2_001 to T2_005)
  // ----------------------------------------------------

  test('T2_001: Zero Friends / Empty Account returns empty array cleanly without zero-division error', async () => {
    const emptyClient = createMockFacebookApiClient({ friends: [], posts: [] });
    const progressEvents = [];

    const scanned = await emptyClient.scanFriends((scannedCount, totalCount) => {
      progressEvents.push({ scannedCount, totalCount });
    });

    assert.ok(Array.isArray(scanned), 'Result must be an array');
    assert.strictEqual(scanned.length, 0, 'Empty account must return 0 friends');
    assert.strictEqual(progressEvents.length, 0, 'No progress events should fire for empty account');
  });

  test('T2_002: Deactivated & Ghost User Handling classifies as DEAD_INACTIVE with isDeactivated flag', () => {
    const ghostFriend = {
      id: '100089999000001',
      name: 'Facebook User',
      profileUrl: null,
      avatar: null,
      isDeactivated: true,
      daysSinceLastInteraction: 999,
      lastMessageTimestamp: null,
      messageCount: 0,
      reactionCount: 0,
      commentCount: 0
    };

    const scored = client.computeInactivity(ghostFriend);

    assert.strictEqual(scored.classification, 'DEAD_INACTIVE', 'Ghost user must be classified as DEAD_INACTIVE');
    assert.ok(scored.inactivityScore >= 0.90, `Inactivity score must be >= 0.90, got ${scored.inactivityScore}`);
    assert.strictEqual(scored.isDeactivated, true, 'isDeactivated flag must be preserved');
    assert.strictEqual(scored.profileUrl, null, 'profileUrl should remain null without attempting fetch');
  });

  test('T2_003: Massive Friends List Scale Test processes 5000 records without stack overflow', () => {
    const massiveFriends = [];
    for (let i = 0; i < 5000; i++) {
      const isDead = i < 100;
      massiveFriends.push({
        id: `10008${String(10000000 + i)}`,
        name: `Friend ${i + 1}`,
        daysSinceLastInteraction: isDead ? 400 : (i % 30),
        messageCount: isDead ? 0 : (i % 15 + 1),
        reactionCount: isDead ? 0 : (i % 8 + 1),
        commentCount: 0
      });
    }

    const start = Date.now();
    const scoredList = massiveFriends.map(f => client.computeInactivity(f));
    const duration = Date.now() - start;

    assert.strictEqual(scoredList.length, 5000, 'All 5,000 friends must be scored');
    assert.ok(duration < 2500, `Execution took ${duration}ms, expected under 2500ms`);

    const hasDead = scoredList.some(f => f.classification === 'DEAD_INACTIVE');
    const hasActive = scoredList.some(f => f.classification === 'ACTIVE');
    assert.ok(hasDead, 'Must contain DEAD_INACTIVE entries');
    assert.ok(hasActive, 'Must contain ACTIVE entries');
  });

  test('T2_004: Complex Unicode, Emoji & RTL Friend Names preserves exact characters and prevents XSS', () => {
    const edgeNames = [
      'Nguyễn Thị Ánh Tuyết 🌸',
      'مريم محمد',
      'יְרוּשָׁלַיִם',
      '<script>alert("xss")</script>',
      'O\'Connor & "Sons"',
      '👨‍👩‍👧‍👦 Family Account 💖'
    ];

    const records = edgeNames.map((name, idx) => ({
      id: `10008${String(20000000 + idx)}`,
      name,
      daysSinceLastInteraction: 10,
      messageCount: 5,
      reactionCount: 2
    }));

    for (let i = 0; i < records.length; i++) {
      const scored = client.computeInactivity(records[i]);
      assert.strictEqual(scored.name, edgeNames[i], 'Name must be preserved verbatim without corruption');
      assert.ok(!scored.name.includes('&amp;'), 'Raw characters must not be double entity-encoded in memory');
    }
  });

  test('T2_005: Transient Network Drop & Cursor Resume handles retry without restarting', async () => {
    let callAttempts = 0;
    const fetchPage = async (cursor) => {
      callAttempts++;
      if (callAttempts === 2) {
        const netErr = new Error('HTTP 503 Service Unavailable');
        netErr.status = 503;
        throw netErr;
      }
      return {
        items: [{ id: `f_${callAttempts}`, name: `Friend ${callAttempts}` }],
        nextCursor: cursor === null ? 'c1' : (cursor === 'c1' ? 'c2' : null)
      };
    };

    runner.setSimulation(false);
    const gathered = [];
    let currentCursor = null;

    while (true) {
      let retryCount = 0;
      let pageRes = null;
      while (retryCount < 2 && !pageRes) {
        const runResult = await runner.execute(
          ACTION_TYPES.UNFRIEND,
          { cursor: currentCursor, attempt: retryCount },
          async () => fetchPage(currentCursor),
          { throwOnError: false }
        );
        if (runResult.success) {
          pageRes = runResult.result;
        } else {
          retryCount++;
        }
      }
      assert.ok(pageRes, 'Page request must succeed after retry');
      gathered.push(...pageRes.items);
      currentCursor = pageRes.nextCursor;
      if (!currentCursor) break;
    }

    assert.strictEqual(callAttempts, 4, 'Should attempt 4 times: page1, page2(fail), page2(retry-succeed), page3');
    assert.strictEqual(gathered.length, 3, 'Must gather items across all pages without losing page 1');
  });

  // ----------------------------------------------------
  // F_R1_2: Rate-Limited Mass Unfriend (T2_006 to T2_010)
  // ----------------------------------------------------

  test('T2_006: Target Already Unfriended / Unavailable (Error 1404006) logged without aborting batch', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const targets = ['1000801', '1000802', '1000803'];
    const executorFactory = (target) => async () => {
      if (target === '1000802') {
        const err = new Error('Relationship does not exist');
        err.code = 1404006;
        throw err;
      }
      return { success: true, friendId: target };
    };

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      targets,
      executorFactory,
      { stopOnError: false }
    );

    assert.strictEqual(results.length, 3, 'Batch must complete all 3 items');
    assert.strictEqual(results[0].success, true);
    assert.strictEqual(results[1].success, false);
    assert.match(results[1].error, /Relationship does not exist/);
    assert.strictEqual(results[2].success, true);
  });

  test('T2_007: Rate Limit Checkpoint Warning (Error 1357004) immediately halts queue and trips circuit breaker', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const targets = ['1000811', '1000812', '1000813', '1000814'];
    const executorFactory = (target, idx) => async () => {
      if (idx === 1) {
        const err = new Error("You're temporarily blocked from this feature");
        err.code = FB_ERROR_CODES.TEMPORARY_BLOCK_1357004;
        throw err;
      }
      return { success: true, friendId: target };
    };

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      targets,
      executorFactory,
      { stopOnError: true }
    );

    assert.strictEqual(results.length, 2, 'Batch must halt at 2nd item upon critical checkpoint error');
    assert.strictEqual(results[1].success, false);
    assert.strictEqual(circuitBreaker.getState(), CIRCUIT_BREAKER_STATES.OPEN, 'Circuit breaker must trip to OPEN');
    assert.ok(circuitBreaker.pausedUntil > Date.now(), 'Cooldown pausedUntil must be set in future');
  });

  test('T2_008: 24-Hour Rolling Quota Saturation Limit rejects action immediately with QUOTA_EXCEEDED', async () => {
    const tracker = new RollingQuotaTracker();
    const limit = 80;

    // Saturate 80 unfriend timestamps within last 24h
    for (let i = 0; i < limit; i++) {
      tracker.recordAction(ACTION_TYPES.UNFRIEND, Date.now() - i * 60000);
    }

    const quotaLimiter = new RateLimiter({
      quotaTracker: tracker
    });

    const runnerWithQuota = new ActionRunner({
      rateLimiter: quotaLimiter,
      fastMode: true,
      isSimulation: true
    });

    const res = await runnerWithQuota.execute(
      ACTION_TYPES.UNFRIEND,
      '1000899',
      null,
      { throwOnError: false }
    );

    assert.strictEqual(res.success, false, 'Action must be rejected when quota saturated');
    assert.match(res.error, /rolling quota exceeded/i);
  });

  test('T2_009: Empty Target Array Rejection returns immediately with zero completions', async () => {
    const results = await runner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      [],
      () => async () => ({ success: true })
    );

    assert.ok(Array.isArray(results), 'Must return an array');
    assert.strictEqual(results.length, 0, 'Must return 0 results');
  });

  test('T2_010: Malformed / Non-Numeric Friend UID rejected by validation before API dispatch', () => {
    const invalidIds = ['', '   ', 'undefined', 'null', 'abc-not-an-id', '-1000', '12#$56'];
    const validIds = ['1000800001234', '1004', '123456789012345678'];

    for (const invalid of invalidIds) {
      assert.strictEqual(isValidFacebookUid(invalid), false, `ID "${invalid}" must be invalid`);
    }

    for (const valid of validIds) {
      assert.strictEqual(isValidFacebookUid(valid), true, `ID "${valid}" must be valid`);
    }
  });

  // ----------------------------------------------------
  // F_R1_3: Mass Poke Friends (T2_011 to T2_015)
  // ----------------------------------------------------

  test('T2_011: Pending Poke Response Handling records PENDING_RESPONSE without tripping failure', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const mockPokeExecutor = async (target) => {
      if (target === '1000821') {
        return {
          success: true,
          status: 'PENDING_RESPONSE',
          message: 'Waiting for friend response'
        };
      }
      return { success: true, pokedUid: target };
    };

    const res = await liveRunner.execute(
      ACTION_TYPES.POKE,
      '1000821',
      mockPokeExecutor
    );

    assert.strictEqual(res.success, true);
    assert.strictEqual(circuitBreaker.getState(), CIRCUIT_BREAKER_STATES.CLOSED, 'Circuit breaker must remain CLOSED');
  });

  test('T2_012: User With Pokes Disabled / Blocked (Error 1404078) marked BLOCKED and advances safely', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const targets = ['1000831', '1000832', '1000833'];
    const executorFactory = (target) => async () => {
      if (target === '1000832') {
        return { success: false, status: 'BLOCKED', error: 'User has blocked interaction or pokes disabled (1404078)' };
      }
      return { success: true, pokedUid: target };
    };

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.POKE,
      targets,
      executorFactory,
      { stopOnError: false }
    );

    assert.strictEqual(results.length, 3);
    assert.strictEqual(results[1].result.status, 'BLOCKED');
    assert.match(results[1].result.error, /blocked/i);
    assert.strictEqual(results[2].success, true, 'Subsequent poke must continue');
  });

  test('T2_013: Checkpoint Error 368 During Poke trips circuit breaker and sets pause state', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const failExecutor = async () => {
      const err = new Error('Action blocked by Facebook checkpoint');
      err.code = FB_ERROR_CODES.CHECKPOINT_368;
      throw err;
    };

    const res = await liveRunner.execute(
      ACTION_TYPES.POKE,
      '1000841',
      failExecutor,
      { throwOnError: false }
    );

    assert.strictEqual(res.success, false);
    assert.strictEqual(circuitBreaker.getState(), CIRCUIT_BREAKER_STATES.OPEN);
    assert.ok(circuitBreaker.pausedUntil > Date.now(), 'Must set pause timestamp');
  });

  test('T2_014: Rapid Double-Trigger Debounce allows only single runner instance', async () => {
    let activeInvocations = 0;
    let isLocked = false;

    const triggerPokeAll = async () => {
      if (isLocked) return { ignored: true };
      isLocked = true;
      activeInvocations++;
      try {
        const res = await runner.executeBatch(
          ACTION_TYPES.POKE,
          ['target_001', 'target_002'],
          (uid) => async () => client.poke(uid)
        );
        return { success: true, count: res.length };
      } finally {
        activeInvocations--;
        isLocked = false;
      }
    };

    // Simulate 10 rapid triggers in parallel
    const promises = Array.from({ length: 10 }, () => triggerPokeAll());
    const outcomes = await Promise.all(promises);

    const executed = outcomes.filter(o => o.success);
    const ignored = outcomes.filter(o => o.ignored);

    assert.strictEqual(executed.length, 1, 'Only exactly 1 poke run should execute');
    assert.strictEqual(ignored.length, 9, '9 rapid spam triggers must be ignored/debounced');
    assert.strictEqual(executed[0].count, 2, 'Executed run must process batch items');
  });

  test('T2_015: Daily Max Poke Quota Reached refuses batch with cooldown timer', async () => {
    const tracker = new RollingQuotaTracker();
    const maxPokes = 100;
    const now = Date.now();

    for (let i = 0; i < maxPokes; i++) {
      tracker.recordAction(ACTION_TYPES.POKE, now - i * 10000);
    }

    const quotaLimiter = new RateLimiter({
      quotaTracker: tracker
    });

    const quotaStatus = quotaLimiter.checkQuota(ACTION_TYPES.POKE);
    assert.strictEqual(quotaStatus.allowed, false);
    assert.strictEqual(quotaStatus.limit, maxPokes);
    assert.strictEqual(quotaStatus.used, maxPokes);
  });

  // ----------------------------------------------------
  // F_R1_4: Mass Story Reactions (T2_016 to T2_020)
  // ----------------------------------------------------

  test('T2_016: Expired Story (Node Not Found) handled as non-fatal STORY_EXPIRED', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const stories = ['story_live_1', 'story_expired_2', 'story_live_3'];
    const executorFactory = (storyId) => async () => {
      if (storyId === 'story_expired_2') {
        const err = new Error('GraphQL error: Story bucket unavailable or expired');
        err.category = 'STORY_EXPIRED';
        throw err;
      }
      return { success: true, storyId, reaction: 'LOVE' };
    };

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.STORY_REACT,
      stories,
      executorFactory,
      { stopOnError: false }
    );

    assert.strictEqual(results.length, 3);
    assert.strictEqual(results[0].success, true);
    assert.strictEqual(results[1].success, false);
    assert.match(results[1].error, /expired/i);
    assert.strictEqual(results[2].success, true);
  });

  test('T2_017: Invalid Reaction Type Parameter rejected by schema validator', () => {
    const invalidTypes = ['DISLIKE', 'HATE', 'RANDOM_ENUM', '', 123, null];
    const validTypes = ['LOVE', 'LIKE', 'SUPPORT', 'HAHA', 'WOW', 'SAD', 'ANGRY'];

    for (const inv of invalidTypes) {
      assert.strictEqual(isValidReactionType(inv), false, `Reaction "${inv}" should be invalid`);
    }

    for (const val of validTypes) {
      assert.strictEqual(isValidReactionType(val), true, `Reaction "${val}" should be valid`);
      assert.strictEqual(isValidReactionType(val.toLowerCase()), true, 'Case-insensitive match accepted');
    }
  });

  test('T2_018: Network Timeout on Story Mutation uses AbortController and marks TIMEOUT', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const timeoutExecutor = async () => {
      const controller = new AbortController();
      controller.abort(); // Immediately abort to simulate timeout
      if (controller.signal.aborted) {
        const timeoutErr = new Error('The operation was aborted due to timeout');
        timeoutErr.name = 'AbortError';
        timeoutErr.code = 'TIMEOUT';
        throw timeoutErr;
      }
    };

    const res = await liveRunner.execute(
      ACTION_TYPES.STORY_REACT,
      'story_slow_99',
      timeoutExecutor,
      { throwOnError: false }
    );

    assert.strictEqual(res.success, false);
    assert.match(res.error, /aborted|timeout/i);
  });

  test('T2_019: Burst Rate 429 Throttle honors Retry-After header', () => {
    const cb = new CircuitBreaker();
    const mockHeaders = {
      'retry-after': '30',
      'content-type': 'application/json'
    };

    const retryAfterSeconds = parseInt(mockHeaders['retry-after'], 10);
    assert.strictEqual(retryAfterSeconds, 30);

    const backoffMs = retryAfterSeconds * 1000;
    assert.strictEqual(backoffMs, 30000, 'Must compute 30,000ms delay from Retry-After header');

    // Trigger circuit breaker on HTTP 429 error
    const err = new Error('HTTP 429 Too Many Requests');
    err.status = 429;
    cb.recordFailure(err);

    assert.strictEqual(cb.getState(), CIRCUIT_BREAKER_STATES.OPEN);
    const check = cb.canExecute();
    assert.strictEqual(check.allowed, false, 'Execution must be blocked when breaker tripped on 429');
  });

  test('T2_020: Zero Unread Stories in Feed terminates cleanly without error', async () => {
    const emptyStoryFeed = [];
    const scanStories = async () => emptyStoryFeed;

    const stories = await scanStories();
    assert.strictEqual(stories.length, 0);

    const results = await runner.executeBatch(
      ACTION_TYPES.STORY_REACT,
      stories,
      () => async () => ({ success: true })
    );

    assert.strictEqual(results.length, 0, 'Empty feed terminates with 0 batch executions');
  });
});
