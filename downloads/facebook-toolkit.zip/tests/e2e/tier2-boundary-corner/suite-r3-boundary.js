/**
 * Tier 2 Test Suite: Requirement R3 - Media & Data Backup Boundary Tests
 * Exactly 20 tests (T2_041 to T2_060) covering F_R3_1 to F_R3_4
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { RateLimiter } from '../../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../../shared/circuit-breaker.js';
import { ACTION_TYPES } from '../../../shared/constants.js';
import {
  generateMockDataset,
  chunkPhotos,
  formatMessageContent,
  resolveSenderName,
  streamMessageBatch
} from '../../../shared/mock-fixtures.js';
import { resolveVideoStream } from '../../../background/fb-api.js';

// Domain helper: Sanitize filename removing illegal characters and emojis
export function sanitizeFileName(name) {
  if (!name) return 'download';
  return String(name)
    .replace(/[\p{Extended_Pictographic}\p{Emoji_Presentation}\u200d\ufe0f]/gu, '')
    .replace(/[\\/:*?"<>|&]/g, '_')
    .replace(/[\x00-\x1f\x80-\x9f]/g, '')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
}

// Domain helper: RFC 4180 + Anti-CSV Injection cell sanitizer
export function sanitizeCsvCell(value) {
  if (value === null || value === undefined) return '';
  let str = String(value);

  // Anti-Spreadsheet Formula Injection: Prepend apostrophe if starting with =, +, -, @, \t, \r
  if (/^[=+\-@\t\r]/.test(str)) {
    str = `'${str}`;
  }

  // RFC 4180 Escaping: If contains comma, quote, or newline, escape quotes and wrap in quotes
  if (/[",\n\r]/.test(str)) {
    str = `"${str.replace(/"/g, '""')}"`;
  }

  return str;
}

// Domain helper: UTF-8 BOM CSV Friends Exporter
export function exportFriendsToCsv(friends, options = {}) {
  const headers = ['UID', 'Name', 'ProfileURL', 'AvatarURL', 'MutualFriends', 'InteractionScore', 'LastInteraction'];
  const rows = [headers.join(',')];

  for (const f of (friends || [])) {
    const row = [
      sanitizeCsvCell(f.id),
      sanitizeCsvCell(f.name),
      sanitizeCsvCell(f.profileUrl),
      sanitizeCsvCell(f.avatar || f.avatarUrl),
      sanitizeCsvCell(f.mutualFriends ?? 0),
      sanitizeCsvCell(f.inactivityScore ?? f.interactionScore ?? 0),
      sanitizeCsvCell(f.daysSinceLastInteraction ?? '')
    ];
    rows.push(row.join(','));
  }

  const csvBody = rows.join('\r\n');
  return options.withBom ? `\uFEFF${csvBody}` : csvBody;
}

// Domain helper: JSON Friends Exporter
export function exportFriendsToJson(friends) {
  return JSON.stringify({
    export_metadata: {
      timestamp: Date.now(),
      total_friends: (friends || []).length,
      version: '1.0.0'
    },
    friends: friends || []
  }, null, 2);
}

// Domain helper: Video URL Validator
export function validateVideoUrl(url) {
  if (!url || typeof url !== 'string') {
    return { valid: false, reason: 'URL must be a non-empty string' };
  }
  const isWatch = url.includes('/watch/?v=') || url.includes('/watch?v=');
  const isReel = url.includes('/reel/') || url.includes('/reels/');
  const isVideoDirect = url.includes('/videos/') || url.includes('/video.php?v=');

  if (!isWatch && !isReel && !isVideoDirect) {
    return { valid: false, reason: 'Provided URL is not a valid Facebook video or Reel' };
  }
  return { valid: true };
}

describe('Tier 2: Requirement R3 - Media & Data Backup (Boundary & Corner Cases)', () => {
  let client;
  let runner;
  let mockData;

  beforeEach(() => {
    mockData = generateMockDataset(7777);
    runner = new ActionRunner({
      rateLimiter: new RateLimiter(),
      circuitBreaker: new CircuitBreaker(),
      isSimulation: true,
      fastMode: true
    });
    client = createMockFacebookApiClient({
      friends: mockData.friends,
      albums: mockData.albums
    });
  });

  // ----------------------------------------------------
  // F_R3_1: Album Photo Batch Downloader (T2_041 to T2_045)
  // ----------------------------------------------------

  test('T2_041: Empty Album (0 Photos) emits notification without creating empty ZIP', async () => {
    const emptyClient = createMockFacebookApiClient({
      albums: [{ id: 'album_empty_001', title: 'Empty Album', photos: [] }]
    });
    const photos = await emptyClient.fetchAlbumPhotos('album_empty_001');
    assert.strictEqual(photos.length, 0);

    const downloadCount = photos.length;
    const createdZip = downloadCount > 0;
    const message = downloadCount === 0 ? 'Album is empty' : 'OK';

    assert.strictEqual(downloadCount, 0);
    assert.strictEqual(createdZip, false);
    assert.strictEqual(message, 'Album is empty');
  });

  test('T2_042: Broken / 404 Photo Representation URL falls back to next resolution', async () => {
    const photoWithBrokenHighRes = {
      id: 'photo_edge_1',
      renditions: [
        { uri: 'https://fbcdn.net/p_broken_404.jpg', width: 2048, height: 1536, isBroken: true },
        { uri: 'https://fbcdn.net/p_fallback_720.jpg', width: 720, height: 540, isBroken: false }
      ]
    };

    const sorted = [...photoWithBrokenHighRes.renditions].sort((a, b) => (b.width * b.height) - (a.width * a.height));
    let chosenRend = null;
    let fellBack = false;
    for (const rend of sorted) {
      if (!rend.isBroken) {
        chosenRend = rend;
        fellBack = rend !== sorted[0];
        break;
      }
    }

    assert.ok(chosenRend);
    assert.strictEqual(chosenRend.uri, 'https://fbcdn.net/p_fallback_720.jpg');
    assert.strictEqual(fellBack, true, 'Must indicate resolution fallback took place');
  });

  test('T2_043: Massive Album Chunking (600+ Photos) splits into chunks to conserve memory', () => {
    const largePhotoList = Array.from({ length: 650 }, (_, i) => ({
      id: `photo_${i}`,
      uri: `https://fbcdn.net/photo_${i}.jpg`
    }));

    const chunks = chunkPhotos(largePhotoList, 50);
    assert.strictEqual(chunks.length, 13, '650 photos must be split into 13 chunks of 50');
    assert.strictEqual(chunks[0].length, 50);
    assert.strictEqual(chunks[12].length, 50);

    const totalCount = chunks.reduce((acc, c) => acc + c.length, 0);
    assert.strictEqual(totalCount, 650);
  });

  test('T2_044: Sanitization of Album Names with Illegal Characters replaces Windows reserved chars', () => {
    const dirtyAlbumName = 'Summer / Fall 2025: Trip & Party? <Wild> | "Awesome"';
    const sanitized = sanitizeFileName(dirtyAlbumName);

    assert.strictEqual(sanitized, 'Summer_Fall_2025_Trip_Party_Wild_Awesome');
    assert.ok(!/[\\/:*?"<>|]/.test(sanitized), 'Sanitized string must not contain illegal Windows chars');
  });

  test('T2_045: Chrome Download Permission Revoked / Denied catches USER_CANCELED cleanly', async () => {
    let caughtError = null;
    try {
      await chrome.downloads.download({
        url: 'https://example.com/photo.jpg',
        filename: 'photo.jpg',
        simulateCancel: true
      });
    } catch (err) {
      caughtError = err;
    }

    assert.ok(caughtError);
    assert.strictEqual(caughtError.code, 'USER_CANCELED');
  });

  // ----------------------------------------------------
  // F_R3_2: High-Resolution Video Downloader (T2_046 to T2_050)
  // ----------------------------------------------------

  test('T2_046: Private / Geoblocked Video returns clear restriction message', async () => {
    const privateVideo = {
      id: 'private_group_123',
      url: 'https://www.facebook.com/watch/?v=private_group_123',
      title: 'Private Group Video',
      hdUrl: null,
      sdUrl: null,
      isRestricted: true
    };
    const testClient = createMockFacebookApiClient({ videos: [privateVideo] });
    const streams = await testClient.fetchVideoStreams(privateVideo.url);

    assert.strictEqual(streams.hdUrl, null);
    assert.strictEqual(streams.sdUrl, null);

    const hasStream = Boolean(streams.hdUrl || streams.sdUrl);
    assert.strictEqual(hasStream, false, 'Private/geoblocked video must not expose stream URLs');
  });

  test('T2_047: DASH-Only Segmented Stream Fallback extracts progressive stream from mobile payload', () => {
    const videoData = {
      id: 'vid_dash_only',
      dash_manifest: '<MPD>...</MPD>',
      browser_native_hd_url: null,
      browser_native_sd_url: null,
      mobile_progressive_url: 'https://m.facebook.com/video/stream_720p.mp4'
    };

    const stream = resolveVideoStream(videoData);
    assert.strictEqual(stream.quality, 'MOBILE_PROGRESSIVE_FALLBACK');
    assert.strictEqual(stream.url, 'https://m.facebook.com/video/stream_720p.mp4');
  });

  test('T2_048: Sanitization of Complex Emojis in Video Title produces safe filesystem filename', () => {
    const rawTitle = 'Học Làm Bánh Cùng Tôi 🎂🍰✨ [Full HD 1080p]';
    const sanitized = sanitizeFileName(rawTitle);

    assert.ok(!sanitized.includes('🎂'), 'Must not contain emoji');
    assert.ok(!sanitized.includes('🍰'), 'Must not contain emoji');
    assert.ok(!/[\\/:*?"<>|]/.test(sanitized));
    assert.ok(sanitized.length > 5, 'Must preserve alphanumeric content');
  });

  test('T2_049: Expired CDN Signed URL Refresh retries download with fresh signed URL', async () => {
    let fetchCount = 0;
    const downloadBinary = async (url) => {
      fetchCount++;
      if (url.includes('stale')) {
        const err = new Error('HTTP 403 Forbidden: CDN URL signature expired');
        err.status = 403;
        throw err;
      }
      return { status: 200, buffer: Buffer.from('mock video bytes') };
    };

    const freshUrlProvider = async () => 'https://fbcdn.net/fresh_signed_stream.mp4';

    let activeUrl = 'https://fbcdn.net/stale_signed_stream.mp4';
    let result = null;
    try {
      result = await downloadBinary(activeUrl);
    } catch (err) {
      if (err.status === 403) {
        activeUrl = await freshUrlProvider();
        result = await downloadBinary(activeUrl);
      } else {
        throw err;
      }
    }

    assert.strictEqual(fetchCount, 2, 'Must fetch fresh signed URL and retry once');
    assert.strictEqual(result.status, 200);
    assert.strictEqual(activeUrl, 'https://fbcdn.net/fresh_signed_stream.mp4');
  });

  test('T2_050: Non-Video Facebook URL Passed to Downloader rejected with validation warning', () => {
    const photoUrl = 'https://www.facebook.com/photo/?fbid=123456';
    const profileUrl = 'https://www.facebook.com/john.doe';
    const validVideo = 'https://www.facebook.com/watch/?v=12345678';
    const validReel = 'https://www.facebook.com/reel/987654321';

    const checkPhoto = validateVideoUrl(photoUrl);
    assert.strictEqual(checkPhoto.valid, false);
    assert.match(checkPhoto.reason, /not a valid Facebook video/i);

    const checkProfile = validateVideoUrl(profileUrl);
    assert.strictEqual(checkProfile.valid, false);

    assert.strictEqual(validateVideoUrl(validVideo).valid, true);
    assert.strictEqual(validateVideoUrl(validReel).valid, true);
  });

  // ----------------------------------------------------
  // F_R3_3: Friend List Structured Export (T2_051 to T2_055)
  // ----------------------------------------------------

  test('T2_051: Zero Friends Export generates valid JSON and CSV headers with 0 rows', () => {
    const jsonStr = exportFriendsToJson([]);
    const parsed = JSON.parse(jsonStr);

    assert.strictEqual(parsed.export_metadata.total_friends, 0);
    assert.ok(Array.isArray(parsed.friends));
    assert.strictEqual(parsed.friends.length, 0);

    const csvStr = exportFriendsToCsv([]);
    const lines = csvStr.split('\r\n');
    assert.strictEqual(lines.length, 1, 'Only header line must exist');
    assert.match(lines[0], /^UID,Name,ProfileURL/);
  });

  test('T2_052: Multiline Bio / Newlines in Friend Fields properly quoted per RFC 4180', () => {
    const friendWithNewlines = [
      {
        id: '1000801',
        name: 'John "Johnny"\r\nDoe, Jr.',
        profileUrl: 'https://facebook.com/1000801',
        avatar: 'https://facebook.com/avatar.jpg',
        mutualFriends: 10,
        inactivityScore: 0.1,
        daysSinceLastInteraction: 3
      }
    ];

    const csv = exportFriendsToCsv(friendWithNewlines);
    // Name cell contains quotes and newlines, so must be wrapped in quotes with quotes escaped
    assert.match(csv, /"John ""Johnny""\r\nDoe, Jr\."/);
  });

  test('T2_053: Null / Undefined Field Sanitization outputs empty string not literal undefined', () => {
    const friendWithNulls = [
      {
        id: '1000802',
        name: 'Alice',
        profileUrl: null,
        avatar: undefined,
        mutualFriends: null,
        inactivityScore: undefined,
        daysSinceLastInteraction: null
      }
    ];

    const csv = exportFriendsToCsv(friendWithNulls);
    assert.ok(!csv.includes('null'), 'CSV output must never contain literal string "null"');
    assert.ok(!csv.includes('undefined'), 'CSV output must never contain literal string "undefined"');
  });

  test('T2_054: UTF-8 BOM Inclusion for Excel Compatibility prepends \\uFEFF to CSV', () => {
    const friends = [
      { id: '1000803', name: 'Đặng Thị Thu Thảo', profileUrl: 'https://fb.com/thao' }
    ];

    const csvWithBom = exportFriendsToCsv(friends, { withBom: true });
    assert.strictEqual(csvWithBom.charCodeAt(0), 0xFEFF, 'First character must be UTF-8 BOM (0xFEFF)');
    assert.ok(csvWithBom.includes('Đặng Thị Thu Thảo'));
  });

  test('T2_055: User Dismissal of Save As Dialog handles cancel cleanly', async () => {
    let caughtErr = null;
    try {
      await chrome.downloads.download({
        url: 'blob:chrome-extension://mock-id/friends.csv',
        filename: 'friends_backup.csv',
        saveAs: true,
        simulateCancel: true
      });
    } catch (err) {
      caughtErr = err;
    }

    assert.ok(caughtErr);
    assert.strictEqual(caughtErr.code, 'USER_CANCELED');
  });

  // ----------------------------------------------------
  // F_R3_4: Message History Structured Export (T2_056 to T2_060)
  // ----------------------------------------------------

  test('T2_056: Empty Conversation Thread (0 Messages) exports valid schema with empty array', () => {
    const emptyThread = {
      threadId: 't_empty_101',
      participantName: 'Bob',
      messages: []
    };

    const jsonExport = JSON.stringify({
      threadId: emptyThread.threadId,
      participant: emptyThread.participantName,
      messageCount: emptyThread.messages.length,
      messages: emptyThread.messages
    });

    const parsed = JSON.parse(jsonExport);
    assert.strictEqual(parsed.threadId, 't_empty_101');
    assert.strictEqual(parsed.messageCount, 0);
    assert.ok(Array.isArray(parsed.messages));
    assert.strictEqual(parsed.messages.length, 0);
  });

  test('T2_057: Unsent / Deleted Messages in Conversation serialized as [Message Unsent]', () => {
    const rawMessage = {
      id: 'm_1001',
      senderId: '1000805',
      senderName: 'Charlie',
      timestamp: Date.now() - 3600000,
      isUnsent: true,
      text: null
    };

    const serialized = formatMessageContent(rawMessage);
    assert.strictEqual(serialized, '[Message Unsent]');
  });

  test('T2_058: Massive Group Chat (50+ Participants) resolves all participant UIDs and names', () => {
    const participantMap = {};
    for (let i = 1; i <= 60; i++) {
      const uid = `user_${i}`;
      participantMap[uid] = `Participant Name ${i}`;
    }

    assert.strictEqual(Object.keys(participantMap).length, 60);

    assert.strictEqual(resolveSenderName('user_1', participantMap), 'Participant Name 1');
    assert.strictEqual(resolveSenderName('user_60', participantMap), 'Participant Name 60');
    assert.strictEqual(resolveSenderName('user_999', participantMap), 'Unknown User');
  });

  test('T2_059: Giant Thread Export Scale (50000 Messages) chunks processing without memory crash', () => {
    const result = streamMessageBatch(50000, 5000);
    assert.strictEqual(result.total, 50000);
    assert.strictEqual(result.batches, 10);
  });

  test('T2_060: CSV Injection Mitigation on Chat Messages prepends apostrophe on formula chars', () => {
    const dangerousMessages = [
      '=cmd|\' /C calc\'!A0',
      '+1234567890',
      '-500*2',
      '@SUM(A1:A10)',
      '\t=2+2'
    ];

    for (const msg of dangerousMessages) {
      const sanitized = sanitizeCsvCell(msg);
      assert.ok(sanitized.startsWith("'") || sanitized.startsWith('"\''), `Message "${msg}" must be escaped with leading apostrophe`);
    }

    const safeMessage = 'Hello, how are you?';
    const sanitizedSafe = sanitizeCsvCell(safeMessage);
    assert.ok(!sanitizedSafe.startsWith("'"));
  });
});
