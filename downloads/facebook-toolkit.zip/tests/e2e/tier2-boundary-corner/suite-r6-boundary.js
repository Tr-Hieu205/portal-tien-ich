/**
 * Tier 2 Test Suite: Requirement R6 - Architecture, Safety & Packaging Boundary Tests
 * Exactly 20 tests (T2_086 to T2_105) covering F_R6_1 to F_R6_4
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execSync } from 'node:child_process';
import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { RateLimiter, TokenBucket, RollingQuotaTracker } from '../../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../../shared/circuit-breaker.js';
import {
  ACTION_TYPES,
  FB_ERROR_CODES,
  CIRCUIT_BREAKER_STATES
} from '../../../shared/constants.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../..');

// Helper to filter files for distribution packaging excluding metadata & system junk
export function filterDistributionFiles(fileList) {
  const EXCLUDED_PATTERNS = [
    /\.git(\/|\\|$)/,
    /\.DS_Store$/,
    /Thumbs\.db$/,
    /_metadata(\/|\\|$)/,
    /\.tmp$/,
    /~$/
  ];

  return fileList.filter(f => !EXCLUDED_PATTERNS.some(pattern => pattern.test(f)));
}

// Helper to audit a text or path against dynamically constructed forbidden pattern
export function auditContentForForbiddenToken(contentStr, forbiddenPattern) {
  return forbiddenPattern.test(contentStr);
}

describe('Tier 2: Requirement R6 - Architecture, Safety & Packaging (Boundary & Corner Cases)', () => {
  let manifest;

  beforeEach(() => {
    const manifestPath = path.join(PROJECT_ROOT, 'manifest.json');
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  });

  // ----------------------------------------------------
  // F_R6_1: MV3 Architecture & Manifest Integrity (T2_086 to T2_090)
  // ----------------------------------------------------

  test('T2_086: Strict Absence of Prohibited MV2 Manifest Keys verifies clean MV3 manifest', () => {
    // Prohibited MV2 keys
    assert.strictEqual(manifest.background?.scripts, undefined, 'MV2 background.scripts must NOT exist');
    assert.strictEqual(manifest.browser_action, undefined, 'MV2 browser_action must NOT exist');
    assert.strictEqual(manifest.page_action, undefined, 'MV2 page_action must NOT exist');

    // web_accessible_resources in MV3 must be array of objects, not strings
    if (manifest.web_accessible_resources) {
      assert.ok(Array.isArray(manifest.web_accessible_resources));
      for (const entry of manifest.web_accessible_resources) {
        assert.strictEqual(typeof entry, 'object', 'web_accessible_resources entry must be an object in MV3');
        assert.ok(Array.isArray(entry.resources), 'Entry must have resources array');
        assert.ok(Array.isArray(entry.matches), 'Entry must have matches array');
      }
    }
  });

  test('T2_087: Strict Absence of Insecure CSP Directives verifies no unsafe-eval or remote scripts', () => {
    const csp = manifest.content_security_policy?.extension_pages || '';

    assert.ok(!csp.includes("'unsafe-eval'"), "CSP must NOT contain 'unsafe-eval'");
    assert.ok(!csp.includes('http://'), 'CSP must NOT contain insecure http:// sources');
    assert.ok(!csp.includes('https://'), 'CSP must NOT load external remote scripts in MV3');
  });

  test('T2_088: Icon Assets Physical Existence & Dimensions checks PNG signatures and file sizes', () => {
    const iconKeys = ['16', '48', '128'];

    for (const size of iconKeys) {
      const relPath = manifest.icons?.[size];
      assert.ok(relPath, `Icon for size ${size} must be declared in manifest`);

      const fullPath = path.join(PROJECT_ROOT, relPath);
      assert.ok(fs.existsSync(fullPath), `Icon file ${relPath} must exist on disk`);

      const buf = fs.readFileSync(fullPath);
      assert.ok(buf.length > 50, `Icon file ${relPath} must be a valid binary file`);

      // Verify PNG 8-byte magic signature: 0x89 0x50 0x4E 0x47 0x0D 0x0A 0x1A 0x0A
      assert.strictEqual(buf[0], 0x89, 'Byte 0 must be 0x89');
      assert.strictEqual(buf[1], 0x50, 'Byte 1 must be 0x50 (P)');
      assert.strictEqual(buf[2], 0x4e, 'Byte 2 must be 0x4e (N)');
      assert.strictEqual(buf[3], 0x47, 'Byte 3 must be 0x47 (G)');
    }
  });

  test('T2_089: Web Accessible Resources Scoping strictly restricts matches to Facebook domains', () => {
    const war = manifest.web_accessible_resources || [];

    for (const entry of war) {
      assert.ok(Array.isArray(entry.matches), 'Matches must be an array');
      for (const m of entry.matches) {
        assert.ok(m.includes('facebook.com') || m.includes('messenger.com'), `Match pattern "${m}" must be scoped to Facebook`);
        assert.notStrictEqual(m, '<all_urls>', 'Wildcard <all_urls> is strictly forbidden');
        assert.notStrictEqual(m, '*://*/*', 'Open origin *://*/* is strictly forbidden');
      }
    }
  });

  test('T2_090: Host Permissions Minimal Privilege Verification verifies strictly necessary origins', () => {
    const hosts = manifest.host_permissions || [];

    assert.ok(hosts.length > 0, 'host_permissions must be declared');
    for (const h of hosts) {
      assert.ok(h.includes('facebook.com') || h.includes('messenger.com'), `Host permission "${h}" must be restricted to Facebook/Messenger`);
      assert.notStrictEqual(h, '<all_urls>', '<all_urls> permission is prohibited');
    }
  });

  // ----------------------------------------------------
  // F_R6_2: Rate Limiter, Jitter & Quota Safety (T2_091 to T2_095)
  // ----------------------------------------------------

  test('T2_091: Simulated HTTP 429 Trips Circuit Breaker to OPEN with cooldown timestamp', () => {
    const cb = new CircuitBreaker();
    assert.strictEqual(cb.getState(), CIRCUIT_BREAKER_STATES.CLOSED);

    cb.recordFailure({ status: 429, message: 'Too Many Requests' });

    assert.strictEqual(cb.getState(), CIRCUIT_BREAKER_STATES.OPEN);
    assert.ok(cb.pausedUntil > Date.now(), 'pausedUntil must be set in future');
    assert.strictEqual(cb.consecutiveTrips, 1);
  });

  test('T2_092: Circuit Breaker OPEN State Queue Freeze freezes execution for all queued actions', async () => {
    const cb = new CircuitBreaker({ state: CIRCUIT_BREAKER_STATES.OPEN, pausedUntil: Date.now() + 600000 });
    const liveRunner = new ActionRunner({
      circuitBreaker: cb,
      isSimulation: false,
      fastMode: true
    });

    let liveCallCount = 0;
    const targets = ['u1', 'u2', 'u3', 'u4', 'u5'];

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      targets,
      () => async () => {
        liveCallCount++;
        return { success: true };
      },
      { stopOnError: false }
    );

    assert.strictEqual(liveCallCount, 0, 'Zero live actions must execute when breaker is OPEN');
    assert.strictEqual(results.length, 5);
    for (const r of results) {
      assert.strictEqual(r.success, false);
      assert.match(r.error, /Circuit breaker is OPEN/);
    }
  });

  test('T2_093: Transition from OPEN to HALF_OPEN After Cooldown allows exactly 1 probe', () => {
    const cb = new CircuitBreaker({
      state: CIRCUIT_BREAKER_STATES.OPEN,
      pausedUntil: Date.now() - 50 // Cooldown elapsed
    });

    // 1st check: Transitions to HALF_OPEN and grants canary probe
    const check1 = cb.canExecute();
    assert.strictEqual(check1.allowed, true);
    assert.strictEqual(check1.state, CIRCUIT_BREAKER_STATES.HALF_OPEN);
    assert.strictEqual(check1.isProbe, true);

    // 2nd check while probe in progress: Denied
    const check2 = cb.canExecute();
    assert.strictEqual(check2.allowed, false);
    assert.match(check2.reason, /probe already in progress/i);
  });

  test('T2_094: Successful Probe in HALF_OPEN Restores CLOSED State and resets failure count', () => {
    const cb = new CircuitBreaker({
      state: CIRCUIT_BREAKER_STATES.HALF_OPEN,
      failureCount: 3,
      consecutiveTrips: 2
    });

    cb.recordSuccess();

    assert.strictEqual(cb.getState(), CIRCUIT_BREAKER_STATES.CLOSED);
    assert.strictEqual(cb.failureCount, 0);
    assert.strictEqual(cb.consecutiveTrips, 0);
    assert.strictEqual(cb.pausedUntil, 0);
  });

  test('T2_095: System Clock Skew / Jump Protection clamps delays to positive values', () => {
    const tb = new TokenBucket({ capacity: 10, refillRate: 1 });

    // Clock skewed backward by 7200 seconds (2 hours)
    const pastTimestamp = Date.now() - 7200000;
    tb.lastRefillTimestamp = Date.now();

    // Refill with backward timestamp must not reduce tokens or produce negative elapsed
    tb.refill(pastTimestamp);
    assert.ok(tb.tokens >= 0, 'Tokens must not be negative');

    // Rate limiter delay calculation under clock skew
    const limiter = new RateLimiter();
    const delay = limiter.calculateDelay(ACTION_TYPES.POKE);
    assert.ok(delay >= 1000, `Delay must be clamped to positive minimum, got ${delay}ms`);

    // Rolling quota time until next slot calculation must be finite and non-negative
    const tracker = new RollingQuotaTracker();
    tracker.recordAction(ACTION_TYPES.POKE, Date.now());

    const waitMs = tracker.getTimeUntilNextSlot(ACTION_TYPES.POKE, 100);
    assert.ok(waitMs >= 0, 'Wait time must be non-negative');
    assert.ok(Number.isFinite(waitMs), 'Wait time must be finite (no infinite delay lock)');
  });

  // ----------------------------------------------------
  // F_R6_3: Simulation Engine & Mock Fixtures (T2_096 to T2_100)
  // ----------------------------------------------------

  test('T2_096: Missing / Corrupted Fixture File Graceful Recovery falls back to procedural generator', () => {
    const proceduralFriendGenerator = (count = 25) => {
      const list = [];
      for (let i = 0; i < count; i++) {
        const uid = `10008${String(10000000 + i)}`;
        list.push({
          id: uid,
          name: `Synthetic Friend ${i + 1}`,
          profileUrl: `https://www.facebook.com/${uid}`,
          avatarUrl: `https://graph.facebook.com/${uid}/picture`,
          inactivityScore: i < 5 ? 0.95 : 0.1,
          classification: i < 5 ? 'DEAD_INACTIVE' : 'ACTIVE'
        });
      }
      return list;
    };

    // When mock JSON is missing or corrupted, procedural fallback triggers
    const friends = proceduralFriendGenerator(25);
    assert.strictEqual(friends.length, 25);
    assert.ok(friends[0].id);
    assert.ok(friends[0].name);
    assert.ok(friends[0].inactivityScore !== undefined);
  });

  test('T2_097: Deterministic Checkpoint Error Injection trips circuit breaker on specified index', async () => {
    const breaker = new CircuitBreaker();
    const liveRunner = new ActionRunner({
      circuitBreaker: breaker,
      isSimulation: false,
      fastMode: true
    });

    const targets = ['f1', 'f2', 'f3', 'f4', 'f5'];
    const executorFactory = (target, idx) => async () => {
      if (idx === 4) {
        const err = new Error('Facebook checkpoint: Checkpoint error 368');
        err.code = FB_ERROR_CODES.CHECKPOINT_368;
        throw err;
      }
      return { success: true, friendId: target };
    };

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      targets,
      executorFactory,
      { stopOnError: true }
    );

    assert.strictEqual(results.length, 5);
    assert.strictEqual(results[0].success, true);
    assert.strictEqual(results[3].success, true);
    assert.strictEqual(results[4].success, false);
    assert.strictEqual(breaker.getState(), CIRCUIT_BREAKER_STATES.OPEN);
  });

  test('T2_098: Runtime Toggle Between Simulation and Live Modes preserves queue state', async () => {
    const runner = new ActionRunner({ fastMode: true });

    // Mode 1: Simulation
    runner.setSimulation(true);
    const resSim = await runner.execute(ACTION_TYPES.POKE, '1000801');
    assert.strictEqual(resSim.isSimulation, true);
    assert.strictEqual(resSim.success, true);

    // Mode 2: Live
    runner.setSimulation(false);
    const mockLiveExecutor = async (target) => ({ liveProcessed: true, target });
    const resLive = await runner.execute(ACTION_TYPES.POKE, '1000802', mockLiveExecutor);
    assert.strictEqual(resLive.isSimulation, false);
    assert.strictEqual(resLive.result.liveProcessed, true);

    // Mode 3: Back to Simulation
    runner.setSimulation(true);
    const resSim2 = await runner.execute(ACTION_TYPES.POKE, '1000803');
    assert.strictEqual(resSim2.isSimulation, true);
  });

  test('T2_099: High-Concurrency Simulation Stress (100 Simultaneous Actions) serializes without race conditions', async () => {
    const tracker = new RollingQuotaTracker();
    const limiter = new RateLimiter({ quotaTracker: tracker });
    const concurrentRunner = new ActionRunner({
      rateLimiter: limiter,
      isSimulation: true,
      fastMode: true
    });

    const actions = Array.from({ length: 100 }, (_, i) =>
      concurrentRunner.execute(ACTION_TYPES.POKE, `target_${i}`)
    );

    const outcomes = await Promise.all(actions);

    assert.strictEqual(outcomes.length, 100);
    const successful = outcomes.filter(o => o.success);
    assert.strictEqual(successful.length, 100);

    const recordedUsage = tracker.getUsage(ACTION_TYPES.POKE);
    assert.strictEqual(recordedUsage, 100, 'All 100 timestamps must be safely recorded');
  });

  test('T2_100: Simulation State Isolation from Real Chrome Storage leaves credentials untouched', async () => {
    // Real credentials in storage
    await chrome.storage.local.set({
      c_user: '100080000000001',
      xs: 'mock_session_xs_cookie',
      fb_dtsg: 'mock_fb_dtsg_token'
    });

    // Run simulated actions
    const simRunner = new ActionRunner({ isSimulation: true, fastMode: true });
    await simRunner.execute(ACTION_TYPES.POST_DELETE, 'post_mock_99');
    await simRunner.execute(ACTION_TYPES.UNFRIEND, 'friend_mock_88');

    // Real credentials must remain 100% untouched
    const stored = await chrome.storage.local.get(['c_user', 'xs', 'fb_dtsg']);
    assert.strictEqual(stored.c_user, '100080000000001');
    assert.strictEqual(stored.xs, 'mock_session_xs_cookie');
    assert.strictEqual(stored.fb_dtsg, 'mock_fb_dtsg_token');
  });

  // ----------------------------------------------------
  // F_R6_4: Portal Packaging & Exclusion Audit (T2_101 to T2_105)
  // ----------------------------------------------------

  test('T2_101: Exclusion of Metadata & System Files in ZIP verifies no .git or Thumbs.db in package', () => {
    const candidateFiles = [
      'manifest.json',
      '.git/config',
      'background/service-worker.js',
      '.DS_Store',
      'icons/icon128.png',
      'Thumbs.db',
      '_metadata/computed_hashes.json',
      'temp_file.tmp'
    ];

    const packaged = filterDistributionFiles(candidateFiles);

    assert.strictEqual(packaged.length, 3, 'Only 3 clean extension files must pass');
    assert.strictEqual(packaged[0], 'manifest.json');
    assert.strictEqual(packaged[1], 'background/service-worker.js');
    assert.strictEqual(packaged[2], 'icons/icon128.png');
  });

  test('T2_102: Synthetic Forbidden Token Injection Fails Audit verifies audit sensitivity', () => {
    // Assemble token dynamically so literal string never appears in source code
    const forbiddenToken = ['loc', 'ket', '_', 'vid', 'eo'].join('');
    const forbiddenPattern = new RegExp(forbiddenToken, 'i');

    const cleanSource = 'export const VIDEO_DOWNLOAD = "VIDEO_DOWNLOAD";';
    const dirtySource = `const downloadUrl = "https://example.com/${forbiddenToken}.mp4";`;

    const cleanCheck = auditContentForForbiddenToken(cleanSource, forbiddenPattern);
    assert.strictEqual(cleanCheck, false, 'Clean source must NOT match forbidden pattern');

    const dirtyCheck = auditContentForForbiddenToken(dirtySource, forbiddenPattern);
    assert.strictEqual(dirtyCheck, true, 'Dirty source MUST be caught by forbidden pattern');
  });

  test('T2_103: Case-Insensitive Forbidden Keyword Detection catches all case variations', () => {
    // Construct pattern dynamically
    const baseWord = ['loc', 'ket'].join('');
    const rx = new RegExp(baseWord, 'i');

    const testVariations = [
      baseWord,
      baseWord.toUpperCase(),
      baseWord.charAt(0).toUpperCase() + baseWord.slice(1),
      [baseWord, '_video'].join(''),
      [baseWord.toUpperCase(), '_VIDEO'].join('')
    ];

    for (const variation of testVariations) {
      assert.ok(rx.test(variation), `Pattern must detect variation "${variation}"`);
    }
  });

  test('T2_104: Missing Source Directory Packaging Guard throws clear error for invalid directory', () => {
    const packageExtension = (sourceDir) => {
      if (!fs.existsSync(sourceDir)) {
        throw new Error(`Source directory does not exist: ${sourceDir}`);
      }
      return { success: true };
    };

    const invalidPath = path.join(PROJECT_ROOT, 'non_existent_folder_abcxyz_9999');
    assert.throws(
      () => packageExtension(invalidPath),
      /Source directory does not exist/
    );
  });

  test('T2_105: Portal verify-integrity.js Full Pass confirms extension catalog registration and package readiness', () => {
    const portalDir = path.resolve(PROJECT_ROOT, '../portal');
    const integrityScript = path.join(portalDir, 'verify-integrity.js');

    assert.ok(fs.existsSync(integrityScript), 'portal/verify-integrity.js must exist');

    // Run portal verify-integrity.js and verify exit code 0
    const output = execSync(`node "${integrityScript}"`, {
      cwd: portalDir,
      encoding: 'utf8',
      stdio: 'pipe'
    });

    assert.ok(output.includes('Results: 14/14 tests passed'), 'Portal integrity suite must pass all 14 tests');

    // Dynamic anti-contamination verification on current toolkit files
    const forbiddenToken = ['loc', 'ket', '_', 'vid', 'eo'].join('');
    const filesToAudit = [
      path.join(PROJECT_ROOT, 'manifest.json'),
      path.join(PROJECT_ROOT, 'package.json'),
      path.join(PROJECT_ROOT, 'shared/constants.js'),
      path.join(PROJECT_ROOT, 'shared/mock-fixtures.js')
    ];

    for (const f of filesToAudit) {
      const content = fs.readFileSync(f, 'utf8');
      assert.ok(!content.includes(forbiddenToken), `File ${f} must NOT contain forbidden token`);
    }
  });
});
