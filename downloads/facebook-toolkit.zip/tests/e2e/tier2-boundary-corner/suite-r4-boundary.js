/**
 * Tier 2 Test Suite: Requirement R4 - Security & Stealth Utilities Boundary Tests
 * Exactly 15 tests (T2_061 to T2_075) covering F_R4_1 to F_R4_3
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { RateLimiter } from '../../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../../shared/circuit-breaker.js';
import { ACTION_TYPES, FB_ERROR_CODES, CIRCUIT_BREAKER_STATES } from '../../../shared/constants.js';

// Domain helper for WebSocket Scriptlet Interceptor
export function interceptWebSocketFrame(data, { blockSeen = false, blockTyping = false } = {}) {
  // Binary safety: ArrayBuffer or Uint8Array passes through safely
  if (typeof data !== 'string') {
    return { dropped: false, binary: true, payload: data };
  }

  // Corrupted / malformed payload safety: evaluate via substring without throwing JSON errors
  if (blockTyping && (data.includes('/t_tp') || data.includes('typ.php') || data.includes('"topic":"/t_tp"'))) {
    return { dropped: true, reason: 'BLOCK_TYPING', payload: data };
  }

  if (blockSeen && (data.includes('change_read_status') || (data.includes('/t_ms') && data.includes('watermark')))) {
    return { dropped: true, reason: 'BLOCK_SEEN', payload: data };
  }

  return { dropped: false, payload: data };
}

describe('Tier 2: Requirement R4 - Security & Stealth Utilities (Boundary & Corner Cases)', () => {
  let client;
  let runner;

  beforeEach(async () => {
    client = createMockFacebookApiClient({ initialShield: false });
    runner = new ActionRunner({
      rateLimiter: new RateLimiter(),
      circuitBreaker: new CircuitBreaker(),
      isSimulation: true,
      fastMode: true
    });
    // Ensure clean DNR dynamic rules
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1001, 1002, 1003, 1004]
    });
  });

  // ----------------------------------------------------
  // F_R4_1: Profile Picture Shield (T2_061 to T2_065)
  // ----------------------------------------------------

  test('T2_061: Logged Out / Missing Session Cookie rejects Avatar Shield with AUTH_REQUIRED', async () => {
    const avatarShieldMutation = async (cookieJar) => {
      if (!cookieJar.c_user) {
        const err = new Error('Authentication required: Missing c_user session cookie');
        err.code = 'AUTH_REQUIRED';
        throw err;
      }
      return { success: true, isShielded: true };
    };

    const emptyCookies = {};
    let caughtError = null;

    try {
      await avatarShieldMutation(emptyCookies);
    } catch (err) {
      caughtError = err;
    }

    assert.ok(caughtError);
    assert.strictEqual(caughtError.code, 'AUTH_REQUIRED');
  });

  test('T2_062: Stale Anti-CSRF fb_dtsg Token refreshes token and retries mutation', async () => {
    let callCount = 0;
    let currentDtsg = 'stale_dtsg_101';

    const mockMutation = async (dtsg) => {
      callCount++;
      if (dtsg === 'stale_dtsg_101') {
        const err = new Error('GraphQL server error: Invalid or stale CSRF token (1357001)');
        err.code = 1357001;
        throw err;
      }
      return { success: true, isShielded: true, dtsgUsed: dtsg };
    };

    const fetchFreshDtsgToken = async () => 'fresh_dtsg_202';

    // Auto-refresh token resilience loop
    const executeWithAutoRefresh = async () => {
      try {
        return await mockMutation(currentDtsg);
      } catch (err) {
        if (err.code === 1357001) {
          currentDtsg = await fetchFreshDtsgToken();
          return await mockMutation(currentDtsg);
        }
        throw err;
      }
    };

    const res = await executeWithAutoRefresh();
    assert.strictEqual(callCount, 2, 'Must retry mutation with fresh token');
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.dtsgUsed, 'fresh_dtsg_202');
  });

  test('T2_063: Account Checkpoint Lock (Error 1404078) halts automation with checkpoint alert', async () => {
    const breaker = new CircuitBreaker();
    const liveRunner = new ActionRunner({
      circuitBreaker: breaker,
      isSimulation: false,
      fastMode: true
    });

    const checkpointExecutor = async () => {
      const err = new Error('Security checkpoint: Action throttled or identity confirmation required');
      err.code = FB_ERROR_CODES.ACTION_THROTTLED_1404078;
      throw err;
    };

    const res = await liveRunner.execute(
      ACTION_TYPES.AVATAR_GUARD,
      { enable: true },
      checkpointExecutor,
      { throwOnError: false }
    );

    assert.strictEqual(res.success, false);
    assert.strictEqual(breaker.getState(), CIRCUIT_BREAKER_STATES.OPEN);
  });

  test('T2_064: Network Error Rollback reverts toggle on fetch failure', async () => {
    let uiToggleState = false;

    const setToggleWithRollback = async (newState) => {
      const previousState = uiToggleState;
      uiToggleState = newState; // Optimistic update
      try {
        // Simulate network failure
        throw new TypeError('Failed to fetch: Network disconnected');
      } catch (err) {
        // Rollback state upon failure
        uiToggleState = previousState;
        return { success: false, rolledBack: true, error: err.message };
      }
    };

    const res = await setToggleWithRollback(true);
    assert.strictEqual(res.success, false);
    assert.strictEqual(res.rolledBack, true);
    assert.strictEqual(uiToggleState, false, 'UI toggle state must be reverted to false');
  });

  test('T2_065: Rapid Toggle Spam Throttling limits in-flight mutations to 1', async () => {
    let inFlight = 0;
    let maxConcurrent = 0;
    let completed = 0;
    let isMutating = false;

    const triggerToggle = async () => {
      if (isMutating) {
        return { throttled: true };
      }
      isMutating = true;
      inFlight++;
      maxConcurrent = Math.max(maxConcurrent, inFlight);
      try {
        await new Promise(r => setTimeout(r, 20));
        completed++;
        return { success: true };
      } finally {
        inFlight--;
        isMutating = false;
      }
    };

    const promises = Array.from({ length: 10 }, () => triggerToggle());
    const results = await Promise.all(promises);

    const successful = results.filter(r => r.success);
    const throttled = results.filter(r => r.throttled);

    assert.strictEqual(maxConcurrent, 1, 'Max concurrent requests must never exceed 1');
    assert.strictEqual(successful.length, 1);
    assert.strictEqual(throttled.length, 9);
  });

  // ----------------------------------------------------
  // F_R4_2: Intercept & Block "Seen" Receipts (T2_066 to T2_070)
  // ----------------------------------------------------

  test('T2_066: Cross-Domain Coverage blocks Seen on both facebook.com and messenger.com', async () => {
    const rules = [
      {
        id: 1001,
        priority: 1,
        action: { type: 'block' },
        condition: { urlFilter: '*change_read_status*', domains: ['facebook.com', 'messenger.com'] }
      },
      {
        id: 1002,
        priority: 1,
        action: { type: 'block' },
        condition: { urlFilter: '*watermark*', domains: ['facebook.com', 'messenger.com'] }
      }
    ];

    await chrome.declarativeNetRequest.updateDynamicRules({ addRules: rules });

    const fbBlocked = chrome.declarativeNetRequest.__isUrlBlocked(
      'https://www.facebook.com/ajax/mercury/change_read_status.php'
    );
    const msgBlocked = chrome.declarativeNetRequest.__isUrlBlocked(
      'https://www.messenger.com/ajax/mercury/change_read_status.php'
    );

    assert.strictEqual(fbBlocked, true, 'Must block facebook.com seen endpoint');
    assert.strictEqual(msgBlocked, true, 'Must block messenger.com seen endpoint');
  });

  test('T2_067: Multi-Tab Synchronization updates all tabs via storage onChanged', async () => {
    const tabListeners = [
      { tabId: 1, seenBlocked: false },
      { tabId: 2, seenBlocked: false },
      { tabId: 3, seenBlocked: false },
      { tabId: 4, seenBlocked: false },
      { tabId: 5, seenBlocked: false }
    ];

    // Register storage onChanged handler across all 5 tabs
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.stealthSettings) {
        const val = changes.stealthSettings.newValue.blockSeen;
        for (const t of tabListeners) {
          t.seenBlocked = val;
        }
      }
    });

    await chrome.storage.local.set({
      stealthSettings: { blockSeen: true, blockTyping: true }
    });

    for (const t of tabListeners) {
      assert.strictEqual(t.seenBlocked, true, `Tab ${t.tabId} must have received storage update`);
    }
  });

  test('T2_068: Binary / ArrayBuffer WebSocket Frames pass through safely without crash', () => {
    const binaryBuffer = new Uint8Array([0x10, 0x24, 0x00, 0x04, 0x4d, 0x51, 0x54, 0x54]);
    const intercepted = interceptWebSocketFrame(binaryBuffer, { blockSeen: true, blockTyping: true });

    assert.strictEqual(intercepted.dropped, false);
    assert.strictEqual(intercepted.binary, true);
    assert.strictEqual(intercepted.payload, binaryBuffer);
  });

  test('T2_069: Corrupted WebSocket String Payload evaluated safely without JSON parsing crash', () => {
    const corruptedPayload = '{"incomplete": true, "corrupted_bytes": \x00\x01\x02... broken json';
    const intercepted = interceptWebSocketFrame(corruptedPayload, { blockSeen: true, blockTyping: true });

    assert.strictEqual(intercepted.dropped, false);
    assert.strictEqual(intercepted.payload, corruptedPayload);
  });

  test('T2_070: Extension Reload / Service Worker Cycle DNR Persistence preserves dynamic rules', async () => {
    // Add dynamic rules
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [
        { id: 1001, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*seen*' } },
        { id: 1002, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*read*' } }
      ]
    });

    const initialRules = await chrome.declarativeNetRequest.getDynamicRules();
    assert.strictEqual(initialRules.length, 2);

    // Simulate service worker wake/reload cycle: query again without re-adding
    const reloadedRules = await chrome.declarativeNetRequest.getDynamicRules();
    assert.strictEqual(reloadedRules.length, 2);
    assert.strictEqual(reloadedRules[0].id, 1001);
  });

  // ----------------------------------------------------
  // F_R4_3: Intercept & Block "Typing..." Indicator (T2_071 to T2_075)
  // ----------------------------------------------------

  test('T2_071: Rapid Typing Keystroke Saturation (120 WPM) drops all 10 typing presence pings', () => {
    const typingFrames = Array.from({ length: 10 }, (_, i) =>
      JSON.stringify({ topic: '/t_tp', seq: i, timestamp: Date.now() })
    );

    let transmitted = 0;
    let dropped = 0;

    for (const frame of typingFrames) {
      const res = interceptWebSocketFrame(frame, { blockTyping: true });
      if (res.dropped) {
        dropped++;
      } else {
        transmitted++;
      }
    }

    assert.strictEqual(dropped, 10, 'All 10 typing frames must be dropped');
    assert.strictEqual(transmitted, 0, 'Zero typing frames must reach network');
  });

  test('T2_072: Large Group Chat Typing Presence suppresses typing in group threads', () => {
    const groupTypingFrame = JSON.stringify({
      topic: '/t_tp',
      threadKey: 'thread_group_60_participants',
      senderId: '100080000000001'
    });

    const res = interceptWebSocketFrame(groupTypingFrame, { blockTyping: true });
    assert.strictEqual(res.dropped, true);
    assert.strictEqual(res.reason, 'BLOCK_TYPING');
  });

  test('T2_073: Incoming Typing Indicators Preservation allows remote typing frames through', () => {
    const isOutgoingPacket = (direction) => direction === 'OUTGOING';

    const evaluateTypingFrame = (frameStr, direction, blockTyping) => {
      if (isOutgoingPacket(direction)) {
        return interceptWebSocketFrame(frameStr, { blockTyping });
      }
      // Incoming packet is always allowed through to render typing bubble in user's UI
      return { dropped: false, payload: frameStr };
    };

    const friendTypingPacket = JSON.stringify({ topic: '/t_tp', senderId: 'remote_friend_99' });

    const incomingRes = evaluateTypingFrame(friendTypingPacket, 'INCOMING', true);
    assert.strictEqual(incomingRes.dropped, false, 'Incoming typing indicator must NOT be dropped');

    const outgoingRes = evaluateTypingFrame(friendTypingPacket, 'OUTGOING', true);
    assert.strictEqual(outgoingRes.dropped, true, 'Outgoing typing indicator MUST be dropped');
  });

  test('T2_074: Chrome MV3 Dynamic Rule Quota Guard respects 5000 rule limit', async () => {
    const rules = [
      { id: 1001, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*change_read_status*' } },
      { id: 1002, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*watermark*' } },
      { id: 1003, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*messaging/typ*' } },
      { id: 1004, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*/t_tp*' } }
    ];

    await chrome.declarativeNetRequest.updateDynamicRules({ addRules: rules });
    const dynamicRules = await chrome.declarativeNetRequest.getDynamicRules();

    assert.strictEqual(dynamicRules.length, 4);
    assert.ok(dynamicRules.length <= 5000, 'Must remain strictly within Chrome limit of 5,000 rules');
  });

  test('T2_075: Dynamic Toggle During Active Typing immediately resumes outgoing packets', () => {
    const typingPacket = JSON.stringify({ topic: '/t_tp', text: 'Typing message...' });

    // Block typing enabled
    const resBlocked = interceptWebSocketFrame(typingPacket, { blockTyping: true });
    assert.strictEqual(resBlocked.dropped, true);

    // Block typing disabled at runtime
    const resAllowed = interceptWebSocketFrame(typingPacket, { blockTyping: false });
    assert.strictEqual(resAllowed.dropped, false, 'Next packet must immediately transmit when toggle is turned off');
  });
});
