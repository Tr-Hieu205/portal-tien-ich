/**
 * Tier 2 Test Suite: Requirement R5 - Automated Post & Reup Scheduling Boundary Tests
 * Exactly 10 tests (T2_076 to T2_085) covering F_R5_1 to F_R5_2
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { RateLimiter, RollingQuotaTracker } from '../../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../../shared/circuit-breaker.js';
import { ACTION_TYPES, DEFAULT_ROLLING_QUOTAS_24H } from '../../../shared/constants.js';
import { AlarmsManager } from '../../../background/alarms-manager.js';

// Domain helper for leap year birthday evaluation
export function isBirthdayToday(birthDateStr, currentDate = new Date()) {
  const parts = birthDateStr.split('-');
  const bMonth = parseInt(parts[0], 10);
  const bDay = parseInt(parts[1], 10);

  const curMonth = currentDate.getMonth() + 1;
  const curDay = currentDate.getDate();
  const curYear = currentDate.getFullYear();
  const isLeapYear = (curYear % 4 === 0 && curYear % 100 !== 0) || (curYear % 400 === 0);

  // Exact match
  if (bMonth === curMonth && bDay === curDay) return true;

  // Leap day corner case: friend born Feb 29 celebrated on Feb 28 in non-leap year
  if (bMonth === 2 && bDay === 29 && !isLeapYear) {
    if (curMonth === 2 && curDay === 28) return true;
  }

  return false;
}

// Domain helper for template token resolution (mononym safe)
export function renderBirthdayTemplate(templateStr, friend) {
  const rawName = friend.name || friend.friendName || '';
  const tokens = rawName.trim().split(/\s+/);
  const firstName = tokens[0] || '';
  const lastName = tokens.length > 1 ? tokens.slice(1).join(' ') : '';

  return templateStr
    .replace(/\{name\}/g, rawName)
    .replace(/\{full_name\}/g, rawName)
    .replace(/\{first_name\}/g, firstName)
    .replace(/\{last_name\}/g, lastName);
}

// Domain helper for resilient RSS XML parsing
export function parseRssFeedSafe(xmlStr) {
  if (!xmlStr || typeof xmlStr !== 'string') {
    return { success: false, items: [], error: 'Feed parse error: Empty XML content' };
  }

  // Basic XML structure sanity check
  if (!xmlStr.includes('<rss') && !xmlStr.includes('<feed') && !xmlStr.includes('<?xml')) {
    return { success: false, items: [], error: 'Feed parse error: Invalid XML format' };
  }

  const items = [];
  const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
  let match;

  while ((match = itemRegex.exec(xmlStr)) !== null) {
    const block = match[1];
    const titleMatch = /<title>(.*?)<\/title>/i.exec(block);
    const linkMatch = /<link>(.*?)<\/link>/i.exec(block);
    const descMatch = /<description>(.*?)<\/description>/i.exec(block);
    const enclosureMatch = /<enclosure[^>]*url="([^"]*)"/i.exec(block);

    items.push({
      title: titleMatch ? titleMatch[1].trim() : '',
      link: linkMatch ? linkMatch[1].trim() : '',
      description: descMatch ? descMatch[1].trim() : '',
      mediaUrl: enclosureMatch ? enclosureMatch[1].trim() : null
    });
  }

  return { success: true, items };
}

// Domain helper for post text truncation
export function sanitizePostText(content, maxChars = 63000) {
  if (!content) return '';
  const str = String(content);
  if (str.length <= maxChars) return str;
  return str.slice(0, maxChars - 3) + '...';
}

describe('Tier 2: Requirement R5 - Automated Post & Reup Scheduling (Boundary & Corner Cases)', () => {
  let client;
  let runner;

  beforeEach(async () => {
    client = createMockFacebookApiClient();
    runner = new ActionRunner({
      rateLimiter: new RateLimiter(),
      circuitBreaker: new CircuitBreaker(),
      isSimulation: true,
      fastMode: true
    });
    await chrome.alarms.clearAll();
  });

  // ----------------------------------------------------
  // F_R5_1: Scheduled Birthday Auto-Greeter (T2_076 to T2_080)
  // ----------------------------------------------------

  test('T2_076: Leap Year Birthday (February 29) handled on non-leap year', () => {
    // Current year is 2026 (non-leap: 2026 % 4 !== 0)
    const testDateFeb28 = new Date(2026, 1, 28); // Month is 0-indexed: 1 = February
    const testDateFeb27 = new Date(2026, 1, 27);

    // Friend born on Feb 29
    const isTodayOnFeb28 = isBirthdayToday('02-29', testDateFeb28);
    const isTodayOnFeb27 = isBirthdayToday('02-29', testDateFeb27);

    assert.strictEqual(isTodayOnFeb28, true, 'Leap-day birthday must match Feb 28 in non-leap year');
    assert.strictEqual(isTodayOnFeb27, false);
  });

  test('T2_077: Birthday Whitelist and Channel Enforcement: Strictly message channel and skipped when not in whitelist', async () => {
    const client = createMockFacebookApiClient();
    const directGreet = await client.sendBirthdayGreeting('10008888001', 'Happy Birthday! 🎂', 'timeline');
    assert.strictEqual(directGreet.success, true);
    assert.strictEqual(directGreet.channel, 'message', 'Channel must be forced to message, never timeline');

    // Empty whitelist boundary
    await chrome.storage.local.set({ birthdayWhitelist: [] });
    let attemptedGreetings = 0;
    const mockFbApi = {
      async fetchBirthdays() {
        return [{ friendId: 'f_test_boundary', name: 'Boundary Friend', isToday: true }];
      },
      async sendBirthdayGreeting() {
        attemptedGreetings++;
        return { success: true };
      }
    };

    await AlarmsManager.init({
      storageManager: chrome.storage.local,
      fbApi: mockFbApi,
      actionRunner: runner
    });

    const res = await AlarmsManager.handleBirthdayCheckerRoutine({ name: 'FB_TOOLKIT_BIRTHDAY_CHECKER' });
    assert.strictEqual(res.greetedCount, 0, 'No greetings when whitelist is empty');
    assert.strictEqual(attemptedGreetings, 0, 'Zero API calls dispatched when not whitelisted');
    const skippedItem = res.results?.find(r => r.friendId === 'f_test_boundary');
    assert.ok(skippedItem && skippedItem.skipped === true, 'Skipped item must have skipped: true');
  });

  test('T2_078: Burst Birthdays on Same Day (10 Friends) paces greetings with safe delay', () => {
    const baseDelayMs = 120000; // 2 minutes between greetings
    const burstCount = 10;
    const computedDelays = [];

    for (let i = 0; i < burstCount; i++) {
      // Pacing formula with random jitter between 60s and 180s
      const delay = Math.round(baseDelayMs * (0.75 + Math.random() * 0.5));
      computedDelays.push(delay);
    }

    assert.strictEqual(computedDelays.length, 10);
    for (const d of computedDelays) {
      assert.ok(d >= 60000, `Delay ${d}ms must be >= 60,000ms`);
      assert.ok(d <= 180000, `Delay ${d}ms must be <= 180,000ms`);
    }
  });

  test('T2_079: Mononym / Single Name Friend resolves template tokens cleanly', () => {
    const friendCher = { friendId: '10008001', name: 'Cher' };
    const friendMinh = { friendId: '10008002', name: 'Minh' };

    const template = 'Happy Birthday {first_name}! Wishing you great success, {full_name}!';

    const renderedCher = renderBirthdayTemplate(template, friendCher);
    assert.strictEqual(renderedCher, 'Happy Birthday Cher! Wishing you great success, Cher!');
    assert.ok(!renderedCher.includes('undefined'));

    const renderedMinh = renderBirthdayTemplate(template, friendMinh);
    assert.strictEqual(renderedMinh, 'Happy Birthday Minh! Wishing you great success, Minh!');
  });

  test('T2_080: Computer Awakening from Prolonged Sleep only greets friends born today', () => {
    const friends = [
      { id: 'f1', name: 'Alice', birthDate: '11-13' }, // Missed 2 days ago
      { id: 'f2', name: 'Bob', birthDate: '11-14' },   // Missed yesterday
      { id: 'f3', name: 'Charlie', birthDate: '11-15' } // Born today
    ];

    const wakeDate = new Date(2026, 10, 15); // Nov 15

    const friendsToGreetToday = friends.filter(f => isBirthdayToday(f.birthDate, wakeDate));

    assert.strictEqual(friendsToGreetToday.length, 1, 'Only friends born on current calendar day should be greeted');
    assert.strictEqual(friendsToGreetToday[0].id, 'f3');
  });

  // ----------------------------------------------------
  // F_R5_2: Scheduled Post & Reel Reup Engine (T2_081 to T2_085)
  // ----------------------------------------------------

  test('T2_081: Malformed / Broken RSS XML Feed catches parse error cleanly', () => {
    const invalidXml = '<html><head><title>500 Internal Server Error</title></head><body>Server crashed</body></html>';
    const result = parseRssFeedSafe(invalidXml);

    assert.strictEqual(result.success, false);
    assert.strictEqual(result.items.length, 0);
    assert.match(result.error, /Feed parse error/);
  });

  test('T2_082: Missing / 404 Enclosure Media in Feed skips item safely', async () => {
    const feedItem = {
      title: 'Amazing Reel',
      link: 'https://example.com/post_1',
      mediaUrl: 'https://cdn.example.com/media_404.mp4'
    };

    const mediaChecker = async (url) => {
      // Simulate 404 response on media enclosure
      if (url.includes('404')) {
        return { status: 404, ok: false };
      }
      return { status: 200, ok: true };
    };

    const scheduleReupPost = async (item) => {
      const check = await mediaChecker(item.mediaUrl);
      if (!check.ok) {
        return {
          published: false,
          status: 'SKIPPED_MISSING_MEDIA',
          reason: `Media enclosure returned HTTP ${check.status}`
        };
      }
      return { published: true, status: 'PUBLISHED' };
    };

    const res = await scheduleReupPost(feedItem);
    assert.strictEqual(res.published, false);
    assert.strictEqual(res.status, 'SKIPPED_MISSING_MEDIA');
  });

  test('T2_083: Oversized Video File Rejection (>500MB) blocks upload with size warning', () => {
    const validateVideoSize = (sizeBytes) => {
      const MAX_BYTES = 500 * 1024 * 1024; // 500 MB
      if (sizeBytes > MAX_BYTES) {
        const sizeMb = Math.round(sizeBytes / (1024 * 1024));
        return {
          allowed: false,
          error: `Video size ${sizeMb}MB exceeds maximum allowed 500MB limit`
        };
      }
      return { allowed: true };
    };

    const oversized = 650 * 1024 * 1024; // 650 MB
    const normal = 45 * 1024 * 1024;     // 45 MB

    const overCheck = validateVideoSize(oversized);
    assert.strictEqual(overCheck.allowed, false);
    assert.match(overCheck.error, /exceeds maximum allowed 500MB limit/);

    const normalCheck = validateVideoSize(normal);
    assert.strictEqual(normalCheck.allowed, true);
  });

  test('T2_084: Post Text Exceeds Facebook Character Limit truncates to 63000 chars', () => {
    const giantDescription = 'X'.repeat(65000);
    const sanitized = sanitizePostText(giantDescription, 63000);

    assert.strictEqual(sanitized.length, 63000);
    assert.ok(sanitized.endsWith('...'));

    const shortDescription = 'Standard length status message';
    const cleanShort = sanitizePostText(shortDescription, 63000);
    assert.strictEqual(cleanShort, shortDescription);
  });

  test('T2_085: Daily Reup Post Quota Exhaustion (Max 10/day) defers post until slot frees', () => {
    const tracker = new RollingQuotaTracker();
    const maxPosts = DEFAULT_ROLLING_QUOTAS_24H[ACTION_TYPES.REUP_POST] || 10;
    const now = Date.now();

    for (let i = 0; i < maxPosts; i++) {
      tracker.recordAction(ACTION_TYPES.REUP_POST, now - i * 3600000);
    }

    const limiter = new RateLimiter({
      quotaTracker: tracker
    });

    const status = limiter.checkQuota(ACTION_TYPES.REUP_POST, maxPosts, now);

    assert.strictEqual(status.allowed, false);
    assert.strictEqual(status.used, maxPosts);
    assert.ok(status.waitMs > 0, 'Wait time must be positive until earliest slot expires');
  });
});
