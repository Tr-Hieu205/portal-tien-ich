/**
 * Tier 2 Test Suite: Requirement R2 - Profile Cleanup Boundary Tests
 * Exactly 20 tests (T2_021 to T2_040) covering F_R2_1 to F_R2_4
 */

import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import { RateLimiter, TokenBucket } from '../../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../../shared/circuit-breaker.js';
import {
  ACTION_TYPES,
  CIRCUIT_BREAKER_STATES
} from '../../../shared/constants.js';
import { generateMockDataset } from '../../../shared/mock-fixtures.js';
import { safePhotoDeleteGuard } from '../../../background/fb-api.js';

// Domain helper for Timeline Content Scanner with boundary normalization
export function filterTimelinePosts(posts, filter = {}) {
  let list = Array.isArray(posts) ? [...posts] : [];

  if (filter.dateRange) {
    let start = new Date(filter.dateRange.start).getTime();
    let end = new Date(filter.dateRange.end).getTime();

    // Boundary Normalization: If dates are inverted, auto-swap them
    if (!Number.isNaN(start) && !Number.isNaN(end) && start > end) {
      const temp = start;
      start = end;
      end = temp;
    }

    if (!Number.isNaN(start)) {
      list = list.filter(p => p.creationTime >= start);
    }
    if (!Number.isNaN(end)) {
      list = list.filter(p => p.creationTime <= end);
    }
  }

  if (filter.keyword !== undefined && filter.keyword !== null) {
    let kw = String(filter.keyword);
    // Boundary Truncation: Maximum 256 chars for keyword query
    if (kw.length > 256) {
      kw = kw.slice(0, 256);
    }
    const lowerKw = kw.toLowerCase();

    list = list.filter(p => {
      // Safe null / media-only post check
      const text = (p.message || p.content || p.attachmentTitle || '').toLowerCase();
      // Literal text search - prevents Regex injection / ReDoS
      return text.includes(lowerKw);
    });
  }

  return list;
}

// Domain helper for Post / Item ID Schema Validation
export function sanitizeTargetIds(ids) {
  if (!Array.isArray(ids)) return [];
  return ids
    .filter(id => id !== null && id !== undefined && typeof id === 'string' && id.trim().length > 0)
    .map(id => id.trim());
}

// Domain helper for Profile Action Validator
export function validateArchiveAction(action) {
  const ALLOWED = ['HIDE', 'ARCHIVE'];
  if (!action || typeof action !== 'string' || !ALLOWED.includes(action.toUpperCase())) {
    throw new Error(`ValidationError: Action must be 'HIDE' or 'ARCHIVE'. Received "${action}".`);
  }
  return action.toUpperCase();
}

describe('Tier 2: Requirement R2 - Profile Cleanup (Boundary & Corner Cases)', () => {
  let client;
  let runner;
  let rateLimiter;
  let circuitBreaker;
  let mockData;

  beforeEach(() => {
    mockData = generateMockDataset(9999);
    circuitBreaker = new CircuitBreaker();
    rateLimiter = new RateLimiter();
    runner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: true,
      fastMode: true
    });
    client = createMockFacebookApiClient({ posts: mockData.posts });
  });

  // ----------------------------------------------------
  // F_R2_1: Timeline Content Scanner & Filter (T2_021 to T2_025)
  // ----------------------------------------------------

  test('T2_021: Inverted Date Range normalizes start and end dates automatically', () => {
    const posts = [
      { id: 'p1', creationTime: new Date('2022-06-15').getTime(), message: 'Summer trip' },
      { id: 'p2', creationTime: new Date('2025-01-01').getTime(), message: 'Future plan' },
      { id: 'p3', creationTime: new Date('2019-12-31').getTime(), message: 'Old memory' }
    ];

    // Inverted date range: start is 2024, end is 2021
    const filtered = filterTimelinePosts(posts, {
      dateRange: { start: '2024-12-31', end: '2021-01-01' }
    });

    assert.strictEqual(filtered.length, 1, 'Should match exactly 1 post within normalized range');
    assert.strictEqual(filtered[0].id, 'p1');
  });

  test('T2_022: Keyword Containing Regex Injection Characters treated as literal string', () => {
    const posts = [
      { id: 'p1', creationTime: Date.now(), message: 'Normal status update' },
      { id: 'p2', creationTime: Date.now(), message: 'Test containing (.*+?^${}()|[]\\/)|@#%^&*! special string' }
    ];

    const maliciousKeyword = '(.*+?^${}()|[]\\/)|@#%^&*!';
    // Should NOT throw RegExp syntax error
    const filtered = filterTimelinePosts(posts, { keyword: maliciousKeyword });

    assert.strictEqual(filtered.length, 1);
    assert.strictEqual(filtered[0].id, 'p2');
  });

  test('T2_023: Post Lacking Text Message (Media-Only) handles null message safely', () => {
    const posts = [
      { id: 'p_null', creationTime: Date.now(), message: null, attachmentTitle: 'Beach Vacation Photo' },
      { id: 'p_empty', creationTime: Date.now(), message: '', attachmentTitle: 'Shared Reel' },
      { id: 'p_undefined', creationTime: Date.now() }
    ];

    // Search for 'beach' matching attachmentTitle fallback
    const matchBeach = filterTimelinePosts(posts, { keyword: 'beach' });
    assert.strictEqual(matchBeach.length, 1);
    assert.strictEqual(matchBeach[0].id, 'p_null');

    // Search for nonexistent string: 0 matches, 0 crashes
    const noMatch = filterTimelinePosts(posts, { keyword: 'xylophone' });
    assert.strictEqual(noMatch.length, 0);
  });

  test('T2_024: Zero Matches Found returns empty array with zero errors', () => {
    const posts = Array.from({ length: 50 }, (_, i) => ({
      id: `post_${i}`,
      creationTime: Date.now(),
      message: `Standard message number ${i}`
    }));

    const filtered = filterTimelinePosts(posts, { keyword: 'xylophone_nonexistent_token_9999' });

    assert.ok(Array.isArray(filtered));
    assert.strictEqual(filtered.length, 0, 'Must return empty array');
  });

  test('T2_025: Extremely Large Keyword String (2000 Chars) truncates or evaluates safely', () => {
    const posts = [
      { id: 'p1', creationTime: Date.now(), message: 'Quick status' }
    ];

    const giantKeyword = 'a'.repeat(2000);
    const start = Date.now();
    const filtered = filterTimelinePosts(posts, { keyword: giantKeyword });
    const elapsed = Date.now() - start;

    assert.ok(elapsed < 100, `Filtering took ${elapsed}ms, must be sub-100ms`);
    assert.strictEqual(filtered.length, 0);
  });

  // ----------------------------------------------------
  // F_R2_2: Bulk Delete Timeline Posts (T2_026 to T2_030)
  // ----------------------------------------------------

  test('T2_026: Already Deleted / Non-Existent Post ID handled as non-fatal ALREADY_DELETED', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const targets = ['post_deleted_9999', 'post_7002'];
    const executorFactory = (postId) => async () => {
      if (postId === 'post_deleted_9999') {
        return { success: false, status: 'ALREADY_DELETED', error: 'Story does not exist or was previously removed' };
      }
      return { success: true, deletedId: postId };
    };

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.POST_DELETE,
      targets,
      executorFactory,
      { stopOnError: false }
    );

    assert.strictEqual(results.length, 2);
    assert.strictEqual(results[0].result.status, 'ALREADY_DELETED');
    assert.strictEqual(results[1].success, true, 'Next post must proceed normally');
  });

  test('T2_027: Active Ad Boost / Promoted Post (Error 1404078) flagged as CANNOT_DELETE_BOOSTED', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const targets = ['post_boosted_101', 'post_7003'];
    const executorFactory = (postId) => async () => {
      if (postId === 'post_boosted_101') {
        return {
          success: false,
          status: 'CANNOT_DELETE_BOOSTED',
          error: 'Post cannot be deleted while boosted in an active ad campaign (1404078)'
        };
      }
      return { success: true, deletedId: postId };
    };

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.POST_DELETE,
      targets,
      executorFactory,
      { stopOnError: false }
    );

    assert.strictEqual(results.length, 2);
    assert.strictEqual(results[0].result.status, 'CANNOT_DELETE_BOOSTED');
    assert.strictEqual(results[1].success, true);
  });

  test('T2_028: User Cancellation of Safety Confirmation Prompt discards queue with 0 calls', async () => {
    let apiCallCount = 0;
    const targets = ['post_del_001', 'post_del_002', 'post_del_003'];
    const abortController = new AbortController();

    // User cancels the modal prompt before batch dispatch
    const userConfirmed = false;
    if (!userConfirmed) {
      abortController.abort();
    }

    const results = await runner.executeBatch(
      ACTION_TYPES.POST_DELETE,
      targets,
      (postId) => async () => {
        apiCallCount++;
        return client.deletePost(postId);
      },
      { abortSignal: abortController.signal }
    );

    assert.strictEqual(results.length, 0, 'Zero batch results when canceled');
    assert.strictEqual(apiCallCount, 0, 'Zero API requests should be sent when user cancels modal');
  });

  test('T2_029: HTTP 429 During Post Deletion Batch trips breaker and pauses remaining queue', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const posts = ['post_1', 'post_2', 'post_3', 'post_4', 'post_5'];
    const executorFactory = (target, idx) => async () => {
      if (idx === 2) {
        const err = new Error('HTTP 429 Too Many Requests');
        err.code = 429;
        throw err;
      }
      return { success: true, deletedId: target };
    };

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.POST_DELETE,
      posts,
      executorFactory,
      { stopOnError: true }
    );

    assert.strictEqual(results.length, 3, 'Batch must stop at post #3');
    assert.strictEqual(results[2].success, false);
    assert.strictEqual(circuitBreaker.getState(), CIRCUIT_BREAKER_STATES.OPEN);
  });

  test('T2_030: Malformed Post ID Parameters filters out invalid types', () => {
    const rawIds = [null, 12345, {}, '', '   ', 'post_clean_101', undefined, 'post_clean_102'];
    const sanitized = sanitizeTargetIds(rawIds);

    assert.strictEqual(sanitized.length, 2, 'Only non-empty strings must pass sanitation');
    assert.strictEqual(sanitized[0], 'post_clean_101');
    assert.strictEqual(sanitized[1], 'post_clean_102');
  });

  // ----------------------------------------------------
  // F_R2_3: Bulk Hide & Archive Posts (T2_031 to T2_035)
  // ----------------------------------------------------

  test('T2_031: Idempotent Hiding of Already Hidden Post succeeds without error', async () => {
    const postId = 'post_7001';
    const firstRes = await client.hidePost(postId);
    assert.strictEqual(firstRes.success, true);
    assert.strictEqual(firstRes.action, 'HIDE');

    // Second call is idempotent and succeeds safely
    const secondRes = await client.hidePost(postId);
    assert.strictEqual(secondRes.success, true);
    assert.strictEqual(secondRes.action, 'HIDE');
    assert.strictEqual(secondRes.storyId, postId);
  });

  test('T2_032: Pinned Post Hide Handling unpins post before hiding', async () => {
    const post = { id: 'post_pinned_99', isPinned: true };
    let unpinCalled = false;

    // Execute unpin mutation
    const unpinPost = async (id) => {
      unpinCalled = true;
      post.isPinned = false;
      return { success: true, id };
    };

    if (post.isPinned) {
      await unpinPost(post.id);
    }
    const result = await client.hidePost(post.id);

    assert.strictEqual(unpinCalled, true, 'Pinned post must be unpinned first');
    assert.strictEqual(post.isPinned, false, 'Post must be marked unpinned');
    assert.strictEqual(result.success, true);
    assert.strictEqual(result.action, 'HIDE');
  });

  test('T2_033: Archived Post Where Original Share Was Removed archives share container cleanly', async () => {
    const sharePostId = 'share_node_888';
    const res = await client.archivePost(sharePostId);
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.storyId, sharePostId);
    assert.strictEqual(res.action, 'ARCHIVE');
  });

  test('T2_034: Service Worker Termination During Long Batch persists state to resume via alarms', async () => {
    // Simulate checkpoint state persistence after post 5
    const batchState = {
      actionType: ACTION_TYPES.POST_HIDE,
      remainingTargets: ['post_6', 'post_7', 'post_8'],
      processedCount: 5,
      totalCount: 8
    };

    await chrome.storage.local.set({ activeCleanupBatch: batchState });

    // Verify stored state
    const stored = await chrome.storage.local.get('activeCleanupBatch');
    assert.ok(stored.activeCleanupBatch);
    assert.strictEqual(stored.activeCleanupBatch.remainingTargets.length, 3);
    assert.strictEqual(stored.activeCleanupBatch.remainingTargets[0], 'post_6');
  });

  test('T2_035: Invalid Action Specifier rejects unsupported actions with ValidationError', () => {
    assert.strictEqual(validateArchiveAction('hide'), 'HIDE');
    assert.strictEqual(validateArchiveAction('ARCHIVE'), 'ARCHIVE');

    assert.throws(
      () => validateArchiveAction('PURGE'),
      /ValidationError: Action must be 'HIDE' or 'ARCHIVE'/
    );
    assert.throws(
      () => validateArchiveAction('DESTROY'),
      /ValidationError: Action must be 'HIDE' or 'ARCHIVE'/
    );
  });

  // ----------------------------------------------------
  // F_R2_4: Bulk Delete Comments & Photos (T2_036 to T2_040)
  // ----------------------------------------------------

  test('T2_036: Comment on Locked or Restricted Thread marked as SKIPPED_LOCKED', async () => {
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const comments = ['c_locked_1', 'c_normal_2'];
    const executorFactory = (cId) => async () => {
      if (cId === 'c_locked_1') {
        return {
          success: false,
          status: 'SKIPPED_LOCKED',
          error: 'Comments are locked on this publication'
        };
      }
      return { success: true, commentId: cId };
    };

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.COMMENT_DELETE,
      comments,
      executorFactory,
      { stopOnError: false }
    );

    assert.strictEqual(results.length, 2);
    assert.strictEqual(results[0].result.status, 'SKIPPED_LOCKED');
    assert.strictEqual(results[1].success, true);
  });

  test('T2_037: Profile / Cover Photo Safeguard prevents accidental avatar deletion', async () => {
    const activeAvatarPhotoId = 'photo_current_avatar_001';
    const activeCoverPhotoId = 'photo_current_cover_002';

    const profile = {
      currentAvatarId: activeAvatarPhotoId,
      currentCoverId: activeCoverPhotoId
    };

    // 1. Verify domain guard function
    const avatarCheck = safePhotoDeleteGuard(activeAvatarPhotoId, profile);
    assert.strictEqual(avatarCheck.allowed, false);
    assert.match(avatarCheck.reason, /SAFETY_RESTRICTION/);

    const regularCheck = safePhotoDeleteGuard('photo_holiday_999', profile);
    assert.strictEqual(regularCheck.allowed, true);

    // 2. Verify client API execution through ActionRunner
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const runRes = await liveRunner.execute(
      ACTION_TYPES.PHOTO_DELETE,
      activeAvatarPhotoId,
      async () => {
        const check = safePhotoDeleteGuard(activeAvatarPhotoId, profile);
        if (!check.allowed) {
          const err = new Error(check.reason);
          err.code = 'PROTECTED_PROFILE_ASSET';
          throw err;
        }
        return client.executePhotoDelete(activeAvatarPhotoId);
      },
      { throwOnError: false }
    );
    assert.strictEqual(runRes.success, false);
    assert.match(runRes.error, /SAFETY_RESTRICTION/);
  });

  test('T2_038: Rapid Comment Deletion Spam Trigger enforced by minimum token-bucket delay', () => {
    // Bucket with capacity 5, refillRate 0.4 (1 token every 2.5s)
    const bucket = new TokenBucket({ capacity: 5, refillRate: 0.4, tokens: 0 });
    const consumeRes = bucket.tryConsume(1);

    assert.strictEqual(consumeRes.allowed, false);
    assert.ok(consumeRes.waitMs >= 2500, `Wait time must be at least 2500ms, got ${consumeRes.waitMs}ms`);
  });

  test('T2_039: Empty Comment ID Array returns zero completions with zero API calls', async () => {
    let apiCalls = 0;
    const deleteCommentApi = async (id) => {
      apiCalls++;
      return { success: true, id };
    };

    const results = await runner.executeBatch(
      ACTION_TYPES.COMMENT_DELETE,
      [],
      () => deleteCommentApi
    );

    assert.strictEqual(results.length, 0);
    assert.strictEqual(apiCalls, 0);
  });

  test('T2_040: Non-Latin & Emoji Comment Deletion preserves unicode without surrogate errors', async () => {
    const comments = [
      { id: 'c_vn', text: 'Chào bạn 👋, chúc ngày mới tốt lành!' },
      { id: 'c_emoji', text: '🔥🔥🎉🎉💯🚀' },
      { id: 'c_ar', text: 'صباح الخير' }
    ];

    const deletedLogs = [];
    for (const c of comments) {
      const res = await client.executeCommentDelete(c.id);
      assert.strictEqual(res.success, true);
      const logEntry = {
        id: c.id,
        preview: c.text.slice(0, 20),
        status: 'DELETED',
        timestamp: Date.now()
      };
      deletedLogs.push(logEntry);
    }

    assert.strictEqual(deletedLogs.length, 3);
    assert.strictEqual(deletedLogs[0].preview, 'Chào bạn 👋, chúc ng');
    assert.strictEqual(deletedLogs[1].preview, '🔥🔥🎉🎉💯🚀');
  });
});
