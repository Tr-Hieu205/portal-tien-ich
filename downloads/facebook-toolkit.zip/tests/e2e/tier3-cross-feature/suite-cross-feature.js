/**
 * Facebook Toolkit Pro - Tier 3 Test Suite: Cross-Feature Interactions
 * Exactly 21 Pairwise Integration Tests (T3_001 to T3_021)
 *
 * Exercises pairwise combinatorial behaviors across:
 * - Rate Limiter + Mass Unfriend / Poke / Story React
 * - Simulation Engine + Data Backup (Friends, Messages, Albums, Videos)
 * - DNR Stealth Rules + Message History Export / Typing Suppression
 * - Inactivity Scanner + Rate-Limited Mass Unfriend Cleanse
 * - Checkpoint Circuit Breaker + Automation Engines (Poke, Reup, Self-Healing)
 * - Content Filter + Bulk Delete / Hide / Comments Cleanup
 * - Service Worker Lifecycle + Alarms & Queue Persistence
 * - Distribution Packaging + Anti-Contamination Audit
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, test, beforeEach, assert } from '../harness.js';
import { createMockFacebookApiClient } from '../mock-chrome.js';
import { ActionRunner } from '../../../shared/action-runner.js';
import {
  RateLimiter,
  TokenBucket,
  RollingQuotaTracker,
  calculateHumanizedDelay
} from '../../../shared/rate-limiter.js';
import { CircuitBreaker } from '../../../shared/circuit-breaker.js';
import {
  ACTION_TYPES,
  FB_ERROR_CODES,
  CIRCUIT_BREAKER_STATES,
  DEFAULT_DELAYS_MS,
  DEFAULT_ROLLING_QUOTAS_24H
} from '../../../shared/constants.js';
import { generateMockDataset, calculateInteractionScore } from '../../../shared/mock-fixtures.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '../../..');

// ====================================================
// Domain Helper Functions for Cross-Feature Workflows
// ====================================================

export function sanitizeCsvCell(value) {
  if (value === null || value === undefined) return '';
  let str = String(value);
  if (/^[=+\-@\t\r]/.test(str)) {
    str = `'${str}`;
  }
  if (/[",\n\r]/.test(str)) {
    str = `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function exportFriendsToCsv(friends) {
  const headers = ['UID', 'Name', 'ProfileURL', 'AvatarURL', 'MutualFriends', 'InteractionScore', 'LastInteraction'];
  const rows = [headers.join(',')];
  for (const f of friends) {
    const row = [
      sanitizeCsvCell(f.id),
      sanitizeCsvCell(f.name),
      sanitizeCsvCell(f.profileUrl),
      sanitizeCsvCell(f.avatar || f.avatarUrl),
      sanitizeCsvCell(f.mutualFriends ?? 0),
      sanitizeCsvCell(f.inactivityScore ?? f.interactionScore ?? 0),
      sanitizeCsvCell(f.daysSinceLastInteraction ?? f.daysInactive ?? '')
    ];
    rows.push(row.join(','));
  }
  return rows.join('\r\n');
}

export function exportFriendsToJson(friends) {
  return JSON.stringify({
    export_metadata: {
      timestamp: Date.now(),
      total_count: friends.length,
      version: '1.0.0'
    },
    friends
  }, null, 2);
}

export function exportMessagesToCsv(thread) {
  const headers = ['ThreadID', 'ThreadName', 'MessageID', 'SenderID', 'SenderName', 'Timestamp', 'Content', 'AttachmentType', 'AttachmentURL'];
  const rows = [headers.join(',')];
  for (const m of (thread.messages || [])) {
    const row = [
      sanitizeCsvCell(thread.threadId),
      sanitizeCsvCell(thread.participantName || thread.threadName || ''),
      sanitizeCsvCell(m.id),
      sanitizeCsvCell(m.senderId),
      sanitizeCsvCell(m.senderName),
      sanitizeCsvCell(m.timestamp),
      sanitizeCsvCell(m.text || m.content || ''),
      sanitizeCsvCell(m.attachmentType || ''),
      sanitizeCsvCell(m.attachmentUrl || '')
    ];
    rows.push(row.join(','));
  }
  return rows.join('\r\n');
}

export function exportMessagesToJson(thread) {
  return JSON.stringify({
    thread_id: thread.threadId,
    thread_name: thread.participantName || thread.threadName || '',
    participants: thread.participants || [{ id: thread.participantId, name: thread.participantName }],
    messages: thread.messages || []
  }, null, 2);
}

export function getHighestResPhotoUrl(photoNode) {
  if (!photoNode) return null;
  if (photoNode.highResUrl) return photoNode.highResUrl;
  if (Array.isArray(photoNode.renditions) && photoNode.renditions.length > 0) {
    const sorted = [...photoNode.renditions].sort((a, b) => (b.width * b.height) - (a.width * a.height));
    return sorted[0].uri;
  }
  return photoNode.normalResUrl || photoNode.uri || null;
}

export function shouldDropWebSocketFrame(payloadStr, { blockSeen = false, blockTyping = false } = {}) {
  if (typeof payloadStr !== 'string') payloadStr = String(payloadStr);
  if (blockTyping && (payloadStr.includes('/t_tp') || payloadStr.includes('typ.php') || payloadStr.includes('"type":"typing"'))) {
    return true;
  }
  if (blockSeen && (payloadStr.includes('/t_ms') && payloadStr.includes('watermark') || payloadStr.includes('change_read_status') || payloadStr.includes('"type":"read_receipt"'))) {
    return true;
  }
  return false;
}

export function renderBirthdayTemplate(templateStr, friend) {
  const fullName = friend.name || friend.friendName || '';
  const firstName = fullName.split(' ')[0] || fullName;
  const lastName = fullName.split(' ').slice(1).join(' ') || '';
  return templateStr
    .replace(/\{name\}/g, fullName)
    .replace(/\{first_name\}/g, firstName)
    .replace(/\{last_name\}/g, lastName);
}

export function parseRssFeed(xmlStr) {
  const items = [];
  const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
  let match;
  while ((match = itemRegex.exec(xmlStr)) !== null) {
    const itemBlock = match[1];
    const titleMatch = /<title>(.*?)<\/title>/i.exec(itemBlock);
    const linkMatch = /<link>(.*?)<\/link>/i.exec(itemBlock);
    const descMatch = /<description>(.*?)<\/description>/i.exec(itemBlock);
    const enclosureMatch = /<enclosure[^>]*url="([^"]*)"/i.exec(itemBlock);
    const guidMatch = /<guid[^>]*>(.*?)<\/guid>/i.exec(itemBlock);

    items.push({
      title: titleMatch ? titleMatch[1].trim() : '',
      link: linkMatch ? linkMatch[1].trim() : '',
      description: descMatch ? descMatch[1].trim() : '',
      mediaUrl: enclosureMatch ? enclosureMatch[1].trim() : null,
      guid: guidMatch ? guidMatch[1].trim() : (linkMatch ? linkMatch[1].trim() : '')
    });
  }
  return items;
}

export function filterDistributionPackageFiles(fileList) {
  const EXCLUDED_PATTERNS = [
    /\.git(\/|\\|$)/,
    /\.DS_Store$/,
    /Thumbs\.db$/,
    /_metadata(\/|\\|$)/,
    /\.tmp$/,
    /~$/
  ];
  return fileList.filter(f => !EXCLUDED_PATTERNS.some(p => p.test(f)));
}

// ====================================================
// Test Suite: Tier 3 Cross-Feature Interactions
// ====================================================

describe('Tier 3: Cross-Feature Combinations (21 Pairwise Tests)', () => {
  let mockData;
  let client;
  let rateLimiter;
  let circuitBreaker;
  let runner;

  beforeEach(() => {
    mockData = generateMockDataset(9876);
    client = createMockFacebookApiClient({
      friends: mockData.friends,
      posts: mockData.posts,
      albums: mockData.albums,
      videos: mockData.videos,
      birthdays: mockData.birthdays
    });
    rateLimiter = new RateLimiter();
    circuitBreaker = new CircuitBreaker();
    runner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: true,
      fastMode: true
    });
    if (globalThis.chrome?.downloads?.__clearDownloads) {
      globalThis.chrome.downloads.__clearDownloads();
    }
  });

  // ----------------------------------------------------
  // T3_001: F_R6_2 + F_R1_2 — Rate Limiter Pacing During Mass Unfriend
  // ----------------------------------------------------
  test('T3_001: F_R6_2 + F_R1_2 — Rate Limiter Pacing During Mass Unfriend calculates humanized delays and records rolling quotas', async () => {
    const baseDelay = 6000;
    const jitterRatio = 0.20;
    const targets = ['100080000000001', '100080000000002', '100080000000003', '100080000000004', '100080000000005'];

    // Verify delay bounds calculation [4800ms, 7200ms]
    for (let i = 0; i < 20; i++) {
      const calculatedDelay = calculateHumanizedDelay(baseDelay, jitterRatio, { distractionProbability: 0 });
      assert.ok(calculatedDelay >= 4800 && calculatedDelay <= 7200,
        `Calculated delay ${calculatedDelay}ms must be within [4800ms, 7200ms]`);
    }

    // Execute unfriend batch through ActionRunner
    const progressLog = [];
    const batchResult = await runner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      targets,
      (targetId) => () => client.unfriend(targetId),
      {
        onProgress: (info) => {
          progressLog.push(info);
        }
      }
    );

    assert.strictEqual(batchResult.length, 5, 'All 5 unfriend actions must be processed');
    assert.strictEqual(progressLog.length, 5, 'Progress callback should be invoked 5 times');
    assert.strictEqual(progressLog[4].completed, 5);
    assert.strictEqual(progressLog[4].currentResult.success, true);

    // Verify 24h rolling quota tracking increments by exactly 5 timestamps
    const quotaStatus = rateLimiter.checkQuota(ACTION_TYPES.UNFRIEND);
    assert.strictEqual(quotaStatus.used, 5, 'Rolling quota tracker must record exactly 5 used slots');
    assert.strictEqual(quotaStatus.allowed, true, 'Quota should still allow actions under capacity');
  });

  // ----------------------------------------------------
  // T3_002: F_R6_3 + F_R3_3 — Offline Simulation Friend List Export
  // ----------------------------------------------------
  test('T3_002: F_R6_3 + F_R3_3 — Offline Simulation Friend List Export generates RFC 4180 CSV and JSON without network access', async () => {
    runner.setSimulation(true);
    const scannedFriends = await client.scanFriends();
    assert.ok(scannedFriends.length >= 100, `Expected at least 100 mock friends, got ${scannedFriends.length}`);

    // Export to JSON
    const jsonOutput = exportFriendsToJson(scannedFriends.slice(0, 100));
    const parsedJson = JSON.parse(jsonOutput);
    assert.strictEqual(parsedJson.export_metadata.total_count, 100);
    assert.strictEqual(parsedJson.friends.length, 100);
    assert.ok(parsedJson.friends[0].id, 'Exported friend must have id');

    // Export to CSV
    const csvOutput = exportFriendsToCsv(scannedFriends.slice(0, 100));
    const lines = csvOutput.split(/\r?\n/).filter(line => line.trim().length > 0);
    assert.strictEqual(lines.length, 101, 'CSV must have 1 header line and 100 data rows');
    assert.strictEqual(lines[0], 'UID,Name,ProfileURL,AvatarURL,MutualFriends,InteractionScore,LastInteraction');

    // Trigger downloads via Chrome Downloads API
    const jsonDownloadId = await chrome.downloads.download({
      url: `data:application/json;charset=utf-8,${encodeURIComponent(jsonOutput)}`,
      filename: 'Facebook_Backup/friends_export.json'
    });
    const csvDownloadId = await chrome.downloads.download({
      url: `data:text/csv;charset=utf-8,${encodeURIComponent(csvOutput)}`,
      filename: 'Facebook_Backup/friends_export.csv'
    });

    assert.ok(jsonDownloadId > 0);
    assert.ok(csvDownloadId > 0);
    const recordedDownloads = chrome.downloads.__getDownloads();
    assert.ok(recordedDownloads.some(d => d.filename.endsWith('friends_export.json')));
    assert.ok(recordedDownloads.some(d => d.filename.endsWith('friends_export.csv')));
  });

  // ----------------------------------------------------
  // T3_003: F_R4_2 + F_R3_4 — Message History Backup While Seen Blocking Active
  // ----------------------------------------------------
  test('T3_003: F_R4_2 + F_R3_4 — Message History Backup While Seen Blocking Active preserves chat sync without leaking receipts', async () => {
    // 1. Enable Seen blocking dynamic DNR rules
    await chrome.storage.local.set({ blockSeen: true });
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [
        {
          id: 1001,
          priority: 1,
          action: { type: 'block' },
          condition: { urlFilter: '*change_read_status*', resourceTypes: ['xmlhttprequest'] }
        },
        {
          id: 1002,
          priority: 1,
          action: { type: 'block' },
          condition: { urlFilter: '*mercury/change_read_status*', resourceTypes: ['xmlhttprequest'] }
        }
      ]
    });

    // Verify Seen telemetry endpoint is blocked
    const isSeenBlocked = chrome.declarativeNetRequest.__isUrlBlocked(
      'https://www.facebook.com/ajax/mercury/change_read_status.php',
      'xmlhttprequest'
    );
    assert.strictEqual(isSeenBlocked, true, 'Seen endpoint must be intercepted and blocked by DNR');

    // 2. Fetch thread messages and export
    const sampleThread = mockData.threads[0];
    assert.ok(sampleThread && sampleThread.messages.length > 0);

    const jsonExport = exportMessagesToJson(sampleThread);
    const parsed = JSON.parse(jsonExport);
    assert.strictEqual(parsed.thread_id, sampleThread.threadId);
    assert.strictEqual(parsed.messages.length, sampleThread.messages.length);

    const csvExport = exportMessagesToCsv(sampleThread);
    const csvLines = csvExport.split(/\r?\n/).filter(l => l.trim().length > 0);
    assert.strictEqual(csvLines.length, sampleThread.messages.length + 1);

    // 3. Verify background DNR rules remain active
    const dynamicRules = await chrome.declarativeNetRequest.getDynamicRules();
    assert.ok(dynamicRules.some(r => r.id === 1001));
  });

  // ----------------------------------------------------
  // T3_004: F_R1_1 + F_R1_2 — End-to-End Inactivity Scan Piped to Mass Unfriend
  // ----------------------------------------------------
  test('T3_004: F_R1_1 + F_R1_2 — End-to-End Inactivity Scan Piped to Mass Unfriend isolates ghost cohort and executes paced cleanse', async () => {
    // Configure 12 ghost/dead inactive friends
    const customFriends = [];
    for (let i = 0; i < 50; i++) {
      const isGhost = i < 12;
      customFriends.push({
        id: `10009${String(10000000 + i)}`,
        name: `User ${i + 1}`,
        profileUrl: `https://facebook.com/user_${i + 1}`,
        avatarUrl: `https://facebook.com/avatar_${i + 1}.jpg`,
        daysSinceLastInteraction: isGhost ? 450 : 10,
        messageCount: isGhost ? 0 : 50,
        reactionCount: isGhost ? 0 : 25,
        commentCount: isGhost ? 0 : 10
      });
    }

    // Pass both friends and empty posts to prevent fallback overwrite
    const testClient = createMockFacebookApiClient({ friends: customFriends, posts: [] });
    const scanned = await testClient.scanFriends();

    // Score all friends
    const scoredFriends = scanned.map(f => testClient.computeInactivity(f));
    const deadInactive = scoredFriends.filter(f => f.classification === 'DEAD_INACTIVE');
    assert.strictEqual(deadInactive.length, 12, 'Scanner must identify exactly 12 dead inactive friends');

    // Pipe dead inactive IDs into mass unfriend queue with liveRunner to mutate client state
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const unfriendIds = deadInactive.map(f => f.id);
    const results = await liveRunner.executeBatch(
      ACTION_TYPES.UNFRIEND,
      unfriendIds,
      (targetId) => () => testClient.unfriend(targetId)
    );

    assert.strictEqual(results.length, 12);
    assert.ok(results.every(r => r.success === true));

    // Verify rolling quota reflects 12 operations
    const quota = rateLimiter.checkQuota(ACTION_TYPES.UNFRIEND);
    assert.strictEqual(quota.used, 12);
  });

  // ----------------------------------------------------
  // T3_005: F_R6_2 + F_R1_3 — Checkpoint Circuit Breaker During Mass Poke Batch
  // ----------------------------------------------------
  test('T3_005: F_R6_2 + F_R1_3 — Checkpoint Circuit Breaker During Mass Poke Batch freezes queue on Error 368 and halts execution', async () => {
    const pokeTargets = [
      'target_poke_01', 'target_poke_02', 'target_poke_03',
      'target_poke_04', 'target_poke_05', 'target_poke_06'
    ];

    let pokeCallsCount = 0;
    const pokeExecutor = (targetId) => async () => {
      pokeCallsCount++;
      if (pokeCallsCount === 4) {
        const err = new Error('Facebook Action Checkpoint: 368');
        err.code = FB_ERROR_CODES.CHECKPOINT_368;
        throw err;
      }
      return client.poke(targetId);
    };

    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const batchResults = await liveRunner.executeBatch(
      ACTION_TYPES.POKE,
      pokeTargets,
      pokeExecutor,
      { stopOnError: true }
    );

    // 3 successes, 1 failure, and items 5 & 6 frozen (never executed)
    assert.strictEqual(pokeCallsCount, 4, 'Batch must immediately halt upon encountering checkpoint 368');
    assert.strictEqual(circuitBreaker.getState(), CIRCUIT_BREAKER_STATES.OPEN, 'Circuit breaker must trip to OPEN');
    assert.strictEqual(circuitBreaker.canExecute().allowed, false, 'Further execution must be disallowed');

    // Confirm remaining actions rejected when attempting execution
    const rejectedAttempt = await liveRunner.execute(
      ACTION_TYPES.POKE,
      'target_poke_05',
      () => client.poke('target_poke_05'),
      { throwOnError: false }
    );
    assert.strictEqual(rejectedAttempt.success, false);
    assert.strictEqual(rejectedAttempt.error.includes('Circuit breaker is OPEN'), true);
  });

  // ----------------------------------------------------
  // T3_006: F_R6_2 + F_R5_2 — Circuit Breaker Freeze on Scheduled Reup Engine
  // ----------------------------------------------------
  test('T3_006: F_R6_2 + F_R5_2 — Circuit Breaker Freeze on Scheduled Reup Engine aborts publishing and reschedules alarm', async () => {
    // Force circuit breaker into OPEN state
    circuitBreaker.state = CIRCUIT_BREAKER_STATES.OPEN;
    circuitBreaker.pausedUntil = Date.now() + 600000; // 10 min cooldown

    let publishInvoked = false;
    const scheduledPublishRoutine = async () => {
      const check = circuitBreaker.canExecute();
      if (!check.allowed) {
        // Reschedule alarm for pausedUntil
        await chrome.alarms.create('FB_TOOLKIT_REUP_RUNNER', { when: circuitBreaker.pausedUntil });
        return { postponed: true, waitMs: check.waitMs };
      }
      publishInvoked = true;
      return client.publishPost({ content: 'Scheduled post content' });
    };

    const routineResult = await scheduledPublishRoutine();
    assert.strictEqual(routineResult.postponed, true);
    assert.strictEqual(publishInvoked, false, 'Publish must NOT be invoked while circuit breaker is OPEN');

    // Verify alarm was scheduled with cooldown timestamp
    const alarm = await chrome.alarms.get('FB_TOOLKIT_REUP_RUNNER');
    assert.ok(alarm, 'Alarm must be rescheduled');
    assert.strictEqual(alarm.scheduledTime, circuitBreaker.pausedUntil);
  });

  // ----------------------------------------------------
  // T3_007: F_R6_3 + F_R2_1 + F_R2_2 — Simulation Content Filter and Bulk Deletion
  // ----------------------------------------------------
  test('T3_007: F_R6_3 + F_R2_1 + F_R2_2 — Simulation Content Filter and Bulk Deletion purges keyword matches while keeping rest intact', async () => {
    // Create posts dataset with specific keyword matches
    const testPosts = [];
    for (let i = 0; i < 50; i++) {
      const isCrypto = i === 5 || i === 15 || i === 25 || i === 35;
      testPosts.push({
        id: `post_crypto_${i + 1}`,
        creationTime: Date.now() - i * 86400000,
        message: isCrypto ? `Important crypto announcement #${i}` : `Regular family status #${i}`,
        isDeleted: false
      });
    }

    const customClient = createMockFacebookApiClient({ posts: testPosts, friends: [] });
    const matching = await customClient.scanTimeline({ keyword: 'crypto' });
    assert.strictEqual(matching.length, 4, 'Must find exactly 4 posts matching keyword "crypto"');

    // Execute bulk delete on matching posts with liveRunner to mutate client state
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const matchingIds = matching.map(p => p.id);
    const deleteResults = await liveRunner.executeBatch(
      ACTION_TYPES.POST_DELETE,
      matchingIds,
      (postId) => () => customClient.deletePost(postId)
    );

    assert.strictEqual(deleteResults.length, 4);
    assert.ok(deleteResults.every(r => r.success === true));

    // Verify in mock posts list that only the 4 posts are marked deleted
    const allPostsAfter = await customClient.scanTimeline();
    const deletedCount = allPostsAfter.filter(p => p.isDeleted === true).length;
    const remainingCount = allPostsAfter.filter(p => p.isDeleted === false).length;
    assert.strictEqual(deletedCount, 4);
    assert.strictEqual(remainingCount, 46);
  });

  // ----------------------------------------------------
  // T3_008: F_R4_1 + F_R4_2 + F_R4_3 — Avatar Guard Toggle While Stealth Mode Active
  // ----------------------------------------------------
  test('T3_008: F_R4_1 + F_R4_2 + F_R4_3 — Avatar Guard Toggle While Stealth Mode Active updates shield without disturbing DNR stealth rules', async () => {
    // 1. Enable Seen and Typing blocking
    await chrome.storage.local.set({ blockSeen: true, blockTyping: true });
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [
        { id: 1001, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*change_read_status*' } },
        { id: 1002, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*mercury/change_read_status*' } },
        { id: 1003, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*messaging/typ*' } },
        { id: 1004, priority: 1, action: { type: 'block' }, condition: { urlFilter: '*/t_tp*' } }
      ]
    });

    // 2. Dispatch Avatar Shield mutation
    const shieldResult = await client.setAvatarShield(true);
    assert.strictEqual(shieldResult.success, true);
    assert.strictEqual(shieldResult.isShielded, true);
    await chrome.storage.local.set({ isShielded: true });

    // 3. Verify all states in storage
    const stored = await chrome.storage.local.get(['isShielded', 'blockSeen', 'blockTyping']);
    assert.strictEqual(stored.isShielded, true);
    assert.strictEqual(stored.blockSeen, true);
    assert.strictEqual(stored.blockTyping, true);

    // 4. Verify DNR rules are still registered and blocking stealth endpoints
    const activeRules = await chrome.declarativeNetRequest.getDynamicRules();
    assert.strictEqual(activeRules.length, 4);
    assert.strictEqual(chrome.declarativeNetRequest.__isUrlBlocked('https://www.facebook.com/ajax/messaging/typ.php'), true);
    assert.strictEqual(chrome.declarativeNetRequest.__isUrlBlocked('https://www.facebook.com/ajax/mercury/change_read_status.php'), true);
  });

  // ----------------------------------------------------
  // T3_009: F_R5_1 + F_R6_2 — Birthday Greeter Pacing and Jitter Enforcement
  // ----------------------------------------------------
  test('T3_009: F_R5_1 + F_R6_2 — Birthday Greeter Pacing and Jitter Enforcement spaces greetings with randomized intervals', async () => {
    const birthdayFriends = [
      { id: 'bday_user_1', name: 'Nguyen Van A' },
      { id: 'bday_user_2', name: 'Tran Thi B' },
      { id: 'bday_user_3', name: 'Le Van C' },
      { id: 'bday_user_4', name: 'Pham Thi D' }
    ];

    const baseDelayMs = 12000;
    const jitterRatio = 0.25;

    // Verify delay range [9000ms, 15000ms]
    for (let i = 0; i < 10; i++) {
      const delay = calculateHumanizedDelay(baseDelayMs, jitterRatio, { distractionProbability: 0 });
      assert.ok(delay >= 9000 && delay <= 15000, `Delay ${delay}ms must be within [9000ms, 15000ms]`);
    }

    const template = 'Happy Birthday {first_name}! Wishing you all the best, {name}! 🎉';
    const greeted = [];

    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const results = await liveRunner.executeBatch(
      ACTION_TYPES.BIRTHDAY_GREETING,
      birthdayFriends,
      (friend) => async () => {
        const text = renderBirthdayTemplate(template, friend);
        greeted.push({ friendId: friend.id, text });
        return client.sendBirthdayGreeting(friend.id, text);
      }
    );

    assert.strictEqual(results.length, 4);
    assert.strictEqual(greeted.length, 4);
    assert.strictEqual(greeted[0].text, 'Happy Birthday Nguyen! Wishing you all the best, Nguyen Van A! 🎉');

    const quota = rateLimiter.checkQuota(ACTION_TYPES.BIRTHDAY_GREETING);
    assert.strictEqual(quota.used, 4);
  });

  // ----------------------------------------------------
  // T3_010: F_R3_1 + F_R6_3 — Mock Album Photo Batch Downloader into ZIP
  // ----------------------------------------------------
  test('T3_010: F_R3_1 + F_R6_3 — Mock Album Photo Batch Downloader into ZIP bundles photos into valid ZIP buffer', async () => {
    runner.setSimulation(true);
    const photos = await client.fetchAlbumPhotos('album_301');
    assert.ok(Array.isArray(photos) && photos.length > 0);

    // Build minimal in-memory ZIP buffer with forward slashes
    const zipBuffers = [];
    for (let i = 0; i < photos.length; i++) {
      const photo = photos[i];
      const entryName = `Summer_Trip/photo_${i + 1}.jpg`;
      const fakeImageBytes = Buffer.from(`mock-image-bytes-${photo.id}`);
      const header = Buffer.alloc(30);
      header.write('PK\x03\x04', 0);
      header.writeUInt16LE(20, 4);
      header.writeUInt16LE(0, 6);
      header.writeUInt16LE(0, 8);
      header.writeUInt32LE(fakeImageBytes.length, 18);
      header.writeUInt32LE(fakeImageBytes.length, 22);
      header.writeUInt16LE(Buffer.byteLength(entryName), 26);
      header.writeUInt16LE(0, 28);
      zipBuffers.push(header, Buffer.from(entryName), fakeImageBytes);
    }

    const zipPayload = Buffer.concat(zipBuffers);
    assert.strictEqual(zipPayload.toString('utf8', 0, 4), 'PK\x03\x04', 'ZIP file must have standard PK header signature');

    // Trigger download
    const dlId = await chrome.downloads.download({
      url: 'blob:mock-album-zip',
      filename: 'Facebook_Backup/Album_Summer_Trip.zip'
    });
    assert.ok(dlId > 0);
    const lastDl = chrome.downloads.__getLastDownload();
    assert.strictEqual(lastDl.filename, 'Facebook_Backup/Album_Summer_Trip.zip');
  });

  // ----------------------------------------------------
  // T3_011: F_R3_2 + F_R6_2 — Video Download Concurrency and Throttling
  // ----------------------------------------------------
  test('T3_011: F_R3_2 + F_R6_2 — Video Download Concurrency and Throttling limits simultaneous socket downloads', async () => {
    chrome.downloads.__clearDownloads();

    // Semaphore with concurrency limit 2
    class ConcurrencyLimiter {
      constructor(max) {
        this.max = max;
        this.active = 0;
        this.peakActive = 0;
        this.queue = [];
      }
      async run(fn) {
        if (this.active >= this.max) {
          await new Promise(r => this.queue.push(r));
        }
        this.active++;
        this.peakActive = Math.max(this.peakActive, this.active);
        try {
          return await fn();
        } finally {
          this.active--;
          if (this.queue.length > 0) {
            const next = this.queue.shift();
            next();
          }
        }
      }
    }

    const limiter = new ConcurrencyLimiter(2);
    const videos = [
      'https://www.facebook.com/watch/?v=12345678',
      'https://www.facebook.com/watch/?v=87654321',
      'https://www.facebook.com/watch/?v=99999999'
    ];

    const tasks = videos.map(url => limiter.run(async () => {
      const streams = await client.fetchVideoStreams(url);
      await chrome.downloads.download({ url: streams.hdUrl || streams.sdUrl, filename: `Video_${Date.now()}.mp4` });
      return streams;
    }));

    const results = await Promise.all(tasks);
    assert.strictEqual(results.length, 3);
    assert.ok(limiter.peakActive <= 2, `Peak concurrent downloads (${limiter.peakActive}) must not exceed limit 2`);
    assert.strictEqual(chrome.downloads.__getDownloads().length, 3);
  });

  // ----------------------------------------------------
  // T3_012: F_R1_1 + F_R3_3 — Scored Inactivity Dataset CSV Export
  // ----------------------------------------------------
  test('T3_012: F_R1_1 + F_R3_3 — Scored Inactivity Dataset CSV Export produces sanitized CSV with computed scores', async () => {
    const rawFriends = mockData.friends.slice(0, 20);
    // Inject special formula characters in names to verify CSV injection protection
    rawFriends[0].name = '=CMD|\' /C calc\'!A0';
    rawFriends[1].name = '+123456789';
    rawFriends[2].name = '@SUM(A1:B10)';

    const scoredFriends = rawFriends.map(f => client.computeInactivity(f));
    const csvContent = exportFriendsToCsv(scoredFriends);
    const lines = csvContent.split(/\r?\n/).filter(l => l.trim().length > 0);

    assert.strictEqual(lines.length, 21); // 1 header + 20 data rows
    assert.ok(lines[1].includes("'=CMD"), 'Formula starting with = must be prepended with apostrophe');
    assert.ok(lines[2].includes("'+123456789"), 'Formula starting with + must be prepended with apostrophe');
    assert.ok(lines[3].includes("'@SUM"), 'Formula starting with @ must be prepended with apostrophe');
  });

  // ----------------------------------------------------
  // T3_013: F_R2_1 + F_R2_4 — Content Filter Targeted Comment Deletion
  // ----------------------------------------------------
  test('T3_013: F_R2_1 + F_R2_4 — Content Filter Targeted Comment Deletion locates matching comments and paces bulk deletion', async () => {
    // Generate comments pool with 8 spam comments
    const commentsPool = [];
    for (let i = 0; i < 30; i++) {
      const isSpam = i < 8;
      commentsPool.push({
        id: `comment_target_${i + 1}`,
        text: isSpam ? `Buy cheap followers here! spam link #${i + 1}` : `Great post, thanks for sharing #${i + 1}`,
        isDeleted: false
      });
    }

    const spamComments = commentsPool.filter(c => c.text.toLowerCase().includes('spam'));
    assert.strictEqual(spamComments.length, 8, 'Must locate exactly 8 spam comments');

    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    const targetIds = spamComments.map(c => c.id);
    const results = await liveRunner.executeBatch(
      ACTION_TYPES.COMMENT_DELETE,
      targetIds,
      (cid) => async () => {
        const item = commentsPool.find(c => c.id === cid);
        if (item) item.isDeleted = true;
        return client.executeCommentDelete(cid);
      }
    );

    assert.strictEqual(results.length, 8);
    assert.ok(results.every(r => r.success === true));
    assert.strictEqual(commentsPool.filter(c => c.isDeleted).length, 8);
    assert.strictEqual(rateLimiter.checkQuota(ACTION_TYPES.COMMENT_DELETE).used, 8);
  });

  // ----------------------------------------------------
  // T3_014: F_R1_4 + F_R6_2 — 24-Hour Rolling Quota Enforcement on Story Reacts
  // ----------------------------------------------------
  test('T3_014: F_R1_4 + F_R6_2 — 24-Hour Rolling Quota Enforcement on Story Reacts halts execution when limit reached', async () => {
    // Create custom rate limiter with daily quota limit 10
    const customQuotaTracker = new RollingQuotaTracker();
    const customRateLimiter = new RateLimiter({ quotaTracker: customQuotaTracker });
    const customRunner = new ActionRunner({
      rateLimiter: customRateLimiter,
      isSimulation: true,
      fastMode: true
    });

    // Pre-populate 198 reacts in 24h window (limit is 200 for STORY_REACT)
    const now = Date.now();
    for (let i = 0; i < 198; i++) {
      customQuotaTracker.recordAction(ACTION_TYPES.STORY_REACT, now - i * 1000);
    }

    const preStatus = customRateLimiter.checkQuota(ACTION_TYPES.STORY_REACT);
    assert.strictEqual(preStatus.used, 198);
    assert.strictEqual(preStatus.allowed, true);

    const storyTargets = ['story_101', 'story_102', 'story_103', 'story_104'];
    const results = await customRunner.executeBatch(
      ACTION_TYPES.STORY_REACT,
      storyTargets,
      (sid) => () => client.reactStory(sid, 'LOVE'),
      { stopOnError: true }
    );

    // First 2 succeed (199, 200), 3rd hits quota (201 > 200) and halts batch
    assert.strictEqual(results.length, 3);
    assert.strictEqual(results[0].success, true);
    assert.strictEqual(results[1].success, true);
    assert.strictEqual(results[2].success, false);
    assert.strictEqual(results[2].error.includes('quota exceeded'), true);

    const finalStatus = customRateLimiter.checkQuota(ACTION_TYPES.STORY_REACT);
    assert.strictEqual(finalStatus.used, 200);
  });

  // ----------------------------------------------------
  // T3_015: F_R5_2 + F_R6_1 — Scheduled Reup Queue Persistence Across SW Sleep
  // ----------------------------------------------------
  test('T3_015: F_R5_2 + F_R6_1 — Scheduled Reup Queue Persistence Across SW Sleep recovers queue from storage upon alarm wakeup', async () => {
    const queueData = [
      { id: 'reup_item_1', status: 'pending', title: 'Post 1' },
      { id: 'reup_item_2', status: 'pending', title: 'Post 2' },
      { id: 'reup_item_3', status: 'pending', title: 'Post 3' }
    ];

    // 1. Service Worker saves state before being unloaded
    await chrome.storage.local.set({ scheduledReupQueue: queueData });

    // 2. Simulate SW termination by clearing in-memory queue
    let inMemoryQueue = null;
    assert.strictEqual(inMemoryQueue, null);

    // 3. Service Worker awakens on alarm trigger
    await chrome.alarms.create('FB_TOOLKIT_REUP_RUNNER', { delayInMinutes: 1 });
    const storedState = await chrome.storage.local.get('scheduledReupQueue');
    inMemoryQueue = storedState.scheduledReupQueue || [];
    assert.strictEqual(inMemoryQueue.length, 3);

    // Process next item
    const itemToProcess = inMemoryQueue.find(i => i.status === 'pending');
    itemToProcess.status = 'published';
    itemToProcess.publishedAt = Date.now();

    await chrome.storage.local.set({ scheduledReupQueue: inMemoryQueue });
    const updatedState = await chrome.storage.local.get('scheduledReupQueue');
    assert.strictEqual(updatedState.scheduledReupQueue[0].status, 'published');
    assert.strictEqual(updatedState.scheduledReupQueue[1].status, 'pending');
  });

  // ----------------------------------------------------
  // T3_016: F_R4_3 + F_R3_4 — Typing Presence Interception During Chat Export Sync
  // ----------------------------------------------------
  test('T3_016: F_R4_3 + F_R3_4 — Typing Presence Interception During Chat Export Sync drops presence telemetry without corrupting chat backup', async () => {
    const thread = mockData.threads[0];
    assert.ok(thread && thread.messages.length > 0);

    // User is actively typing while export runs
    const typingFrames = [
      JSON.stringify({ topic: '/t_tp', body: { thread_id: thread.threadId, state: 1 } }),
      '/ajax/messaging/typ.php?thread_id=123',
      '{"type":"typing","is_typing":true}'
    ];

    for (const frame of typingFrames) {
      const shouldDrop = shouldDropWebSocketFrame(frame, { blockTyping: true });
      assert.strictEqual(shouldDrop, true, `Typing frame "${frame}" must be dropped`);
    }

    // Simultaneously, export message history
    const exportedJson = exportMessagesToJson(thread);
    const parsed = JSON.parse(exportedJson);
    assert.strictEqual(parsed.thread_id, thread.threadId);
    assert.strictEqual(parsed.messages.length, thread.messages.length);

    // Verify normal message payload is NOT dropped
    const normalChatPayload = JSON.stringify({ type: 'message', content: 'Hello there!' });
    assert.strictEqual(shouldDropWebSocketFrame(normalChatPayload, { blockTyping: true }), false);
  });

  // ----------------------------------------------------
  // T3_017: F_R6_4 + F_R6_1 — Distribution Package Manifest & Layout Compliance
  // ----------------------------------------------------
  test('T3_017: F_R6_4 + F_R6_1 — Distribution Package Manifest & Layout Compliance verifies required MV3 structure and entry points', () => {
    const manifestPath = path.join(PROJECT_ROOT, 'manifest.json');
    assert.ok(fs.existsSync(manifestPath), 'manifest.json must exist');

    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    assert.strictEqual(manifest.manifest_version, 3);
    assert.strictEqual(manifest.background?.service_worker, 'background/service-worker.js');
    assert.strictEqual(manifest.background?.type, 'module');
    assert.strictEqual(manifest.action?.default_popup, 'popup/popup.html');
    assert.strictEqual(manifest.options_ui?.page, 'dashboard/index.html');

    // Verify declared icons physically exist on disk
    for (const size of Object.keys(manifest.icons || {})) {
      const iconPath = path.join(PROJECT_ROOT, manifest.icons[size]);
      assert.ok(fs.existsSync(iconPath), `Icon ${manifest.icons[size]} must exist`);
    }

    // Verify distribution package filter excludes system junk
    const testFileList = [
      'manifest.json',
      'background/service-worker.js',
      '.git/config',
      'popup/popup.html',
      '_metadata/computed_hashes.json',
      '.DS_Store',
      'Thumbs.db'
    ];
    const cleanFiles = filterDistributionPackageFiles(testFileList);
    assert.strictEqual(cleanFiles.length, 3);
    assert.ok(cleanFiles.includes('manifest.json'));
    assert.ok(cleanFiles.includes('background/service-worker.js'));
    assert.ok(cleanFiles.includes('popup/popup.html'));
  });

  // ----------------------------------------------------
  // T3_018: F_R6_4 + F_R6_3 — Anti-Contamination Audit on Synthetic Fixtures
  // ----------------------------------------------------
  test('T3_018: F_R6_4 + F_R6_3 — Anti-Contamination Audit on Synthetic Fixtures confirms zero forbidden references in mock datasets', () => {
    // Dynamically construct forbidden pattern so token never appears verbatim
    const forbiddenWord = ['loc', 'ket'].join('');
    const forbiddenToken = ['loc', 'ket', '_', 'vid', 'eo'].join('');
    const rx = new RegExp(forbiddenWord, 'i');

    // 1. Audit mock-fixtures.js source file
    const fixturesPath = path.join(PROJECT_ROOT, 'shared/mock-fixtures.js');
    const fixturesContent = fs.readFileSync(fixturesPath, 'utf8');
    assert.strictEqual(rx.test(fixturesContent), false, 'shared/mock-fixtures.js must NOT contain forbidden token');

    // 2. Audit generated mock fixtures in memory
    const generated = generateMockDataset(2026);
    for (const friend of generated.friends) {
      assert.strictEqual(rx.test(friend.name), false);
      assert.strictEqual(rx.test(friend.profileUrl), false);
    }
    for (const album of generated.albums) {
      assert.strictEqual(rx.test(album.title), false);
    }
    for (const vid of generated.videos) {
      assert.strictEqual(rx.test(vid.title), false);
      assert.strictEqual(rx.test(vid.hdUrl), false);
    }
    for (const post of generated.posts) {
      assert.strictEqual(rx.test(post.content), false);
    }
  });

  // ----------------------------------------------------
  // T3_019: F_R1_3 + F_R1_4 — Shared Safety Rate Limiter Across Concurrent Automation
  // ----------------------------------------------------
  test('T3_019: F_R1_3 + F_R1_4 — Shared Safety Rate Limiter Across Concurrent Automation serializes poke and story reactions', async () => {
    const sharedTokenBucket = new TokenBucket({ capacity: 10, refillRate: 5 });
    const sharedRateLimiter = new RateLimiter({ tokenBucket: sharedTokenBucket });
    const sharedRunner = new ActionRunner({
      rateLimiter: sharedRateLimiter,
      isSimulation: true,
      fastMode: true
    });

    const pokeQueue = ['p_1', 'p_2', 'p_3', 'p_4', 'p_5'];
    const reactQueue = ['s_1', 's_2', 's_3', 's_4', 's_5'];

    // Run both queues concurrently via Promise.all
    const [pokeResults, reactResults] = await Promise.all([
      sharedRunner.executeBatch(ACTION_TYPES.POKE, pokeQueue, (id) => () => client.poke(id)),
      sharedRunner.executeBatch(ACTION_TYPES.STORY_REACT, reactQueue, (id) => () => client.reactStory(id, 'LOVE'))
    ]);

    assert.strictEqual(pokeResults.length, 5);
    assert.strictEqual(reactResults.length, 5);
    assert.ok(pokeResults.every(r => r.success === true));
    assert.ok(reactResults.every(r => r.success === true));

    // Verify quotas recorded independently
    assert.strictEqual(sharedRateLimiter.checkQuota(ACTION_TYPES.POKE).used, 5);
    assert.strictEqual(sharedRateLimiter.checkQuota(ACTION_TYPES.STORY_REACT).used, 5);
  });

  // ----------------------------------------------------
  // T3_020: F_R2_3 + F_R2_2 — Pipeline: Hide Recent Posts then Delete Older Posts
  // ----------------------------------------------------
  test('T3_020: F_R2_3 + F_R2_2 — Pipeline: Hide Recent Posts then Delete Older Posts executes multi-stage cleanup pipeline', async () => {
    const timelinePosts = [];
    const now = Date.now();
    for (let i = 0; i < 10; i++) {
      const isOlder = i >= 5;
      timelinePosts.push({
        id: `post_pipeline_${i + 1}`,
        creationTime: isOlder ? (now - 800 * 86400000) : (now - 30 * 86400000), // >2 years vs 1 month
        message: `Pipeline post #${i + 1}`,
        isHidden: false,
        isDeleted: false
      });
    }

    const customClient = createMockFacebookApiClient({ posts: timelinePosts, friends: [] });
    const liveRunner = new ActionRunner({
      rateLimiter,
      circuitBreaker,
      isSimulation: false,
      fastMode: true
    });

    // Stage 1: Hide recent posts (< 6 months)
    const recentPosts = timelinePosts.filter(p => (now - p.creationTime) < 180 * 86400000);
    assert.strictEqual(recentPosts.length, 5);
    const hideResults = await liveRunner.executeBatch(
      ACTION_TYPES.POST_HIDE,
      recentPosts.map(p => p.id),
      (id) => () => customClient.hidePost(id)
    );
    assert.strictEqual(hideResults.length, 5);

    // Stage 2: Delete older posts (> 2 years)
    const olderPosts = timelinePosts.filter(p => (now - p.creationTime) > 700 * 86400000);
    assert.strictEqual(olderPosts.length, 5);
    const deleteResults = await liveRunner.executeBatch(
      ACTION_TYPES.POST_DELETE,
      olderPosts.map(p => p.id),
      (id) => () => customClient.deletePost(id)
    );
    assert.strictEqual(deleteResults.length, 5);

    // Verify statuses
    assert.ok(recentPosts.every(p => p.isHidden === true && p.isDeleted === false));
    assert.ok(olderPosts.every(p => p.isDeleted === true));
  });

  // ----------------------------------------------------
  // T3_021: F_R6_2 + F_R6_3 — Circuit Breaker Self-Healing in Simulation Mode
  // ----------------------------------------------------
  test('T3_021: F_R6_2 + F_R6_3 — Circuit Breaker Self-Healing in Simulation Mode heals from OPEN to HALF_OPEN to CLOSED', async () => {
    runner.setSimulation(true);
    // 1. Inject error 429 to trip breaker to OPEN
    const err429 = new Error('HTTP 429 Too Many Requests');
    err429.code = FB_ERROR_CODES.TOO_MANY_REQUESTS_429;
    circuitBreaker.recordFailure(err429);

    assert.strictEqual(circuitBreaker.getState(), CIRCUIT_BREAKER_STATES.OPEN);
    const cooldownEnd = circuitBreaker.pausedUntil;
    assert.ok(cooldownEnd > Date.now());

    // 2. Fast-forward virtual clock past cooldown
    const futureTime = cooldownEnd + 1000;
    assert.strictEqual(circuitBreaker.getState(futureTime), CIRCUIT_BREAKER_STATES.HALF_OPEN);

    // 3. Dispatch probe action in HALF_OPEN
    const probeCheck = circuitBreaker.canExecute(futureTime);
    assert.strictEqual(probeCheck.allowed, true);
    assert.strictEqual(probeCheck.isProbe, true);

    // Probe succeeds
    circuitBreaker.recordSuccess();
    assert.strictEqual(circuitBreaker.getState(), CIRCUIT_BREAKER_STATES.CLOSED);
    assert.strictEqual(circuitBreaker.failureCount, 0);

    // 4. Regular processing resumes
    const resumeAction = await runner.execute(ACTION_TYPES.POKE, 'probe_user_99', () => client.poke('probe_user_99'));
    assert.strictEqual(resumeAction.success, true);
  });
});
