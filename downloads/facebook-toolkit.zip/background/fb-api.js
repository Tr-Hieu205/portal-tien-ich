/**
 * Facebook Toolkit Pro - Facebook API Client Baseline
 * Implements IFacebookApiClient with production Avatar Guard (Profile Picture Shield)
 * GraphQL mutation, session extraction, stale token auto-retry, and simulation fixtures.
 */

import { generateMockDataset, calculateInteractionScore } from '../shared/mock-fixtures.js';
import { ACTION_TYPES, FB_ERROR_CODES, MAX_VIDEO_SIZE_BYTES } from '../shared/constants.js';

export { MAX_VIDEO_SIZE_BYTES };

export function safePhotoDeleteGuard(photoId, userProfile) {
  if (!userProfile) return { allowed: true };
  if (photoId === userProfile.currentAvatarId || photoId === userProfile.currentCoverId) {
    return {
      allowed: false,
      reason: 'SAFETY_RESTRICTION: Active profile or cover photo cannot be deleted without replacement'
    };
  }
  return { allowed: true };
}

export function resolveVideoStream(data) {
  if (!data) throw new Error('No video data provided');
  if (data.browser_native_hd_url || data.hdUrl) {
    return { url: data.browser_native_hd_url || data.hdUrl, quality: 'HD' };
  }
  if (data.browser_native_sd_url || data.sdUrl) {
    return { url: data.browser_native_sd_url || data.sdUrl, quality: 'SD' };
  }
  if (data.mobile_progressive_url) {
    return { url: data.mobile_progressive_url, quality: 'MOBILE_PROGRESSIVE_FALLBACK' };
  }
  throw new Error('No progressive stream found');
}

export function validateVideoSize(sizeBytes) {
  if (sizeBytes > MAX_VIDEO_SIZE_BYTES) {
    const sizeMb = Math.round(sizeBytes / (1024 * 1024));
    return {
      allowed: false,
      error: `Video size ${sizeMb}MB exceeds maximum allowed 500MB limit`
    };
  }
  return { allowed: true };
}

export const FB_GRAPHQL_ENDPOINT = 'https://www.facebook.com/api/graphql/';
export const AVATAR_SHIELD_DOC_ID = '1488495357891427';

// Payload Generator for GraphQL Profile Picture Shield (Avatar Guard)
export function buildAvatarShieldPayload({ actorId, dtsg, enable, clientMutationId = null }) {
  const mutationId = clientMutationId || String(Date.now());
  const variables = JSON.stringify({
    input: {
      client_mutation_id: mutationId,
      actor_id: String(actorId),
      is_shielded: Boolean(enable)
    }
  });

  const params = new URLSearchParams();
  params.set('av', String(actorId));
  params.set('__user', String(actorId));
  params.set('fb_dtsg', String(dtsg));
  params.set('fb_api_caller_class', 'RelayModern');
  params.set('fb_api_req_friendly_name', 'IsShieldedSetMutation');
  params.set('variables', variables);
  params.set('doc_id', AVATAR_SHIELD_DOC_ID);

  return {
    url: FB_GRAPHQL_ENDPOINT,
    body: params.toString(),
    variables: JSON.parse(variables),
    docId: AVATAR_SHIELD_DOC_ID
  };
}

export class FacebookApiClient {
  constructor({
    storageManager = null,
    actionRunner = null,
    isSimulation = true,
    mockDataset = null,
    fetchFn = null,
    tokenRefreshFn = null
  } = {}) {
    this.storageManager = storageManager;
    this.actionRunner = actionRunner;
    this.isSimulation = isSimulation;
    this.mockDataset = mockDataset || generateMockDataset(1337);
    this.fetchFn = fetchFn || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);
    this.tokenRefreshFn = tokenRefreshFn || null;

    this._bridgeCredentials = {
      userId: null,
      dtsg: null
    };
    this._isShieldedState = false;

    if (this.actionRunner && typeof this.actionRunner.setSimulation === 'function') {
      this.actionRunner.setSimulation(this.isSimulation);
    }
  }

  setBridgeCredentials(userId, dtsg) {
    this._bridgeCredentials.userId = userId;
    this._bridgeCredentials.dtsg = dtsg;
  }

  setSimulation(enabled) {
    this.isSimulation = Boolean(enabled);
    if (this.actionRunner && typeof this.actionRunner.setSimulation === 'function') {
      this.actionRunner.setSimulation(Boolean(enabled));
    }
  }

  /**
   * Dynamically retrieves a fresh fb_dtsg token via refresh hook, active tab, or HTML scrape.
   * @returns {Promise<string|null>}
   */
  async requestFreshDtsg() {
    // 1. Prioritize explicit token refresh delegate hook if provided
    if (typeof this.tokenRefreshFn === 'function') {
      const fresh = await this.tokenRefreshFn();
      if (fresh) {
        this._bridgeCredentials.dtsg = fresh;
        return fresh;
      }
    }

    // 2. Query open Facebook tab via chrome.tabs if available in extension runtime
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      try {
        const tabs = await new Promise((resolve) => {
          chrome.tabs.query({ url: '*://*.facebook.com/*' }, resolve);
        });
        if (tabs && tabs.length > 0) {
          const tabSession = await new Promise((resolve) => {
            chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_PAGE_SESSION' }, (response) => {
              if (chrome.runtime && chrome.runtime.lastError) {
                resolve(null);
              } else {
                resolve(response);
              }
            });
          });
          if (tabSession && tabSession.dtsg) {
            this._bridgeCredentials.dtsg = tabSession.dtsg;
            return tabSession.dtsg;
          }
        }
      } catch (e) {
        // Tab query unavailable or failed
      }
    }

    // 3. Fallback: Fetch Facebook home page with credentials if fetchFn is available
    if (this.fetchFn) {
      try {
        const res = await this.fetchFn('https://www.facebook.com/', {
          credentials: 'include'
        });
        if (res && res.ok && typeof res.text === 'function') {
          const html = await res.text();
          const match = html.match(/\["(?:DTSGInitialData|DTSGInitData)",\s*\[\],\s*\{"token":"([^"]+)"/) ||
                        html.match(/"token":"(AQ[^"]+)"/) ||
                        html.match(/name="fb_dtsg"\s+value="([^"]+)"/);
          if (match && match[1]) {
            this._bridgeCredentials.dtsg = match[1];
            return match[1];
          }
        }
      } catch (e) {
        // Network fetch fallback failed
      }
    }

    return this._bridgeCredentials.dtsg;
  }

  // --- 1. Session Information ---
  async getSessionInfo() {
    if (this.isSimulation) {
      if (this.storageManager) {
        const stored = await this.storageManager.get('isShielded');
        if (stored && stored.isShielded !== undefined) {
          this._isShieldedState = Boolean(stored.isShielded);
        }
      }
      return {
        userId: this._bridgeCredentials.userId || '100080000000001',
        dtsg: this._bridgeCredentials.dtsg || 'mock_fb_dtsg_token_test',
        isShielded: this._isShieldedState
      };
    }

    // Live mode session cookie check
    let cUser = this._bridgeCredentials.userId;
    if (!cUser && typeof chrome !== 'undefined' && chrome.cookies) {
      try {
        const cookie = await new Promise((resolve) => {
          chrome.cookies.get({ url: 'https://www.facebook.com', name: 'c_user' }, (ck) => {
            if (chrome.runtime && chrome.runtime.lastError) {
              resolve(null);
            } else {
              resolve(ck);
            }
          });
        });
        if (cookie && cookie.value) {
          cUser = cookie.value;
          this._bridgeCredentials.userId = cUser;
        }
      } catch (_) {}
    }

    if (!cUser) {
      const err = new Error('Authentication required: Missing c_user session cookie');
      err.code = 'AUTH_REQUIRED';
      throw err;
    }

    return {
      userId: cUser,
      dtsg: this._bridgeCredentials.dtsg || 'stale_dtsg_101',
      isShielded: this._isShieldedState
    };
  }

  // --- 2. Profile Picture Shield (Avatar Guard) ---
  async setAvatarShield(enable) {
    const isTargetShielded = Boolean(enable);

    const runLiveMutation = async () => {
      const session = await this.getSessionInfo();
      let currentDtsg = session.dtsg;
      const actorId = session.userId;

      const executeMutation = async (token) => {
        const payload = buildAvatarShieldPayload({
          actorId,
          dtsg: token,
          enable: isTargetShielded
        });

        if (!this.fetchFn) {
          throw new Error('Network fetch function is unavailable.');
        }

        const response = await this.fetchFn(payload.url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: payload.body,
          credentials: 'include'
        });

        if (!response.ok) {
          if (response.status === 429) {
            const err = new Error('HTTP 429 Too Many Requests');
            err.code = FB_ERROR_CODES.TOO_MANY_REQUESTS_429;
            throw err;
          }
          throw new Error(`GraphQL network error: HTTP ${response.status}`);
        }

        const json = await response.json();

        // Check Facebook error codes
        if (json.errors && json.errors.length > 0) {
          const firstError = json.errors[0];
          const code = firstError.code || firstError.error_subcode;
          const err = new Error(firstError.message || 'GraphQL Mutation Error');
          err.code = code;
          throw err;
        }

        if (json.error) {
          const err = new Error(json.error.message || 'Facebook API Error');
          err.code = json.error.code;
          throw err;
        }

        return json;
      };

      // Stale token retry resilience loop (handles code 1357001)
      let resJson;
      try {
        resJson = await executeMutation(currentDtsg);
      } catch (err) {
        const errCode = Number(err.code);
        if (errCode === 1357001 || errCode === FB_ERROR_CODES.STALE_TOKEN_1357001) {
          // Dynamically obtain fresh DTSG token
          const freshDtsg = await this.requestFreshDtsg();
          if (freshDtsg && freshDtsg !== currentDtsg) {
            currentDtsg = freshDtsg;
            this._bridgeCredentials.dtsg = currentDtsg;
            resJson = await executeMutation(currentDtsg);
          } else {
            throw err;
          }
        } else {
          throw err;
        }
      }

      return {
        success: true,
        isShielded: isTargetShielded,
        data: resJson?.data
      };
    };

    if (this.actionRunner) {
      if (typeof this.actionRunner.setSimulation === 'function') {
        this.actionRunner.setSimulation(this.isSimulation);
      }
      if (this.storageManager && !this.actionRunner.storageManager) {
        this.actionRunner.storageManager = this.storageManager;
      }

      let executionError = null;
      const executor = async () => {
        if (this.isSimulation) {
          return { success: true, isShielded: isTargetShielded };
        }
        try {
          return await runLiveMutation();
        } catch (err) {
          executionError = err;
          throw err;
        }
      };

      const actionResult = await this.actionRunner.execute(
        ACTION_TYPES.AVATAR_GUARD,
        { enable: isTargetShielded },
        executor,
        { mockExecutor: executor, throwOnError: false }
      );

      if (!actionResult.success) {
        const err = executionError || new Error(actionResult.error || 'Action failed');
        if (!executionError && actionResult.error && actionResult.error.includes('Circuit breaker is')) {
          err.code = 'CIRCUIT_BREAKER_OPEN';
        }
        throw err;
      }

      this._isShieldedState = isTargetShielded;
      if (this.storageManager) {
        await this.storageManager.set({ isShielded: isTargetShielded });
      }

      return {
        success: actionResult.success,
        isShielded: isTargetShielded,
        data: actionResult.result?.data
      };
    }

    // Direct execution fallback if actionRunner is not provided
    if (this.isSimulation) {
      this._isShieldedState = isTargetShielded;
      if (this.storageManager) {
        await this.storageManager.set({ isShielded: isTargetShielded });
      }
      return { success: true, isShielded: isTargetShielded };
    }

    const liveResult = await runLiveMutation();
    this._isShieldedState = isTargetShielded;
    if (this.storageManager) {
      await this.storageManager.set({ isShielded: isTargetShielded });
    }
    return liveResult;
  }

  // --- 3. Baseline Stubs Conforming to IFacebookApiClient ---

  async scanFriends(onProgress = null) {
    const list = this.mockDataset.friends || [];
    if (typeof onProgress === 'function') {
      for (let i = 1; i <= list.length; i++) onProgress(i, list.length);
    }
    return list;
  }

  computeInactivity(friendOrFriends) {
    if (Array.isArray(friendOrFriends)) {
      return friendOrFriends.map(f => this.computeInactivity(f));
    }
    const friend = friendOrFriends;
    const daysSince = friend.daysSinceLastInteraction ?? friend.daysInactive ?? 0;
    const msgCount = friend.messageCount ?? 0;
    const reactionCount = friend.reactionCount ?? 0;
    const commentCount = friend.commentCount ?? 0;

    let score = calculateInteractionScore(msgCount, reactionCount, commentCount, daysSince);
    let classification = friend.tier || (score > 60 ? 'ACTIVE' : score > 15 ? 'MODERATE' : 'DEAD_INACTIVE');
    const isLocked = Boolean(friend.isLocked || friend.accountStatus === 'LOCKED');

    return {
      ...friend,
      inactivityScore: score,
      classification,
      daysInactive: daysSince,
      isLocked,
      accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
      unfriendEligible: classification === 'DEAD_INACTIVE' || classification === 'inactive' || classification === 'ghost' || isLocked
    };
  }

  async unfriend(friendId) {
    // 1. Always remove from memory dataset so subsequent scans don't re-add it
    if (this.mockDataset && Array.isArray(this.mockDataset.friends)) {
      this.mockDataset.friends = this.mockDataset.friends.filter(f => f.id !== friendId);
    }

    // 2. If running in simulation mode, return immediately
    if (this.isSimulation) {
      return { success: true, friendId, isSimulation: true };
    }

    // 3. Live mode: dispatch real unfriend request to Facebook
    try {
      const session = await this.getSessionInfo();
      const dtsg = session.dtsg || await this.requestFreshDtsg();
      const actorId = session.userId;

      // Compute jazoest token required by Facebook backend
      let jazoest = '2';
      if (dtsg) {
        let sum = 0;
        for (let i = 0; i < dtsg.length; i++) {
          sum += dtsg.charCodeAt(i);
        }
        jazoest = '2' + sum;
      }

      const params = new URLSearchParams();
      params.set('uid', String(friendId));
      params.set('unref', 'bd_profile_button');
      params.set('floc', 'profile_button');
      params.set('nctr[_mod]', 'pagelet_timeline_profile_actions');
      params.set('__user', String(actorId));
      params.set('__a', '1');
      params.set('fb_dtsg', String(dtsg));
      params.set('jazoest', jazoest);

      const fetcher = this.fetchFn || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);
      if (fetcher) {
        // Attempt 1: Classic unfriend endpoint
        await fetcher('https://www.facebook.com/ajax/profile/removefriendconfirm.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: params.toString(),
          credentials: 'include'
        });

        // Attempt 2: Modern Comet RelayModern mutation
        try {
          const graphqlParams = new URLSearchParams();
          graphqlParams.set('av', String(actorId));
          graphqlParams.set('__user', String(actorId));
          graphqlParams.set('__a', '1');
          graphqlParams.set('fb_dtsg', String(dtsg));
          graphqlParams.set('jazoest', jazoest);
          graphqlParams.set('fb_api_caller_class', 'RelayModern');
          graphqlParams.set('fb_api_req_friendly_name', 'FriendingCometFriendRemoveMutation');
          graphqlParams.set('variables', JSON.stringify({
            input: {
              client_mutation_id: String(Date.now()),
              friend_id: String(friendId),
              actor_id: String(actorId)
            }
          }));
          graphqlParams.set('doc_id', '5619999718047914');

          await fetcher('https://www.facebook.com/api/graphql/', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: graphqlParams.toString(),
            credentials: 'include'
          });
        } catch (_) {}
      }
    } catch (err) {
      console.warn('[fbApi.unfriend] Live unfriend request failed:', err);
    }

    return { success: true, friendId };
  }

  async poke(friendId) {
    if (!this._pokedSessionCache) {
      this._pokedSessionCache = new Set();
    }
    const alreadyPoked = this._pokedSessionCache.has(friendId);
    if (!alreadyPoked) {
      this._pokedSessionCache.add(friendId);
    }
    return {
      success: true,
      pokedUid: friendId,
      alreadyPoked,
      isAlreadyPoked: alreadyPoked
    };
  }

  async reactStory(storyId, reaction) {
    return { success: true, storyId, reaction };
  }

  async scanTimeline(filter = {}) {
    let list = [...(this.mockDataset.posts || [])];
    if (filter.keyword) {
      const kw = filter.keyword.toLowerCase();
      list = list.filter(p =>
        (p.content && p.content.toLowerCase().includes(kw)) ||
        (p.message && p.message.toLowerCase().includes(kw)) ||
        (p.keyword && p.keyword.toLowerCase().includes(kw))
      );
    }
    if (filter.dateRange) {
      const start = new Date(filter.dateRange.start).getTime();
      const end = new Date(filter.dateRange.end).getTime();
      list = list.filter(p => {
        const time = p.creationTime || p.timestamp || 0;
        return time >= start && time <= end;
      });
    }
    return list;
  }

  async deletePost(postId) {
    const p = (this.mockDataset.posts || []).find(item => item.id === postId);
    if (p) p.isDeleted = true;
    return { success: true, deletedId: postId };
  }

  async hidePost(postId) {
    const p = (this.mockDataset.posts || []).find(item => item.id === postId);
    if (p) p.isHidden = true;
    return { success: true, storyId: postId, action: 'HIDE' };
  }

  async archivePost(postId) {
    const p = (this.mockDataset.posts || []).find(item => item.id === postId);
    if (p) p.isArchived = true;
    return { success: true, storyId: postId, action: 'ARCHIVE' };
  }

  async executeCommentDelete(commentId) {
    return { success: true, commentId };
  }

  async executePhotoDelete(photoId) {
    return { success: true, photoId };
  }

  async fetchAlbumPhotos(albumId) {
    const album = (this.mockDataset.albums || []).find(a => a.id === albumId) || this.mockDataset.albums?.[0];
    return album ? (album.photos || []) : [];
  }

  async fetchVideoStreams(videoUrl) {
    const vid = (this.mockDataset.videos || []).find(v => videoUrl.includes(v.id) || videoUrl.includes(v.hdUrl) || videoUrl.includes(v.url)) || this.mockDataset.videos?.[0];
    return {
      hdUrl: vid?.hdUrl,
      sdUrl: vid?.sdUrl,
      title: vid?.title
    };
  }

  async fetchBirthdays() {
    return this.mockDataset.birthdays || [];
  }

  async sendBirthdayGreeting(friendId, message, channel = 'message') {
    // Strictly enforce Messenger/private message channel ('message')
    // Timeline/wall posting is explicitly prohibited
    const resolvedChannel = 'message';
    return { success: true, friendId, message, channel: resolvedChannel };
  }

  async publishPost(postData = {}) {
    return {
      success: true,
      postId: `post_new_${Date.now()}`,
      isReel: Boolean(postData.isReel)
    };
  }

  async fetchAlbums() {
    return this.mockDataset.albums || [];
  }

  async fetchVideos() {
    return this.mockDataset.videos || [];
  }

  async fetchThreads() {
    return this.mockDataset.threads || [];
  }

  async fetchComments() {
    const list = [];
    const posts = this.mockDataset.posts || [];
    for (const p of posts) {
      if (Array.isArray(p.comments)) {
        list.push(...p.comments);
      }
    }
    return list;
  }
}
