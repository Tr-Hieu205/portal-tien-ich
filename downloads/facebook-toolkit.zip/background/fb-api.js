/**
 * Facebook Toolkit Pro - Facebook API Client Baseline
 * Implements IFacebookApiClient with production Avatar Guard (Profile Picture Shield)
 * GraphQL mutation, session extraction, stale token auto-retry, and simulation fixtures.
 */

import { generateMockDataset, calculateInteractionScore } from '../shared/mock-fixtures.js';
import { ACTION_TYPES, FB_ERROR_CODES, MAX_VIDEO_SIZE_BYTES } from '../shared/constants.js';

export { MAX_VIDEO_SIZE_BYTES };

export function safePhotoDeleteGuard(photoId, userProfile) {
  if (!userProfile) return { allowed: true };
  if (photoId === userProfile.currentAvatarId || photoId === userProfile.currentCoverId) {
    return {
      allowed: false,
      reason: 'SAFETY_RESTRICTION: Active profile or cover photo cannot be deleted without replacement'
    };
  }
  return { allowed: true };
}

export function resolveVideoStream(data) {
  if (!data) throw new Error('No video data provided');
  if (data.browser_native_hd_url || data.hdUrl) {
    return { url: data.browser_native_hd_url || data.hdUrl, quality: 'HD' };
  }
  if (data.browser_native_sd_url || data.sdUrl) {
    return { url: data.browser_native_sd_url || data.sdUrl, quality: 'SD' };
  }
  if (data.mobile_progressive_url) {
    return { url: data.mobile_progressive_url, quality: 'MOBILE_PROGRESSIVE_FALLBACK' };
  }
  throw new Error('No progressive stream found');
}

export function validateVideoSize(sizeBytes) {
  if (sizeBytes > MAX_VIDEO_SIZE_BYTES) {
    const sizeMb = Math.round(sizeBytes / (1024 * 1024));
    return {
      allowed: false,
      error: `Video size ${sizeMb}MB exceeds maximum allowed 500MB limit`
    };
  }
  return { allowed: true };
}

export const FB_GRAPHQL_ENDPOINT = 'https://www.facebook.com/api/graphql/';
export const AVATAR_SHIELD_DOC_ID = '1488495357891427';

// Payload Generator for GraphQL Profile Picture Shield (Avatar Guard)
export function buildAvatarShieldPayload({ actorId, dtsg, enable, clientMutationId = null }) {
  const mutationId = clientMutationId || String(Date.now());
  const variables = JSON.stringify({
    input: {
      client_mutation_id: mutationId,
      actor_id: String(actorId),
      is_shielded: Boolean(enable)
    }
  });

  const params = new URLSearchParams();
  params.set('av', String(actorId));
  params.set('__user', String(actorId));
  params.set('fb_dtsg', String(dtsg));
  params.set('fb_api_caller_class', 'RelayModern');
  params.set('fb_api_req_friendly_name', 'IsShieldedSetMutation');
  params.set('variables', variables);
  params.set('doc_id', AVATAR_SHIELD_DOC_ID);

  return {
    url: FB_GRAPHQL_ENDPOINT,
    body: params.toString(),
    variables: JSON.parse(variables),
    docId: AVATAR_SHIELD_DOC_ID
  };
}

export class FacebookApiClient {
  constructor({
    storageManager = null,
    actionRunner = null,
    isSimulation = true,
    mockDataset = null,
    fetchFn = null,
    tokenRefreshFn = null
  } = {}) {
    this.storageManager = storageManager;
    this.actionRunner = actionRunner;
    this.isSimulation = isSimulation;
    this.mockDataset = mockDataset || generateMockDataset(1337);
    this.fetchFn = fetchFn || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);
    this.tokenRefreshFn = tokenRefreshFn || null;

    this._bridgeCredentials = {
      userId: null,
      dtsg: null
    };
    this._isShieldedState = false;

    if (this.actionRunner && typeof this.actionRunner.setSimulation === 'function') {
      this.actionRunner.setSimulation(this.isSimulation);
    }
  }

  setBridgeCredentials(userId, dtsg) {
    this._bridgeCredentials.userId = userId;
    this._bridgeCredentials.dtsg = dtsg;
  }

  setSimulation(enabled) {
    this.isSimulation = Boolean(enabled);
    if (this.actionRunner && typeof this.actionRunner.setSimulation === 'function') {
      this.actionRunner.setSimulation(Boolean(enabled));
    }
  }

  /**
   * Dynamically retrieves a fresh fb_dtsg token via refresh hook, active tab, or HTML scrape.
   * @returns {Promise<string|null>}
   */
  async requestFreshDtsg() {
    // 1. Prioritize explicit token refresh delegate hook if provided
    if (typeof this.tokenRefreshFn === 'function') {
      const fresh = await this.tokenRefreshFn();
      if (fresh) {
        this._bridgeCredentials.dtsg = fresh;
        return fresh;
      }
    }

    // 2. Query open Facebook tab via chrome.tabs if available in extension runtime
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      try {
        const tabs = await new Promise((resolve) => {
          chrome.tabs.query({ url: '*://*.facebook.com/*' }, resolve);
        });
        if (tabs && tabs.length > 0) {
          const tabSession = await new Promise((resolve) => {
            const timer = setTimeout(() => resolve(null), 3000);
            try {
              chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_PAGE_SESSION' }, (response) => {
                clearTimeout(timer);
                if (chrome.runtime && chrome.runtime.lastError) {
                  resolve(null);
                } else {
                  resolve(response);
                }
              });
            } catch (_) {
              clearTimeout(timer);
              resolve(null);
            }
          });
          if (tabSession && tabSession.dtsg) {
            this._bridgeCredentials.dtsg = tabSession.dtsg;
            return tabSession.dtsg;
          }
        }
      } catch (e) {
        // Tab query unavailable or failed
      }
    }

    // 3. Fallback: Fetch Facebook home page with credentials if fetchFn is available
    if (this.fetchFn) {
      try {
        const res = await this.fetchFn('https://www.facebook.com/', {
          credentials: 'include'
        });
        if (res && res.ok && typeof res.text === 'function') {
          const html = await res.text();
          const match = html.match(/\["(?:DTSGInitialData|DTSGInitData)",\s*\[\],\s*\{"token":"([^"]+)"/) ||
                        html.match(/"token":"(AQ[^"]+)"/) ||
                        html.match(/name="fb_dtsg"\s+value="([^"]+)"/);
          if (match && match[1]) {
            this._bridgeCredentials.dtsg = match[1];
            return match[1];
          }
        }
      } catch (e) {
        // Network fetch fallback failed
      }
    }

    return this._bridgeCredentials.dtsg;
  }

  // --- 1. Session Information ---
  async getSessionInfo() {
    // Check real c_user cookie if running in extension runtime
    let cUser = this._bridgeCredentials.userId;
    if (!cUser && typeof chrome !== 'undefined' && chrome.cookies) {
      try {
        const cookie = await new Promise((resolve) => {
          chrome.cookies.get({ url: 'https://www.facebook.com', name: 'c_user' }, (ck) => {
            if (chrome.runtime && chrome.runtime.lastError) {
              resolve(null);
            } else {
              resolve(ck);
            }
          });
        });
        if (cookie && cookie.value) {
          cUser = cookie.value;
          this._bridgeCredentials.userId = cUser;
        }
      } catch (_) {}
    }

    if (this.isSimulation) {
      if (this.storageManager) {
        const stored = await this.storageManager.get('isShielded');
        if (stored && stored.isShielded !== undefined) {
          this._isShieldedState = Boolean(stored.isShielded);
        }
      }
      return {
        userId: cUser || this._bridgeCredentials.userId || '100080000000001',
        realUserId: cUser || null,
        isRealSession: Boolean(cUser),
        dtsg: this._bridgeCredentials.dtsg || 'mock_fb_dtsg_token_test',
        isShielded: this._isShieldedState
      };
    }

    if (!cUser) {
      const err = new Error('Authentication required: Missing c_user session cookie');
      err.code = 'AUTH_REQUIRED';
      throw err;
    }

    return {
      userId: cUser,
      realUserId: cUser,
      isRealSession: true,
      dtsg: this._bridgeCredentials.dtsg || 'stale_dtsg_101',
      isShielded: this._isShieldedState
    };
  }

  // --- 2. Profile Picture Shield (Avatar Guard) ---
  async setAvatarShield(enable) {
    const isTargetShielded = Boolean(enable);

    const runLiveMutation = async () => {
      const session = await this.getSessionInfo();
      let currentDtsg = session.dtsg;
      const actorId = session.userId;

      const executeMutation = async (token) => {
        const payload = buildAvatarShieldPayload({
          actorId,
          dtsg: token,
          enable: isTargetShielded
        });

        if (!this.fetchFn) {
          throw new Error('Network fetch function is unavailable.');
        }

        const response = await this.fetchFn(payload.url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: payload.body,
          credentials: 'include'
        });

        if (!response.ok) {
          if (response.status === 429) {
            const err = new Error('HTTP 429 Too Many Requests');
            err.code = FB_ERROR_CODES.TOO_MANY_REQUESTS_429;
            throw err;
          }
          throw new Error(`GraphQL network error: HTTP ${response.status}`);
        }

        const json = await response.json();

        // Check Facebook error codes
        if (json.errors && json.errors.length > 0) {
          const firstError = json.errors[0];
          const code = firstError.code || firstError.error_subcode;
          const err = new Error(firstError.message || 'GraphQL Mutation Error');
          err.code = code;
          throw err;
        }

        if (json.error) {
          const err = new Error(json.error.message || 'Facebook API Error');
          err.code = json.error.code;
          throw err;
        }

        return json;
      };

      // Stale token retry resilience loop (handles code 1357001)
      let resJson;
      try {
        resJson = await executeMutation(currentDtsg);
      } catch (err) {
        const errCode = Number(err.code);
        if (errCode === 1357001 || errCode === FB_ERROR_CODES.STALE_TOKEN_1357001) {
          // Dynamically obtain fresh DTSG token
          const freshDtsg = await this.requestFreshDtsg();
          if (freshDtsg && freshDtsg !== currentDtsg) {
            currentDtsg = freshDtsg;
            this._bridgeCredentials.dtsg = currentDtsg;
            resJson = await executeMutation(currentDtsg);
          } else {
            throw err;
          }
        } else {
          throw err;
        }
      }

      return {
        success: true,
        isShielded: isTargetShielded,
        data: resJson?.data
      };
    };

    if (this.actionRunner) {
      if (typeof this.actionRunner.setSimulation === 'function') {
        this.actionRunner.setSimulation(this.isSimulation);
      }
      if (this.storageManager && !this.actionRunner.storageManager) {
        this.actionRunner.storageManager = this.storageManager;
      }

      let executionError = null;
      const executor = async () => {
        if (this.isSimulation) {
          return { success: true, isShielded: isTargetShielded };
        }
        try {
          return await runLiveMutation();
        } catch (err) {
          executionError = err;
          throw err;
        }
      };

      const actionResult = await this.actionRunner.execute(
        ACTION_TYPES.AVATAR_GUARD,
        { enable: isTargetShielded },
        executor,
        { mockExecutor: executor, throwOnError: false }
      );

      if (!actionResult.success) {
        const err = executionError || new Error(actionResult.error || 'Action failed');
        if (!executionError && actionResult.error && actionResult.error.includes('Circuit breaker is')) {
          err.code = 'CIRCUIT_BREAKER_OPEN';
        }
        throw err;
      }

      this._isShieldedState = isTargetShielded;
      if (this.storageManager) {
        await this.storageManager.set({ isShielded: isTargetShielded });
      }

      return {
        success: actionResult.success,
        isShielded: isTargetShielded,
        data: actionResult.result?.data
      };
    }

    // Direct execution fallback if actionRunner is not provided
    if (this.isSimulation) {
      this._isShieldedState = isTargetShielded;
      if (this.storageManager) {
        await this.storageManager.set({ isShielded: isTargetShielded });
      }
      return { success: true, isShielded: isTargetShielded };
    }

    const liveResult = await runLiveMutation();
    this._isShieldedState = isTargetShielded;
    if (this.storageManager) {
      await this.storageManager.set({ isShielded: isTargetShielded });
    }
    return liveResult;
  }

  // --- 3. Baseline Stubs Conforming to IFacebookApiClient ---

  async fetchLiveFacebookFriends(onProgress = null) {
    const friends = [];
    const seenUids = new Set();
    const session = await this.getSessionInfo().catch(() => ({}));
    const actorId = session.userId;

    const SYSTEM_ROUTES = new Set([
      'notifications', 'notification', 'reel', 'reels', 'watch', 'groups', 'gaming',
      'messages', 'message', 'stories', 'story', 'marketplace', 'settings', 'professional',
      'professional_dashboard', 'bookmarks', 'help', 'privacy', 'l.php', 'sharer',
      'dialog', 'login', 'logout', 'me', 'home', 'friends', 'events', 'saved',
      'pages', 'ad_center', 'ads', 'fundraisers', 'memories', 'feeds', 'news',
      'profile.php', 'photo', 'photo.php', 'video', 'videos', 'live', 'browse',
      'search', 'checkpoint', 'recover', 'allactivity'
    ]);

    const isValidCandidate = (item) => {
      if (!item || !item.id || !item.name) return false;
      const id = String(item.id).trim().toLowerCase();
      const name = String(item.name).trim();

      if (actorId && id === String(actorId).trim().toLowerCase()) return false;
      if (SYSTEM_ROUTES.has(id)) return false;
      if (id.includes('.php') || id.includes('?') || id.includes('/') || id.includes('&') || id.includes('=')) return false;
      if (
        name.startsWith('Chưa đọc') || name === 'Xem tất cả' ||
        name.includes('người theo dõi') || name === 'Cài đặt' ||
        name.includes('sáng tạo nội dung') || name.includes('thông báo') ||
        name.includes('Trang chủ') || name === 'Bạn bè' || name.length < 2
      ) {
        return false;
      }
      return true;
    };

    const addFriend = (item) => {
      if (!item || !item.id || seenUids.has(String(item.id)) || !isValidCandidate(item)) return;
      seenUids.add(String(item.id));
      friends.push(item);
      if (typeof onProgress === 'function') {
        onProgress(friends.length, Math.max(friends.length, 760));
      }
    };

    // 1. Query open Facebook tabs via chrome.tabs if available
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      try {
        const tabs = await new Promise((resolve) => {
          chrome.tabs.query({ url: '*://*.facebook.com/*' }, resolve);
        });
        if (tabs && tabs.length > 0) {
          for (const tab of tabs) {
            try {
              const res = await new Promise((resolve) => {
                const timer = setTimeout(() => resolve(null), 3000);
                chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_PAGE_FRIENDS', currentUserId: actorId }, (response) => {
                  clearTimeout(timer);
                  if (chrome.runtime?.lastError) resolve(null);
                  else resolve(response);
                });
              });
              if (res && Array.isArray(res.friends) && res.friends.length > 0) {
                for (const f of res.friends) addFriend(f);

                // If tab is on friends page, auto-scroll to gather all friends
                if (res.onFriendsPage) {
                  try {
                    const scrollRes = await new Promise((resolve) => {
                      const scrollTimer = setTimeout(() => resolve(null), 6000);
                      chrome.tabs.sendMessage(tab.id, { type: 'AUTO_SCROLL_COLLECT_FRIENDS', currentUserId: actorId }, (sResp) => {
                        clearTimeout(scrollTimer);
                        resolve(sResp);
                      });
                    });
                    if (scrollRes && Array.isArray(scrollRes.friends)) {
                      for (const f of scrollRes.friends) addFriend(f);
                    }
                  } catch (_) {}
                }
              }
            } catch (_) {}
          }
        }
      } catch (tabErr) {
        console.warn('[fbApi.fetchLiveFacebookFriends] Tab query failed:', tabErr);
      }
    }

    // 2. Fetch GraphQL collection pagination if session credentials exist
    try {
      const session = await this.getSessionInfo();
      const actorId = session.userId;
      const dtsg = session.dtsg || await this.requestFreshDtsg();
      const fetcher = this.fetchFn || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);

      if (actorId && dtsg && fetcher) {
        let collectionToken = '';
        try {
          const raw = `app_collection:${actorId}:2356318349`;
          collectionToken = typeof btoa === 'function' ? btoa(raw) : Buffer.from(raw).toString('base64');
        } catch (_) {}

        const docIds = ['6860361367339794', '5619999718047914', '5578794895565597', '4163909770335016'];
        let cursor = null;
        let hasNextPage = true;
        let pageCount = 0;
        const maxPages = 40;

        while (hasNextPage && pageCount < maxPages) {
          pageCount++;
          let pageLoaded = false;

          for (const docId of docIds) {
            try {
              const params = new URLSearchParams();
              params.set('av', String(actorId));
              params.set('__user', String(actorId));
              params.set('__a', '1');
              params.set('fb_dtsg', String(dtsg));
              params.set('fb_api_caller_class', 'RelayModern');
              params.set('fb_api_req_friendly_name', 'ProfileCometAppCollectionListRendererPaginationQuery');
              params.set('variables', JSON.stringify({
                count: 36,
                cursor: cursor,
                scale: 1,
                search: null,
                id: collectionToken
              }));
              params.set('doc_id', docId);

              const resp = await fetcher('https://www.facebook.com/api/graphql/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: params.toString(),
                credentials: 'include'
              });

              if (resp.ok) {
                const json = await resp.json();
                const node = json.data?.node || json.data?.viewer;
                const pageItems = node?.pageItems || node?.all_collections?.nodes?.[0]?.pageItems;
                const edges = pageItems?.edges || [];

                if (edges.length > 0) {
                  for (const edge of edges) {
                    const n = edge.node || {};
                    const id = n.id || n.user?.id;
                    const name = n.title?.text || n.name || 'Người dùng Facebook';
                    const avatarUrl = n.image?.uri || n.profile_picture?.uri;
                    const profileUrl = n.url || `https://www.facebook.com/${id}`;
                    const isLocked = name.toLowerCase().includes('người dùng facebook') ||
                                     name.toLowerCase().includes('facebook user') ||
                                     Boolean(n.is_memorialized);

                    const subtitle = n.subtitle_text?.text || n.subtitle?.text || '';
                    let mutualFriends = 0;
                    const mMatch = subtitle.match(/([0-9.,]+)\s*(?:người\s*)?bạn chung/i) || subtitle.match(/([0-9.,]+)\s*mutual/i);
                    if (mMatch) {
                      mutualFriends = parseInt(mMatch[1].replace(/[,.]/g, ''), 10) || 0;
                    }

                    if (id) {
                      addFriend({
                        id: String(id),
                        name,
                        avatarUrl,
                        profileUrl,
                        isLocked,
                        accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
                        classification: isLocked ? 'DEAD_INACTIVE' : 'MODERATE',
                        daysInactive: isLocked ? 999 : Math.floor(Math.random() * 30),
                        messageCount: isLocked ? 0 : 5,
                        reactionCount: isLocked ? 0 : 2,
                        mutualFriends
                      });
                    }
                  }

                  const pageInfo = pageItems?.page_info;
                  hasNextPage = Boolean(pageInfo?.has_next_page);
                  cursor = pageInfo?.end_cursor || null;
                  pageLoaded = true;
                  break;
                }
              }
            } catch (_) {}
          }

          if (!pageLoaded || !cursor) {
            break;
          }
        }
      }
    } catch (gqlErr) {
      console.warn('[fbApi.fetchLiveFacebookFriends] GraphQL fetch failed:', gqlErr);
    }

    // 3. Fallback: Parse HTML from https://www.facebook.com/me/friends if GraphQL yielded 0
    if (friends.length === 0) {
      try {
        const fetcher = this.fetchFn || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);
        if (fetcher) {
          const resp = await fetcher('https://www.facebook.com/me/friends', { credentials: 'include' });
          if (resp.ok) {
            const html = await resp.text();
            const userMatches = html.matchAll(/"__typename":"User","id":"([0-9]+)","name":"([^"]+)"(?:,"profile_picture":(?:\{"uri":"([^"]+)"\}|null))?/g);
            for (const match of userMatches) {
              const [, id, rawName, avatar] = match;
              let name = rawName;
              try { name = JSON.parse(`"${rawName}"`); } catch (_) {}
              const isLocked = name.toLowerCase().includes('người dùng facebook') || name.toLowerCase().includes('facebook user');
              addFriend({
                id: String(id),
                name,
                avatarUrl: avatar ? avatar.replace(/\\/g, '') : null,
                profileUrl: `https://www.facebook.com/${id}`,
                isLocked,
                accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
                classification: isLocked ? 'DEAD_INACTIVE' : 'MODERATE',
                daysInactive: isLocked ? 999 : 0
              });
            }
          }
        }
      } catch (htmlErr) {
        console.warn('[fbApi.fetchLiveFacebookFriends] HTML scrape fallback error:', htmlErr);
      }
    }

    return friends;
  }

  async scanFriends(onProgress = null) {
    if (this.isSimulation) {
      const list = this.mockDataset.friends || [];
      if (typeof onProgress === 'function') {
        for (let i = 1; i <= list.length; i++) onProgress(i, list.length);
      }
      return list;
    }

    try {
      const liveFriends = await this.fetchLiveFacebookFriends(onProgress);
      if (Array.isArray(liveFriends) && liveFriends.length > 0) {
        return liveFriends;
      }
    } catch (err) {
      console.warn('[fbApi.scanFriends] Live friend extraction encountered an error:', err);
    }

    // Fallback: Check storage cache if live retrieval returned 0
    if (this.storageManager) {
      try {
        const stored = await this.storageManager.get('cachedFriends');
        const cached = stored?.cachedFriends;
        if (Array.isArray(cached) && cached.length > 0) {
          return cached;
        }
      } catch (_) {}
    }

    const list = this.mockDataset.friends || [];
    if (typeof onProgress === 'function') {
      for (let i = 1; i <= list.length; i++) onProgress(i, list.length);
    }
    return list;
  }

  computeInactivity(friendOrFriends) {
    if (Array.isArray(friendOrFriends)) {
      return friendOrFriends.map(f => this.computeInactivity(f));
    }
    const friend = friendOrFriends;
    const daysSince = friend.daysSinceLastInteraction ?? friend.daysInactive ?? 0;
    const msgCount = friend.messageCount ?? 0;
    const reactionCount = friend.reactionCount ?? 0;
    const commentCount = friend.commentCount ?? 0;

    let score = calculateInteractionScore(msgCount, reactionCount, commentCount, daysSince);
    let classification = friend.tier || (score > 60 ? 'ACTIVE' : score > 15 ? 'MODERATE' : 'DEAD_INACTIVE');
    const isLocked = Boolean(friend.isLocked || friend.accountStatus === 'LOCKED');

    return {
      ...friend,
      inactivityScore: score,
      classification,
      daysInactive: daysSince,
      isLocked,
      accountStatus: isLocked ? 'LOCKED' : 'ACTIVE',
      unfriendEligible: classification === 'DEAD_INACTIVE' || classification === 'inactive' || classification === 'ghost' || isLocked
    };
  }

  async unfriend(friendId) {
    // 1. Simulation mode: return immediately
    if (this.isSimulation) {
      if (this.mockDataset && Array.isArray(this.mockDataset.friends)) {
        this.mockDataset.friends = this.mockDataset.friends.filter(f => f.id !== friendId);
      }
      return { success: true, friendId, isSimulation: true };
    }

    // 2. Live mode: dispatch to active Facebook tab where origin and cookies are same-origin
    let liveSuccess = false;
    let liveError = null;

    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      try {
        const tabs = await new Promise((resolve) => {
          chrome.tabs.query({ url: '*://*.facebook.com/*' }, resolve);
        });

        if (tabs && tabs.length > 0) {
          const session = await this.getSessionInfo().catch(() => ({}));
          for (const tab of tabs) {
            try {
              const tabRes = await new Promise((resolve) => {
                const timer = setTimeout(() => resolve(null), 8000);
                chrome.tabs.sendMessage(
                  tab.id,
                  {
                    type: 'EXECUTE_LIVE_UNFRIEND',
                    friendId,
                    actorId: session.userId,
                    dtsg: session.dtsg
                  },
                  (response) => {
                    clearTimeout(timer);
                    if (chrome.runtime?.lastError) resolve(null);
                    else resolve(response);
                  }
                );
              });

              if (tabRes) {
                if (tabRes.success) {
                  liveSuccess = true;
                  break;
                } else if (tabRes.error) {
                  liveError = tabRes.error;
                }
              }
            } catch (tabErr) {
              liveError = tabErr.message;
            }
          }
        }
      } catch (qErr) {
        liveError = qErr.message;
      }
    }

    // Direct fetch fallback if tabs unavailable (e.g. Node test environments with mock fetchFn)
    if (!liveSuccess && !liveError) {
      try {
        const session = await this.getSessionInfo();
        const dtsg = session.dtsg || await this.requestFreshDtsg();
        const actorId = session.userId;

        let jazoest = '2';
        if (dtsg) {
          let sum = 0;
          for (let i = 0; i < dtsg.length; i++) {
            sum += dtsg.charCodeAt(i);
          }
          jazoest = '2' + sum;
        }

        const params = new URLSearchParams();
        params.set('uid', String(friendId));
        params.set('friend_id', String(friendId));
        params.set('confirmed', '1');
        params.set('unfriend', '1');
        params.set('unref', 'bd_profile_button');
        params.set('floc', 'profile_button');
        params.set('nctr[_mod]', 'pagelet_timeline_profile_actions');
        params.set('__user', String(actorId || ''));
        params.set('__a', '1');
        if (dtsg) params.set('fb_dtsg', String(dtsg));
        params.set('jazoest', jazoest);

        const fetcher = this.fetchFn || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);
        if (fetcher) {
          const resp = await fetcher('https://www.facebook.com/ajax/profile/removefriendconfirm.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: params.toString(),
            credentials: 'include'
          });
          if (resp && resp.ok) {
            liveSuccess = true;
          } else if (resp) {
            liveError = `HTTP ${resp.status}`;
          }

          // Fallback via mbasic endpoint
          if (!liveSuccess) {
            try {
              const mbParams = new URLSearchParams();
              mbParams.set('friend_id', String(friendId));
              mbParams.set('confirm', '1');
              if (dtsg) mbParams.set('fb_dtsg', String(dtsg));
              mbParams.set('jazoest', jazoest);

              const mbResp = await fetcher('https://mbasic.facebook.com/removefriend.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: mbParams.toString(),
                credentials: 'include'
              });
              if (mbResp && mbResp.ok) {
                liveSuccess = true;
                liveError = null;
              }
            } catch (_) {}
          }
        }
      } catch (err) {
        liveError = err.message;
      }
    }

    if (!liveSuccess) {
      const err = new Error(liveError || 'Không thể hủy kết bạn trên Facebook (Vui lòng mở ít nhất 1 tab facebook.com)');
      err.code = 'UNFRIEND_FAILED';
      throw err;
    }

    // Only on confirmed success, remove from in-memory mock dataset
    if (this.mockDataset && Array.isArray(this.mockDataset.friends)) {
      this.mockDataset.friends = this.mockDataset.friends.filter(f => f.id !== friendId);
    }

    return { success: true, friendId, isLive: true };
  }

  async syncMessengerInteractions() {
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      try {
        const tabs = await new Promise((resolve) => {
          chrome.tabs.query({ url: '*://*.facebook.com/*' }, resolve);
        });
        if (tabs && tabs.length > 0) {
          const session = await this.getSessionInfo().catch(() => ({}));
          for (const tab of tabs) {
            try {
              const res = await new Promise((resolve) => {
                const timer = setTimeout(() => resolve(null), 6000);
                chrome.tabs.sendMessage(tab.id, { type: 'SYNC_MESSENGER_CHATS', currentUserId: session.userId }, (response) => {
                  clearTimeout(timer);
                  if (chrome.runtime?.lastError) resolve(null);
                  else resolve(response);
                });
              });
              if (res && res.success && res.interactions) {
                return res.interactions;
              }
            } catch (_) {}
          }
        }
      } catch (_) {}
    }
    return {};
  }

  async poke(friendId) {
    if (!this._pokedSessionCache) {
      this._pokedSessionCache = new Set();
    }
    const alreadyPoked = this._pokedSessionCache.has(friendId);
    if (!alreadyPoked) {
      this._pokedSessionCache.add(friendId);
    }
    return {
      success: true,
      pokedUid: friendId,
      alreadyPoked,
      isAlreadyPoked: alreadyPoked
    };
  }

  async reactStory(storyId, reaction) {
    return { success: true, storyId, reaction };
  }

  async scanTimeline(filter = {}) {
    let list = [...(this.mockDataset.posts || [])];
    if (filter.keyword) {
      const kw = filter.keyword.toLowerCase();
      list = list.filter(p =>
        (p.content && p.content.toLowerCase().includes(kw)) ||
        (p.message && p.message.toLowerCase().includes(kw)) ||
        (p.keyword && p.keyword.toLowerCase().includes(kw))
      );
    }
    if (filter.dateRange) {
      const start = new Date(filter.dateRange.start).getTime();
      const end = new Date(filter.dateRange.end).getTime();
      list = list.filter(p => {
        const time = p.creationTime || p.timestamp || 0;
        return time >= start && time <= end;
      });
    }
    return list;
  }

  async deletePost(postId) {
    const p = (this.mockDataset.posts || []).find(item => item.id === postId);
    if (p) p.isDeleted = true;
    return { success: true, deletedId: postId };
  }

  async hidePost(postId) {
    const p = (this.mockDataset.posts || []).find(item => item.id === postId);
    if (p) p.isHidden = true;
    return { success: true, storyId: postId, action: 'HIDE' };
  }

  async archivePost(postId) {
    const p = (this.mockDataset.posts || []).find(item => item.id === postId);
    if (p) p.isArchived = true;
    return { success: true, storyId: postId, action: 'ARCHIVE' };
  }

  async executeCommentDelete(commentId) {
    return { success: true, commentId };
  }

  async executePhotoDelete(photoId) {
    return { success: true, photoId };
  }

  async fetchAlbumPhotos(albumId) {
    const album = (this.mockDataset.albums || []).find(a => a.id === albumId) || this.mockDataset.albums?.[0];
    return album ? (album.photos || []) : [];
  }

  async fetchVideoStreams(videoUrl) {
    const vid = (this.mockDataset.videos || []).find(v => videoUrl.includes(v.id) || videoUrl.includes(v.hdUrl) || videoUrl.includes(v.url)) || this.mockDataset.videos?.[0];
    return {
      hdUrl: vid?.hdUrl,
      sdUrl: vid?.sdUrl,
      title: vid?.title
    };
  }

  async fetchBirthdays() {
    return this.mockDataset.birthdays || [];
  }

  async sendBirthdayGreeting(friendId, message, channel = 'message') {
    // Strictly enforce Messenger/private message channel ('message')
    // Timeline/wall posting is explicitly prohibited
    const resolvedChannel = 'message';
    return { success: true, friendId, message, channel: resolvedChannel };
  }

  async publishPost(postData = {}) {
    return {
      success: true,
      postId: `post_new_${Date.now()}`,
      isReel: Boolean(postData.isReel)
    };
  }

  async fetchAlbums() {
    return this.mockDataset.albums || [];
  }

  async fetchVideos() {
    return this.mockDataset.videos || [];
  }

  async fetchThreads() {
    return this.mockDataset.threads || [];
  }

  async fetchComments() {
    const list = [];
    const posts = this.mockDataset.posts || [];
    for (const p of posts) {
      if (Array.isArray(p.comments)) {
        list.push(...p.comments);
      }
    }
    return list;
  }
}
