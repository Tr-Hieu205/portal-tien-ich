/**
 * Facebook Toolkit Pro - DeclarativeNetRequest Manager
 * Manages static and dynamic network interception rules for privacy/stealth:
 * - Intercepts & blocks Seen delivery receipts (change_read_status.php)
 * - Intercepts & blocks Typing presence indicators (typ.php)
 * - Manages dynamic rulesets via chrome.declarativeNetRequest.updateDynamicRules
 * - Synchronizes static rulesets via updateEnabledRulesets
 */

import { STORAGE_KEYS, STORAGE_DEFAULTS } from '../shared/constants.js';

export const DNR_RULE_IDS = Object.freeze({
  SEEN_PRIMARY: 1001,
  SEEN_SECONDARY: 1002,
  TYPING_PRIMARY: 1003,
  TYPING_SECONDARY: 1004
});

export const SEEN_RULE_IDS = Object.freeze([
  DNR_RULE_IDS.SEEN_PRIMARY,
  DNR_RULE_IDS.SEEN_SECONDARY
]);

export const TYPING_RULE_IDS = Object.freeze([
  DNR_RULE_IDS.TYPING_PRIMARY,
  DNR_RULE_IDS.TYPING_SECONDARY
]);

export const ALL_STEALTH_RULE_IDS = Object.freeze([
  ...SEEN_RULE_IDS,
  ...TYPING_RULE_IDS
]);

export const STATIC_RULESET_ID = 'stealth_rules';

export const SEEN_DYNAMIC_RULES = Object.freeze([
  {
    id: DNR_RULE_IDS.SEEN_PRIMARY,
    priority: 1,
    action: { type: 'block' },
    condition: {
      urlFilter: '*change_read_status.php*',
      resourceTypes: ['xmlhttprequest']
    }
  },
  {
    id: DNR_RULE_IDS.SEEN_SECONDARY,
    priority: 1,
    action: { type: 'block' },
    condition: {
      urlFilter: '*ajax/mercury/change_read_status*',
      resourceTypes: ['xmlhttprequest']
    }
  }
]);

export const TYPING_DYNAMIC_RULES = Object.freeze([
  {
    id: DNR_RULE_IDS.TYPING_PRIMARY,
    priority: 1,
    action: { type: 'block' },
    condition: {
      urlFilter: '*ajax/messaging/typ.php*',
      resourceTypes: ['xmlhttprequest']
    }
  },
  {
    id: DNR_RULE_IDS.TYPING_SECONDARY,
    priority: 1,
    action: { type: 'block' },
    condition: {
      urlFilter: '*messaging/typ*',
      resourceTypes: ['xmlhttprequest']
    }
  }
]);

export class DnrManager {
  static getDnrApi(customApi = null) {
    if (customApi) return customApi;
    if (typeof chrome !== 'undefined' && chrome.declarativeNetRequest) {
      return chrome.declarativeNetRequest;
    }
    return null;
  }

  static async init(storageManager = null, dnrApi = null) {
    const api = this.getDnrApi(dnrApi);
    if (!api) return { initialized: false, reason: 'DNR API unavailable' };

    let stealthSettings = STORAGE_DEFAULTS[STORAGE_KEYS.STEALTH_SETTINGS];
    if (storageManager && typeof storageManager.getStealthSettings === 'function') {
      stealthSettings = await storageManager.getStealthSettings();
    }

    return this.updateStealthRules(stealthSettings, api);
  }

  static async updateStealthRules({ blockSeen = true, blockTyping = true } = {}, customApi = null) {
    const api = this.getDnrApi(customApi);
    if (!api) {
      return { success: false, reason: 'DNR API not available' };
    }

    const removeRuleIds = [...ALL_STEALTH_RULE_IDS];
    const addRules = [];

    if (blockSeen) {
      addRules.push(...SEEN_DYNAMIC_RULES);
    }

    if (blockTyping) {
      addRules.push(...TYPING_DYNAMIC_RULES);
    }

    await api.updateDynamicRules({
      removeRuleIds,
      addRules
    });

    if (typeof api.updateEnabledRulesets === 'function') {
      if (!blockSeen && !blockTyping) {
        await api.updateEnabledRulesets({
          disableRulesetIds: [STATIC_RULESET_ID]
        });
      } else if (blockSeen && blockTyping) {
        await api.updateEnabledRulesets({
          enableRulesetIds: [STATIC_RULESET_ID]
        });
      } else {
        await api.updateEnabledRulesets({
          disableRulesetIds: [STATIC_RULESET_ID]
        });
      }
    }

    return {
      success: true,
      blockSeen: Boolean(blockSeen),
      blockTyping: Boolean(blockTyping),
      activeDynamicRuleCount: addRules.length
    };
  }

  static async getStealthStatus(customApi = null) {
    const api = this.getDnrApi(customApi);
    if (!api) {
      return { blockSeen: false, blockTyping: false, activeRuleIds: [] };
    }

    const dynamicRules = await api.getDynamicRules();
    const activeRuleIds = dynamicRules.map(r => r.id);

    const hasSeen = SEEN_RULE_IDS.some(id => activeRuleIds.includes(id));
    const hasTyping = TYPING_RULE_IDS.some(id => activeRuleIds.includes(id));

    return {
      blockSeen: hasSeen,
      blockTyping: hasTyping,
      activeRuleIds
    };
  }

  static async clearAllRules(customApi = null) {
    const api = this.getDnrApi(customApi);
    if (!api) return;

    await api.updateDynamicRules({
      removeRuleIds: [...ALL_STEALTH_RULE_IDS]
    });

    if (typeof api.updateEnabledRulesets === 'function') {
      await api.updateEnabledRulesets({
        disableRulesetIds: [STATIC_RULESET_ID]
      });
    }
  }
}
