/**
 * Facebook Toolkit Pro - Chrome Alarms Scheduler
 * Manages periodic routines (birthday auto-greeter, reup runner, quota pruner)
 * resilient to service worker dormancy in MV3.
 */

import { ACTION_TYPES, STORAGE_KEYS } from '../shared/constants.js';

export const ALARM_NAMES = Object.freeze({
  BIRTHDAY_CHECKER: 'FB_TOOLKIT_BIRTHDAY_CHECKER',
  REUP_RUNNER: 'FB_TOOLKIT_REUP_RUNNER',
  QUOTA_PRUNER: 'FB_TOOLKIT_QUOTA_PRUNER'
});

export const DEFAULT_ALARM_INTERVALS_MIN = Object.freeze({
  [ALARM_NAMES.BIRTHDAY_CHECKER]: 360, // Every 6 hours
  [ALARM_NAMES.REUP_RUNNER]: 60,       // Every 1 hour
  [ALARM_NAMES.QUOTA_PRUNER]: 120      // Every 2 hours
});

// Domain helper for leap-year-aware birthday matching
export function isBirthdayToday(birthDateStr, currentDate = new Date()) {
  if (!birthDateStr || typeof birthDateStr !== 'string') return false;
  const parts = birthDateStr.split(/[-/]/);
  if (parts.length < 2) return false;

  let bMonth, bDay;
  if (parts.length >= 3) {
    if (parts[0].length === 4) {
      // YYYY-MM-DD or YYYY/MM/DD
      bMonth = parseInt(parts[1], 10);
      bDay = parseInt(parts[2], 10);
    } else {
      // MM/DD/YYYY or MM-DD-YYYY
      bMonth = parseInt(parts[0], 10);
      bDay = parseInt(parts[1], 10);
    }
  } else {
    bMonth = parseInt(parts[0], 10);
    bDay = parseInt(parts[1], 10);
  }

  const curMonth = currentDate.getMonth() + 1;
  const curDay = currentDate.getDate();
  const curYear = currentDate.getFullYear();
  const isLeapYear = (curYear % 4 === 0 && curYear % 100 !== 0) || (curYear % 400 === 0);

  if (bMonth === curMonth && bDay === curDay) return true;

  // Leap-day birthday (Feb 29) handled on Feb 28 on non-leap years
  if (bMonth === 2 && bDay === 29 && !isLeapYear) {
    if (curMonth === 2 && curDay === 28) return true;
  }

  return false;
}

// Domain helper for template token resolution
export function renderBirthdayTemplate(templateStr, friend) {
  const rawName = friend.name || friend.friendName || '';
  const tokens = rawName.trim().split(/\s+/);
  const firstName = tokens[0] || '';
  const lastName = tokens.length > 1 ? tokens.slice(1).join(' ') : '';

  return templateStr
    .replace(/\{name\}/g, rawName)
    .replace(/\{full_name\}/g, rawName)
    .replace(/\{first_name\}/g, firstName)
    .replace(/\{last_name\}/g, lastName);
}

// In-Memory fallback for pure Node.js execution without chrome.alarms
export class InMemoryAlarmsBackend {
  constructor() {
    this._alarms = new Map();
    this._listeners = [];
  }

  create(name, alarmInfo = {}) {
    const periodInMinutes = alarmInfo.periodInMinutes || null;
    const delayInMinutes = alarmInfo.delayInMinutes || periodInMinutes || 0;
    const scheduledTime = Date.now() + delayInMinutes * 60 * 1000;
    this._alarms.set(name, { name, scheduledTime, periodInMinutes });
  }

  async get(name, callback) {
    const alarm = this._alarms.get(name) ? { ...this._alarms.get(name) } : null;
    if (typeof callback === 'function') callback(alarm);
    return alarm;
  }

  async getAll(callback) {
    const list = Array.from(this._alarms.values()).map(a => ({ ...a }));
    if (typeof callback === 'function') callback(list);
    return list;
  }

  async clear(name, callback) {
    const res = this._alarms.delete(name);
    if (typeof callback === 'function') callback(res);
    return res;
  }

  async clearAll(callback) {
    const had = this._alarms.size > 0;
    this._alarms.clear();
    if (typeof callback === 'function') callback(had);
    return had;
  }

  onAlarm = {
    addListener: (fn) => { if (!this._listeners.includes(fn)) this._listeners.push(fn); },
    removeListener: (fn) => {
      const idx = this._listeners.indexOf(fn);
      if (idx !== -1) this._listeners.splice(idx, 1);
    }
  };

  trigger(name) {
    const alarm = this._alarms.get(name);
    if (alarm) {
      for (const fn of this._listeners) fn({ ...alarm });
    }
  }
}

export class AlarmsManager {
  static _backend = null;
  static _handlers = new Map();
  static _initialized = false;
  static _dependencies = {};

  static getBackend() {
    if (!AlarmsManager._backend) {
      if (typeof chrome !== 'undefined' && chrome.alarms) {
        AlarmsManager._backend = chrome.alarms;
      } else {
        AlarmsManager._backend = new InMemoryAlarmsBackend();
      }
    }
    return AlarmsManager._backend;
  }

  static setBackend(customBackend) {
    AlarmsManager._backend = customBackend;
  }

  static async init(dependencies = {}) {
    AlarmsManager._dependencies = dependencies;
    const backend = AlarmsManager.getBackend();

    // Register standard routine handlers
    AlarmsManager.registerHandler(ALARM_NAMES.BIRTHDAY_CHECKER, async (alarm) => {
      return AlarmsManager.handleBirthdayCheckerRoutine(alarm);
    });

    AlarmsManager.registerHandler(ALARM_NAMES.REUP_RUNNER, async (alarm) => {
      return AlarmsManager.handleReupRunnerRoutine(alarm);
    });

    AlarmsManager.registerHandler(ALARM_NAMES.QUOTA_PRUNER, async (alarm) => {
      return AlarmsManager.handleQuotaPrunerRoutine(alarm);
    });

    // Register alarm listener synchronously
    if (backend && backend.onAlarm && typeof backend.onAlarm.addListener === 'function') {
      try {
        backend.onAlarm.addListener(AlarmsManager.handleAlarm);
      } catch (_) {}
    }

    // Register periodic alarms if not already scheduled
    for (const [name, interval] of Object.entries(DEFAULT_ALARM_INTERVALS_MIN)) {
      const existing = await AlarmsManager.getAlarm(name);
      if (!existing) {
        await AlarmsManager.registerPeriodicAlarm(name, interval);
      }
    }

    AlarmsManager._initialized = true;
  }

  static registerHandler(name, handlerFn) {
    AlarmsManager._handlers.set(name, handlerFn);
  }

  static async registerPeriodicAlarm(name, periodInMinutes, options = {}) {
    const backend = AlarmsManager.getBackend();
    const delayInMinutes = options.delayInMinutes || periodInMinutes;
    backend.create(name, {
      periodInMinutes,
      delayInMinutes
    });
    return { name, periodInMinutes };
  }

  static async cancelAlarm(name) {
    const backend = AlarmsManager.getBackend();
    return new Promise((resolve) => {
      let called = false;
      const done = (val) => {
        if (!called) {
          called = true;
          resolve(val);
        }
      };
      const res = backend.clear(name, done);
      if (res && typeof res.then === 'function') {
        res.then(done, () => done(false));
      }
    });
  }

  static async getAlarm(name) {
    const backend = AlarmsManager.getBackend();
    return new Promise((resolve) => {
      let called = false;
      const done = (val) => {
        if (!called) {
          called = true;
          resolve(val);
        }
      };
      const res = backend.get(name, done);
      if (res && typeof res.then === 'function') {
        res.then(done, () => done(null));
      }
    });
  }

  static async getAllAlarms() {
    const backend = AlarmsManager.getBackend();
    return new Promise((resolve) => {
      let called = false;
      const done = (val) => {
        if (!called) {
          called = true;
          resolve(val);
        }
      };
      const res = backend.getAll(done);
      if (res && typeof res.then === 'function') {
        res.then(done, () => done([]));
      }
    });
  }

  static async handleAlarm(alarm) {
    if (!alarm || !alarm.name) return { handled: false, reason: 'INVALID_ALARM' };
    const handler = AlarmsManager._handlers.get(alarm.name);
    if (!handler) {
      console.warn(`[AlarmsManager] No handler registered for alarm: ${alarm.name}`);
      return { handled: false, reason: 'UNREGISTERED_HANDLER' };
    }

    try {
      const result = await handler(alarm);
      return { handled: true, alarmName: alarm.name, result };
    } catch (err) {
      console.error(`[AlarmsManager] Error executing handler for ${alarm.name}:`, err);
      return { handled: false, alarmName: alarm.name, error: err.message };
    }
  }

  // --- Routine Handlers ---

  static async handleBirthdayCheckerRoutine(alarm) {
    const { storageManager, fbApi, actionRunner } = AlarmsManager._dependencies;
    if (!fbApi || !storageManager) return { skipped: true, reason: 'NO_DEPENDENCIES' };

    const birthdays = await fbApi.fetchBirthdays();
    const stored = await storageManager.get([
      STORAGE_KEYS.BIRTHDAY_HISTORY,
      STORAGE_KEYS.BIRTHDAY_WHITELIST
    ]);
    const history = stored[STORAGE_KEYS.BIRTHDAY_HISTORY] || {};
    const rawWhitelist = stored[STORAGE_KEYS.BIRTHDAY_WHITELIST] || [];
    const whitelist = Array.isArray(rawWhitelist) ? rawWhitelist : [];
    const whitelistSet = new Set(
      whitelist.map(item => (typeof item === 'object' && item !== null ? String(item.friendId || item.id) : String(item)))
    );

    const currentYear = new Date().getFullYear();
    const results = [];

    const defaultTemplate = 'Happy birthday {first_name}! Wishing you joy and success! 🎂';

    for (const bday of birthdays) {
      const friendId = String(bday.friendId || bday.id);
      // Skip if already greeted this year
      if (history[friendId] && history[friendId].year === currentYear) {
        continue;
      }

      // Check if birthday is today (accounting for leap years)
      if (bday.isToday || isBirthdayToday(bday.birthDate)) {
        // Enforce whitelist: if friendId not in whitelist, MUST be skipped with skipped: true
        if (!whitelistSet.has(friendId)) {
          results.push({ friendId, skipped: true, reason: 'NOT_IN_WHITELIST' });
          continue;
        }

        const message = renderBirthdayTemplate(defaultTemplate, bday);
        const executor = async () => fbApi.sendBirthdayGreeting(friendId, message, 'message');

        let res;
        if (actionRunner) {
          res = await actionRunner.execute(ACTION_TYPES.BIRTHDAY_GREETING, { id: friendId }, executor, {
            throwOnError: false
          });
        } else {
          res = await executor();
        }

        if (res && res.success) {
          history[friendId] = {
            year: currentYear,
            timestamp: Date.now(),
            channel: 'message'
          };
          results.push({ friendId, greeted: true, channel: 'message' });
        }
      }
    }

    const greetedCount = results.filter(r => r.greeted).length;
    const skippedCount = results.filter(r => r.skipped).length;

    if (greetedCount > 0) {
      await storageManager.set({ [STORAGE_KEYS.BIRTHDAY_HISTORY]: history });
    }

    return {
      processed: results.length,
      greetedCount,
      skippedCount,
      results
    };
  }

  static async handleReupRunnerRoutine(alarm) {
    const { storageManager, fbApi, actionRunner } = AlarmsManager._dependencies;
    if (!fbApi || !storageManager) return { skipped: true, reason: 'NO_DEPENDENCIES' };

    const stored = await storageManager.get(STORAGE_KEYS.REUP_QUEUE);
    const queue = Array.isArray(stored[STORAGE_KEYS.REUP_QUEUE]) ? stored[STORAGE_KEYS.REUP_QUEUE] : [];

    if (queue.length === 0) {
      return { processed: 0, message: 'Queue is empty' };
    }

    const nextItem = queue.shift();
    const executor = async () => fbApi.publishPost({
      text: nextItem.text || nextItem.title,
      isReel: Boolean(nextItem.isReel)
    });

    let res;
    if (actionRunner) {
      res = await actionRunner.execute(ACTION_TYPES.REUP_POST, nextItem, executor, { throwOnError: false });
    } else {
      res = await executor();
    }

    await storageManager.set({ [STORAGE_KEYS.REUP_QUEUE]: queue });
    return { processed: 1, published: res.success, targetId: nextItem.id || nextItem.guid };
  }

  static async handleQuotaPrunerRoutine(alarm) {
    const { storageManager } = AlarmsManager._dependencies;
    if (storageManager && typeof storageManager.pruneRollingQuotas === 'function') {
      const pruned = await storageManager.pruneRollingQuotas();
      return { pruned: true, quotas: pruned };
    }
    return { pruned: false };
  }
}
