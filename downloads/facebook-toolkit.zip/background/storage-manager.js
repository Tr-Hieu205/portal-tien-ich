/**
 * Facebook Toolkit Pro - Storage Manager
 * Asynchronous persistence layer wrapping chrome.storage.local
 * Includes headless InMemoryStorageBackend for Node.js unit tests.
 */

import {
  STORAGE_KEYS,
  STORAGE_DEFAULTS,
  ACTION_TYPES,
  CIRCUIT_BREAKER_STATES
} from '../shared/constants.js';

export class InMemoryStorageBackend {
  constructor() {
    this._store = new Map();
  }

  async get(keys) {
    if (keys === null || keys === undefined) {
      const obj = {};
      for (const [k, v] of this._store.entries()) {
        obj[k] = JSON.parse(JSON.stringify(v));
      }
      return obj;
    }
    if (typeof keys === 'string') {
      const val = this._store.get(keys);
      return val !== undefined ? { [keys]: JSON.parse(JSON.stringify(val)) } : {};
    }
    if (Array.isArray(keys)) {
      const obj = {};
      for (const k of keys) {
        if (this._store.has(k)) {
          obj[k] = JSON.parse(JSON.stringify(this._store.get(k)));
        }
      }
      return obj;
    }
    if (typeof keys === 'object') {
      const obj = {};
      for (const [k, defaultVal] of Object.entries(keys)) {
        if (this._store.has(k)) {
          obj[k] = JSON.parse(JSON.stringify(this._store.get(k)));
        } else {
          obj[k] = JSON.parse(JSON.stringify(defaultVal));
        }
      }
      return obj;
    }
    return {};
  }

  async set(items) {
    for (const [k, v] of Object.entries(items)) {
      this._store.set(k, JSON.parse(JSON.stringify(v)));
    }
  }

  async remove(keys) {
    const arr = Array.isArray(keys) ? keys : [keys];
    for (const k of arr) {
      this._store.delete(k);
    }
  }

  async clear() {
    this._store.clear();
  }

  async getBytesInUse(keys) {
    return 1024;
  }
}

export const DEFAULT_STORAGE_SCHEMA = STORAGE_DEFAULTS;

export class StorageManager {
  constructor(customBackend = null) {
    if (customBackend) {
      this.backend = customBackend;
    } else if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      this.backend = chrome.storage.local;
    } else {
      this.backend = new InMemoryStorageBackend();
    }
  }

  async init() {
    const current = await this.get(null);
    const toSet = {};
    for (const [key, defaultValue] of Object.entries(DEFAULT_STORAGE_SCHEMA)) {
      if (current[key] === undefined) {
        toSet[key] = defaultValue;
      }
    }
    if (Object.keys(toSet).length > 0) {
      await this.set(toSet);
    }
    return this.get(null);
  }

  async get(keys = null) {
    return new Promise((resolve, reject) => {
      try {
        const res = this.backend.get(keys);
        if (res && typeof res.then === 'function') {
          res.then(resolve).catch(reject);
        } else {
          this.backend.get(keys, (items) => {
            if (typeof chrome !== 'undefined' && chrome.runtime?.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve(items || {});
            }
          });
        }
      } catch (err) {
        reject(err);
      }
    });
  }

  async set(items) {
    return new Promise((resolve, reject) => {
      try {
        const res = this.backend.set(items);
        if (res && typeof res.then === 'function') {
          res.then(resolve).catch(reject);
        } else {
          this.backend.set(items, () => {
            if (typeof chrome !== 'undefined' && chrome.runtime?.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve();
            }
          });
        }
      } catch (err) {
        reject(err);
      }
    });
  }

  async update(key, updaterFn) {
    const data = await this.get(key);
    const currentValue = data[key] !== undefined ? data[key] : DEFAULT_STORAGE_SCHEMA[key];
    const updatedValue = await updaterFn(currentValue);
    await this.set({ [key]: updatedValue });
    return updatedValue;
  }

  async remove(keys) {
    return new Promise((resolve, reject) => {
      try {
        const res = this.backend.remove(keys);
        if (res && typeof res.then === 'function') {
          res.then(resolve).catch(reject);
        } else {
          this.backend.remove(keys, () => resolve());
        }
      } catch (err) {
        reject(err);
      }
    });
  }

  async clear() {
    return new Promise((resolve, reject) => {
      try {
        const res = this.backend.clear();
        if (res && typeof res.then === 'function') {
          res.then(resolve).catch(reject);
        } else {
          this.backend.clear(() => resolve());
        }
      } catch (err) {
        reject(err);
      }
    });
  }

  async reset(section = null) {
    if (!section) {
      await this.set(DEFAULT_STORAGE_SCHEMA);
    } else if (DEFAULT_STORAGE_SCHEMA[section] !== undefined) {
      await this.set({ [section]: DEFAULT_STORAGE_SCHEMA[section] });
    }
  }

  // Domain Helper Methods
  async getSimulationMode() {
    const { simulationMode } = await this.get(STORAGE_KEYS.SIMULATION_MODE);
    return simulationMode !== undefined ? simulationMode : true;
  }

  async setSimulationMode(enabled) {
    await this.set({ [STORAGE_KEYS.SIMULATION_MODE]: Boolean(enabled) });
  }

  async getStealthSettings() {
    const { stealthSettings } = await this.get(STORAGE_KEYS.STEALTH_SETTINGS);
    return stealthSettings || DEFAULT_STORAGE_SCHEMA.stealthSettings;
  }

  async setStealthSettings(patch) {
    return this.update(STORAGE_KEYS.STEALTH_SETTINGS, (curr) => ({ ...curr, ...patch }));
  }

  async getRollingQuotas() {
    const { rollingQuotas24h } = await this.get(STORAGE_KEYS.ROLLING_QUOTAS);
    return rollingQuotas24h || DEFAULT_STORAGE_SCHEMA.rollingQuotas24h;
  }

  async recordQuotaTimestamp(actionType, timestamp = Date.now()) {
    return this.update(STORAGE_KEYS.ROLLING_QUOTAS, (quotas) => {
      const list = Array.isArray(quotas[actionType]) ? [...quotas[actionType]] : [];
      list.push(timestamp);
      return { ...quotas, [actionType]: list };
    });
  }

  async pruneRollingQuotas(windowMs = 86400000) {
    const cutoff = Date.now() - windowMs;
    return this.update(STORAGE_KEYS.ROLLING_QUOTAS, (quotas) => {
      const pruned = {};
      for (const [act, times] of Object.entries(quotas)) {
        pruned[act] = Array.isArray(times) ? times.filter(t => t > cutoff) : [];
      }
      return pruned;
    });
  }

  async getCircuitBreakerState() {
    const { circuitBreaker } = await this.get(STORAGE_KEYS.CIRCUIT_BREAKER);
    return circuitBreaker || DEFAULT_STORAGE_SCHEMA.circuitBreaker;
  }

  async saveCircuitBreakerState(state) {
    return this.update(STORAGE_KEYS.CIRCUIT_BREAKER, (curr) => ({ ...curr, ...state }));
  }

  async appendActionLog(logEntry, maxLogs = 500) {
    return this.update(STORAGE_KEYS.ACTION_LOGS, (logs) => {
      const currentLogs = Array.isArray(logs) ? logs : [];
      const updated = [logEntry, ...currentLogs];
      return updated.slice(0, maxLogs);
    });
  }

  async getBirthdayWhitelist() {
    const data = await this.get(STORAGE_KEYS.BIRTHDAY_WHITELIST);
    return data[STORAGE_KEYS.BIRTHDAY_WHITELIST] || DEFAULT_STORAGE_SCHEMA[STORAGE_KEYS.BIRTHDAY_WHITELIST] || [];
  }

  async setBirthdayWhitelist(whitelist) {
    const rawList = Array.isArray(whitelist) ? whitelist : [];
    const list = rawList.map(item => (typeof item === 'object' && item !== null ? String(item.friendId || item.id) : String(item)));
    await this.set({ [STORAGE_KEYS.BIRTHDAY_WHITELIST]: list });
    return list;
  }
}
