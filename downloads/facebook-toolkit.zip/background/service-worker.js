/**
 * Facebook Toolkit Pro - Background Service Worker Core (MV3)
 * Central coordinator managing lifecycle, message dispatching, and background automation.
 */

import { StorageManager } from './storage-manager.js';
import { AlarmsManager, ALARM_NAMES } from './alarms-manager.js';
import { DnrManager } from './dnr-manager.js';
import { FacebookApiClient } from './fb-api.js';
import { ActionRunner } from '../shared/action-runner.js';
import { RateLimiter } from '../shared/rate-limiter.js';
import { CircuitBreaker } from '../shared/circuit-breaker.js';
import {
  ACTION_TYPES,
  STORAGE_KEYS,
  FB_ERROR_CODES
} from '../shared/constants.js';

// 1. Synchronous Global Instantiation
const storageManager = new StorageManager();
const rateLimiter = new RateLimiter();
const circuitBreaker = new CircuitBreaker();
const actionRunner = new ActionRunner({
  storageManager,
  rateLimiter,
  circuitBreaker,
  isSimulation: true
});
const fbApi = new FacebookApiClient({
  storageManager,
  actionRunner
});

// Cache for tokens bridged from content script
let activeSessionTokens = {
  userId: null,
  dtsg: null,
  lastUpdated: 0
};

// 2. Extension Lifecycle Listeners (Registered Synchronously at Module Root)
if (typeof chrome !== 'undefined' && chrome.runtime) {
  if (chrome.runtime.onInstalled) {
    chrome.runtime.onInstalled.addListener(async (details) => {
      try {
        // Initialize storage with defaults
        await storageManager.init();

        // Synchronize DNR stealth rules
        const stealthSettings = await storageManager.getStealthSettings();
        if (typeof DnrManager !== 'undefined' && DnrManager.updateStealthRules) {
          await DnrManager.updateStealthRules(stealthSettings);
        }

        // Initialize alarms
        await AlarmsManager.init({ storageManager, fbApi, actionRunner });
      } catch (err) {
        console.error('[ServiceWorker] Error during onInstalled initialization:', err);
      }
    });
  }

  if (chrome.runtime.onStartup) {
    chrome.runtime.onStartup.addListener(async () => {
      try {
        await AlarmsManager.init({ storageManager, fbApi, actionRunner });
      } catch (err) {
        console.error('[ServiceWorker] Error during onStartup:', err);
      }
    });
  }

  // 3. Centralized Message Dispatcher (Registered Synchronously at Module Root)
  if (chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || typeof message !== 'object') {
        sendResponse({ success: false, error: 'Invalid message payload' });
        return false;
      }

      // Handle message asynchronously
      handleIncomingMessage(message, sender)
        .then((result) => sendResponse({ success: true, data: result }))
        .catch((err) => {
          sendResponse({
            success: false,
            error: err.message,
            code: err.code || null
          });
        });

      return true; // Keep message channel open for async response
    });
  }
}

// 4. Message Routing Implementation
export async function handleIncomingMessage(message, sender) {
  const type = message.type || message.action;

  switch (type) {
    case 'PING':
      return { status: 'PONG', timestamp: Date.now() };

    case 'GET_SESSION_INFO': {
      return await fbApi.getSessionInfo();
    }

    case 'SET_AVATAR_SHIELD': {
      const enable = Boolean(message.enable);
      return await fbApi.setAvatarShield(enable);
    }

    case 'GET_STEALTH_SETTINGS': {
      return await storageManager.getStealthSettings();
    }

    case 'UPDATE_STEALTH_SETTINGS': {
      const newSettings = message.settings || {};
      const updated = await storageManager.setStealthSettings(newSettings);
      if (typeof DnrManager !== 'undefined' && DnrManager.updateStealthRules) {
        await DnrManager.updateStealthRules(updated);
      }
      return updated;
    }

    case 'EXECUTE_ACTION': {
      const { actionType, target, options } = message;
      return await actionRunner.execute(actionType, target, null, options);
    }

    case 'GET_STORAGE_DATA': {
      return await storageManager.get(message.keys || null);
    }

    case 'SET_STORAGE_DATA': {
      await storageManager.set(message.items || {});
      return { saved: true };
    }

    case 'CONTENT_SCRIPT_TOKEN_REPORT':
    case 'SESSION_INFO_UPDATE': {
      const { userId, dtsg } = message.payload || {};
      if (userId) {
        activeSessionTokens.userId = userId;
      }
      if (dtsg) {
        activeSessionTokens.dtsg = dtsg;
      }
      if (userId || dtsg) {
        activeSessionTokens.lastUpdated = Date.now();
        fbApi.setBridgeCredentials(activeSessionTokens.userId, activeSessionTokens.dtsg);
      }
      return { acknowledged: true };
    }

    case 'GET_ALARMS': {
      return await AlarmsManager.getAllAlarms();
    }

    case 'TRIGGER_ALARM': {
      return await AlarmsManager.handleAlarm({ name: message.alarmName });
    }

    case 'GET_DASHBOARD_STATE': {
      const stealthSettings = await storageManager.getStealthSettings();
      let session = null;
      try {
        session = await fbApi.getSessionInfo();
      } catch (sessionErr) {
        session = {
          userId: activeSessionTokens.userId || null,
          dtsg: activeSessionTokens.dtsg || null,
          isShielded: false,
          connected: false,
          error: sessionErr.message
        };
      }
      const isSimulation = actionRunner.isSimulation();
      const circuitBreakerState = {
        state: circuitBreaker.getState(),
        pausedUntil: circuitBreaker.pausedUntil || 0,
        failureCount: circuitBreaker.failureCount || 0,
        consecutiveTrips: circuitBreaker.consecutiveTrips || 0
      };
      const quotas = {};
      for (const act of Object.values(ACTION_TYPES)) {
        quotas[act] = rateLimiter.checkQuota(act);
      }
      const alarms = await AlarmsManager.getAllAlarms();
      const actionLogs = (await storageManager.get(STORAGE_KEYS.ACTION_LOGS))[STORAGE_KEYS.ACTION_LOGS] || [];
      const reupQueue = (await storageManager.get(STORAGE_KEYS.REUP_QUEUE))[STORAGE_KEYS.REUP_QUEUE] || [];
      const birthdayWhitelist = (await storageManager.get(STORAGE_KEYS.BIRTHDAY_WHITELIST))[STORAGE_KEYS.BIRTHDAY_WHITELIST] || [];
      return {
        session,
        isSimulation,
        simulationMode: isSimulation,
        stealthSettings,
        circuitBreaker: circuitBreakerState,
        quotas,
        alarms,
        actionLogs,
        reupQueue,
        birthdayWhitelist
      };
    }

    case 'SET_SIMULATION_MODE': {
      const enabled = Boolean(message.enabled);
      actionRunner.setSimulation(enabled);
      fbApi.isSimulation = enabled;
      await storageManager.set({ [STORAGE_KEYS.SIMULATION_MODE]: enabled });
      return { simulationMode: enabled };
    }

    case 'RESET_CIRCUIT_BREAKER': {
      if (typeof circuitBreaker.reset === 'function') {
        circuitBreaker.reset();
      }
      return { state: circuitBreaker.getState() };
    }

    case 'SCAN_FRIENDS': {
      const friends = await fbApi.scanFriends();
      const scored = fbApi.computeInactivity(friends);
      await storageManager.set({ [STORAGE_KEYS.CACHED_FRIENDS]: scored });
      return scored;
    }

    case 'BATCH_UNFRIEND': {
      const friendIds = message.friendIds || [];
      return await actionRunner.executeBatch(
        ACTION_TYPES.UNFRIEND,
        friendIds,
        (id) => () => fbApi.unfriend(id),
        { fastMode: Boolean(message.fastMode) }
      );
    }

    case 'BATCH_POKE': {
      const friendIds = message.friendIds || [];
      return await actionRunner.executeBatch(
        ACTION_TYPES.POKE,
        friendIds,
        (id) => () => fbApi.poke(id),
        { fastMode: Boolean(message.fastMode) }
      );
    }

    case 'BATCH_REACT_STORIES': {
      const storyIds = message.storyIds || [];
      const reaction = message.reaction || 'LOVE';
      return await actionRunner.executeBatch(
        ACTION_TYPES.STORY_REACT,
        storyIds,
        (id) => () => fbApi.reactStory(id, reaction),
        { fastMode: Boolean(message.fastMode) }
      );
    }

    case 'SCAN_TIMELINE': {
      return await fbApi.scanTimeline(message.filter || {});
    }

    case 'BATCH_CLEANUP_POSTS': {
      const postIds = message.postIds || [];
      const subAction = (message.subAction || 'DELETE').toUpperCase();
      let actionType = ACTION_TYPES.POST_DELETE;
      let executorFn = (id) => () => fbApi.deletePost(id);
      if (subAction === 'HIDE') {
        actionType = ACTION_TYPES.POST_HIDE;
        executorFn = (id) => () => fbApi.hidePost(id);
      } else if (subAction === 'ARCHIVE') {
        actionType = ACTION_TYPES.POST_ARCHIVE;
        executorFn = (id) => () => fbApi.archivePost(id);
      }
      return await actionRunner.executeBatch(
        actionType,
        postIds,
        executorFn,
        { fastMode: Boolean(message.fastMode) }
      );
    }

    case 'FETCH_ALBUMS': {
      return await fbApi.fetchAlbums();
    }

    case 'FETCH_ALBUM_PHOTOS': {
      return await fbApi.fetchAlbumPhotos(message.albumId);
    }

    case 'FETCH_VIDEOS': {
      return await fbApi.fetchVideos();
    }

    case 'FETCH_VIDEO_STREAMS': {
      return await fbApi.fetchVideoStreams(message.videoUrl);
    }

    case 'FETCH_THREADS': {
      return await fbApi.fetchThreads();
    }

    case 'FETCH_BIRTHDAYS': {
      return await fbApi.fetchBirthdays();
    }

    case 'GET_BIRTHDAY_WHITELIST': {
      const stored = await storageManager.get(STORAGE_KEYS.BIRTHDAY_WHITELIST);
      return stored[STORAGE_KEYS.BIRTHDAY_WHITELIST] || [];
    }

    case 'SET_BIRTHDAY_WHITELIST': {
      const rawList = message.whitelist ?? message.friendIds ?? message.data ?? [];
      const whitelist = Array.isArray(rawList)
        ? rawList.map(item => (typeof item === 'object' && item !== null ? String(item.friendId || item.id) : String(item)))
        : [];
      await storageManager.set({ [STORAGE_KEYS.BIRTHDAY_WHITELIST]: whitelist });
      return { saved: true, whitelist };
    }

    case 'SEND_BIRTHDAY_GREETING': {
      const { friendId, message: greetingText } = message;
      return await actionRunner.execute(
        ACTION_TYPES.BIRTHDAY_GREETING,
        { id: friendId },
        () => fbApi.sendBirthdayGreeting(friendId, greetingText, 'message'),
        { fastMode: Boolean(message.fastMode) }
      );
    }

    case 'GET_REUP_QUEUE': {
      const stored = await storageManager.get(STORAGE_KEYS.REUP_QUEUE);
      return stored[STORAGE_KEYS.REUP_QUEUE] || [];
    }

    case 'ADD_REUP_ITEM': {
      const stored = await storageManager.get(STORAGE_KEYS.REUP_QUEUE);
      const queue = stored[STORAGE_KEYS.REUP_QUEUE] || [];
      queue.push(message.item);
      await storageManager.set({ [STORAGE_KEYS.REUP_QUEUE]: queue });
      return queue;
    }

    case 'REMOVE_REUP_ITEM': {
      const stored = await storageManager.get(STORAGE_KEYS.REUP_QUEUE);
      let queue = stored[STORAGE_KEYS.REUP_QUEUE] || [];
      queue = queue.filter(item => item.id !== message.itemId && item.guid !== message.itemId);
      await storageManager.set({ [STORAGE_KEYS.REUP_QUEUE]: queue });
      return queue;
    }

    case 'CLEAR_ACTION_LOGS': {
      await storageManager.set({ [STORAGE_KEYS.ACTION_LOGS]: [] });
      return { cleared: true };
    }

    default:
      throw new Error(`Unknown message type: ${type}`);
  }
}

// 5. Initialize Alarms Manager on worker wakeup
AlarmsManager.init({ storageManager, fbApi, actionRunner }).catch((err) => {
  // Graceful catch for initial load
});

export function getActiveSessionTokens() {
  return activeSessionTokens;
}

export {
  storageManager,
  rateLimiter,
  circuitBreaker,
  actionRunner,
  fbApi,
  activeSessionTokens
};
