/**
 * Facebook Toolkit Pro - Dashboard SPA Controller (MV3)
 */

let state = {
  isSimulation: true,
  session: null,
  stealth: { blockSeen: true, blockTyping: true },
  circuitBreaker: { state: 'CLOSED' },
  quotas: {},
  friends: [],
  selectedFriends: new Set(),
  posts: [],
  selectedPosts: new Set(),
  albums: [],
  threads: [],
  birthdays: [],
  birthdayWhitelist: new Set(),
  reupQueue: [],
  actionLogs: []
};

document.addEventListener('DOMContentLoaded', async () => {
  initNavigation();
  initEventListeners();
  await refreshDashboardState();
});

// 1. Navigation Controller
function initNavigation() {
  const navButtons = document.querySelectorAll('.sidebar-nav .nav-item');
  const panes = document.querySelectorAll('.tab-pane');

  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      navButtons.forEach(b => b.classList.remove('active'));
      panes.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const pane = document.getElementById(targetTab);
      if (pane) pane.classList.add('active');
    });
  });
}

// 2. Global State Synchronization
async function refreshDashboardState() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'GET_DASHBOARD_STATE' });
    if (!res || !res.success || !res.data) return;

    const data = res.data;
    state.isSimulation = Boolean(data.simulationMode);
    state.session = data.session || null;
    state.stealth = data.stealthSettings || { blockSeen: true, blockTyping: true };
    state.circuitBreaker = data.circuitBreaker || { state: 'CLOSED' };
    state.quotas = data.quotas || {};
    state.actionLogs = data.actionLogs || [];
    state.reupQueue = data.reupQueue || [];

    updateHeaderAndSidebarUI();
    updateStealthUI();
    renderLogsTable();
    renderReupQueue();

    // Populate initial dropdowns and tables if not loaded
    if (state.albums.length === 0) loadAlbums();
    if (state.threads.length === 0) loadThreads();

    await loadBirthdayWhitelist();
    if (state.friends.length === 0) {
      await scanFriendsList();
    } else {
      renderFriendsTable();
      renderBirthdayFriendsList();
    }

    if (state.posts.length === 0) {
      await scanTimeline();
    } else {
      renderPostsTable();
    }
  } catch (err) {
    console.error('[Dashboard] Error refreshing state:', err);
  }
}

function updateHeaderAndSidebarUI() {
  // Simulation Pill in Sidebar & Alert Banner
  const simBtn = document.getElementById('dashSimToggleBtn');
  const simText = document.getElementById('dashSimText');
  const settingsSimState = document.getElementById('settingsSimState');
  const banner = document.getElementById('simModeAlertBanner');
  const bannerIcon = document.getElementById('simBannerIcon');
  const bannerText = document.getElementById('simBannerText');
  const bannerBtn = document.getElementById('bannerToggleSimBtn');

  if (state.isSimulation) {
    if (simBtn) simBtn.className = 'pill-badge pill-simulation';
    if (simText) simText.textContent = 'Giả lập';
    if (settingsSimState) {
      settingsSimState.textContent = 'Giả lập (Simulation - An toàn 100%)';
      settingsSimState.className = 'text-emerald';
    }
    if (banner) {
      banner.style.background = 'rgba(59, 130, 246, 0.12)';
      banner.style.borderColor = 'rgba(59, 130, 246, 0.35)';
      if (bannerIcon) bannerIcon.textContent = '🛡️';
      if (bannerText) bannerText.innerHTML = 'Tiện ích đang ở chế độ <strong>Giả lập (Simulation)</strong>: Các thao tác được chạy thử an toàn. Để <strong>HỦY KẾT BẠN THẬT TRÊN FACEBOOK</strong>, hãy chuyển sang chế độ <strong>Trực tiếp (Live)</strong>.';
      if (bannerBtn) {
        bannerBtn.textContent = 'Chuyển sang Live 🟢';
        bannerBtn.className = 'btn btn-sm btn-primary';
      }
    }
  } else {
    if (simBtn) simBtn.className = 'pill-badge pill-live';
    if (simText) simText.textContent = 'Trực tiếp (Live)';
    if (settingsSimState) {
      settingsSimState.textContent = 'Thực tế (Live - Gửi request thật)';
      settingsSimState.className = 'text-danger';
    }
    if (banner) {
      banner.style.background = 'rgba(16, 185, 129, 0.12)';
      banner.style.borderColor = 'rgba(16, 185, 129, 0.35)';
      if (bannerIcon) bannerIcon.textContent = '🟢';
      if (bannerText) bannerText.innerHTML = 'Tiện ích đang ở chế độ <strong>TRỰC TIẾP (LIVE)</strong>: Thao tác hủy bạn bè sẽ được gửi <strong>THẬT TRÊN FACEBOOK</strong> của bạn. Hãy thao tác cẩn thận!';
      if (bannerBtn) {
        bannerBtn.textContent = 'Bật Giả lập 🛡️';
        bannerBtn.className = 'btn btn-sm btn-secondary';
      }
    }
  }

  // Circuit Breaker Status
  const breakerText = document.getElementById('dashBreakerText');
  const settingsBreaker = document.getElementById('settingsBreakerState');
  const cbState = state.circuitBreaker?.state || 'CLOSED';
  if (breakerText) {
    breakerText.textContent = `${cbState} (${cbState === 'CLOSED' ? 'Bình thường' : 'Tạm ngưng'})`;
    breakerText.className = cbState === 'CLOSED' ? 'text-success' : 'text-danger';
  }
  if (settingsBreaker) {
    settingsBreaker.textContent = cbState;
    settingsBreaker.className = cbState === 'CLOSED' ? 'text-success' : 'text-danger';
  }

  // User Profile
  const uNameEl = document.getElementById('sidebarUserName');
  const uIdEl = document.getElementById('sidebarUserId');
  if (state.isSimulation) {
    if (uNameEl) uNameEl.textContent = 'Mô phỏng (Offline Sandbox)';
    if (uIdEl) uIdEl.textContent = `UID: ${state.session?.userId || '100080000000001'}`;
  } else if (state.session && state.session.userId && state.session.connected !== false) {
    if (uNameEl) uNameEl.textContent = state.session.userName || 'Người dùng Facebook';
    if (uIdEl) uIdEl.textContent = `UID: ${state.session.userId}`;
  } else {
    if (uNameEl) uNameEl.innerHTML = '<span style="color:#f59e0b;">Chưa kết nối FB</span>';
    if (uIdEl) {
      uIdEl.innerHTML = '<a href="https://www.facebook.com" target="_blank" style="color:var(--neon-primary, #60a5fa);text-decoration:underline;">👉 Mở Facebook để đăng nhập</a>';
    }
  }
}

function updateStealthUI() {
  const shieldToggle = document.getElementById('dashAvatarShieldToggle');
  const shieldStatus = document.getElementById('avatarShieldStatus');
  const seenToggle = document.getElementById('dashBlockSeenToggle');
  const typingToggle = document.getElementById('dashBlockTypingToggle');

  const isShielded = Boolean(state.session?.isShielded);
  if (shieldToggle) shieldToggle.checked = isShielded;
  if (shieldStatus) {
    shieldStatus.textContent = isShielded ? 'Đang bật (Có viền bảo vệ)' : 'Đang tắt';
    shieldStatus.className = isShielded ? 'text-success' : 'text-muted';
  }

  if (seenToggle) seenToggle.checked = Boolean(state.stealth.blockSeen);
  if (typingToggle) typingToggle.checked = Boolean(state.stealth.blockTyping);
}

// 3. Tab 1: Friend Filtering & Mass Interaction
async function scanFriendsList() {
  const btn = document.getElementById('scanFriendsBtn');
  if (btn) btn.disabled = true;

  try {
    const res = await chrome.runtime.sendMessage({ type: 'SCAN_FRIENDS' });
    const friendsData = Array.isArray(res)
      ? res
      : (res?.data || res?.friends || (res?.success && Array.isArray(res?.data) ? res.data : []));

    if (Array.isArray(friendsData)) {
      state.friends = friendsData;
      renderFriendsTable();
      renderBirthdayFriendsList();
    } else {
      alert('Không thể quét danh sách bạn bè: ' + (res?.error || 'Lỗi không xác định'));
    }
  } catch (err) {
    console.error('Scan friends error:', err);
  } finally {
    if (btn) btn.disabled = false;
  }
}
      alert('Không thể quét danh sách bạn bè: ' + (res?.error || 'Lỗi không xác định'));
    }
  } catch (err) {
    console.error('Scan friends error:', err);
  } finally {
    if (btn) btn.disabled = false;
  }
}

function getFriendAvatarUrl(name, id, avatarUrl) {
  if (avatarUrl && !avatarUrl.includes('graph.facebook.com/10008')) {
    return avatarUrl;
  }
  const colors = ['#f43f5e', '#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#06b6d4', '#ec4899', '#6366f1'];
  const charCode = (id ? String(id).charCodeAt(String(id).length - 1) : 0) % colors.length;
  const bg = colors[charCode];
  const initial = (name || 'U').trim().charAt(0).toUpperCase();
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80"><rect width="80" height="80" rx="40" fill="${bg}"/><text x="50%" y="54%" text-anchor="middle" dominant-baseline="middle" font-family="-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif" font-weight="700" font-size="34" fill="#ffffff">${initial}</text></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function renderFriendsTable() {
  const tbody = document.getElementById('friendsTableBody');
  if (!tbody) return;

  const tierFilter = document.getElementById('friendsTierFilter')?.value || 'ALL';
  const statusFilter = document.getElementById('friendsStatusFilter')?.value || 'ALL';
  const inactiveDaysFilter = parseInt(document.getElementById('friendsInactiveDaysFilter')?.value || '0', 10);
  const query = (document.getElementById('friendsSearchInput')?.value || '').toLowerCase().trim();

  let filtered = [...state.friends];

  if (tierFilter !== 'ALL') {
    filtered = filtered.filter(f => f.classification === tierFilter);
  }

  if (statusFilter === 'LOCKED') {
    filtered = filtered.filter(f => Boolean(f.isLocked || f.accountStatus === 'LOCKED'));
  } else if (statusFilter === 'ACTIVE') {
    filtered = filtered.filter(f => !f.isLocked && f.accountStatus !== 'LOCKED');
  }

  if (inactiveDaysFilter > 0) {
    filtered = filtered.filter(f => {
      const days = f.daysSinceLastInteraction ?? f.daysInactive ?? 0;
      return days >= inactiveDaysFilter;
    });
  }

  if (query) {
    filtered = filtered.filter(f =>
      (f.name && f.name.toLowerCase().includes(query)) ||
      (f.id && String(f.id).includes(query))
    );
  }

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" class="text-center text-muted py-6">Không tìm thấy bạn bè phù hợp với bộ lọc.</td></tr>`;
    updateSelectedFriendsCount();
    return;
  }

  tbody.innerHTML = filtered.map(f => {
    const isChecked = state.selectedFriends.has(f.id);
    let tagClass = 'tag-moderate';
    let tagLabel = 'Vừa phải';
    if (f.classification === 'ACTIVE') {
      tagClass = 'tag-active';
      tagLabel = 'Tích cực';
    } else if (f.classification === 'DEAD_INACTIVE') {
      tagClass = 'tag-dead';
      tagLabel = 'Không tương tác';
    }

    const isLocked = Boolean(f.isLocked || f.accountStatus === 'LOCKED');
    const statusBadge = isLocked
      ? '<span class="badge-tag tag-locked" title="Tài khoản đã bị khóa / vô hiệu hóa / checkpoint">🔒 Bị khóa</span>'
      : '<span class="badge-tag tag-normal" title="Tài khoản đang hoạt động bình thường">● Hoạt động</span>';

    const daysInactive = f.daysSinceLastInteraction ?? f.daysInactive ?? 0;
    let daysHuman = `${daysInactive} ngày`;
    if (daysInactive >= 365) {
      daysHuman = `${daysInactive} ngày (~${(daysInactive / 365).toFixed(1)} năm)`;
    } else if (daysInactive >= 60) {
      daysHuman = `${daysInactive} ngày (~${Math.round(daysInactive / 30)} tháng)`;
    }

    let daysClass = 'text-success';
    if (daysInactive >= 180) daysClass = 'text-danger';
    else if (daysInactive >= 30) daysClass = 'text-warning';

    const avatarSrc = getFriendAvatarUrl(f.name, f.id, f.avatarUrl);
    const profileUrl = f.profileUrl || `https://www.facebook.com/${f.id}`;

    return `
      <tr>
        <td><input type="checkbox" class="friend-row-checkbox" data-id="${f.id}" ${isChecked ? 'checked' : ''}></td>
        <td>
          <div class="friend-cell">
            <a href="${escapeHtml(profileUrl)}" target="_blank" rel="noopener noreferrer" class="friend-avatar-wrap ${isLocked ? 'is-locked' : ''}" title="Nhấp để xem trang cá nhân Facebook">
              <img src="${escapeHtml(avatarSrc)}" alt="" class="friend-avatar-img" onerror="this.onerror=null; this.src='../icons/icon48.png';">
              ${isLocked ? '<span class="locked-mini-badge" title="Tài khoản đã bị khóa">🔒</span>' : ''}
            </a>
            <div class="friend-meta-name">
              <a href="${escapeHtml(profileUrl)}" target="_blank" rel="noopener noreferrer" class="friend-profile-link" title="Mở trang cá nhân Facebook">
                ${escapeHtml(f.name || 'Người dùng')}
              </a>
              <small class="text-muted">${f.mutualFriends ?? 0} bạn chung</small>
            </div>
          </div>
        </td>
        <td>
          <a href="${escapeHtml(profileUrl)}" target="_blank" rel="noopener noreferrer" class="mono text-muted" style="text-decoration:none;" title="Mở Facebook UID ${escapeHtml(f.id)}">
            <code>${escapeHtml(f.id)}</code> ↗
          </a>
        </td>
        <td>${statusBadge}</td>
        <td><strong class="${daysClass}">${daysHuman}</strong></td>
        <td>${f.messageCount ?? 0}</td>
        <td>${f.reactionCount ?? 0}</td>
        <td><strong>${f.inactivityScore ?? f.interactionScore ?? 0}</strong>/100</td>
        <td><span class="badge-tag ${tagClass}">${tagLabel}</span></td>
        <td>
          <div style="display:flex; gap:6px; align-items:center;">
            <a href="${escapeHtml(profileUrl)}" target="_blank" rel="noopener noreferrer" class="btn-profile-link" title="Xem trang cá nhân Facebook">
              🔗 FB
            </a>
            <button type="button" class="btn-single-unfriend" data-id="${f.id}" data-name="${escapeHtml(f.name || f.id)}" title="Hủy kết bạn với người này">
              ❌ Hủy
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  // Attach row checkbox handlers
  tbody.querySelectorAll('.friend-row-checkbox').forEach(cb => {
    cb.addEventListener('change', (e) => {
      const id = e.target.getAttribute('data-id');
      if (e.target.checked) {
        state.selectedFriends.add(id);
      } else {
        state.selectedFriends.delete(id);
      }
      updateSelectedFriendsCount();
    });
  });

  // Attach single unfriend handlers
  tbody.querySelectorAll('.btn-single-unfriend').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = e.currentTarget.getAttribute('data-id');
      const name = e.currentTarget.getAttribute('data-name');
      if (!confirm(`Bạn có chắc chắn muốn HỦY KẾT BẠN với "${name}" (UID: ${id}) không?\nThao tác sẽ tự động xóa nick khỏi danh sách.`)) {
        return;
      }
      btn.disabled = true;
      try {
        const res = await chrome.runtime.sendMessage({ type: 'BATCH_UNFRIEND', friendIds: [id] });
        const isSuccess = Boolean(res && (res.success || Array.isArray(res)));
        if (isSuccess) {
          state.friends = state.friends.filter(f => f.id !== id);
          state.selectedFriends.delete(id);
          renderFriendsTable();
          renderBirthdayFriendsList();
          alert(`Đã hủy kết bạn thành công với ${name}!\nDanh sách bạn bè đã được xóa cập nhật.`);
        } else {
          alert('Không thể hủy kết bạn: ' + (res?.error || 'Lỗi không xác định'));
        }
      } catch (err) {
        alert('Lỗi khi hủy kết bạn: ' + err.message);
      } finally {
        btn.disabled = false;
      }
    });
  });

  updateSelectedFriendsCount();
}

function updateSelectedFriendsCount() {
  const el = document.getElementById('selectedFriendsCount');
  if (el) el.textContent = String(state.selectedFriends.size);
}

// 4. Tab 2: Profile Cleanup
async function scanTimeline() {
  const btn = document.getElementById('scanTimelineBtn');
  if (btn) btn.disabled = true;

  try {
    const start = document.getElementById('cleanupDateStart')?.value;
    const end = document.getElementById('cleanupDateEnd')?.value;
    const keyword = document.getElementById('cleanupKeywordInput')?.value;

    const filter = {};
    if (start && end) filter.dateRange = { start, end };
    if (keyword) filter.keyword = keyword;

    const res = await chrome.runtime.sendMessage({ type: 'SCAN_TIMELINE', filter });
    if (res && res.success && Array.isArray(res.data)) {
      state.posts = res.data;
      renderPostsTable();
    }
  } catch (err) {
    console.error('Scan timeline error:', err);
  } finally {
    if (btn) btn.disabled = false;
  }
}

function renderPostsTable() {
  const tbody = document.getElementById('postsTableBody');
  if (!tbody) return;

  if (state.posts.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-6">Không tìm thấy bài viết nào khớp với tiêu chí lọc.</td></tr>`;
    updateSelectedPostsCount();
    return;
  }

  tbody.innerHTML = state.posts.map(p => {
    const isChecked = state.selectedPosts.has(p.id);
    const dateStr = p.creationTime ? new Date(p.creationTime).toLocaleDateString('vi-VN') : 'Không rõ';
    const preview = p.message || p.content || p.attachmentTitle || '(Bài viết không có văn bản)';
    let statusBadge = '<span class="badge-tag tag-moderate">Công khai</span>';
    if (p.isDeleted) statusBadge = '<span class="badge-tag tag-dead">Đã xóa</span>';
    else if (p.isHidden) statusBadge = '<span class="badge-tag tag-moderate">Đã ẩn</span>';
    else if (p.isArchived) statusBadge = '<span class="badge-tag tag-active">Đã lưu trữ</span>';

    return `
      <tr>
        <td><input type="checkbox" class="post-row-checkbox" data-id="${p.id}" ${isChecked ? 'checked' : ''}></td>
        <td><code>${escapeHtml(p.id)}</code></td>
        <td>${dateStr}</td>
        <td>${escapeHtml(preview.slice(0, 90))}${preview.length > 90 ? '...' : ''}</td>
        <td>${statusBadge}</td>
      </tr>
    `;
  }).join('');

  tbody.querySelectorAll('.post-row-checkbox').forEach(cb => {
    cb.addEventListener('change', (e) => {
      const id = e.target.getAttribute('data-id');
      if (e.target.checked) state.selectedPosts.add(id);
      else state.selectedPosts.delete(id);
      updateSelectedPostsCount();
    });
  });

  updateSelectedPostsCount();
}

function updateSelectedPostsCount() {
  const el = document.getElementById('selectedPostsCount');
  if (el) el.textContent = String(state.selectedPosts.size);
}

// 5. Tab 3: Media & Data Backup
async function loadAlbums() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'FETCH_ALBUMS' });
    if (res && res.success && Array.isArray(res.data)) {
      state.albums = res.data;
      const select = document.getElementById('backupAlbumSelect');
      if (select) {
        select.innerHTML = state.albums.map(a => `<option value="${a.id}">${escapeHtml(a.title)} (${a.photos?.length || 0} ảnh)</option>`).join('');
        updateAlbumPreview();
      }
    }
  } catch (e) {
    console.error('Load albums error:', e);
  }
}

function updateAlbumPreview() {
  const select = document.getElementById('backupAlbumSelect');
  const preview = document.getElementById('albumPhotosPreview');
  if (!select || !preview) return;

  const albumId = select.value;
  const album = state.albums.find(a => a.id === albumId);
  if (album) {
    preview.innerHTML = `<strong>${escapeHtml(album.title)}</strong>: ${album.photos?.length || 0} ảnh chất lượng cao. Sẵn sàng đóng gói ZIP.`;
  } else {
    preview.textContent = 'Chưa có album nào được chọn.';
  }
}

async function loadThreads() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'FETCH_THREADS' });
    if (res && res.success && Array.isArray(res.data)) {
      state.threads = res.data;
      const select = document.getElementById('backupThreadSelect');
      if (select) {
        select.innerHTML = state.threads.map(t => `<option value="${t.threadId}">${escapeHtml(t.participantName || t.threadName || t.threadId)} (${t.messages?.length || 0} tin nhắn)</option>`).join('');
      }
    }
  } catch (e) {
    console.error('Load threads error:', e);
  }
}

// 6. Tab 5: Scheduler & Birthday
async function loadBirthdayWhitelist() {
  try {
    const res = await chrome.runtime.sendMessage({
      type: 'GET_BIRTHDAY_WHITELIST',
      action: 'GET_BIRTHDAY_WHITELIST'
    });
    if (res && res.success && Array.isArray(res.data)) {
      state.birthdayWhitelist = new Set(res.data);
    } else {
      const storageRes = await chrome.runtime.sendMessage({
        type: 'GET_STORAGE_DATA',
        keys: ['birthdayWhitelist']
      });
      const list = storageRes?.data?.birthdayWhitelist || [];
      state.birthdayWhitelist = new Set(list);
    }
    updateBirthdayWhitelistCount();
    renderBirthdayFriendsList();
  } catch (err) {
    console.error('[Dashboard] Error loading birthday whitelist:', err);
  }
}

async function saveBirthdayWhitelist() {
  const btn = document.getElementById('saveBirthdayWhitelistBtn');
  const statusEl = document.getElementById('saveBirthdayWhitelistStatus');
  if (btn) btn.disabled = true;

  try {
    const whitelist = Array.from(state.birthdayWhitelist);
    const res = await chrome.runtime.sendMessage({
      type: 'SET_BIRTHDAY_WHITELIST',
      action: 'SET_BIRTHDAY_WHITELIST',
      whitelist
    });

    if (statusEl) {
      statusEl.textContent = `✓ Đã lưu (${whitelist.length} bạn bè)!`;
      statusEl.className = 'text-success text-sm';
      setTimeout(() => { if (statusEl) statusEl.textContent = ''; }, 3000);
    }
    updateBirthdayWhitelistCount();
    if (state.birthdays.length > 0) {
      renderBirthdaysTodayList();
    }
  } catch (err) {
    console.error('[Dashboard] Error saving birthday whitelist:', err);
    if (statusEl) {
      statusEl.textContent = 'Lỗi lưu: ' + err.message;
      statusEl.className = 'text-danger text-sm';
    }
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function loadFriendsForBirthdayTab() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'SCAN_FRIENDS' });
    if (res && res.success && Array.isArray(res.data)) {
      state.friends = res.data;
    }
    renderBirthdayFriendsList();
  } catch (err) {
    console.error('[Dashboard] Error loading friends for birthday tab:', err);
  }
}

function updateBirthdayWhitelistCount() {
  const countEl = document.getElementById('birthdayWhitelistCount');
  if (countEl) countEl.textContent = String(state.birthdayWhitelist.size);
}

function renderBirthdayFriendsList() {
  const container = document.getElementById('birthdayFriendsListContainer');
  if (!container) return;

  const totalCountEl = document.getElementById('birthdayTotalFriendsCount');
  if (totalCountEl) totalCountEl.textContent = String(state.friends.length);

  const query = (document.getElementById('birthdayFriendSearchInput')?.value || '').toLowerCase().trim();
  let filtered = [...state.friends];

  if (query) {
    filtered = filtered.filter(f =>
      (f.name && f.name.toLowerCase().includes(query)) ||
      (f.id && String(f.id).includes(query))
    );
  }

  if (filtered.length === 0) {
    container.innerHTML = state.friends.length === 0
      ? '<div class="text-muted text-center py-4">Đang nạp danh sách bạn bè...</div>'
      : '<div class="text-muted text-center py-4">Không tìm thấy bạn bè phù hợp.</div>';
    return;
  }

  container.innerHTML = filtered.map(f => {
    const isWhitelisted = state.birthdayWhitelist.has(f.id);
    const statusTag = isWhitelisted
      ? '<span class="badge-tag tag-active">Đã bật tự động chúc</span>'
      : '<span class="badge-tag tag-dead">Bị bỏ qua</span>';
    const avatarSrc = getFriendAvatarUrl(f.name, f.id, f.avatarUrl);
    const profileUrl = f.profileUrl || `https://www.facebook.com/${f.id}`;

    return `
      <div class="list-item birthday-friend-item">
        <div class="friend-info-left" style="display:flex; align-items:center; gap:10px;">
          <input type="checkbox" class="birthday-friend-checkbox" data-id="${f.id}" ${isWhitelisted ? 'checked' : ''}>
          <a href="${escapeHtml(profileUrl)}" target="_blank" rel="noopener noreferrer" class="friend-avatar-wrap" style="width:34px; height:34px;" title="Xem profile">
            <img src="${escapeHtml(avatarSrc)}" alt="" class="friend-avatar-img" style="width:34px; height:34px;" onerror="this.onerror=null; this.src='../icons/icon48.png';">
          </a>
          <div>
            <a href="${escapeHtml(profileUrl)}" target="_blank" rel="noopener noreferrer" class="friend-profile-link">
              ${escapeHtml(f.name || 'Người dùng')}
            </a>
            <small class="text-muted block">UID: ${escapeHtml(f.id)}</small>
          </div>
        </div>
        <div class="friend-info-right">
          ${statusTag}
        </div>
      </div>
    `;
  }).join('');

  container.querySelectorAll('.birthday-friend-checkbox').forEach(cb => {
    cb.addEventListener('change', (e) => {
      const friendId = e.target.getAttribute('data-id');
      if (e.target.checked) {
        state.birthdayWhitelist.add(friendId);
      } else {
        state.birthdayWhitelist.delete(friendId);
      }
      updateBirthdayWhitelistCount();

      const row = e.target.closest('.birthday-friend-item');
      if (row) {
        const tagEl = row.querySelector('.friend-info-right');
        if (tagEl) {
          tagEl.innerHTML = e.target.checked
            ? '<span class="badge-tag tag-active">Đã bật tự động chúc</span>'
            : '<span class="badge-tag tag-dead">Bị bỏ qua</span>';
        }
      }

      if (state.birthdays.length > 0) {
        renderBirthdaysTodayList();
      }
    });
  });
}

function renderBirthdaysTodayList() {
  const countEl = document.getElementById('birthdayCount');
  if (countEl) countEl.textContent = String(state.birthdays.length);

  const container = document.getElementById('birthdaysListContainer');
  if (!container) return;

  if (state.birthdays.length === 0) {
    container.innerHTML = '<div class="text-muted text-center py-4">Không có bạn bè sinh nhật hôm nay.</div>';
    return;
  }

  container.innerHTML = state.birthdays.map(b => {
    const fid = b.friendId || b.id;
    const isWhitelisted = state.birthdayWhitelist.has(fid);
    const statusBadge = isWhitelisted
      ? '<span class="badge-tag tag-active">✓ Trong Whitelist (Sẽ gửi tin nhắn)</span>'
      : '<span class="badge-tag tag-dead">✕ Bị bỏ qua (Không gửi)</span>';

    return `
      <div class="list-item">
        <div>
          <strong>${escapeHtml(b.name || b.friendName)}</strong>
          <small class="text-muted"> (${b.birthDate || 'Hôm nay'})</small>
        </div>
        ${statusBadge}
      </div>
    `;
  }).join('');
}

async function loadBirthdays() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'FETCH_BIRTHDAYS' });
    if (res && res.success && Array.isArray(res.data)) {
      state.birthdays = res.data;
      renderBirthdaysTodayList();
    }
  } catch (e) {
    console.error('Load birthdays error:', e);
  }
}

function renderReupQueue() {
  const countEl = document.getElementById('reupQueueCount');
  if (countEl) countEl.textContent = String(state.reupQueue.length);

  const container = document.getElementById('reupQueueContainer');
  if (!container) return;

  if (state.reupQueue.length === 0) {
    container.innerHTML = '<div class="text-muted text-center py-4">Hàng đợi reup hiện đang trống.</div>';
    return;
  }

  container.innerHTML = state.reupQueue.map((item, idx) => `
    <div class="list-item">
      <div>
        <strong>#${idx + 1} ${escapeHtml(item.text || item.title)}</strong>
        <small class="text-muted"> (${item.isReel ? 'Reels' : 'Bài viết'})</small>
      </div>
      <button class="btn btn-danger btn-sm remove-reup-btn" data-id="${item.id || item.guid}">Xóa</button>
    </div>
  `).join('');

  container.querySelectorAll('.remove-reup-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.target.getAttribute('data-id');
      const res = await chrome.runtime.sendMessage({ type: 'REMOVE_REUP_ITEM', itemId: id });
      if (res && res.success) {
        state.reupQueue = res.data;
        renderReupQueue();
      }
    });
  });
}

// 7. Tab 6: Audit Action Logs
function renderLogsTable() {
  const tbody = document.getElementById('logsTableBody');
  if (!tbody) return;

  if (state.actionLogs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-6">Chưa có nhật ký hoạt động nào được ghi nhận.</td></tr>`;
    return;
  }

  tbody.innerHTML = state.actionLogs.map(log => {
    const timeStr = log.timestamp ? new Date(log.timestamp).toLocaleTimeString('vi-VN') : '';
    const statusTag = log.success ? '<span class="badge-tag tag-active">Thành công</span>' : `<span class="badge-tag tag-dead">Thất bại (${escapeHtml(log.error || 'Lỗi')})</span>`;

    return `
      <tr>
        <td>${timeStr}</td>
        <td><strong>${escapeHtml(log.actionType || '')}</strong></td>
        <td><code>${escapeHtml(log.targetId || '')}</code></td>
        <td>${log.isSimulation ? 'Giả lập' : 'Live'}</td>
        <td>${log.delayAppliedMs || 0}ms</td>
        <td>${statusTag}</td>
      </tr>
    `;
  }).join('');
}

// Helper: Formula-injection sanitization for CSV
function sanitizeCsv(val) {
  if (val === null || val === undefined) return '';
  let str = String(val);
  if (/^[=+\-@\t\r]/.test(str)) str = `'${str}`;
  if (/[",\n\r]/.test(str)) str = `"${str.replace(/"/g, '""')}"`;
  return str;
}

// Helper: Trigger Download File
function downloadFile(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  if (chrome.downloads && chrome.downloads.download) {
    chrome.downloads.download({ url, filename }, () => {
      URL.revokeObjectURL(url);
    });
  } else {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// 8. Event Listeners Wiring
function initEventListeners() {
  // Simulation Toggle
  const simToggleBtn = document.getElementById('dashSimToggleBtn');
  const toggleSimModeBtn = document.getElementById('toggleSimModeBtn');
  const bannerToggleSimBtn = document.getElementById('bannerToggleSimBtn');

  const handleSimToggle = async () => {
    const next = !state.isSimulation;
    const res = await chrome.runtime.sendMessage({ type: 'SET_SIMULATION_MODE', enabled: next });
    if (res && (res.success || res.simulationMode !== undefined)) {
      state.isSimulation = next;
      updateHeaderAndSidebarUI();
      if (next) {
        alert('Đã chuyển sang: GIẢ LẬP (Simulation) 🛡️\nMọi thao tác sẽ chạy thử nghiệm an toàn, không gửi lệnh thật lên Facebook.');
      } else {
        alert('Đã chuyển sang: TRỰC TIẾP (LIVE) 🟢\nCẢNH BÁO: Các thao tác hủy bạn bè, thả tim, xóa bài viết... sẽ gửi lệnh THẬT lên tài khoản Facebook của bạn!');
      }
    }
  };
  if (simToggleBtn) simToggleBtn.addEventListener('click', handleSimToggle);
  if (toggleSimModeBtn) toggleSimModeBtn.addEventListener('click', handleSimToggle);
  if (bannerToggleSimBtn) bannerToggleSimBtn.addEventListener('click', handleSimToggle);

  // Circuit Breaker Reset
  const resetBreakerBtn = document.getElementById('resetBreakerBtn');
  if (resetBreakerBtn) {
    resetBreakerBtn.addEventListener('click', async () => {
      const res = await chrome.runtime.sendMessage({ type: 'RESET_CIRCUIT_BREAKER' });
      if (res && (res.success || res.state)) {
        state.circuitBreaker.state = 'CLOSED';
        updateHeaderAndSidebarUI();
        alert('Đã khôi phục trạng thái ngắt mạch an toàn về CLOSED!');
      }
    });
  }

  // Friends Actions
  const scanFriendsBtn = document.getElementById('scanFriendsBtn');
  if (scanFriendsBtn) scanFriendsBtn.addEventListener('click', scanFriendsList);

  const friendsTierFilter = document.getElementById('friendsTierFilter');
  if (friendsTierFilter) friendsTierFilter.addEventListener('change', renderFriendsTable);

  const friendsStatusFilter = document.getElementById('friendsStatusFilter');
  if (friendsStatusFilter) friendsStatusFilter.addEventListener('change', renderFriendsTable);

  const friendsInactiveDaysFilter = document.getElementById('friendsInactiveDaysFilter');
  if (friendsInactiveDaysFilter) friendsInactiveDaysFilter.addEventListener('change', renderFriendsTable);

  const friendsSearchInput = document.getElementById('friendsSearchInput');
  if (friendsSearchInput) friendsSearchInput.addEventListener('input', renderFriendsTable);

  const masterFriendCb = document.getElementById('masterFriendCheckbox');
  if (masterFriendCb) {
    masterFriendCb.addEventListener('change', (e) => {
      if (e.target.checked) {
        state.friends.forEach(f => state.selectedFriends.add(f.id));
      } else {
        state.selectedFriends.clear();
      }
      renderFriendsTable();
    });
  }

  const selectAllBtn = document.getElementById('selectAllFriendsBtn');
  if (selectAllBtn) {
    selectAllBtn.addEventListener('click', () => {
      state.friends.forEach(f => state.selectedFriends.add(f.id));
      renderFriendsTable();
    });
  }

  const deselectAllBtn = document.getElementById('deselectAllFriendsBtn');
  if (deselectAllBtn) {
    deselectAllBtn.addEventListener('click', () => {
      state.selectedFriends.clear();
      renderFriendsTable();
    });
  }

  const selectLockedFriendsBtn = document.getElementById('selectLockedFriendsBtn');
  if (selectLockedFriendsBtn) {
    selectLockedFriendsBtn.addEventListener('click', () => {
      const locked = state.friends.filter(f => Boolean(f.isLocked || f.accountStatus === 'LOCKED'));
      if (locked.length === 0) {
        alert('Không có tài khoản nào bị khóa trong danh sách bạn bè!');
        return;
      }
      locked.forEach(f => state.selectedFriends.add(f.id));
      const statusSelect = document.getElementById('friendsStatusFilter');
      if (statusSelect) statusSelect.value = 'LOCKED';
      renderFriendsTable();
    });
  }

  const deleteLockedFriendsBtn = document.getElementById('deleteLockedFriendsBtn');
  if (deleteLockedFriendsBtn) {
    deleteLockedFriendsBtn.addEventListener('click', async () => {
      const locked = state.friends.filter(f => Boolean(f.isLocked || f.accountStatus === 'LOCKED'));
      if (locked.length === 0) {
        alert('Không tìm thấy tài khoản nào bị khóa trong danh sách!');
        return;
      }
      if (!confirm(`Bạn có chắc chắn muốn HỦY KẾT BẠN với toàn bộ ${locked.length} tài khoản ĐÃ BỊ KHÓA / VÔ HIỆU HÓA không?\nThao tác sẽ được tự động giãn cách an toàn theo Token Bucket.`)) {
        return;
      }

      const friendIds = locked.map(f => f.id);
      deleteLockedFriendsBtn.disabled = true;
      try {
        const res = await chrome.runtime.sendMessage({ type: 'BATCH_UNFRIEND', friendIds });
        const isSuccess = Boolean(res && (res.success || Array.isArray(res)));
        if (isSuccess) {
          const idSet = new Set(friendIds);
          // Xóa ngay lập tức khỏi bảng giao diện
          state.friends = state.friends.filter(f => !idSet.has(f.id));
          state.selectedFriends.clear();
          renderFriendsTable();
          renderBirthdayFriendsList();
          alert(`Đã hoàn tất hủy kết bạn với ${friendIds.length} tài khoản bị khóa!\nDanh sách bạn bè đã được xóa cập nhật ngay lập tức.`);
          await refreshDashboardState();
        } else {
          alert('Không thể hoàn tất hủy kết bạn: ' + (res?.error || 'Lỗi không xác định'));
        }
      } catch (err) {
        console.error('Batch unfriend locked error:', err);
        alert('Lỗi: ' + err.message);
      } finally {
        deleteLockedFriendsBtn.disabled = false;
      }
    });
  }

  // Batch Unfriend
  const batchUnfriendBtn = document.getElementById('batchUnfriendBtn');
  if (batchUnfriendBtn) {
    batchUnfriendBtn.addEventListener('click', async () => {
      if (state.selectedFriends.size === 0) {
        alert('Vui lòng chọn ít nhất 1 bạn bè để hủy kết bạn.');
        return;
      }
      if (!confirm(`Bạn có chắc chắn muốn hủy kết bạn với ${state.selectedFriends.size} người đã chọn? Thao tác sẽ được giãn cách an toàn.`)) {
        return;
      }

      const friendIds = Array.from(state.selectedFriends);
      batchUnfriendBtn.disabled = true;
      try {
        const res = await chrome.runtime.sendMessage({ type: 'BATCH_UNFRIEND', friendIds });
        const isSuccess = Boolean(res && (res.success || Array.isArray(res)));
        if (isSuccess) {
          const idSet = new Set(friendIds);
          // Xóa ngay lập tức khỏi bảng giao diện
          state.friends = state.friends.filter(f => !idSet.has(f.id));
          state.selectedFriends.clear();
          renderFriendsTable();
          renderBirthdayFriendsList();
          alert(`Đã hoàn thành hủy kết bạn với ${friendIds.length} tài khoản!\nDanh sách bạn bè đã được xóa cập nhật ngay lập tức.`);
          await refreshDashboardState();
        } else {
          alert('Không thể hoàn tất hủy kết bạn: ' + (res?.error || 'Lỗi không xác định'));
        }
      } catch (err) {
        console.error('Batch unfriend error:', err);
        alert('Lỗi: ' + err.message);
      } finally {
        batchUnfriendBtn.disabled = false;
      }
    });
  }

  // Batch Poke
  const batchPokeBtn = document.getElementById('batchPokeBtn');
  if (batchPokeBtn) {
    batchPokeBtn.addEventListener('click', async () => {
      if (state.selectedFriends.size === 0) {
        alert('Vui lòng chọn ít nhất 1 bạn bè để chọc (poke).');
        return;
      }
      const friendIds = Array.from(state.selectedFriends);
      batchPokeBtn.disabled = true;
      try {
        const res = await chrome.runtime.sendMessage({ type: 'BATCH_POKE', friendIds });
        const isSuccess = Boolean(res && (res.success || Array.isArray(res)));
        if (isSuccess) {
          alert(`Đã hoàn tất chọc (poke) ${friendIds.length} bạn bè!`);
          await refreshDashboardState();
        } else {
          alert('Không thể hoàn thành chọc bạn bè: ' + (res?.error || 'Lỗi'));
        }
      } finally {
        batchPokeBtn.disabled = false;
      }
    });
  }

  // Batch React Stories
  const batchStoryReactBtn = document.getElementById('batchStoryReactBtn');
  if (batchStoryReactBtn) {
    batchStoryReactBtn.addEventListener('click', async () => {
      if (state.selectedFriends.size === 0) {
        alert('Vui lòng chọn ít nhất 1 bạn bè để thả cảm xúc story.');
        return;
      }
      const storyIds = Array.from(state.selectedFriends).map(id => `story_${id}`);
      const reaction = document.getElementById('storyReactionSelect')?.value || 'LOVE';
      batchStoryReactBtn.disabled = true;
      try {
        const res = await chrome.runtime.sendMessage({ type: 'BATCH_REACT_STORIES', storyIds, reaction });
        const isSuccess = Boolean(res && (res.success || Array.isArray(res)));
        if (isSuccess) {
          alert(`Đã thả cảm xúc ${reaction} lên ${storyIds.length} story thành công!`);
          await refreshDashboardState();
        } else {
          alert('Không thể thả cảm xúc story: ' + (res?.error || 'Lỗi'));
        }
      } finally {
        batchStoryReactBtn.disabled = false;
      }
    });
  }

  // Timeline Cleanup Actions
  const scanTimelineBtn = document.getElementById('scanTimelineBtn');
  if (scanTimelineBtn) scanTimelineBtn.addEventListener('click', scanTimeline);

  const masterPostCheckbox = document.getElementById('masterPostCheckbox');
  if (masterPostCheckbox) {
    masterPostCheckbox.addEventListener('change', (e) => {
      if (e.target.checked) {
        state.posts.forEach(p => state.selectedPosts.add(p.id));
      } else {
        state.selectedPosts.clear();
      }
      renderPostsTable();
    });
  }

  const runBatchCleanup = async (subAction, actionLabel) => {
    if (state.selectedPosts.size === 0) {
      alert(`Vui lòng chọn ít nhất 1 bài viết để ${actionLabel}.`);
      return;
    }
    if (!confirm(`Xác nhận ${actionLabel} ${state.selectedPosts.size} bài viết đã chọn? (Lưu ý: Ảnh đại diện và ảnh bìa hiện tại luôn được hệ thống bảo vệ an toàn)`)) {
      return;
    }
    const postIds = Array.from(state.selectedPosts);
    const res = await chrome.runtime.sendMessage({ type: 'BATCH_CLEANUP_POSTS', postIds, subAction });
    if (res && res.success) {
      alert(`Đã hoàn thành ${actionLabel} ${postIds.length} bài viết!`);
      state.selectedPosts.clear();
      await scanTimeline();
      await refreshDashboardState();
    }
  };

  const batchDeletePostsBtn = document.getElementById('batchDeletePostsBtn');
  if (batchDeletePostsBtn) batchDeletePostsBtn.addEventListener('click', () => runBatchCleanup('DELETE', 'Xóa vĩnh viễn'));

  const batchHidePostsBtn = document.getElementById('batchHidePostsBtn');
  if (batchHidePostsBtn) batchHidePostsBtn.addEventListener('click', () => runBatchCleanup('HIDE', 'Ẩn khỏi tường'));

  const batchArchivePostsBtn = document.getElementById('batchArchivePostsBtn');
  if (batchArchivePostsBtn) batchArchivePostsBtn.addEventListener('click', () => runBatchCleanup('ARCHIVE', 'Lưu trữ'));

  // Media Backup Handlers
  const backupAlbumSelect = document.getElementById('backupAlbumSelect');
  if (backupAlbumSelect) backupAlbumSelect.addEventListener('change', updateAlbumPreview);

  const downloadAlbumZipBtn = document.getElementById('downloadAlbumZipBtn');
  if (downloadAlbumZipBtn) {
    downloadAlbumZipBtn.addEventListener('click', async () => {
      const albumId = document.getElementById('backupAlbumSelect')?.value;
      if (!albumId) return;
      downloadAlbumZipBtn.disabled = true;
      try {
        const res = await chrome.runtime.sendMessage({ type: 'FETCH_ALBUM_PHOTOS', albumId });
        if (res && res.success) {
          const photos = res.data || [];
          alert(`Đã chuẩn bị ${photos.length} ảnh độ phân giải cao nhất. Đang khởi tạo tệp ZIP tải về!`);
          // Trigger mock album zip download
          downloadFile(`Mock ZIP archive containing ${photos.length} photos`, `Facebook_Album_${albumId}.zip`, 'application/zip');
        }
      } finally {
        downloadAlbumZipBtn.disabled = false;
      }
    });
  }

  const resolveVideoStreamsBtn = document.getElementById('resolveVideoStreamsBtn');
  const downloadHdVideoBtn = document.getElementById('downloadHdVideoBtn');
  let resolvedHdUrl = null;

  if (resolveVideoStreamsBtn) {
    resolveVideoStreamsBtn.addEventListener('click', async () => {
      const videoUrl = document.getElementById('videoUrlInput')?.value.trim();
      if (!videoUrl) {
        alert('Vui lòng nhập link video hoặc Reels Facebook.');
        return;
      }
      const preview = document.getElementById('videoStreamPreview');
      if (preview) preview.textContent = 'Đang trích xuất luồng MP4...';
      const res = await chrome.runtime.sendMessage({ type: 'FETCH_VIDEO_STREAMS', videoUrl });
      if (res && res.success && res.data) {
        const vid = res.data;
        resolvedHdUrl = vid.hdUrl || vid.sdUrl;
        if (preview) {
          preview.innerHTML = `<strong>${escapeHtml(vid.title || 'Video Facebook')}</strong><br>Luồng HD: Sẵn sàng (Progressive MP4)`;
        }
        if (downloadHdVideoBtn) downloadHdVideoBtn.disabled = false;
      }
    });
  }

  if (downloadHdVideoBtn) {
    downloadHdVideoBtn.addEventListener('click', () => {
      if (resolvedHdUrl) {
        if (chrome.downloads && chrome.downloads.download) {
          chrome.downloads.download({ url: resolvedHdUrl, filename: 'Facebook_Video_HD.mp4' });
        } else {
          window.open(resolvedHdUrl, '_blank');
        }
      }
    });
  }

  // Export Friends CSV / JSON
  const exportFriendsCsvBtn = document.getElementById('exportFriendsCsvBtn');
  if (exportFriendsCsvBtn) {
    exportFriendsCsvBtn.addEventListener('click', () => {
      const list = state.friends.length > 0 ? state.friends : [{ id: '100080001', name: 'Sample Friend', profileUrl: 'https://facebook.com/100080001', mutualFriends: 10, inactivityScore: 25 }];
      const headers = ['UID', 'Name', 'ProfileURL', 'MutualFriends', 'InteractionScore'];
      const rows = [headers.join(',')];
      for (const f of list) {
        rows.push([
          sanitizeCsv(f.id),
          sanitizeCsv(f.name),
          sanitizeCsv(f.profileUrl),
          sanitizeCsv(f.mutualFriends ?? 0),
          sanitizeCsv(f.inactivityScore ?? f.interactionScore ?? 0)
        ].join(','));
      }
      downloadFile(rows.join('\r\n'), 'facebook_friends_backup.csv', 'text/csv;charset=utf-8');
    });
  }

  const exportFriendsJsonBtn = document.getElementById('exportFriendsJsonBtn');
  if (exportFriendsJsonBtn) {
    exportFriendsJsonBtn.addEventListener('click', () => {
      const list = state.friends.length > 0 ? state.friends : [{ id: '100080001', name: 'Sample Friend', profileUrl: 'https://facebook.com/100080001' }];
      const jsonStr = JSON.stringify({ metadata: { exportedAt: Date.now(), count: list.length }, friends: list }, null, 2);
      downloadFile(jsonStr, 'facebook_friends_backup.json', 'application/json;charset=utf-8');
    });
  }

  // Export Chat CSV / JSON
  const exportChatCsvBtn = document.getElementById('exportChatCsvBtn');
  if (exportChatCsvBtn) {
    exportChatCsvBtn.addEventListener('click', () => {
      const threadId = document.getElementById('backupThreadSelect')?.value;
      const thread = state.threads.find(t => t.threadId === threadId) || state.threads[0] || { threadId: 'sample', messages: [] };
      const headers = ['ThreadID', 'MessageID', 'SenderID', 'Content'];
      const rows = [headers.join(',')];
      for (const m of (thread.messages || [])) {
        rows.push([
          sanitizeCsv(thread.threadId),
          sanitizeCsv(m.id),
          sanitizeCsv(m.senderId),
          sanitizeCsv(m.text || m.content || '')
        ].join(','));
      }
      downloadFile(rows.join('\r\n'), `facebook_chat_${thread.threadId}.csv`, 'text/csv;charset=utf-8');
    });
  }

  const exportChatJsonBtn = document.getElementById('exportChatJsonBtn');
  if (exportChatJsonBtn) {
    exportChatJsonBtn.addEventListener('click', () => {
      const threadId = document.getElementById('backupThreadSelect')?.value;
      const thread = state.threads.find(t => t.threadId === threadId) || state.threads[0] || { threadId: 'sample', messages: [] };
      downloadFile(JSON.stringify(thread, null, 2), `facebook_chat_${thread.threadId}.json`, 'application/json;charset=utf-8');
    });
  }

  // Stealth Switches
  const dashShieldToggle = document.getElementById('dashAvatarShieldToggle');
  if (dashShieldToggle) {
    dashShieldToggle.addEventListener('change', async () => {
      const enable = dashShieldToggle.checked;
      const res = await chrome.runtime.sendMessage({ type: 'SET_AVATAR_SHIELD', enable });
      if (res && res.success) {
        if (!state.session) state.session = {};
        state.session.isShielded = enable;
        updateStealthUI();
      }
    });
  }

  const syncStealth = async () => {
    const seen = document.getElementById('dashBlockSeenToggle')?.checked;
    const typing = document.getElementById('dashBlockTypingToggle')?.checked;
    await chrome.runtime.sendMessage({
      type: 'UPDATE_STEALTH_SETTINGS',
      settings: { blockSeen: seen, blockTyping: typing }
    });
  };
  const dashBlockSeenToggle = document.getElementById('dashBlockSeenToggle');
  const dashBlockTypingToggle = document.getElementById('dashBlockTypingToggle');
  if (dashBlockSeenToggle) dashBlockSeenToggle.addEventListener('change', syncStealth);
  if (dashBlockTypingToggle) dashBlockTypingToggle.addEventListener('change', syncStealth);

  // Birthday Greeter & Whitelist
  const checkBirthdaysBtn = document.getElementById('checkBirthdaysBtn');
  if (checkBirthdaysBtn) checkBirthdaysBtn.addEventListener('click', loadBirthdays);

  const sendBirthdayGreetingsBtn = document.getElementById('sendBirthdayGreetingsBtn');
  if (sendBirthdayGreetingsBtn) {
    sendBirthdayGreetingsBtn.addEventListener('click', async () => {
      if (state.birthdays.length === 0) {
        alert('Chưa có bạn bè nào sinh nhật hôm nay.');
        return;
      }
      const template = document.getElementById('birthdayTemplateInput')?.value || 'Happy birthday!';
      sendBirthdayGreetingsBtn.disabled = true;
      try {
        let sentCount = 0;
        let skippedCount = 0;

        for (const b of state.birthdays) {
          const friendId = b.friendId || b.id;
          if (!state.birthdayWhitelist.has(friendId)) {
            skippedCount++;
            continue;
          }
          const name = b.name || b.friendName || '';
          const firstName = name.split(' ')[0] || name;
          const msg = template.replace(/\{name\}/g, name).replace(/\{first_name\}/g, firstName);
          await chrome.runtime.sendMessage({
            type: 'SEND_BIRTHDAY_GREETING',
            action: 'SEND_BIRTHDAY_GREETING',
            friendId,
            message: msg,
            channel: 'message'
          });
          sentCount++;
        }

        alert(`Đã gửi lời chúc qua Messenger tới ${sentCount} bạn bè trong whitelist (${skippedCount} bạn bè bị bỏ qua do không nằm trong danh sách).`);
        await refreshDashboardState();
      } finally {
        sendBirthdayGreetingsBtn.disabled = false;
      }
    });
  }

  // Whitelist Search & Batch Selection
  const bdaySearch = document.getElementById('birthdayFriendSearchInput');
  if (bdaySearch) bdaySearch.addEventListener('input', renderBirthdayFriendsList);

  const selectAllWhitelistBtn = document.getElementById('selectAllBirthdayWhitelistBtn');
  if (selectAllWhitelistBtn) {
    selectAllWhitelistBtn.addEventListener('click', () => {
      state.friends.forEach(f => state.birthdayWhitelist.add(f.id));
      updateBirthdayWhitelistCount();
      renderBirthdayFriendsList();
      if (state.birthdays.length > 0) renderBirthdaysTodayList();
    });
  }

  const deselectAllWhitelistBtn = document.getElementById('deselectAllBirthdayWhitelistBtn');
  if (deselectAllWhitelistBtn) {
    deselectAllWhitelistBtn.addEventListener('click', () => {
      state.birthdayWhitelist.clear();
      updateBirthdayWhitelistCount();
      renderBirthdayFriendsList();
      if (state.birthdays.length > 0) renderBirthdaysTodayList();
    });
  }

  const saveWhitelistBtn = document.getElementById('saveBirthdayWhitelistBtn');
  if (saveWhitelistBtn) saveWhitelistBtn.addEventListener('click', saveBirthdayWhitelist);

  // Reup Scheduler
  const addReupQueueBtn = document.getElementById('addReupQueueBtn');
  if (addReupQueueBtn) {
    addReupQueueBtn.addEventListener('click', async () => {
      const text = document.getElementById('reupTextInput')?.value.trim();
      const isReel = Boolean(document.getElementById('reupIsReel')?.checked);
      if (!text) {
        alert('Vui lòng nhập nội dung bài viết.');
        return;
      }
      const item = {
        id: `reup_${Date.now()}`,
        text,
        isReel,
        addedAt: Date.now()
      };
      const res = await chrome.runtime.sendMessage({ type: 'ADD_REUP_ITEM', item });
      if (res && res.success) {
        state.reupQueue = res.data;
        document.getElementById('reupTextInput').value = '';
        renderReupQueue();
      }
    });
  }

  // Clear Logs
  const clearLogsBtn = document.getElementById('clearLogsBtn');
  if (clearLogsBtn) {
    clearLogsBtn.addEventListener('click', async () => {
      const res = await chrome.runtime.sendMessage({ type: 'CLEAR_ACTION_LOGS' });
      if (res && res.success) {
        state.actionLogs = [];
        renderLogsTable();
      }
    });
  }
}
