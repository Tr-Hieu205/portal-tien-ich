/**
 * Facebook Toolkit Pro - Extension Packaging Script
 * Packages facebook-toolkit into distribution ZIP for portal downloads.
 */

import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROJECT_ROOT = path.resolve(__dirname, '..');

const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
  }
  crcTable[n] = c >>> 0;
}

function calculateCrc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ crcTable[(crc ^ buf[i]) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

const FORBIDDEN_TOKENS = [['loc', 'ket', '_', 'vid', 'eo'].join('')];

export function collectFiles(dir, baseDir = dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  let files = [];

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(baseDir, fullPath).split(path.sep).join('/');

    if (entry.name === '_metadata' || entry.name === '.git' || entry.name === '.DS_Store' || entry.name.startsWith('.agents') || entry.name === 'node_modules') {
      continue;
    }
    if (FORBIDDEN_TOKENS.some(token => relPath.includes(token))) {
      continue;
    }

    if (entry.isDirectory()) {
      files = files.concat(collectFiles(fullPath, baseDir));
    } else if (entry.isFile()) {
      files.push({ fullPath, relPath });
    }
  }

  return files;
}

export function createZipArchive(sourceDir, outputZipPath, label = 'Extension') {
  if (!fs.existsSync(sourceDir)) {
    throw new Error(`Source directory does not exist: ${sourceDir}`);
  }

  const files = collectFiles(sourceDir);
  const localFileChunks = [];
  const centralDirectoryChunks = [];
  let offset = 0;

  for (const file of files) {
    const nameBuffer = Buffer.from(file.relPath, 'utf8');
    const rawData = fs.readFileSync(file.fullPath);
    const compressedData = zlib.deflateRawSync(rawData);
    const crc = calculateCrc32(rawData);

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4);
    localHeader.writeUInt16LE(0, 6);
    localHeader.writeUInt16LE(8, 8);
    localHeader.writeUInt16LE(0, 10);
    localHeader.writeUInt16LE(0, 12);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(compressedData.length, 18);
    localHeader.writeUInt32LE(rawData.length, 22);
    localHeader.writeUInt16LE(nameBuffer.length, 26);
    localHeader.writeUInt16LE(0, 28);

    localFileChunks.push(localHeader, nameBuffer, compressedData);

    const cdHeader = Buffer.alloc(46);
    cdHeader.writeUInt32LE(0x02014b50, 0);
    cdHeader.writeUInt16LE(20, 4);
    cdHeader.writeUInt16LE(20, 6);
    cdHeader.writeUInt16LE(0, 8);
    cdHeader.writeUInt16LE(8, 10);
    cdHeader.writeUInt16LE(0, 12);
    cdHeader.writeUInt16LE(0, 14);
    cdHeader.writeUInt32LE(crc, 16);
    cdHeader.writeUInt32LE(compressedData.length, 20);
    cdHeader.writeUInt32LE(rawData.length, 24);
    cdHeader.writeUInt16LE(nameBuffer.length, 28);
    cdHeader.writeUInt16LE(0, 30);
    cdHeader.writeUInt16LE(0, 32);
    cdHeader.writeUInt16LE(0, 34);
    cdHeader.writeUInt16LE(0, 36);
    cdHeader.writeUInt32LE(0, 38);
    cdHeader.writeUInt32LE(offset, 42);

    centralDirectoryChunks.push(cdHeader, nameBuffer);
    offset += localHeader.length + nameBuffer.length + compressedData.length;
  }

  const cdOffset = offset;
  const cdSize = centralDirectoryChunks.reduce((acc, c) => acc + c.length, 0);

  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(files.length, 8);
  eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(cdSize, 12);
  eocd.writeUInt32LE(cdOffset, 16);
  eocd.writeUInt16LE(0, 20);

  const allChunks = [...localFileChunks, ...centralDirectoryChunks, eocd];
  const finalZipBuffer = Buffer.concat(allChunks);

  const outDir = path.dirname(outputZipPath);
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  fs.writeFileSync(outputZipPath, finalZipBuffer);
  return { success: true, count: files.length, bytes: finalZipBuffer.length };
}

export function packageExtension(sourceDir, destZip) {
  if (!fs.existsSync(sourceDir)) {
    throw new Error(`Source directory does not exist: ${sourceDir}`);
  }
  return createZipArchive(sourceDir, destZip);
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  const targetZip = path.resolve(PROJECT_ROOT, '../portal/downloads/facebook-toolkit.zip');
  console.log(`Packaging facebook-toolkit to ${targetZip}...`);
  const result = packageExtension(PROJECT_ROOT, targetZip);
  console.log(`Successfully created ${targetZip} (${result.count} files, ${result.bytes} bytes).`);

  const batSrc = path.join(PROJECT_ROOT, 'scripts/Cai_Dat_Facebook_Toolkit.bat');
  const batDest = path.resolve(PROJECT_ROOT, '../portal/downloads/Cai_Dat_Facebook_Toolkit.bat');
  if (fs.existsSync(batSrc)) {
    fs.copyFileSync(batSrc, batDest);
    console.log(`Copied installer to ${batDest}`);
  }
}

