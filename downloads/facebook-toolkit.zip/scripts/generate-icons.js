/**
 * scripts/generate-icons.js
 * Generates valid PNG icons (16x16, 48x48, 128x128) in pure Node.js.
 * Zero external dependencies.
 */

import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');
const iconsDir = path.join(projectRoot, 'icons');

// Precomputed CRC32 table
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
  }
  crcTable[n] = c >>> 0;
}

function calculateCrc32(buf) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ crcTable[(crc ^ buf[i]) & 0xFF];
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function createChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeAndData = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(calculateCrc32(typeAndData), 0);
  return Buffer.concat([len, typeAndData, crc]);
}

export function generatePngIcon(size) {
  const signature = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);

  // IHDR chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; // 8-bit depth
  ihdr[9] = 6; // Color type 6 (RGBA)
  ihdr[10] = 0; // Deflate compression
  ihdr[11] = 0; // Standard filter
  ihdr[12] = 0; // No interlacing

  const rowSize = 1 + size * 4;
  const rawData = Buffer.alloc(size * rowSize);

  const radius = size * 0.22;
  const center = size / 2;

  // Render rounded badge with Facebook blue (#1877F2) and stylized 'F'
  for (let y = 0; y < size; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // Filter: None

    for (let x = 0; x < size; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const dx = Math.max(Math.abs(x - center + 0.5) - (center - radius - 1), 0);
      const dy = Math.max(Math.abs(y - center + 0.5) - (center - radius - 1), 0);
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist <= radius) {
        const relX = x / size;
        const relY = y / size;

        // Stylized 'F' badge
        const isStem = relX >= 0.40 && relX <= 0.55 && relY >= 0.22 && relY <= 0.78;
        const isTopBar = relX >= 0.40 && relX <= 0.75 && relY >= 0.22 && relY <= 0.36;
        const isMidBar = relX >= 0.40 && relX <= 0.68 && relY >= 0.44 && relY <= 0.56;

        if (isStem || isTopBar || isMidBar) {
          rawData[pxOffset] = 255;     // R
          rawData[pxOffset + 1] = 255; // G
          rawData[pxOffset + 2] = 255; // B
          rawData[pxOffset + 3] = 255; // A
        } else {
          rawData[pxOffset] = 24;      // R: #1877F2
          rawData[pxOffset + 1] = 119; // G
          rawData[pxOffset + 2] = 242; // B
          rawData[pxOffset + 3] = 255; // A
        }
      } else {
        // Transparent outside rounded corner
        rawData[pxOffset] = 0;
        rawData[pxOffset + 1] = 0;
        rawData[pxOffset + 2] = 0;
        rawData[pxOffset + 3] = 0;
      }
    }
  }

  const compressed = zlib.deflateSync(rawData, { level: 9 });
  const idat = createChunk('IDAT', compressed);
  const iend = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, createChunk('IHDR', ihdr), idat, iend]);
}

export function writeIcons(targetDir = iconsDir) {
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }

  const sizes = [16, 48, 128];
  for (const size of sizes) {
    const pngBuf = generatePngIcon(size);
    const dest = path.join(targetDir, `icon${size}.png`);
    fs.writeFileSync(dest, pngBuf);
    console.log(`[+] Generated ${dest} (${size}x${size}, ${pngBuf.length} bytes)`);
  }
}

// Auto-run if executed as script
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  writeIcons();
}
