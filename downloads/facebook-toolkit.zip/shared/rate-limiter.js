/**
 * Facebook Toolkit Pro - Safe Rate Limiter & Humanized Jitter Engine
 * Token-Bucket + Leaky-Bucket + Box-Muller/Pareto Jitter + 24h Rolling Quota
 */

import {
  ACTION_TYPES,
  DEFAULT_DELAYS_MS,
  JITTER_CONFIG,
  DEFAULT_ROLLING_QUOTAS_24H
} from './constants.js';

/**
 * Generates a pseudo-Gaussian random number using the Box-Muller transform.
 * @param {number} mean - Expected central value
 * @param {number} stdDev - Standard deviation
 * @param {number} [min] - Optional lower clamp
 * @param {number} [max] - Optional upper clamp
 * @returns {number}
 */
export function boxMullerRandom(mean, stdDev, min = undefined, max = undefined) {
  let u1 = Math.random();
  let u2 = Math.random();
  while (u1 === 0) u1 = Math.random(); // Prevent log(0)
  const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
  let val = mean + z0 * stdDev;
  if (min !== undefined && val < min) val = min;
  if (max !== undefined && val > max) val = max;
  return Math.round(val);
}

/**
 * Generates a heavy-tailed delay using Pareto inverse transform sampling.
 * @param {number} alpha - Shape parameter (lower = heavier tail)
 * @param {number} minVal - Scale parameter (minimum delay x_m)
 * @param {number} maxVal - Upper clamp to prevent indefinite pause
 * @returns {number}
 */
export function paretoRandom(alpha, minVal, maxVal) {
  let u = Math.random();
  if (u >= 1) u = 0.999999;
  const val = minVal / Math.pow(1 - u, 1 / alpha);
  return Math.round(Math.min(val, maxVal));
}

/**
 * Calculates a composite humanized delay combining pseudo-Gaussian reaction
 * distribution with occasional Pareto micro-pauses (distraction/reading time).
 * @param {number} baseDelayMs - Base delay in milliseconds
 * @param {number} [jitterRatio=0.35] - Fractional variance around base
 * @param {object} [options] - Optional overrides
 * @returns {number}
 */
export function calculateHumanizedDelay(baseDelayMs, jitterRatio = JITTER_CONFIG.DEFAULT_RATIO, options = {}) {
  const min = options.min ?? Math.round(baseDelayMs * (1 - jitterRatio));
  const max = options.max ?? Math.round(baseDelayMs * (1 + jitterRatio));
  // Set stdDev so that 3 * stdDev = baseDelayMs * jitterRatio (99.7% falls within bounds)
  const stdDev = (baseDelayMs * jitterRatio) / 3;
  let delay = boxMullerRandom(baseDelayMs, stdDev, min, max);

  const pauseProb = options.distractionProbability ?? JITTER_CONFIG.PARETO_PROBABILITY;
  if (Math.random() < pauseProb) {
    const pause = paretoRandom(
      options.alpha ?? JITTER_CONFIG.PARETO_ALPHA,
      options.minPause ?? JITTER_CONFIG.PARETO_MIN_MS,
      options.maxPause ?? JITTER_CONFIG.PARETO_MAX_MS
    );
    delay += pause;
  }
  return delay;
}

/**
 * Token Bucket implementation with continuous refill and burst capacity.
 */
export class TokenBucket {
  constructor({ capacity = 10, refillRate = 1, tokens = null, lastRefillTimestamp = null } = {}) {
    this.capacity = capacity;
    this.refillRate = refillRate; // tokens per second
    this.tokens = tokens !== null ? Math.min(capacity, Math.max(0, tokens)) : capacity;
    this.lastRefillTimestamp = lastRefillTimestamp ?? Date.now();
  }

  refill(now = Date.now()) {
    const elapsedMs = Math.max(0, now - this.lastRefillTimestamp);
    if (elapsedMs > 0) {
      const added = (elapsedMs / 1000) * this.refillRate;
      this.tokens = Math.min(this.capacity, this.tokens + added);
      this.lastRefillTimestamp = now;
    }
  }

  tryConsume(cost = 1, now = Date.now()) {
    this.refill(now);
    if (this.tokens >= cost) {
      this.tokens -= cost;
      return { allowed: true, remainingTokens: this.tokens, waitMs: 0 };
    }
    const needed = cost - this.tokens;
    const waitMs = Math.ceil((needed / this.refillRate) * 1000);
    return { allowed: false, remainingTokens: this.tokens, waitMs };
  }

  getTokens(now = Date.now()) {
    this.refill(now);
    return this.tokens;
  }

  toJSON() {
    return {
      capacity: this.capacity,
      refillRate: this.refillRate,
      tokens: this.tokens,
      lastRefillTimestamp: this.lastRefillTimestamp
    };
  }

  static fromJSON(data) {
    return new TokenBucket(data);
  }
}

/**
 * Leaky Bucket Rate Smoother.
 * Prevents instantaneous bursting by enforcing a minimum interval between requests.
 */
export class LeakyBucketSmoother {
  constructor({ minIntervalMs = 1500, lastExecutionTime = 0 } = {}) {
    this.minIntervalMs = minIntervalMs;
    this.lastExecutionTime = lastExecutionTime;
  }

  getWaitTime(now = Date.now()) {
    const elapsed = now - this.lastExecutionTime;
    return elapsed < this.minIntervalMs ? this.minIntervalMs - elapsed : 0;
  }

  recordExecution(now = Date.now()) {
    this.lastExecutionTime = now;
  }

  toJSON() {
    return {
      minIntervalMs: this.minIntervalMs,
      lastExecutionTime: this.lastExecutionTime
    };
  }

  static fromJSON(data) {
    return new LeakyBucketSmoother(data);
  }
}

/**
 * Sliding 24-Hour Rolling Quota Tracker.
 * Tracks timestamps of actions, prunes records older than 24h, and calculates remaining slots.
 */
export class RollingQuotaTracker {
  static WINDOW_MS = 24 * 60 * 60 * 1000; // 86,400,000 ms

  constructor(initialData = {}) {
    this.quotas = {};
    for (const [actionType, timestamps] of Object.entries(initialData)) {
      if (Array.isArray(timestamps)) {
        this.quotas[actionType] = [...timestamps];
      }
    }
  }

  prune(actionType, now = Date.now()) {
    if (!this.quotas[actionType]) {
      this.quotas[actionType] = [];
      return [];
    }
    const cutoff = now - RollingQuotaTracker.WINDOW_MS;
    this.quotas[actionType] = this.quotas[actionType].filter(t => t > cutoff);
    return this.quotas[actionType];
  }

  pruneAll(now = Date.now()) {
    for (const actionType of Object.keys(this.quotas)) {
      this.prune(actionType, now);
    }
  }

  getUsage(actionType, now = Date.now()) {
    const valid = this.prune(actionType, now);
    return valid.length;
  }

  canExecute(actionType, maxQuota = null, now = Date.now()) {
    const limit = maxQuota ?? DEFAULT_ROLLING_QUOTAS_24H[actionType] ?? 100;
    const usage = this.getUsage(actionType, now);
    return usage < limit;
  }

  getRemainingQuota(actionType, maxQuota = null, now = Date.now()) {
    const limit = maxQuota ?? DEFAULT_ROLLING_QUOTAS_24H[actionType] ?? 100;
    const usage = this.getUsage(actionType, now);
    return Math.max(0, limit - usage);
  }

  recordAction(actionType, timestamp = Date.now()) {
    this.prune(actionType, timestamp);
    if (!this.quotas[actionType]) {
      this.quotas[actionType] = [];
    }
    this.quotas[actionType].push(timestamp);
    return this.quotas[actionType].length;
  }

  getTimeUntilNextSlot(actionType, maxQuota = null, now = Date.now()) {
    const limit = maxQuota ?? DEFAULT_ROLLING_QUOTAS_24H[actionType] ?? 100;
    const timestamps = this.prune(actionType, now);
    if (timestamps.length < limit) {
      return 0;
    }
    const oldest = Math.min(...timestamps);
    const expireTime = oldest + RollingQuotaTracker.WINDOW_MS;
    return Math.max(0, expireTime - now);
  }

  toJSON() {
    this.pruneAll();
    return { ...this.quotas };
  }

  static fromJSON(data) {
    return new RollingQuotaTracker(data);
  }
}

/**
 * Unified Rate Limiter coordinating Token Bucket, Leaky Bucket Smoother,
 * Humanized Jitter, and 24h Rolling Quotas.
 */
export class RateLimiter {
  constructor({
    buckets = {},
    smoother = null,
    quotaTracker = null,
    jitterRatio = JITTER_CONFIG.DEFAULT_RATIO,
    customDelays = {}
  } = {}) {
    this.buckets = new Map();
    for (const [type, cfg] of Object.entries(buckets)) {
      this.buckets.set(type, cfg instanceof TokenBucket ? cfg : new TokenBucket(cfg));
    }
    this.smoother = smoother instanceof LeakyBucketSmoother ? smoother : new LeakyBucketSmoother();
    this.quotaTracker = quotaTracker instanceof RollingQuotaTracker ? quotaTracker : new RollingQuotaTracker();
    this.jitterRatio = jitterRatio;
    this.customDelays = customDelays;
  }

  getOrCreateBucket(actionType) {
    if (!this.buckets.has(actionType)) {
      // Default: capacity 5, refill 0.2 (1 token every 5s)
      this.buckets.set(actionType, new TokenBucket({ capacity: 5, refillRate: 0.2 }));
    }
    return this.buckets.get(actionType);
  }

  checkQuota(actionType, maxQuota = null, now = Date.now()) {
    const limit = maxQuota ?? DEFAULT_ROLLING_QUOTAS_24H[actionType] ?? 100;
    const usage = this.quotaTracker.getUsage(actionType, now);
    return {
      allowed: usage < limit,
      remaining: Math.max(0, limit - usage),
      waitMs: this.quotaTracker.getTimeUntilNextSlot(actionType, maxQuota, now),
      limit,
      used: usage
    };
  }

  calculateDelay(actionType, options = {}) {
    const delaySpec = this.customDelays[actionType] || DEFAULT_DELAYS_MS[actionType] || { base: 3000, min: 2000, max: 5000 };
    return calculateHumanizedDelay(delaySpec.base, this.jitterRatio, {
      min: delaySpec.min,
      max: delaySpec.max,
      ...options
    });
  }

  async acquire(actionType, options = {}) {
    const now = Date.now();
    const quotaCheck = this.checkQuota(actionType, options.maxQuota, now);
    if (!quotaCheck.allowed) {
      return {
        allowed: false,
        reason: 'QUOTA_EXCEEDED_24H',
        waitMs: quotaCheck.waitMs
      };
    }

    const bucket = this.getOrCreateBucket(actionType);
    const tokenResult = bucket.tryConsume(1, now);
    const leakyWait = this.smoother.getWaitTime(now);
    const jitterDelay = this.calculateDelay(actionType, options);

    const baseWait = Math.max(tokenResult.waitMs, leakyWait);
    const totalDelayMs = baseWait + jitterDelay;

    return {
      allowed: true,
      totalDelayMs,
      breakdown: {
        tokenWaitMs: tokenResult.waitMs,
        leakyWaitMs: leakyWait,
        jitterDelayMs: jitterDelay
      }
    };
  }

  async consume(actionType, options = {}) {
    const res = await this.acquire(actionType, options);
    if (!res.allowed) {
      const err = new Error(`Rate limit exceeded: ${res.reason}`);
      err.code = 'QUOTA_EXCEEDED';
      err.waitMs = res.waitMs;
      throw err;
    }
    return res.totalDelayMs;
  }

  recordSuccess(actionType, timestamp = Date.now()) {
    this.smoother.recordExecution(timestamp);
    this.quotaTracker.recordAction(actionType, timestamp);
  }

  recordAction(actionType, timestamp = Date.now()) {
    this.recordSuccess(actionType, timestamp);
  }

  serialize() {
    const bucketsObj = {};
    for (const [k, v] of this.buckets.entries()) {
      bucketsObj[k] = v.toJSON();
    }
    return {
      buckets: bucketsObj,
      smoother: this.smoother.toJSON(),
      quotas: this.quotaTracker.toJSON(),
      jitterRatio: this.jitterRatio
    };
  }

  hydrate(data) {
    if (!data) return;
    if (data.buckets) {
      this.buckets.clear();
      for (const [k, v] of Object.entries(data.buckets)) {
        this.buckets.set(k, TokenBucket.fromJSON(v));
      }
    }
    if (data.smoother) {
      this.smoother = LeakyBucketSmoother.fromJSON(data.smoother);
    }
    if (data.quotas) {
      this.quotaTracker = RollingQuotaTracker.fromJSON(data.quotas);
    }
    if (data.jitterRatio !== undefined) {
      this.jitterRatio = data.jitterRatio;
    }
  }
}
