/**
 * Facebook Toolkit Pro - Action Runner Engine
 * Universal action execution pipeline integrating:
 * - Simulation Mode vs Live Execution
 * - Circuit Breaker State Verification
 * - 24-Hour Rolling Quota Enforcement
 * - Rate Limiter Delay & Gaussian Jitter
 * - Fast Mode for Non-Blocking Test Runs
 * - Batch Processing with AbortSignal & Progress Events
 * - Audit History Logging
 */

export class ActionRunner {
  constructor({
    storageManager = null,
    rateLimiter = null,
    circuitBreaker = null,
    isSimulation = true,
    fastMode = false,
    logger = console.log
  } = {}) {
    this.storageManager = storageManager;
    this.rateLimiter = rateLimiter;
    this.circuitBreaker = circuitBreaker;
    this.simulationMode = isSimulation;
    this.fastMode = fastMode;
    this.logger = logger;
  }

  isSimulation() {
    return this.simulationMode;
  }

  setSimulation(enabled) {
    this.simulationMode = Boolean(enabled);
  }

  setFastMode(enabled) {
    this.fastMode = Boolean(enabled);
  }

  /**
   * Universal single-action execution pipeline
   */
  async execute(actionType, target, executor = null, options = {}) {
    const startTime = Date.now();
    const targetId = typeof target === 'object' && target !== null ? (target.id || JSON.stringify(target)) : String(target);
    const fastMode = options.fastMode !== undefined ? options.fastMode : this.fastMode;
    const throwOnError = options.throwOnError !== false;

    // Step 1: Circuit Breaker Inspection
    if (this.circuitBreaker) {
      let isAllowed = true;
      if (typeof this.circuitBreaker.canExecute === 'function') {
        const check = this.circuitBreaker.canExecute();
        isAllowed = typeof check === 'boolean' ? check : check.allowed;
      }
      if (!isAllowed) {
        const state = typeof this.circuitBreaker.getState === 'function' ? this.circuitBreaker.getState() : 'OPEN';
        const error = new Error(`Circuit breaker is ${state}. Actions temporarily suspended.`);
        error.code = 'CIRCUIT_BREAKER_OPEN';
        if (throwOnError) throw error;
        return {
          success: false,
          actionType,
          targetId,
          error: error.message,
          isSimulation: this.simulationMode
        };
      }
    }

    // Step 2: 24-Hour Rolling Quota Verification
    if (this.rateLimiter && typeof this.rateLimiter.checkQuota === 'function') {
      const quotaStatus = this.rateLimiter.checkQuota(actionType);
      if (!quotaStatus.allowed) {
        const limit = quotaStatus.limit !== undefined ? quotaStatus.limit : 'unknown';
        const used = quotaStatus.used !== undefined ? quotaStatus.used : 'unknown';
        const error = new Error(`24h rolling quota exceeded for action "${actionType}". Limit: ${limit}, Used: ${used}.`);
        error.code = 'QUOTA_EXCEEDED';
        if (throwOnError) throw error;
        return {
          success: false,
          actionType,
          targetId,
          error: error.message,
          isSimulation: this.simulationMode
        };
      }
    }

    // Step 3: Rate Limiting & Jitter Delay Acquisition
    let delayAppliedMs = 0;
    if (this.rateLimiter) {
      if (typeof this.rateLimiter.consume === 'function') {
        delayAppliedMs = await this.rateLimiter.consume(actionType, { dryRun: fastMode });
      } else if (typeof this.rateLimiter.acquire === 'function') {
        const res = await this.rateLimiter.acquire(actionType);
        if (!res.allowed) {
          const error = new Error(`Rate limit exceeded for action "${actionType}": ${res.reason}`);
          error.code = 'QUOTA_EXCEEDED';
          if (throwOnError) throw error;
          return { success: false, actionType, targetId, error: error.message, isSimulation: this.simulationMode };
        }
        delayAppliedMs = res.totalDelayMs;
      }

      if (!fastMode && delayAppliedMs > 0) {
        await this._sleep(delayAppliedMs);
      }
    }

    // Step 4: Execute Action (Simulation vs Live)
    let result = null;
    let success = false;
    let executionError = null;

    try {
      if (this.simulationMode) {
        if (typeof options.mockExecutor === 'function') {
          result = await options.mockExecutor(target);
        } else {
          result = { simulated: true, actionType, targetId, timestamp: Date.now() };
        }
        success = true;
      } else {
        if (typeof executor !== 'function') {
          throw new Error(`Live execution requires an executor function for action "${actionType}".`);
        }
        result = await executor(target);
        success = true;
      }
    } catch (err) {
      executionError = err;
      success = false;
    }

    // Step 5: Post-Execution Handling & Feedback
    const completedAt = Date.now();
    if (success) {
      if (this.circuitBreaker && typeof this.circuitBreaker.recordSuccess === 'function') {
        this.circuitBreaker.recordSuccess();
      }
      if (this.rateLimiter) {
        if (typeof this.rateLimiter.recordSuccess === 'function') {
          this.rateLimiter.recordSuccess(actionType, completedAt);
        } else if (typeof this.rateLimiter.recordAction === 'function') {
          this.rateLimiter.recordAction(actionType, completedAt);
        }
      }
      if (this.storageManager && typeof this.storageManager.recordQuotaTimestamp === 'function') {
        await this.storageManager.recordQuotaTimestamp(actionType, completedAt);
      }
    } else {
      if (this.circuitBreaker && typeof this.circuitBreaker.recordFailure === 'function') {
        this.circuitBreaker.recordFailure(executionError);
      }
      if (throwOnError) {
        throw executionError;
      }
    }

    // Step 6: Audit Logging
    const actionResult = {
      success,
      actionType,
      targetId,
      result,
      error: executionError ? (executionError.message || String(executionError)) : null,
      delayAppliedMs,
      timestamp: completedAt,
      isSimulation: this.simulationMode,
      durationMs: completedAt - startTime
    };

    if (this.storageManager && typeof this.storageManager.appendActionLog === 'function') {
      try {
        await this.storageManager.appendActionLog(actionResult);
      } catch (logErr) {
        this.logger(`[ActionRunner] Failed to persist action log: ${logErr.message}`);
      }
    }

    return actionResult;
  }

  /**
   * Batch execution with item delays, cooldowns, abort signals, and progress reporting
   */
  async executeBatch(actionType, targets, executorFactory, options = {}) {
    const total = targets.length;
    const results = [];
    const abortSignal = options.abortSignal;
    const onProgress = typeof options.onProgress === 'function' ? options.onProgress : null;
    const stopOnError = options.stopOnError === true;
    const batchSize = options.batchSize || Infinity;
    const cooldownMs = options.cooldownMs || 0;
    const fastMode = options.fastMode !== undefined ? options.fastMode : this.fastMode;

    for (let i = 0; i < total; i++) {
      if (abortSignal && abortSignal.aborted) {
        this.logger(`[ActionRunner] Batch for "${actionType}" aborted at item ${i + 1}/${total}.`);
        break;
      }

      const target = targets[i];
      const executor = typeof executorFactory === 'function' ? executorFactory(target, i) : null;

      let res;
      try {
        res = await this.execute(actionType, target, executor, {
          ...options,
          throwOnError: stopOnError
        });
      } catch (batchErr) {
        res = {
          success: false,
          actionType,
          targetId: target?.id || String(target),
          error: batchErr.message,
          isSimulation: this.simulationMode
        };
        if (stopOnError) {
          results.push(res);
          break;
        }
      }

      results.push(res);

      if (onProgress) {
        onProgress({
          completed: i + 1,
          total,
          percent: Math.round(((i + 1) / total) * 100),
          currentItem: target,
          currentResult: res
        });
      }

      // Check inter-batch cooldown
      if (!fastMode && (i + 1) % batchSize === 0 && (i + 1) < total && cooldownMs > 0) {
        this.logger(`[ActionRunner] Reached batch size ${batchSize}. Cooling down for ${cooldownMs}ms...`);
        await this._sleep(cooldownMs);
      }
    }

    return results;
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
