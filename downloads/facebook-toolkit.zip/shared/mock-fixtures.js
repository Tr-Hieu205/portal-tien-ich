/**
 * Facebook Toolkit Pro - Deterministic Mock Data Fixtures
 * Seeded PRNG (Mulberry32) generating synthetic test datasets:
 * - 150 Stratified Friends (ghost, inactive, moderate, active)
 * - 50 Timeline Posts (with keyword and date variations)
 * - 5 Photo Albums with High-Res / Standard photo items
 * - 10 MP4 Videos with HD / SD stream URLs
 * - 20 Conversation Message Threads
 * - 15 Upcoming Birthdays
 */

export class SeededPRNG {
  constructor(seed = 1337) {
    this.seed = (seed >>> 0) || 1;
  }

  next() {
    let t = (this.seed += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  nextInt(min, max) {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }

  nextFloat(min, max) {
    return this.next() * (max - min) + min;
  }

  choice(arr) {
    if (!arr || arr.length === 0) return null;
    return arr[this.nextInt(0, arr.length - 1)];
  }

  sample(arr, count) {
    const copy = [...arr];
    const result = [];
    const n = Math.min(count, copy.length);
    for (let i = 0; i < n; i++) {
      const idx = this.nextInt(0, copy.length - 1);
      result.push(copy.splice(idx, 1)[0]);
    }
    return result;
  }

  nextBoolean(prob = 0.5) {
    return this.next() < prob;
  }
}

const FIRST_NAMES = [
  'Minh', 'Linh', 'Duc', 'Hoang', 'Trang', 'Nam', 'Phuong', 'Thao', 'Tuan', 'Hanh',
  'Alex', 'Jordan', 'Taylor', 'Morgan', 'Sam', 'Chris', 'Pat', 'Riley', 'Cameron', 'Casey',
  'David', 'Sarah', 'Michael', 'Emma', 'Daniel', 'Olivia', 'James', 'Sophia', 'Lucas', 'Mia'
];

const LAST_NAMES = [
  'Nguyen', 'Tran', 'Le', 'Pham', 'Hoang', 'Phan', 'Vu', 'Dang', 'Bui', 'Do',
  'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Wilson', 'Anderson', 'Taylor'
];

const POST_TOPICS = [
  { keyword: 'ex', content: 'Cleaning up memories with my ex. Time to move on and start a fresh chapter!' },
  { keyword: 'happy birthday', content: 'Happy birthday to my dearest friend! Wishing you all the health, joy and success!' },
  { keyword: 'vacation', content: 'Unbelievable summer vacation in Da Nang and Hoi An. The beaches and food were marvelous.' },
  { keyword: 'announcement', content: 'Big announcement: I am thrilled to share that I have started a new position today!' },
  { keyword: 'throwback', content: 'Throwback Thursday! Looking back at our graduation day 5 years ago, how time flies.' },
  { keyword: 'politics', content: 'Interesting political debate on renewable energy investments and civic infrastructure.' },
  { keyword: 'tech', content: 'Diving deep into modern web development, service workers, and privacy engineering.' },
  { keyword: 'food', content: 'Sunday homemade cooking: traditional beef pho with fresh herbs and lime.' }
];

export function calculateInteractionScore(messages, reactions, comments, daysSinceLast) {
  const engagement = (messages * 0.4) + (reactions * 0.3) + (comments * 0.3);
  const recencyFactor = Math.exp(-daysSinceLast / 180);
  const raw = engagement * recencyFactor;
  return Math.max(0, Math.min(100, Math.round(raw * 10) / 10));
}

export function generateMockDataset(seed = 1337) {
  const prng = new SeededPRNG(seed);
  const now = 1731657600000; // Fixed baseline timestamp for reproducibility (~Nov 2024 / 2026)

  // 1. Generate 150 Stratified Friends
  // Stratification:
  // - 30 Ghost (index 0..29)
  // - 45 Inactive (index 30..74)
  // - 45 Moderate (index 75..119)
  // - 30 Active (index 120..149)
  const friends = [];
  for (let i = 0; i < 150; i++) {
    const friendId = `1000${String(80000000000 + i)}`;
    const firstName = prng.choice(FIRST_NAMES);
    const lastName = prng.choice(LAST_NAMES);
    const fullName = `${firstName} ${lastName}`;
    const mutualFriends = prng.nextInt(0, 150);

    let tier, messageCount, reactionCount, commentCount, daysSinceLast, unfriendEligible;

    if (i < 30) {
      // Ghost
      tier = 'ghost';
      messageCount = 0;
      reactionCount = 0;
      commentCount = 0;
      daysSinceLast = prng.nextInt(181, 730);
      unfriendEligible = true;
    } else if (i < 75) {
      // Inactive
      tier = 'inactive';
      messageCount = prng.nextInt(1, 5);
      reactionCount = prng.nextInt(0, 2);
      commentCount = prng.nextInt(0, 1);
      daysSinceLast = prng.nextInt(90, 365);
      unfriendEligible = true;
    } else if (i < 120) {
      // Moderate
      tier = 'moderate';
      messageCount = prng.nextInt(10, 100);
      reactionCount = prng.nextInt(5, 30);
      commentCount = prng.nextInt(1, 15);
      daysSinceLast = prng.nextInt(15, 90);
      unfriendEligible = false;
    } else {
      // Active
      tier = 'active';
      messageCount = prng.nextInt(100, 1200);
      reactionCount = prng.nextInt(30, 150);
      commentCount = prng.nextInt(15, 90);
      daysSinceLast = prng.nextInt(0, 14);
      unfriendEligible = false;
    }

    let score = calculateInteractionScore(messageCount, reactionCount, commentCount, daysSinceLast);
    if (tier === 'ghost') score = 0;
    if (tier === 'inactive' && score >= 15) score = 14.5;
    if (tier === 'moderate' && score < 15) score = 15.0;
    if (tier === 'moderate' && score > 60) score = 60.0;
    if (tier === 'active' && score <= 60) score = 61.0;

    friends.push({
      id: friendId,
      name: fullName,
      profileUrl: `https://www.facebook.com/profile.php?id=${friendId}`,
      avatarUrl: `https://graph.facebook.com/${friendId}/picture?type=large`,
      mutualFriends,
      messageCount,
      daysSinceLastInteraction: daysSinceLast,
      reactionCount,
      commentCount,
      interactionScore: score,
      tier,
      unfriendEligible,
      isShielded: prng.nextBoolean(0.3),
      poked: false
    });
  }

  // 2. Generate 50 Timeline Posts
  const posts = [];
  for (let i = 0; i < 50; i++) {
    const postId = `post_${10001 + i}`;
    const topic = POST_TOPICS[i % POST_TOPICS.length];
    // Dates spanning past 3 years (0 to 1095 days ago)
    const daysAgo = prng.nextInt(5, 1000);
    const postTimestamp = now - daysAgo * 86400000;
    const author = prng.choice(friends);

    const commentsCount = prng.nextInt(0, 20);
    const comments = [];
    for (let c = 0; c < Math.min(5, commentsCount); c++) {
      const commenter = prng.choice(friends);
      comments.push({
        id: `comment_${postId}_${c + 1}`,
        authorId: commenter.id,
        authorName: commenter.name,
        text: `Nice post! Insightful perspective on this. #${c + 1}`,
        timestamp: postTimestamp + (c + 1) * 3600000
      });
    }

    const mediaTypes = ['text', 'photo', 'video', 'link'];
    const mediaType = prng.choice(mediaTypes);

    posts.push({
      id: postId,
      authorId: author.id,
      authorName: author.name,
      timestamp: postTimestamp,
      dateIso: new Date(postTimestamp).toISOString(),
      content: `${topic.content} (Ref: ${i + 1})`,
      keyword: topic.keyword,
      mediaType,
      mediaUrl: mediaType !== 'text' ? `https://scontent.xx.fbcdn.net/v/post_${postId}_media.jpg` : undefined,
      likesCount: prng.nextInt(2, 250),
      commentsCount,
      comments,
      isDeleted: false,
      isHidden: false,
      isArchived: false
    });
  }

  // 3. Generate 5 Photo Albums
  const albumTitles = [
    'Summer Vacation 2024',
    'Family & Friends',
    'Profile Pictures',
    'Mobile Uploads',
    'Cover Photos'
  ];
  const albums = [];
  for (let a = 0; a < albumTitles.length; a++) {
    const albumId = `album_${20001 + a}`;
    const photoCount = prng.nextInt(10, 25);
    const photos = [];
    const createdAt = now - (a + 1) * 60 * 86400000;

    for (let p = 0; p < photoCount; p++) {
      const photoId = `photo_${albumId}_${p + 1}`;
      photos.push({
        id: photoId,
        albumId,
        title: `${albumTitles[a]} - Photo #${p + 1}`,
        highResUrl: `https://scontent.xx.fbcdn.net/v/high_res_${photoId}.jpg`,
        normalResUrl: `https://scontent.xx.fbcdn.net/v/normal_res_${photoId}.jpg`,
        width: 1920,
        height: 1080,
        timestamp: createdAt + p * 1800000
      });
    }

    albums.push({
      id: albumId,
      title: albumTitles[a],
      description: `Album containing memories from ${albumTitles[a]}`,
      photoCount: photos.length,
      createdAt,
      photos
    });
  }

  // 4. Generate 10 MP4 Videos
  const videos = [];
  for (let v = 0; v < 10; v++) {
    const videoId = `fb_video_${30001 + v}`;
    const durationSec = prng.nextInt(15, 300);
    const createdAt = now - (v + 1) * 15 * 86400000;
    videos.push({
      id: videoId,
      title: `Highlights Clip #${v + 1}`,
      description: `Recorded video memory clip #${v + 1}`,
      durationSec,
      createdAt,
      hdUrl: `https://video.xx.fbcdn.net/v/hd_stream_${videoId}.mp4`,
      sdUrl: `https://video.xx.fbcdn.net/v/sd_stream_${videoId}.mp4`,
      thumbnailUrl: `https://video.xx.fbcdn.net/v/thumb_${videoId}.jpg`
    });
  }

  // 5. Generate 20 Message Conversation Threads
  const threads = [];
  const sampledFriends = friends.slice(60, 80);
  for (let t = 0; t < 20; t++) {
    const threadId = `thread_${40001 + t}`;
    const friend = sampledFriends[t % sampledFriends.length];
    const msgCount = prng.nextInt(3, 10);
    const messages = [];
    const baseTime = now - prng.nextInt(1, 30) * 86400000;

    for (let m = 0; m < msgCount; m++) {
      const isFromMe = prng.nextBoolean(0.5);
      messages.push({
        id: `msg_${threadId}_${m + 1}`,
        threadId,
        senderId: isFromMe ? 'me_user_1' : friend.id,
        senderName: isFromMe ? 'Me' : friend.name,
        text: `Message content #${m + 1} in conversation with ${friend.name}`,
        timestamp: baseTime + m * 600000,
        isRead: true,
        deliveryStatus: 'read'
      });
    }

    threads.push({
      threadId,
      participantId: friend.id,
      participantName: friend.name,
      unreadCount: 0,
      lastActivityTimestamp: baseTime + (msgCount - 1) * 600000,
      messages
    });
  }

  // 6. Generate 15 Upcoming Birthdays
  const birthdays = [];
  const bdayFriends = friends.slice(10, 25);
  for (let b = 0; b < 15; b++) {
    const friend = bdayFriends[b % bdayFriends.length];
    const daysUntil = prng.nextInt(0, 30);
    const bdayDate = new Date(now + daysUntil * 86400000);
    const month = String(bdayDate.getMonth() + 1).padStart(2, '0');
    const day = String(bdayDate.getDate()).padStart(2, '0');

    birthdays.push({
      friendId: friend.id,
      friendName: friend.name,
      avatarUrl: friend.avatarUrl,
      birthDate: `${month}-${day}`,
      daysUntil,
      alreadyGreeted: false
    });
  }

  return {
    friends,
    posts,
    albums,
    videos,
    threads,
    birthdays
  };
}

// CRC32 table for ZIP checksums
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
  }
  crcTable[n] = c >>> 0;
}

function calculateCrc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ crcTable[(crc ^ buf[i]) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export function createZipBuffer(entries) {
  const localChunks = [];
  const cdChunks = [];
  let offset = 0;

  for (const entry of entries) {
    const nameStr = entry.name.replace(/\\/g, '/');
    const nameBuf = typeof Buffer !== 'undefined'
      ? Buffer.from(nameStr, 'utf8')
      : new TextEncoder().encode(nameStr);

    let rawData;
    if (typeof Buffer !== 'undefined' && Buffer.isBuffer(entry.data)) {
      rawData = entry.data;
    } else if (entry.data instanceof Uint8Array) {
      rawData = entry.data;
    } else {
      rawData = typeof Buffer !== 'undefined'
        ? Buffer.from(entry.data)
        : new TextEncoder().encode(entry.data);
    }

    const dataLen = rawData.length;
    const crc = calculateCrc32(rawData);

    // Local file header (30 bytes)
    const lh = typeof Buffer !== 'undefined' ? Buffer.alloc(30) : new Uint8Array(30);
    const lhView = new DataView(lh.buffer, lh.byteOffset, lh.byteLength);
    lhView.setUint32(0, 0x04034b50, true); // PK\x03\x04
    lhView.setUint16(4, 20, true);         // version needed
    lhView.setUint16(6, 0, true);          // flags
    lhView.setUint16(8, 0, true);          // method 0 = Stored (no compression needed)
    lhView.setUint16(10, 0, true);         // mod time
    lhView.setUint16(12, 0, true);         // mod date
    lhView.setUint32(14, crc, true);       // crc-32
    lhView.setUint32(18, dataLen, true);   // compressed size
    lhView.setUint32(22, dataLen, true);   // uncompressed size
    lhView.setUint16(26, nameBuf.length, true); // filename length
    lhView.setUint16(28, 0, true);         // extra length

    localChunks.push(lh, nameBuf, rawData);

    // Central directory header (46 bytes)
    const cd = typeof Buffer !== 'undefined' ? Buffer.alloc(46) : new Uint8Array(46);
    const cdView = new DataView(cd.buffer, cd.byteOffset, cd.byteLength);
    cdView.setUint32(0, 0x02014b50, true); // PK\x01\x02
    cdView.setUint16(4, 20, true);
    cdView.setUint16(6, 20, true);
    cdView.setUint16(8, 0, true);
    cdView.setUint16(10, 0, true);         // method 0 = Stored
    cdView.setUint16(12, 0, true);
    cdView.setUint16(14, 0, true);
    cdView.setUint32(16, crc, true);
    cdView.setUint32(20, dataLen, true);
    cdView.setUint32(24, dataLen, true);
    cdView.setUint16(28, nameBuf.length, true);
    cdView.setUint16(30, 0, true);
    cdView.setUint16(32, 0, true);
    cdView.setUint16(34, 0, true);
    cdView.setUint16(36, 0, true);
    cdView.setUint32(38, 0, true);
    cdView.setUint32(42, offset, true);

    cdChunks.push(cd, nameBuf);
    offset += lh.length + nameBuf.length + dataLen;
  }

  const cdOffset = offset;
  const cdSize = cdChunks.reduce((acc, c) => acc + c.length, 0);

  // End of central directory record (22 bytes)
  const eocd = typeof Buffer !== 'undefined' ? Buffer.alloc(22) : new Uint8Array(22);
  const eocdView = new DataView(eocd.buffer, eocd.byteOffset, eocd.byteLength);
  eocdView.setUint32(0, 0x06054b50, true); // PK\x05\x06
  eocdView.setUint16(4, 0, true);
  eocdView.setUint16(6, 0, true);
  eocdView.setUint16(8, entries.length, true);
  eocdView.setUint16(10, entries.length, true);
  eocdView.setUint32(12, cdSize, true);
  eocdView.setUint32(16, cdOffset, true);
  eocdView.setUint16(20, 0, true);

  const allChunks = [...localChunks, ...cdChunks, eocd];
  if (typeof Buffer !== 'undefined') {
    return Buffer.concat(allChunks);
  }

  const totalLen = allChunks.reduce((acc, c) => acc + c.length, 0);
  const out = new Uint8Array(totalLen);
  let pos = 0;
  for (const chunk of allChunks) {
    out.set(chunk, pos);
    pos += chunk.length;
  }
  return out;
}

export function chunkPhotos(photos, chunkSize = 50) {
  if (!Array.isArray(photos)) return [];
  const chunks = [];
  for (let i = 0; i < photos.length; i += chunkSize) {
    chunks.push(photos.slice(i, i + chunkSize));
  }
  return chunks;
}

export function formatMessageContent(msg) {
  if (!msg) return '';
  if (msg.isUnsent) return '[Message Unsent]';
  return msg.text || msg.content || '';
}

export function resolveSenderName(senderId, participantMap = {}) {
  return participantMap[senderId] || 'Unknown User';
}

export function streamMessageBatch(totalMessages, batchSize = 5000) {
  let processed = 0;
  let batchCount = 0;
  while (processed < totalMessages) {
    const count = Math.min(batchSize, totalMessages - processed);
    processed += count;
    batchCount++;
  }
  return { total: processed, batches: batchCount };
}
