/**
 * Facebook Toolkit Pro - System Constants & Defaults
 * Shared configuration constants across background, content, UI and tests.
 */

export const ACTION_TYPES = Object.freeze({
  UNFRIEND: 'UNFRIEND',
  POKE: 'POKE',
  STORY_REACT: 'STORY_REACT',
  POST_DELETE: 'POST_DELETE',
  POST_HIDE: 'POST_HIDE',
  POST_ARCHIVE: 'POST_ARCHIVE',
  COMMENT_DELETE: 'COMMENT_DELETE',
  PHOTO_DELETE: 'PHOTO_DELETE',
  ALBUM_DOWNLOAD: 'ALBUM_DOWNLOAD',
  VIDEO_DOWNLOAD: 'VIDEO_DOWNLOAD',
  EXPORT_FRIENDS: 'EXPORT_FRIENDS',
  EXPORT_MESSAGES: 'EXPORT_MESSAGES',
  AVATAR_GUARD: 'AVATAR_GUARD',
  BIRTHDAY_GREETING: 'BIRTHDAY_GREETING',
  REUP_POST: 'REUP_POST'
});

export const FB_ERROR_CODES = Object.freeze({
  CHECKPOINT_368: 368,          // Action blocked / checkpoint triggered
  TOO_MANY_REQUESTS_429: 429,   // HTTP 429 Too Many Requests
  TEMPORARY_BLOCK_1357004: 1357004, // Feature limit / temporary restriction
  ACTION_THROTTLED_1404078: 1404078, // Action throttled / safety cooldown
  STALE_TOKEN_1357001: 1357001  // Stale or invalid CSRF / fb_dtsg token
});

export const CRITICAL_FB_ERROR_CODES = Object.freeze([
  FB_ERROR_CODES.CHECKPOINT_368,
  FB_ERROR_CODES.TOO_MANY_REQUESTS_429,
  FB_ERROR_CODES.TEMPORARY_BLOCK_1357004,
  FB_ERROR_CODES.ACTION_THROTTLED_1404078
]);

export const DEFAULT_DELAYS_MS = Object.freeze({
  [ACTION_TYPES.UNFRIEND]: { base: 4500, min: 3000, max: 7000 },
  [ACTION_TYPES.POKE]: { base: 3000, min: 2000, max: 5000 },
  [ACTION_TYPES.STORY_REACT]: { base: 2200, min: 1500, max: 3500 },
  [ACTION_TYPES.POST_DELETE]: { base: 4000, min: 2500, max: 6000 },
  [ACTION_TYPES.POST_HIDE]: { base: 3000, min: 2000, max: 5000 },
  [ACTION_TYPES.POST_ARCHIVE]: { base: 3000, min: 2000, max: 5000 },
  [ACTION_TYPES.COMMENT_DELETE]: { base: 2500, min: 1500, max: 4000 },
  [ACTION_TYPES.PHOTO_DELETE]: { base: 3000, min: 2000, max: 4500 },
  [ACTION_TYPES.ALBUM_DOWNLOAD]: { base: 1500, min: 1000, max: 2500 },
  [ACTION_TYPES.VIDEO_DOWNLOAD]: { base: 5000, min: 3000, max: 8000 },
  [ACTION_TYPES.EXPORT_FRIENDS]: { base: 2000, min: 1000, max: 3000 },
  [ACTION_TYPES.EXPORT_MESSAGES]: { base: 2500, min: 1500, max: 4000 },
  [ACTION_TYPES.AVATAR_GUARD]: { base: 3000, min: 2000, max: 5000 },
  [ACTION_TYPES.BIRTHDAY_GREETING]: { base: 12000, min: 8000, max: 20000 },
  [ACTION_TYPES.REUP_POST]: { base: 60000, min: 30000, max: 90000 }
});

export const JITTER_CONFIG = Object.freeze({
  DEFAULT_RATIO: 0.35, // +/- 35% variance around base delay
  PARETO_ALPHA: 2.5,   // Shape parameter for power-law distraction tail
  PARETO_MIN_MS: 1500, // Minimum thinking pause
  PARETO_MAX_MS: 15000,// Maximum clamped thinking pause
  PARETO_PROBABILITY: 0.10 // 10% chance of human pause
});

export const DEFAULT_ROLLING_QUOTAS_24H = Object.freeze({
  [ACTION_TYPES.UNFRIEND]: 50,
  [ACTION_TYPES.POKE]: 100,
  [ACTION_TYPES.STORY_REACT]: 200,
  [ACTION_TYPES.POST_DELETE]: 100,
  [ACTION_TYPES.POST_HIDE]: 150,
  [ACTION_TYPES.POST_ARCHIVE]: 150,
  [ACTION_TYPES.COMMENT_DELETE]: 100,
  [ACTION_TYPES.PHOTO_DELETE]: 100,
  [ACTION_TYPES.ALBUM_DOWNLOAD]: 500,
  [ACTION_TYPES.VIDEO_DOWNLOAD]: 50,
  [ACTION_TYPES.EXPORT_FRIENDS]: 20,
  [ACTION_TYPES.EXPORT_MESSAGES]: 20,
  [ACTION_TYPES.AVATAR_GUARD]: 10,
  [ACTION_TYPES.BIRTHDAY_GREETING]: 25,
  [ACTION_TYPES.REUP_POST]: 10
});

export const CIRCUIT_BREAKER_STATES = Object.freeze({
  CLOSED: 'CLOSED',
  OPEN: 'OPEN',
  HALF_OPEN: 'HALF_OPEN'
});

export const CIRCUIT_BREAKER_DEFAULTS = Object.freeze({
  FAILURE_THRESHOLD: 3,
  FAILURE_WINDOW_MS: 60000,
  BASE_COOLDOWNS_MS: {
    TRANSIENT: 60000,        // 1 minute
    HTTP_429: 300000,        // 5 minutes
    CHECKPOINT_368: 900000,  // 15 minutes
    BLOCK_1357004: 900000,   // 15 minutes
    THROTTLED_1404078: 300000// 5 minutes
  },
  MAX_BACKOFF_MS: 3600000,   // 1 hour max cooldown
  BACKOFF_FACTOR: 2,
  JITTER_RATIO: 0.15
});

export const STORAGE_KEYS = Object.freeze({
  SIMULATION_MODE: 'simulationMode',
  STEALTH_SETTINGS: 'stealthSettings',
  RATE_LIMITS: 'rateLimits',
  ROLLING_QUOTAS: 'rollingQuotas24h',
  CIRCUIT_BREAKER: 'circuitBreaker',
  CACHED_FRIENDS: 'cachedFriends',
  BIRTHDAY_HISTORY: 'birthdayHistory',
  BIRTHDAY_WHITELIST: 'birthdayWhitelist',
  REUP_QUEUE: 'reupQueue',
  ACTION_LOGS: 'actionLogs'
});

export const STORAGE_DEFAULTS = Object.freeze({
  [STORAGE_KEYS.SIMULATION_MODE]: true,
  [STORAGE_KEYS.STEALTH_SETTINGS]: {
    blockSeen: true,
    blockTyping: true
  },
  [STORAGE_KEYS.RATE_LIMITS]: {
    baseDelayMs: Object.fromEntries(
      Object.entries(DEFAULT_DELAYS_MS).map(([k, v]) => [k, v.base])
    ),
    jitterRatio: JITTER_CONFIG.DEFAULT_RATIO,
    batchSize: {
      [ACTION_TYPES.UNFRIEND]: 10,
      [ACTION_TYPES.POKE]: 20,
      [ACTION_TYPES.STORY_REACT]: 25,
      [ACTION_TYPES.POST_DELETE]: 10,
      [ACTION_TYPES.POST_HIDE]: 15,
      [ACTION_TYPES.POST_ARCHIVE]: 15,
      [ACTION_TYPES.COMMENT_DELETE]: 10,
      [ACTION_TYPES.PHOTO_DELETE]: 10,
      [ACTION_TYPES.ALBUM_DOWNLOAD]: 50,
      [ACTION_TYPES.VIDEO_DOWNLOAD]: 5,
      [ACTION_TYPES.BIRTHDAY_GREETING]: 5,
      [ACTION_TYPES.REUP_POST]: 1
    },
    cooldownMs: {
      [ACTION_TYPES.UNFRIEND]: 30000,
      [ACTION_TYPES.POKE]: 15000,
      [ACTION_TYPES.STORY_REACT]: 10000,
      [ACTION_TYPES.POST_DELETE]: 20000,
      [ACTION_TYPES.POST_HIDE]: 15000,
      [ACTION_TYPES.POST_ARCHIVE]: 15000,
      [ACTION_TYPES.COMMENT_DELETE]: 15000,
      [ACTION_TYPES.PHOTO_DELETE]: 15000,
      [ACTION_TYPES.ALBUM_DOWNLOAD]: 30000,
      [ACTION_TYPES.VIDEO_DOWNLOAD]: 45000,
      [ACTION_TYPES.BIRTHDAY_GREETING]: 60000,
      [ACTION_TYPES.REUP_POST]: 120000
    }
  },
  [STORAGE_KEYS.ROLLING_QUOTAS]: {},
  [STORAGE_KEYS.CIRCUIT_BREAKER]: {
    state: CIRCUIT_BREAKER_STATES.CLOSED,
    pausedUntil: 0,
    failureCount: 0,
    consecutiveTrips: 0,
    lastError: null
  },
  [STORAGE_KEYS.CACHED_FRIENDS]: [],
  [STORAGE_KEYS.BIRTHDAY_HISTORY]: {},
  [STORAGE_KEYS.BIRTHDAY_WHITELIST]: [],
  [STORAGE_KEYS.REUP_QUEUE]: [],
  [STORAGE_KEYS.ACTION_LOGS]: []
});

export const MAX_VIDEO_SIZE_BYTES = 500 * 1024 * 1024; // 500 MB

