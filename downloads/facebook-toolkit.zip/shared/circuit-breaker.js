/**
 * Facebook Toolkit Pro - Checkpoint Circuit Breaker
 * State Machine: CLOSED -> OPEN -> HALF_OPEN -> CLOSED
 * Checkpoint Interception (FB codes 368, 429, 1357004, 1404078)
 */

import {
  CIRCUIT_BREAKER_STATES,
  CIRCUIT_BREAKER_DEFAULTS,
  CRITICAL_FB_ERROR_CODES,
  FB_ERROR_CODES
} from './constants.js';

export class CircuitBreaker {
  constructor({
    state = CIRCUIT_BREAKER_STATES.CLOSED,
    failureThreshold = CIRCUIT_BREAKER_DEFAULTS.FAILURE_THRESHOLD,
    failureWindowMs = CIRCUIT_BREAKER_DEFAULTS.FAILURE_WINDOW_MS,
    baseCooldowns = CIRCUIT_BREAKER_DEFAULTS.BASE_COOLDOWNS_MS,
    maxBackoffMs = CIRCUIT_BREAKER_DEFAULTS.MAX_BACKOFF_MS,
    jitterRatio = CIRCUIT_BREAKER_DEFAULTS.JITTER_RATIO,
    pausedUntil = 0,
    failureCount = 0,
    consecutiveTrips = 0,
    lastFailureTime = 0,
    lastError = null
  } = {}) {
    this.state = state;
    this.failureThreshold = failureThreshold;
    this.failureWindowMs = failureWindowMs;
    this.baseCooldowns = { ...CIRCUIT_BREAKER_DEFAULTS.BASE_COOLDOWNS_MS, ...baseCooldowns };
    this.maxBackoffMs = maxBackoffMs;
    this.jitterRatio = jitterRatio;

    this.pausedUntil = pausedUntil;
    this.failureCount = failureCount;
    this.consecutiveTrips = consecutiveTrips;
    this.lastFailureTime = lastFailureTime;
    this.lastError = lastError;
    this.probeInProgress = false;
  }

  getState(now = Date.now()) {
    if (this.state === CIRCUIT_BREAKER_STATES.OPEN) {
      if (now >= this.pausedUntil) {
        this.state = CIRCUIT_BREAKER_STATES.HALF_OPEN;
        this.probeInProgress = false;
      }
    }
    return this.state;
  }

  canExecute(now = Date.now()) {
    const currentState = this.getState(now);

    if (currentState === CIRCUIT_BREAKER_STATES.CLOSED) {
      return { allowed: true, state: CIRCUIT_BREAKER_STATES.CLOSED };
    }

    if (currentState === CIRCUIT_BREAKER_STATES.OPEN) {
      const waitMs = Math.max(0, this.pausedUntil - now);
      return {
        allowed: false,
        state: CIRCUIT_BREAKER_STATES.OPEN,
        waitMs,
        reason: this.lastError?.message || 'Circuit breaker is OPEN'
      };
    }

    if (currentState === CIRCUIT_BREAKER_STATES.HALF_OPEN) {
      if (!this.probeInProgress) {
        this.probeInProgress = true;
        return {
          allowed: true,
          state: CIRCUIT_BREAKER_STATES.HALF_OPEN,
          isProbe: true
        };
      }
      return {
        allowed: false,
        state: CIRCUIT_BREAKER_STATES.HALF_OPEN,
        waitMs: 1000,
        reason: 'Circuit breaker probe already in progress'
      };
    }

    return { allowed: false, state: this.state, waitMs: 0 };
  }

  isCallAllowed(now = Date.now()) {
    return this.canExecute(now);
  }

  calculateBackoff(baseMs, trips) {
    const multiplier = Math.pow(CIRCUIT_BREAKER_DEFAULTS.BACKOFF_FACTOR, Math.max(0, trips - 1));
    const rawBackoff = Math.min(this.maxBackoffMs, baseMs * multiplier);
    // Add jitter: +/- jitterRatio
    const jitterVariance = rawBackoff * this.jitterRatio;
    const randomized = rawBackoff + (Math.random() * 2 - 1) * jitterVariance;
    return Math.round(Math.min(this.maxBackoffMs, Math.max(baseMs, randomized)));
  }

  extractErrorCode(error) {
    if (!error) return null;
    if (typeof error === 'number') {
      return !Number.isNaN(error) ? error : null;
    }
    if (typeof error === 'string') {
      const match = error.match(/\b(368|429|1357004|1404078)\b/) || error.match(/(?:^|[^\d])(368|429|1357004|1404078)(?:[^\d]|$)/);
      if (match) return Number(match[1]);
      const num = Number(error);
      if (!Number.isNaN(num) && CRITICAL_FB_ERROR_CODES.includes(num)) return num;
      return null;
    }
    if (error.code !== undefined && !Number.isNaN(Number(error.code))) {
      return Number(error.code);
    }
    if (error.status !== undefined && !Number.isNaN(Number(error.status))) {
      return Number(error.status);
    }
    if (error.error_code !== undefined && !Number.isNaN(Number(error.error_code))) {
      return Number(error.error_code);
    }
    const msg = error.message;
    if (msg && typeof msg === 'string') {
      const match = msg.match(/\b(368|429|1357004|1404078)\b/) || msg.match(/(?:^|[^\d])(368|429|1357004|1404078)(?:[^\d]|$)/);
      if (match) return Number(match[1]);
      const num = Number(msg);
      if (!Number.isNaN(num) && CRITICAL_FB_ERROR_CODES.includes(num)) return num;
    }
    return null;
  }

  isCriticalCheckpoint(errorCode) {
    if (!errorCode) return false;
    return CRITICAL_FB_ERROR_CODES.includes(errorCode);
  }

  trip(reason, baseCooldownMs = null, now = Date.now()) {
    this.consecutiveTrips++;
    const base = baseCooldownMs ?? this.baseCooldowns.TRANSIENT;
    const cooldown = this.calculateBackoff(base, this.consecutiveTrips);

    this.state = CIRCUIT_BREAKER_STATES.OPEN;
    this.pausedUntil = now + cooldown;
    this.probeInProgress = false;
    this.lastError = typeof reason === 'string' ? { message: reason, timestamp: now } : { ...reason, timestamp: now };
  }

  recordSuccess() {
    if (this.state === CIRCUIT_BREAKER_STATES.HALF_OPEN) {
      // Canary probe succeeded, restore full operational status
      this.state = CIRCUIT_BREAKER_STATES.CLOSED;
      this.consecutiveTrips = 0;
      this.failureCount = 0;
      this.pausedUntil = 0;
      this.probeInProgress = false;
      this.lastError = null;
    } else if (this.state === CIRCUIT_BREAKER_STATES.CLOSED) {
      this.failureCount = 0;
    }
  }

  recordFailure(error, now = Date.now()) {
    const code = this.extractErrorCode(error);
    const errInfo = {
      code,
      message: error?.message || String(error),
      timestamp: now
    };

    if (this.state === CIRCUIT_BREAKER_STATES.HALF_OPEN) {
      // Probe failed: re-open immediately with escalated backoff
      const base = this.resolveBaseCooldown(code);
      this.trip(errInfo, base, now);
      return;
    }

    if (this.isCriticalCheckpoint(code)) {
      // Critical checkpoint: immediate trip
      const base = this.resolveBaseCooldown(code);
      this.trip(errInfo, base, now);
      return;
    }

    // Transient failure handling
    if (now - this.lastFailureTime > this.failureWindowMs) {
      this.failureCount = 1;
    } else {
      this.failureCount++;
    }
    this.lastFailureTime = now;

    if (this.failureCount >= this.failureThreshold) {
      this.trip(errInfo, this.baseCooldowns.TRANSIENT, now);
    }
  }

  resolveBaseCooldown(code) {
    switch (code) {
      case FB_ERROR_CODES.CHECKPOINT_368:
        return this.baseCooldowns.CHECKPOINT_368;
      case FB_ERROR_CODES.TOO_MANY_REQUESTS_429:
        return this.baseCooldowns.HTTP_429;
      case FB_ERROR_CODES.TEMPORARY_BLOCK_1357004:
        return this.baseCooldowns.BLOCK_1357004;
      case FB_ERROR_CODES.ACTION_THROTTLED_1404078:
        return this.baseCooldowns.THROTTLED_1404078;
      default:
        return this.baseCooldowns.TRANSIENT;
    }
  }

  reset() {
    this.state = CIRCUIT_BREAKER_STATES.CLOSED;
    this.failureCount = 0;
    this.consecutiveTrips = 0;
    this.pausedUntil = 0;
    this.probeInProgress = false;
    this.lastError = null;
  }

  toJSON() {
    return {
      state: this.state,
      pausedUntil: this.pausedUntil,
      failureCount: this.failureCount,
      consecutiveTrips: this.consecutiveTrips,
      lastFailureTime: this.lastFailureTime,
      lastError: this.lastError
    };
  }

  static fromJSON(data) {
    return new CircuitBreaker(data);
  }
}
